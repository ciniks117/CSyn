function T6E = getTransform6E()
  % Input: void
  % Output: homogeneous transformation Matrix from the end-effector frame E to frame 6. T_6E
  
  % PLACEHOLDER FOR OUTPUT -> REPLACE WITH SOLUTION
  T6E = eye(4);
end

