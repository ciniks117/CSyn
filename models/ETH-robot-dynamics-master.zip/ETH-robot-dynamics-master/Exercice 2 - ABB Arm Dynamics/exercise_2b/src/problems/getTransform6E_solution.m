function T6E = getTransform6E_solution()
  % Input: void
  % Output: homogeneous transformation Matrix from frame 6 to the end-effector frame E. T_6E
  T6E = eye(4);
end

