# ETH-robot-dynamics
(Sept 2018 - Dec 2018)

Small simulation exercises realized in the Robot Dynamics course given at ETH Zürich by Prof. Marco Hutter.

Exercise 1: Forward, differential, and inverse kinematics of the ABB IRB 120 robotic arm

Exercise 2: Dynamics and model-based control of the ABB IRB 120 robotic arm

Exercise 3: Legged robot control 
