function output = mbHeaviside( input )

    if input >= 0
        output = 1;
    else
        output = 0;
    end
    
end
