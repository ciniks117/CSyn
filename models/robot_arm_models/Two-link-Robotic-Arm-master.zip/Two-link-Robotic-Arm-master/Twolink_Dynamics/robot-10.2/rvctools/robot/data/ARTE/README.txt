This folder contains a very small subset of the robot models shipped with

ARTE: A robotics toolbox for education, by Arturo Gil
http://arvc.umh.es/arte/index_en.html

You can obtain additional models from the full ARTE download, the full list is
available at http://arvc.umh.es/arte/supported_robots.html

Download and unzip ARTE, then move the arte/robots to RTB/robot/data/ARTE.
