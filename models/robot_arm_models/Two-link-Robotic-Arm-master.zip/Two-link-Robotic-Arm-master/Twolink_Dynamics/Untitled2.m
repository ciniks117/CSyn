syms q1 q2 q1d q2d q1dd q2dd Q1 Q2
% tau = twolink.rne([q1 q2],[q1d q2d],[q1dd q2dd])
