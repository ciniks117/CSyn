syms q1 q2
twolink.inertia([q1 q2])