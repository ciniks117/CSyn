syms m1 m2 a1 a2 c1 c2 g
m1= 1; m2=1; a1=0.2; a2=0.15; c1=0.1; c2=0.075;g=9.81;
para = [m1; m2; c1; c2; a1; a2; g]';
