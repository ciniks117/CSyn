% Copyright 2016-2020 The MathWorks, Inc.

youBot_optim_test_friction
youBot_optim_test_noFriction


