function Opts = settings_reachsetMPC_stirredTankReactor_traj1()
% SETTINGS_REACHSETMPC_STIRREDTANKREACTOR_TRAJ1 - algorithm settings for 
%                                                 the stirred tank reactor 
%                                                 benchmark 
%
% Syntax:
%       Opts = SETTINGS_REACHSETMPC_STIRREDTANKREACTOR_TRAJ1()
%
% Description:
%       Algorithm settings and parameter for the Reachset Model Predictive
%       Control algorithm for the stirred tank reactor benchmark
%
% Output Arguments:
%
%       -Opts:              a structure containing following options
%
%           -.tOpt:         final time for the optimization  
%           -.N:            number of time steps
%                           [{10} / positive integer]
%           -.reachSteps:   number of reachability steps during one time 
%                           step [{10} / positive integer]
%           -.U_:           tightened set of admissible control inputs 
%                           (class: interval)
%           -.termReg:      terminal region around the steady state xf
%                           (class: mptPolytope)
%           -.Q:            state weighting matrix for the cost function of
%                           optimal control problem (reference trajectory)
%           -.R:            input weighting matrix for the cost function of
%                           optimal control problem (reference trajectory)
%           -.Qlqr:         state weighting matrix for the cost function of
%                           the LQR approach (tracking controller)
%           -.Rlqr:         input weighting matrix for the cost function of
%                           the LQR approach (tracking controller)
%           -.realTime:     flag specifying if real time computation time 
%                           constraints are considered (Opts.realTime = 1) 
%                           or not (Opts.realTime = 0) [{true} / boolean]
%           -.tComp:        time allocated to perform the computations for 
%                           the optimizations (0 < tComp < tOpt/N).
%           -.alpha:        contraction rate for the contraction constraint
%                           [{0.1} / alpha > 0]
%           -.maxIter:      maximum number of iterations for the optimal
%                           control problem [{10} / positive integer]
%
%           -.cora.alg:                 reachability algorithm that is used
%                                       [{'lin'} / 'poly']
%           -.cora.tensorOrder:         taylor order for the abstraction of
%                                       the nonlinear function [{2}/ 3]
%           -.cora.taylorTerms:         taylor order for computing e^At
%                                       [{10} / positive integer]
%           -.cora.zonotopeOrder:       upper bound for the zonotope order
%                                       [{5} / positive integer]
%           -.cora.errorOrder:          upper bound for the zonotope order
%                                       before comp. the abstraction error
%                                       [{3} / positive integer]
%           -.cora.intermediateOrder:   upper bound for the zonotope order
%                                       during internal computations
%                                       [{3} / positive integer]
%
% See Also:
%       reachsetMPC, stirredTankReactor
%
%------------------------------------------------------------------
% This file is part of <a href="matlab:docsearch aroc">AROC</a>, a Toolbox for Automatic Reachset-
% Optimal Controller Synthesis developed at the Chair of Robotics, 
% Artificial Intelligence and Embedded Systems, 
% Technische Universitaet Muenchen. 
%
% For updates and further information please visit <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
%
% More Toolbox Info by searching <a href="matlab:docsearch aroc">AROC</a> in the Matlab Documentation
%
%------------------------------------------------------------------
% Authors:      Niklas Kochdumper
% Website:      <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
% Work Adress:  Technische Universitaet Muenchen
% Copyright (c) 2019 Chair of Robotics, Artificial Intelligence and
%               Embedded Systems, TU Muenchen
%------------------------------------------------------------------
    
    % tightend input contraints
    Opts.U_ = interval(-18,68);
    
    % number of time steps and optimization horizon
    Opts.N = 11;
    Opts.tOpt = 19.8;
    
    % weighting matrices for the cost function
    Opts.Q = diag([100,1]);             
    Opts.R = 1e-12; 
    
    % tracking controller
    Opts.Qlqr = diag([1;1]);
    Opts.Rlqr = 100;
    
    % terminal region
    A = [-1.0000 0;1.0000 0;30.0000 -1.0000;66.6526 -4.8603;-66.6526 4.8603];
    b = [0.3000;0.0620;11.8400;65.0000;15.0000];
    Opts.termReg = mptPolytope(A,b);
    
    % algorithm parameter
    Opts.tComp = 0.54;
    Opts.alpha = 0.1;
    Opts.maxIter = 12;
    Opts.reachSteps = 1;

end