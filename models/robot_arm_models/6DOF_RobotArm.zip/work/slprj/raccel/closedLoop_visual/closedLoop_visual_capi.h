#include "__cf_closedLoop_visual.h"
#ifndef RTW_HEADER_closedLoop_visual_capi_h
#define RTW_HEADER_closedLoop_visual_capi_h
#include "closedLoop_visual.h"
extern void closedLoop_visual_InitializeDataMapInfo ( void ) ;
#endif
