#include "__cf_closedLoop_visual.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifndef CLOSEDLOOP_VISUAL_2F6391D8_2_DS_DNF_P_H
#define CLOSEDLOOP_VISUAL_2F6391D8_2_DS_DNF_P_H 1
extern int32_T closedLoop_visual_2f6391d8_2_ds_dnf_p ( const NeDynamicSystem
* sys , const NeDynamicSystemInput * in , NeDsMethodOutput * ou ) ;
#endif
#ifdef __cplusplus
}
#endif
