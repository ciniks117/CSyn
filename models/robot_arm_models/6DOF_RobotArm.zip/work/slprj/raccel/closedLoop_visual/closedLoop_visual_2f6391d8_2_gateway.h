#include "__cf_closedLoop_visual.h"
#ifndef __closedLoop_visual_2f6391d8_2_gateway_h__
#define __closedLoop_visual_2f6391d8_2_gateway_h__
#ifdef __cplusplus
extern "C" {
#endif
extern void closedLoop_visual_2f6391d8_2_gateway ( void ) ;
#ifdef __cplusplus
}
#endif
#endif
