#include "__cf_closedLoop_visual.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifndef CLOSEDLOOP_VISUAL_2F6391D8_2_DS_H
#define CLOSEDLOOP_VISUAL_2F6391D8_2_DS_H 1
extern NeDynamicSystem * closedLoop_visual_2f6391d8_2_dae_ds ( PmAllocator *
allocator ) ;
#endif
#ifdef __cplusplus
}
#endif
