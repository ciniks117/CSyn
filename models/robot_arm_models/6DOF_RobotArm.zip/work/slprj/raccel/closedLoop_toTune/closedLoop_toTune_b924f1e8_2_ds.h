#include "__cf_closedLoop_toTune.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifndef CLOSEDLOOP_TOTUNE_B924F1E8_2_DS_H
#define CLOSEDLOOP_TOTUNE_B924F1E8_2_DS_H 1
extern NeDynamicSystem * closedLoop_toTune_b924f1e8_2_dae_ds ( PmAllocator *
allocator ) ;
#endif
#ifdef __cplusplus
}
#endif
