#include "__cf_closedLoop_toTune.h"
#ifndef RTW_HEADER_closedLoop_toTune_capi_h
#define RTW_HEADER_closedLoop_toTune_capi_h
#include "closedLoop_toTune.h"
extern void closedLoop_toTune_InitializeDataMapInfo ( void ) ;
#endif
