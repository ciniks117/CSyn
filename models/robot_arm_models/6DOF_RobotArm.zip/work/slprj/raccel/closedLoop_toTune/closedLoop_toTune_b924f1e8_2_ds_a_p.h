#include "__cf_closedLoop_toTune.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifndef CLOSEDLOOP_TOTUNE_B924F1E8_2_DS_A_P_H
#define CLOSEDLOOP_TOTUNE_B924F1E8_2_DS_A_P_H 1
extern int32_T closedLoop_toTune_b924f1e8_2_ds_a_p ( const NeDynamicSystem *
sys , const NeDynamicSystemInput * in , NeDsMethodOutput * ou ) ;
#endif
#ifdef __cplusplus
}
#endif
