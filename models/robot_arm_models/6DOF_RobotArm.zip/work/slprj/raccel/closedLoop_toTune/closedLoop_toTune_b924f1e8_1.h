#include "__cf_closedLoop_toTune.h"
#ifndef __closedLoop_toTune_b924f1e8_1_h__
#define __closedLoop_toTune_b924f1e8_1_h__
#ifdef __cplusplus
extern "C" {
#endif
extern void closedLoop_toTune_b924f1e8_1_dae ( NeDae * * dae , const
NeModelParameters * modelParams , const NeSolverParameters * solverParams ) ;
#ifdef __cplusplus
}
#endif
#endif
