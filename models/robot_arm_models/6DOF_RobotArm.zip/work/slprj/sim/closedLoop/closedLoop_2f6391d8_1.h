#include "__cf_closedLoop.h"
#ifndef __closedLoop_2f6391d8_1_h__
#define __closedLoop_2f6391d8_1_h__
#ifdef __cplusplus
extern "C" {
#endif
extern void closedLoop_2f6391d8_1_dae ( NeDae * * dae , const
NeModelParameters * modelParams , const NeSolverParameters * solverParams ) ;
#ifdef __cplusplus
}
#endif
#endif
