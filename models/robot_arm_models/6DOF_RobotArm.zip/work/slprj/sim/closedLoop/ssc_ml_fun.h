#include "__cf_closedLoop.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifndef SSC_ML_FUN_H
#define SSC_ML_FUN_H                   1
#endif
#ifdef __cplusplus
} ;
#endif
