#include "__cf_closedLoop.h"
#include "closedLoop_capi.h"
#include "closedLoop.h"
#include "closedLoop_private.h"
#include "sfcn_loader_c_api.h"
int_T etrgs4mokz [ 2 ] ; static RegMdlInfo rtMdlInfo_closedLoop [ 64 ] = { {
"ope1wg3cbz4" , MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * )
"closedLoop" } , { "ope1wg3cbz" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "gkw52lrwgp4" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"lstcgsiwndv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "f0y1f4vpz3e" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "pvccj5rupnx" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"pig3puin4o2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "ozsm5ycwkq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "ppjf2prso32" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"fxe1ho3dgzg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "cy2wstccxew" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "ar4cvowam3t" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"mrno05akddg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "gkw52lrwgp" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "lstcgsiwnd" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"f0y1f4vpz3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "pvccj5rupn" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "pig3puin4o" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"ppjf2prso3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "fxe1ho3dgz" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "cy2wstccxe" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"ar4cvowam3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "mrno05akdd" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "hdo4tqofyg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"cnzzkdsgp5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "i51jvolrrc" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "kja25six4i" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"ci0rchb45g" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "ciavwlvtml" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "o2iluetqck" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"a5w1dgbmqf" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "ddc0t4t15d" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "bmtszmiqmi" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"iqau2xj2y1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "lu22svnl5z" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "kutjjarlzv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"closedLoop" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , {
"omdpq2p1gno" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "hjujyy12ru5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "etrgs4mokz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"l1kpu4wb4rx" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "iqd4nnjnc2n" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "omdpq2p1gn" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"hjujyy12ru" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop" } , { "orlpf30qtl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "closedLoop" } , { "k2snwiamgb" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop" } , {
"jointVelBus" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"jointTorqueBus" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"jointMotionBus" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"mr_closedLoop_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "closedLoop" } , {
"mr_closedLoop_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "closedLoop" } , {
"mr_closedLoop_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "closedLoop" } , {
"mr_closedLoop_restoreDataFromMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "closedLoop" } , {
"mr_closedLoop_cacheDataToMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "closedLoop" } , {
"mr_closedLoop_extractBitFieldFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "closedLoop" } , { "mr_closedLoop_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "closedLoop" } , {
"mr_closedLoop_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1
, ( void * ) "closedLoop" } , { "mr_closedLoop_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "closedLoop" } , {
"mr_closedLoop_RegisterSimStateChecksum" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "closedLoop" } , { "mr_closedLoop_SetDWork" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "closedLoop" } , {
"mr_closedLoop_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"closedLoop" } , { "scblock" , MDL_INFO_ID_SFCN_NAME , 0 , 0 , ( void * )
"S-Function" } , { "closedLoop.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , (
NULL ) } , { "closedLoop.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"closedLoop" } } ; gogtmvqwcmx cy2wstccxe = { 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 0.63
, 0.67 , 0.72 , 0.72 , 0.54 , 0.62 , 183.6 , 41.75 , 704.0 , 704.0 , 966.0 ,
729.75 , 0.092 , 0.04 , 0.03 , 0.03 , 1.75 , 0.07 , 23.83 , 0.0076 , 60.39 ,
0.002 , 85.0 , 0.0045 , 85.0 , 0.0045 , 116.0 , 0.08 , 93.6 , 0.02 , 230.0 ,
735.4 , 243.45 , 243.45 , 190.0 , 740.7 , 0.0 , 0.0 , 50.0 , 50.0 , 0.0 , 0.0
, 0.01 , 0.01 , 0.01 , 0.01 , 0.01 , 0.01 , 0.01 , 0.01 , 0.01 , 0.01 , 0.01
, 0.01 , 57.295779513082323 , 1.0 , 57.295779513082323 , 1.0 ,
57.295779513082323 , 1.0 , 57.295779513082323 , 1.0 , 57.295779513082323 ,
1.0 , 57.295779513082323 , 1.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 2.0 ,
{ 1.0 , 1.0 } , 3.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 2.0 } , { - 100.0 , 100.0
} , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 5000.0 , { 1.0 , 1.0 } , 1.0 , {
1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 0.0 , { 1.0 , 1.0 }
, 1.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 0.0 , { 1.0 , 1.0 } , 0.0 , {
1.0 , 8.0 } , { 100.0 , 97.0 , 116.0 , 97.0 , 46.0 , 100.0 , 97.0 , 116.0 } ,
{ 1.0 , 4.0 } , { 108.0 , 97.0 , 122.0 , 121.0 } , { 1.0 , 1.0 } , 512.0 , {
1.0 , 1.0 } , 0.0 , { 1.0 , 6.0 } , { 37.0 , 49.0 , 53.0 , 46.0 , 54.0 ,
102.0 } , { 1.0 , 1.0 } , 0.0 , { 1.0 , 1.0 } , 5.36870912E+8 , { 1.0 , 1.0 }
, 0.0 , { 1.0 , 1.0 } , 2.0 , { 1.0 , 1.0 } , 2.0 , { 1.0 , 1.0 } , 3.0 , {
1.0 , 1.0 } , 1.0 , { 1.0 , 2.0 } , { - 45.0 , 45.0 } , { 1.0 , 1.0 } , 1.0 ,
{ 1.0 , 1.0 } , 5000.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 ,
1.0 } , 1.0 , { 1.0 , 1.0 } , 0.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 1.0
, { 1.0 , 1.0 } , 0.0 , { 1.0 , 1.0 } , 0.0 , { 1.0 , 8.0 } , { 100.0 , 97.0
, 116.0 , 97.0 , 46.0 , 100.0 , 97.0 , 116.0 } , { 1.0 , 4.0 } , { 108.0 ,
97.0 , 122.0 , 121.0 } , { 1.0 , 1.0 } , 512.0 , { 1.0 , 1.0 } , 0.0 , { 1.0
, 6.0 } , { 37.0 , 49.0 , 53.0 , 46.0 , 54.0 , 102.0 } , { 1.0 , 1.0 } , 0.0
, { 1.0 , 1.0 } , 5.36870912E+8 , { 1.0 , 1.0 } , 0.0 , { 1.0 , 1.0 } , 3.0 ,
{ 1.0 , 1.0 } , 2.0 , { 1.0 , 1.0 } , 3.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 2.0
} , { - 100.0 , 5.0 } , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 5000.0 , { 1.0
, 1.0 } , 1.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } ,
0.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 0.0 , { 1.0
, 1.0 } , 0.0 , { 1.0 , 8.0 } , { 100.0 , 97.0 , 116.0 , 97.0 , 46.0 , 100.0
, 97.0 , 116.0 } , { 1.0 , 4.0 } , { 108.0 , 97.0 , 122.0 , 121.0 } , { 1.0 ,
1.0 } , 512.0 , { 1.0 , 1.0 } , 0.0 , { 1.0 , 6.0 } , { 37.0 , 49.0 , 53.0 ,
46.0 , 54.0 , 102.0 } , { 1.0 , 1.0 } , 0.0 , { 1.0 , 1.0 } , 5.36870912E+8 ,
{ 1.0 , 1.0 } , 0.0 , { 1.0 , 1.0 } , 4.0 , { 1.0 , 1.0 } , 2.0 , { 1.0 , 1.0
} , 3.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 2.0 } , { - 50.0 , 50.0 } , { 1.0 ,
1.0 } , 1.0 , { 1.0 , 1.0 } , 5000.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } ,
1.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 0.0 , { 1.0 , 1.0 } , 1.0 , { 1.0
, 1.0 } , 1.0 , { 1.0 , 1.0 } , 0.0 , { 1.0 , 1.0 } , 0.0 , { 1.0 , 8.0 } , {
100.0 , 97.0 , 116.0 , 97.0 , 46.0 , 100.0 , 97.0 , 116.0 } , { 1.0 , 4.0 } ,
{ 108.0 , 97.0 , 122.0 , 121.0 } , { 1.0 , 1.0 } , 512.0 , { 1.0 , 1.0 } ,
0.0 , { 1.0 , 6.0 } , { 37.0 , 49.0 , 53.0 , 46.0 , 54.0 , 102.0 } , { 1.0 ,
1.0 } , 0.0 , { 1.0 , 1.0 } , 5.36870912E+8 , { 1.0 , 1.0 } , 0.0 , { 1.0 ,
1.0 } , 5.0 , { 1.0 , 1.0 } , 2.0 , { 1.0 , 1.0 } , 3.0 , { 1.0 , 1.0 } , 1.0
, { 1.0 , 2.0 } , { 120.0 , 160.0 } , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } ,
5000.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 1.0 , {
1.0 , 1.0 } , 0.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 }
, 0.0 , { 1.0 , 1.0 } , 0.0 , { 1.0 , 8.0 } , { 100.0 , 97.0 , 116.0 , 97.0 ,
46.0 , 100.0 , 97.0 , 116.0 } , { 1.0 , 4.0 } , { 108.0 , 97.0 , 122.0 ,
121.0 } , { 1.0 , 1.0 } , 512.0 , { 1.0 , 1.0 } , 0.0 , { 1.0 , 6.0 } , {
37.0 , 49.0 , 53.0 , 46.0 , 54.0 , 102.0 } , { 1.0 , 1.0 } , 0.0 , { 1.0 ,
1.0 } , 5.36870912E+8 , { 1.0 , 1.0 } , 0.0 , { 1.0 , 1.0 } , 6.0 , { 1.0 ,
1.0 } , 2.0 , { 1.0 , 1.0 } , 3.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 2.0 } , { -
160.0 , - 120.0 } , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 5000.0 , { 1.0 ,
1.0 } , 1.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 0.0
, { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 1.0 , { 1.0 , 1.0 } , 0.0 , { 1.0 ,
1.0 } , 0.0 , { 1.0 , 8.0 } , { 100.0 , 97.0 , 116.0 , 97.0 , 46.0 , 100.0 ,
97.0 , 116.0 } , { 1.0 , 4.0 } , { 108.0 , 97.0 , 122.0 , 121.0 } , { 1.0 ,
1.0 } , 512.0 , { 1.0 , 1.0 } , 0.0 , { 1.0 , 6.0 } , { 37.0 , 49.0 , 53.0 ,
46.0 , 54.0 , 102.0 } , { 1.0 , 1.0 } , 0.0 , { 1.0 , 1.0 } , 5.36870912E+8 ,
{ 1.0 , 1.0 } , 0.0 , 57.295779513082323 , 57.295779513082323 ,
57.295779513082323 , 57.295779513082323 , 57.295779513082323 ,
57.295779513082323 , 0.0 , 0.0 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0025 ,
0.0025 , 0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0025 , 0.0025 , 0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0025 , 0.0025 , 0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0025 , 0.0025 , 0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0025 , 0.0025 , 0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0025 , 0.0025 , 0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.16666666666666666 , 0.0025 , 9.5492965855137211 , 9.5492965855137211 , 6.0
, 6.0 , 9.5492965855137211 , 6.0 , 9.5492965855137211 , 6.0 ,
9.5492965855137211 , 6.0 , 9.5492965855137211 , 6.0 } ; ope1wg3cbz4
ope1wg3cbz ; mrno05akddg iqd4nnjnc2n ; ar4cvowam3t l1kpu4wb4rx ; void
bmtszmiqmi ( void ) { k2snwiamgb * const nehesmkint = & ( ope1wg3cbz . rtm )
; boolean_T tmp ; int_T tmp_p ; char * tmp_e ; tmp = true ; if ( tmp ) {
tmp_p = strcmp ( "ode14x" , ssGetSolverName ( nehesmkint -> _mdlRefSfcnS ) )
; if ( tmp_p != 0 ) { tmp_e = solver_mismatch_message ( "ode14x" ,
ssGetSolverName ( nehesmkint -> _mdlRefSfcnS ) ) ; ssSetErrorStatus (
nehesmkint -> _mdlRefSfcnS , tmp_e ) ; } } l1kpu4wb4rx . bepyqlw5qu = 1U ;
l1kpu4wb4rx . dyn5irgyjj = 0 ; l1kpu4wb4rx . ccquv3ehj4 = cy2wstccxe . P_6 ;
l1kpu4wb4rx . pbidohzefw = cy2wstccxe . P_0 ; l1kpu4wb4rx . hritc1babc = 1U ;
l1kpu4wb4rx . kayrm3qjer = 0 ; l1kpu4wb4rx . ndcz2pevdt = cy2wstccxe . P_7 ;
l1kpu4wb4rx . jpgsqiqfhq = 1U ; l1kpu4wb4rx . h2jjjrmgpx = 0 ; l1kpu4wb4rx .
ipoqi0vxan = cy2wstccxe . P_8 ; l1kpu4wb4rx . h5eac0mibo = cy2wstccxe . P_1 ;
l1kpu4wb4rx . n1umrqm4ou = 1U ; l1kpu4wb4rx . n1r0ywaznf = 0 ; l1kpu4wb4rx .
ckwjuadpca = cy2wstccxe . P_9 ; l1kpu4wb4rx . akgp3l4qdu = 1U ; l1kpu4wb4rx .
alglf53p5h = 0 ; l1kpu4wb4rx . kjml2jdhog = cy2wstccxe . P_10 ; l1kpu4wb4rx .
onzlg3sfc1 = cy2wstccxe . P_2 ; l1kpu4wb4rx . nw11erxd40 = 1U ; l1kpu4wb4rx .
mmmkxfaf4h = 0 ; l1kpu4wb4rx . aqmkm5qp10 = cy2wstccxe . P_11 ; l1kpu4wb4rx .
dceylbyzbv = 1U ; l1kpu4wb4rx . bmhe2rp2ug = 0 ; l1kpu4wb4rx . daodt1zxg3 =
cy2wstccxe . P_12 ; l1kpu4wb4rx . k2jw35opgq = cy2wstccxe . P_3 ; l1kpu4wb4rx
. epxooln5rc = 1U ; l1kpu4wb4rx . g5es2g4qos = 0 ; l1kpu4wb4rx . limd3gdwcq =
cy2wstccxe . P_13 ; l1kpu4wb4rx . bbvyyfxxc2 = 1U ; l1kpu4wb4rx . flp2r32tjj
= 0 ; l1kpu4wb4rx . lgzj3kmwmk = cy2wstccxe . P_14 ; l1kpu4wb4rx . o32wlonvfn
= cy2wstccxe . P_4 ; l1kpu4wb4rx . etz51dx5fm = 1U ; l1kpu4wb4rx . gyifh2fi2t
= 0 ; l1kpu4wb4rx . cwuv444nvd = cy2wstccxe . P_15 ; l1kpu4wb4rx . axinhpqqcc
= 1U ; l1kpu4wb4rx . cct53vt3uw = 0 ; l1kpu4wb4rx . arjxbzyxfd = cy2wstccxe .
P_16 ; l1kpu4wb4rx . iep3kan2rd = cy2wstccxe . P_5 ; l1kpu4wb4rx . h1d4piegmo
= 1U ; l1kpu4wb4rx . ithaa4tvwx = 0 ; l1kpu4wb4rx . ajirvaztbv = cy2wstccxe .
P_17 ; tmp = true ; if ( tmp ) { tmp_p = strcmp ( "ode14x" , ssGetSolverName
( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp_p != 0 ) { tmp_e =
solver_mismatch_message ( "ode14x" , ssGetSolverName ( nehesmkint ->
_mdlRefSfcnS ) ) ; ssSetErrorStatus ( nehesmkint -> _mdlRefSfcnS , tmp_e ) ;
} } } void ddc0t4t15d ( void ) { k2snwiamgb * const nehesmkint = & (
ope1wg3cbz . rtm ) ; boolean_T tmp ; int_T tmp_p ; char * tmp_e ; tmp = true
; if ( tmp ) { tmp_p = strcmp ( "ode14x" , ssGetSolverName ( nehesmkint ->
_mdlRefSfcnS ) ) ; if ( tmp_p != 0 ) { tmp_e = solver_mismatch_message (
"ode14x" , ssGetSolverName ( nehesmkint -> _mdlRefSfcnS ) ) ;
ssSetErrorStatus ( nehesmkint -> _mdlRefSfcnS , tmp_e ) ; } } l1kpu4wb4rx .
bepyqlw5qu = 1U ; l1kpu4wb4rx . dyn5irgyjj = 0 ; l1kpu4wb4rx . ccquv3ehj4 =
cy2wstccxe . P_6 ; l1kpu4wb4rx . pbidohzefw = cy2wstccxe . P_0 ; l1kpu4wb4rx
. hritc1babc = 1U ; l1kpu4wb4rx . kayrm3qjer = 0 ; l1kpu4wb4rx . ndcz2pevdt =
cy2wstccxe . P_7 ; l1kpu4wb4rx . jpgsqiqfhq = 1U ; l1kpu4wb4rx . h2jjjrmgpx =
0 ; l1kpu4wb4rx . ipoqi0vxan = cy2wstccxe . P_8 ; l1kpu4wb4rx . h5eac0mibo =
cy2wstccxe . P_1 ; l1kpu4wb4rx . n1umrqm4ou = 1U ; l1kpu4wb4rx . n1r0ywaznf =
0 ; l1kpu4wb4rx . ckwjuadpca = cy2wstccxe . P_9 ; l1kpu4wb4rx . akgp3l4qdu =
1U ; l1kpu4wb4rx . alglf53p5h = 0 ; l1kpu4wb4rx . kjml2jdhog = cy2wstccxe .
P_10 ; l1kpu4wb4rx . onzlg3sfc1 = cy2wstccxe . P_2 ; l1kpu4wb4rx . nw11erxd40
= 1U ; l1kpu4wb4rx . mmmkxfaf4h = 0 ; l1kpu4wb4rx . aqmkm5qp10 = cy2wstccxe .
P_11 ; l1kpu4wb4rx . dceylbyzbv = 1U ; l1kpu4wb4rx . bmhe2rp2ug = 0 ;
l1kpu4wb4rx . daodt1zxg3 = cy2wstccxe . P_12 ; l1kpu4wb4rx . k2jw35opgq =
cy2wstccxe . P_3 ; l1kpu4wb4rx . epxooln5rc = 1U ; l1kpu4wb4rx . g5es2g4qos =
0 ; l1kpu4wb4rx . limd3gdwcq = cy2wstccxe . P_13 ; l1kpu4wb4rx . bbvyyfxxc2 =
1U ; l1kpu4wb4rx . flp2r32tjj = 0 ; l1kpu4wb4rx . lgzj3kmwmk = cy2wstccxe .
P_14 ; l1kpu4wb4rx . o32wlonvfn = cy2wstccxe . P_4 ; l1kpu4wb4rx . etz51dx5fm
= 1U ; l1kpu4wb4rx . gyifh2fi2t = 0 ; l1kpu4wb4rx . cwuv444nvd = cy2wstccxe .
P_15 ; l1kpu4wb4rx . axinhpqqcc = 1U ; l1kpu4wb4rx . cct53vt3uw = 0 ;
l1kpu4wb4rx . arjxbzyxfd = cy2wstccxe . P_16 ; l1kpu4wb4rx . iep3kan2rd =
cy2wstccxe . P_5 ; l1kpu4wb4rx . h1d4piegmo = 1U ; l1kpu4wb4rx . ithaa4tvwx =
0 ; l1kpu4wb4rx . ajirvaztbv = cy2wstccxe . P_17 ; tmp = true ; if ( tmp ) {
tmp_p = strcmp ( "ode14x" , ssGetSolverName ( nehesmkint -> _mdlRefSfcnS ) )
; if ( tmp_p != 0 ) { tmp_e = solver_mismatch_message ( "ode14x" ,
ssGetSolverName ( nehesmkint -> _mdlRefSfcnS ) ) ; ssSetErrorStatus (
nehesmkint -> _mdlRefSfcnS , tmp_e ) ; } } } void lu22svnl5z ( real_T *
localX_ ) { k2snwiamgb * const nehesmkint = & ( ope1wg3cbz . rtm ) ;
pig3puin4o2 * localX = ( pig3puin4o2 * ) localX_ ; boolean_T tmp ;
NeuDiagnosticManager * diagnosticManager ; NeModelParameters modelParameters
; real_T tmp_p ; NeslSimulator * simulator ; NeuDiagnosticTree *
diagnosticTree ; char * msg ; int_T parameterBundle_mLogicalParameters_mN ;
NeslSimulationData * simulationData ; real_T time ; NeModelParameters
modelParameters_p ; real_T time_p ; NeModelParameters modelParameters_e ;
real_T time_e ; NeModelParameters modelParameters_i ; real_T time_i ;
NeParameterBundle expl_temp ; NeParameterBundle expl_temp_p ; simulator =
nesl_lease_simulator ( "closedLoop/Plant/Robot/Solver Configuration_1" , 0 ,
0 ) ; l1kpu4wb4rx . es1n0xuy5w = ( void * ) simulator ; tmp = pointer_is_null
( l1kpu4wb4rx . es1n0xuy5w ) ; if ( tmp ) { closedLoop_2f6391d8_1_gateway ( )
; simulator = nesl_lease_simulator (
"closedLoop/Plant/Robot/Solver Configuration_1" , 0 , 0 ) ; l1kpu4wb4rx .
es1n0xuy5w = ( void * ) simulator ; } simulationData =
nesl_create_simulation_data ( ) ; l1kpu4wb4rx . mtmd51jfqa = ( void * )
simulationData ; diagnosticManager = rtw_create_diagnostics ( ) ; l1kpu4wb4rx
. pryqdadyrt = ( void * ) diagnosticManager ; modelParameters . mSolverType =
NE_SOLVER_TYPE_DAE ; modelParameters . mSolverTolerance = 0.001 ;
modelParameters . mVariableStepSolver = false ; modelParameters .
mFixedStepSize = 0.0025 ; modelParameters . mStartTime = 0.0 ;
modelParameters . mLoadInitialState = false ; modelParameters . mUseSimState
= false ; modelParameters . mLinTrimCompile = false ; modelParameters .
mLoggingMode = SSC_LOGGING_NONE ; modelParameters . mRTWModifiedTimeStamp =
4.76756437E+8 ; tmp_p = 0.001 ; modelParameters . mSolverTolerance = tmp_p ;
tmp_p = 0.0025 ; modelParameters . mFixedStepSize = tmp_p ; tmp = false ;
modelParameters . mVariableStepSolver = tmp ; simulator = ( NeslSimulator * )
l1kpu4wb4rx . es1n0xuy5w ; diagnosticManager = ( NeuDiagnosticManager * )
l1kpu4wb4rx . pryqdadyrt ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ;
parameterBundle_mLogicalParameters_mN = nesl_initialize_simulator ( simulator
, & modelParameters , diagnosticManager ) ; if (
parameterBundle_mLogicalParameters_mN != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } simulator = ( NeslSimulator * ) l1kpu4wb4rx .
es1n0xuy5w ; expl_temp . mRealParameters . mN = 0 ; expl_temp .
mRealParameters . mX = NULL ; expl_temp . mLogicalParameters . mN = 0 ;
expl_temp . mLogicalParameters . mX = NULL ; expl_temp . mIntegerParameters .
mN = 0 ; expl_temp . mIntegerParameters . mX = NULL ; expl_temp .
mIndexParameters . mN = 0 ; expl_temp . mIndexParameters . mX = NULL ;
nesl_simulator_set_rtps ( simulator , expl_temp ) ; simulationData = (
NeslSimulationData * ) l1kpu4wb4rx . mtmd51jfqa ; time = rtmGetTaskTime (
nehesmkint , 0 ) ; simulationData -> mData -> mTime . mN = 1 ; simulationData
-> mData -> mTime . mX = & time ; simulationData -> mData -> mContStates . mN
= 24 ; simulationData -> mData -> mContStates . mX = & localX -> kvq2o0kyuy [
0 ] ; simulationData -> mData -> mDiscStates . mN = 0 ; simulationData ->
mData -> mDiscStates . mX = & l1kpu4wb4rx . i3bqhqdooa ; simulationData ->
mData -> mModeVector . mN = 0 ; simulationData -> mData -> mModeVector . mX =
& l1kpu4wb4rx . psdfuxjdsv ; tmp = false ; simulationData -> mData ->
mFoundZcEvents = tmp ; simulationData -> mData -> mIsMajorTimeStep =
rtmIsMajorTimeStep ( nehesmkint ) ; tmp = _ssGetSolverAssertCheck (
nehesmkint -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsSolverAssertCheck = tmp ; simulationData -> mData -> mIsSolverCheckingCIC
= false ; tmp = ssIsSolverComputingJacobian ( nehesmkint -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsComputingJacobian = tmp ; simulationData ->
mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian ( nehesmkint ->
_mdlRefSfcnS ) != 0 ) ; simulationData -> mData -> mIsSolverRequestingReset =
false ; simulator = ( NeslSimulator * ) l1kpu4wb4rx . es1n0xuy5w ;
diagnosticManager = ( NeuDiagnosticManager * ) l1kpu4wb4rx . pryqdadyrt ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; parameterBundle_mLogicalParameters_mN = ne_simulator_method ( simulator ,
NESL_SIM_INITIALIZEONCE , simulationData , diagnosticManager ) ; if (
parameterBundle_mLogicalParameters_mN != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } simulator = nesl_lease_simulator (
"closedLoop/Plant/Robot/Solver Configuration_1" , 1 , 0 ) ; l1kpu4wb4rx .
lbpm3d2oh5 = ( void * ) simulator ; tmp = pointer_is_null ( l1kpu4wb4rx .
lbpm3d2oh5 ) ; if ( tmp ) { closedLoop_2f6391d8_1_gateway ( ) ; simulator =
nesl_lease_simulator ( "closedLoop/Plant/Robot/Solver Configuration_1" , 1 ,
0 ) ; l1kpu4wb4rx . lbpm3d2oh5 = ( void * ) simulator ; } simulationData =
nesl_create_simulation_data ( ) ; l1kpu4wb4rx . kiq53exfqv = ( void * )
simulationData ; diagnosticManager = rtw_create_diagnostics ( ) ; l1kpu4wb4rx
. hnzbntkygs = ( void * ) diagnosticManager ; modelParameters_p . mSolverType
= NE_SOLVER_TYPE_DAE ; modelParameters_p . mSolverTolerance = 0.001 ;
modelParameters_p . mVariableStepSolver = false ; modelParameters_p .
mFixedStepSize = 0.0025 ; modelParameters_p . mStartTime = 0.0 ;
modelParameters_p . mLoadInitialState = false ; modelParameters_p .
mUseSimState = false ; modelParameters_p . mLinTrimCompile = false ;
modelParameters_p . mLoggingMode = SSC_LOGGING_NONE ; modelParameters_p .
mRTWModifiedTimeStamp = 4.76756437E+8 ; tmp_p = 0.001 ; modelParameters_p .
mSolverTolerance = tmp_p ; tmp_p = 0.0025 ; modelParameters_p .
mFixedStepSize = tmp_p ; tmp = false ; modelParameters_p .
mVariableStepSolver = tmp ; simulator = ( NeslSimulator * ) l1kpu4wb4rx .
lbpm3d2oh5 ; diagnosticManager = ( NeuDiagnosticManager * ) l1kpu4wb4rx .
hnzbntkygs ; diagnosticTree = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; parameterBundle_mLogicalParameters_mN =
nesl_initialize_simulator ( simulator , & modelParameters_p ,
diagnosticManager ) ; if ( parameterBundle_mLogicalParameters_mN != 0 ) { tmp
= error_buffer_is_empty ( ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ;
if ( tmp ) { msg = rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus
( nehesmkint -> _mdlRefSfcnS , msg ) ; } } simulationData = (
NeslSimulationData * ) l1kpu4wb4rx . kiq53exfqv ; time_p = rtmGetTaskTime (
nehesmkint , 0 ) ; simulationData -> mData -> mTime . mN = 1 ; simulationData
-> mData -> mTime . mX = & time_p ; simulationData -> mData -> mContStates .
mN = 0 ; simulationData -> mData -> mContStates . mX = NULL ; simulationData
-> mData -> mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates .
mX = & l1kpu4wb4rx . no0lkkst0o ; simulationData -> mData -> mModeVector . mN
= 0 ; simulationData -> mData -> mModeVector . mX = & l1kpu4wb4rx .
kzyw5zlnoa ; tmp = false ; simulationData -> mData -> mFoundZcEvents = tmp ;
simulationData -> mData -> mIsMajorTimeStep = rtmIsMajorTimeStep ( nehesmkint
) ; tmp = _ssGetSolverAssertCheck ( nehesmkint -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsSolverAssertCheck = tmp ; simulationData ->
mData -> mIsSolverCheckingCIC = false ; simulationData -> mData ->
mIsComputingJacobian = false ; simulationData -> mData -> mIsEvaluatingF0 =
false ; simulationData -> mData -> mIsSolverRequestingReset = false ;
simulator = ( NeslSimulator * ) l1kpu4wb4rx . lbpm3d2oh5 ; diagnosticManager
= ( NeuDiagnosticManager * ) l1kpu4wb4rx . hnzbntkygs ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ;
parameterBundle_mLogicalParameters_mN = ne_simulator_method ( simulator ,
NESL_SIM_INITIALIZEONCE , simulationData , diagnosticManager ) ; if (
parameterBundle_mLogicalParameters_mN != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } iqd4nnjnc2n . dvdfpqupvw [ 0 ] = 0.0025 ;
iqd4nnjnc2n . dvdfpqupvw [ 1 ] = 0.0 ; iqd4nnjnc2n . gvxqq2drkr [ 0 ] =
0.0025 ; iqd4nnjnc2n . gvxqq2drkr [ 1 ] = 0.0 ; iqd4nnjnc2n . ecllldohtk [ 0
] = 0.0025 ; iqd4nnjnc2n . ecllldohtk [ 1 ] = 0.0 ; iqd4nnjnc2n . lglx1tyi3w
[ 0 ] = 0.0025 ; iqd4nnjnc2n . lglx1tyi3w [ 1 ] = 0.0 ; iqd4nnjnc2n .
ni2moweccg [ 0 ] = 0.0025 ; iqd4nnjnc2n . ni2moweccg [ 1 ] = 0.0 ;
iqd4nnjnc2n . gimccxcbis [ 0 ] = 0.0025 ; iqd4nnjnc2n . gimccxcbis [ 1 ] =
0.0 ; iqd4nnjnc2n . laxrqi2iig [ 0 ] = 0.0025 ; iqd4nnjnc2n . laxrqi2iig [ 1
] = 0.0 ; iqd4nnjnc2n . dfa1yu3sfp [ 0 ] = 0.0025 ; iqd4nnjnc2n . dfa1yu3sfp
[ 1 ] = 0.0 ; iqd4nnjnc2n . bbvyttcgmj [ 0 ] = 0.0025 ; iqd4nnjnc2n .
bbvyttcgmj [ 1 ] = 0.0 ; iqd4nnjnc2n . nd2k2c1rii [ 0 ] = 0.0025 ;
iqd4nnjnc2n . nd2k2c1rii [ 1 ] = 0.0 ; iqd4nnjnc2n . huiknpmeom [ 0 ] =
0.0025 ; iqd4nnjnc2n . huiknpmeom [ 1 ] = 0.0 ; iqd4nnjnc2n . mj5b4ytj5n [ 0
] = 0.0025 ; iqd4nnjnc2n . mj5b4ytj5n [ 1 ] = 0.0 ; simulator =
nesl_lease_simulator ( "closedLoop/Plant/Robot/Solver Configuration_2" , 0 ,
0 ) ; l1kpu4wb4rx . gajog0hbzz = ( void * ) simulator ; tmp = pointer_is_null
( l1kpu4wb4rx . gajog0hbzz ) ; if ( tmp ) { closedLoop_2f6391d8_2_gateway ( )
; simulator = nesl_lease_simulator (
"closedLoop/Plant/Robot/Solver Configuration_2" , 0 , 0 ) ; l1kpu4wb4rx .
gajog0hbzz = ( void * ) simulator ; } simulationData =
nesl_create_simulation_data ( ) ; l1kpu4wb4rx . bilgsbrgvi = ( void * )
simulationData ; diagnosticManager = rtw_create_diagnostics ( ) ; l1kpu4wb4rx
. hczaoupcph = ( void * ) diagnosticManager ; modelParameters_e . mSolverType
= NE_SOLVER_TYPE_DAE ; modelParameters_e . mSolverTolerance = 0.001 ;
modelParameters_e . mVariableStepSolver = false ; modelParameters_e .
mFixedStepSize = 0.0025 ; modelParameters_e . mStartTime = 0.0 ;
modelParameters_e . mLoadInitialState = false ; modelParameters_e .
mUseSimState = false ; modelParameters_e . mLinTrimCompile = false ;
modelParameters_e . mLoggingMode = SSC_LOGGING_NONE ; modelParameters_e .
mRTWModifiedTimeStamp = 4.76756437E+8 ; tmp_p = 0.001 ; modelParameters_e .
mSolverTolerance = tmp_p ; tmp_p = 0.0025 ; modelParameters_e .
mFixedStepSize = tmp_p ; tmp = false ; modelParameters_e .
mVariableStepSolver = tmp ; simulator = ( NeslSimulator * ) l1kpu4wb4rx .
gajog0hbzz ; diagnosticManager = ( NeuDiagnosticManager * ) l1kpu4wb4rx .
hczaoupcph ; diagnosticTree = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; parameterBundle_mLogicalParameters_mN =
nesl_initialize_simulator ( simulator , & modelParameters_e ,
diagnosticManager ) ; if ( parameterBundle_mLogicalParameters_mN != 0 ) { tmp
= error_buffer_is_empty ( ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ;
if ( tmp ) { msg = rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus
( nehesmkint -> _mdlRefSfcnS , msg ) ; } } simulator = ( NeslSimulator * )
l1kpu4wb4rx . gajog0hbzz ; expl_temp_p . mRealParameters . mN = 0 ;
expl_temp_p . mRealParameters . mX = NULL ; expl_temp_p . mLogicalParameters
. mN = 0 ; expl_temp_p . mLogicalParameters . mX = NULL ; expl_temp_p .
mIntegerParameters . mN = 0 ; expl_temp_p . mIntegerParameters . mX = NULL ;
expl_temp_p . mIndexParameters . mN = 0 ; expl_temp_p . mIndexParameters . mX
= NULL ; nesl_simulator_set_rtps ( simulator , expl_temp_p ) ; simulationData
= ( NeslSimulationData * ) l1kpu4wb4rx . bilgsbrgvi ; time_e = rtmGetTaskTime
( nehesmkint , 0 ) ; simulationData -> mData -> mTime . mN = 1 ;
simulationData -> mData -> mTime . mX = & time_e ; simulationData -> mData ->
mContStates . mN = 30 ; simulationData -> mData -> mContStates . mX = &
localX -> lrmmgwl4ze [ 0 ] ; simulationData -> mData -> mDiscStates . mN = 0
; simulationData -> mData -> mDiscStates . mX = & l1kpu4wb4rx . ebgm2o4pem ;
simulationData -> mData -> mModeVector . mN = 6 ; simulationData -> mData ->
mModeVector . mX = & l1kpu4wb4rx . dvaxfxyujx [ 0 ] ; tmp = false ;
simulationData -> mData -> mFoundZcEvents = tmp ; simulationData -> mData ->
mIsMajorTimeStep = rtmIsMajorTimeStep ( nehesmkint ) ; tmp =
_ssGetSolverAssertCheck ( nehesmkint -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; tmp = ssIsSolverComputingJacobian ( nehesmkint
-> _mdlRefSfcnS ) ; simulationData -> mData -> mIsComputingJacobian = tmp ;
simulationData -> mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian (
nehesmkint -> _mdlRefSfcnS ) != 0 ) ; simulationData -> mData ->
mIsSolverRequestingReset = false ; simulator = ( NeslSimulator * )
l1kpu4wb4rx . gajog0hbzz ; diagnosticManager = ( NeuDiagnosticManager * )
l1kpu4wb4rx . hczaoupcph ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ;
parameterBundle_mLogicalParameters_mN = ne_simulator_method ( simulator ,
NESL_SIM_INITIALIZEONCE , simulationData , diagnosticManager ) ; if (
parameterBundle_mLogicalParameters_mN != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } simulator = nesl_lease_simulator (
"closedLoop/Plant/Robot/Solver Configuration_2" , 1 , 0 ) ; l1kpu4wb4rx .
ew4t3cugld = ( void * ) simulator ; tmp = pointer_is_null ( l1kpu4wb4rx .
ew4t3cugld ) ; if ( tmp ) { closedLoop_2f6391d8_2_gateway ( ) ; simulator =
nesl_lease_simulator ( "closedLoop/Plant/Robot/Solver Configuration_2" , 1 ,
0 ) ; l1kpu4wb4rx . ew4t3cugld = ( void * ) simulator ; } simulationData =
nesl_create_simulation_data ( ) ; l1kpu4wb4rx . nia05kgprc = ( void * )
simulationData ; diagnosticManager = rtw_create_diagnostics ( ) ; l1kpu4wb4rx
. mihmamakpr = ( void * ) diagnosticManager ; modelParameters_i . mSolverType
= NE_SOLVER_TYPE_DAE ; modelParameters_i . mSolverTolerance = 0.001 ;
modelParameters_i . mVariableStepSolver = false ; modelParameters_i .
mFixedStepSize = 0.0025 ; modelParameters_i . mStartTime = 0.0 ;
modelParameters_i . mLoadInitialState = false ; modelParameters_i .
mUseSimState = false ; modelParameters_i . mLinTrimCompile = false ;
modelParameters_i . mLoggingMode = SSC_LOGGING_NONE ; modelParameters_i .
mRTWModifiedTimeStamp = 4.76756437E+8 ; tmp_p = 0.001 ; modelParameters_i .
mSolverTolerance = tmp_p ; tmp_p = 0.0025 ; modelParameters_i .
mFixedStepSize = tmp_p ; tmp = false ; modelParameters_i .
mVariableStepSolver = tmp ; simulator = ( NeslSimulator * ) l1kpu4wb4rx .
ew4t3cugld ; diagnosticManager = ( NeuDiagnosticManager * ) l1kpu4wb4rx .
mihmamakpr ; diagnosticTree = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; parameterBundle_mLogicalParameters_mN =
nesl_initialize_simulator ( simulator , & modelParameters_i ,
diagnosticManager ) ; if ( parameterBundle_mLogicalParameters_mN != 0 ) { tmp
= error_buffer_is_empty ( ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ;
if ( tmp ) { msg = rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus
( nehesmkint -> _mdlRefSfcnS , msg ) ; } } simulationData = (
NeslSimulationData * ) l1kpu4wb4rx . nia05kgprc ; time_i = rtmGetTaskTime (
nehesmkint , 0 ) ; simulationData -> mData -> mTime . mN = 1 ; simulationData
-> mData -> mTime . mX = & time_i ; simulationData -> mData -> mContStates .
mN = 0 ; simulationData -> mData -> mContStates . mX = NULL ; simulationData
-> mData -> mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates .
mX = & l1kpu4wb4rx . bztbsebwen ; simulationData -> mData -> mModeVector . mN
= 0 ; simulationData -> mData -> mModeVector . mX = & l1kpu4wb4rx .
krzcukqncn ; tmp = false ; simulationData -> mData -> mFoundZcEvents = tmp ;
simulationData -> mData -> mIsMajorTimeStep = rtmIsMajorTimeStep ( nehesmkint
) ; tmp = _ssGetSolverAssertCheck ( nehesmkint -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsSolverAssertCheck = tmp ; simulationData ->
mData -> mIsSolverCheckingCIC = false ; simulationData -> mData ->
mIsComputingJacobian = false ; simulationData -> mData -> mIsEvaluatingF0 =
false ; simulationData -> mData -> mIsSolverRequestingReset = false ;
simulator = ( NeslSimulator * ) l1kpu4wb4rx . ew4t3cugld ; diagnosticManager
= ( NeuDiagnosticManager * ) l1kpu4wb4rx . mihmamakpr ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ;
parameterBundle_mLogicalParameters_mN = ne_simulator_method ( simulator ,
NESL_SIM_INITIALIZEONCE , simulationData , diagnosticManager ) ; if (
parameterBundle_mLogicalParameters_mN != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } } void closedLoop ( const real_T * plr0vvmgxv ,
const real_T * aa5mtdip3u , const real_T * juh3rnjpfo , const real_T *
kmigltnqf0 , const real_T * ep31hvib5x , const real_T * ialgy4wl0y , real_T *
pboqsovn2d , real_T * lxemy5vpal , real_T * d3in4i2zmt , real_T * e4bkxfm024
, real_T * pkowjhpjjk , real_T * elg5jbxlvv , real_T * localX_ ) { k2snwiamgb
* const nehesmkint = & ( ope1wg3cbz . rtm ) ; pig3puin4o2 * localX = (
pig3puin4o2 * ) localX_ ; NeslSimulationData * simulationData ; real_T time ;
real_T tmp [ 24 ] ; int_T tmp_p [ 7 ] ; NeslSimulator * simulator ;
NeuDiagnosticManager * diagnosticManager ; NeuDiagnosticTree * diagnosticTree
; int32_T tmp_e ; char * msg ; real_T time_p ; real_T tmp_i [ 48 ] ; int_T
tmp_m [ 8 ] ; boolean_T first_output ; real_T time_e ; real_T tmp_g [ 48 ] ;
int_T tmp_j [ 13 ] ; real_T time_i ; real_T tmp_f [ 84 ] ; int_T tmp_c [ 14 ]
; real_T u0 ; real_T u1 ; real_T u2 ; simulationData = ( NeslSimulationData *
) l1kpu4wb4rx . mtmd51jfqa ; time = rtmGetTaskTime ( nehesmkint , 0 ) ;
simulationData -> mData -> mTime . mN = 1 ; simulationData -> mData -> mTime
. mX = & time ; simulationData -> mData -> mContStates . mN = 24 ;
simulationData -> mData -> mContStates . mX = & localX -> kvq2o0kyuy [ 0 ] ;
simulationData -> mData -> mDiscStates . mN = 0 ; simulationData -> mData ->
mDiscStates . mX = & l1kpu4wb4rx . i3bqhqdooa ; simulationData -> mData ->
mModeVector . mN = 0 ; simulationData -> mData -> mModeVector . mX = &
l1kpu4wb4rx . psdfuxjdsv ; first_output = false ; simulationData -> mData ->
mFoundZcEvents = first_output ; simulationData -> mData -> mIsMajorTimeStep =
rtmIsMajorTimeStep ( nehesmkint ) ; first_output = _ssGetSolverAssertCheck (
nehesmkint -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsSolverAssertCheck = first_output ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; first_output = ssIsSolverComputingJacobian (
nehesmkint -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsComputingJacobian = first_output ; simulationData -> mData ->
mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian ( nehesmkint -> _mdlRefSfcnS
) != 0 ) ; simulationData -> mData -> mIsSolverRequestingReset = false ;
tmp_p [ 0 ] = 0 ; tmp [ 0 ] = iqd4nnjnc2n . hhczjtzyj5 [ 0 ] ; tmp [ 1 ] =
iqd4nnjnc2n . hhczjtzyj5 [ 1 ] ; tmp [ 2 ] = iqd4nnjnc2n . hhczjtzyj5 [ 2 ] ;
tmp [ 3 ] = iqd4nnjnc2n . hhczjtzyj5 [ 3 ] ; tmp_p [ 1 ] = 4 ; tmp [ 4 ] =
iqd4nnjnc2n . imtlp51aqd [ 0 ] ; tmp [ 5 ] = iqd4nnjnc2n . imtlp51aqd [ 1 ] ;
tmp [ 6 ] = iqd4nnjnc2n . imtlp51aqd [ 2 ] ; tmp [ 7 ] = iqd4nnjnc2n .
imtlp51aqd [ 3 ] ; tmp_p [ 2 ] = 8 ; tmp [ 8 ] = iqd4nnjnc2n . oe1dnrny2q [ 0
] ; tmp [ 9 ] = iqd4nnjnc2n . oe1dnrny2q [ 1 ] ; tmp [ 10 ] = iqd4nnjnc2n .
oe1dnrny2q [ 2 ] ; tmp [ 11 ] = iqd4nnjnc2n . oe1dnrny2q [ 3 ] ; tmp_p [ 3 ]
= 12 ; tmp [ 12 ] = iqd4nnjnc2n . e3os4rwhiv [ 0 ] ; tmp [ 13 ] = iqd4nnjnc2n
. e3os4rwhiv [ 1 ] ; tmp [ 14 ] = iqd4nnjnc2n . e3os4rwhiv [ 2 ] ; tmp [ 15 ]
= iqd4nnjnc2n . e3os4rwhiv [ 3 ] ; tmp_p [ 4 ] = 16 ; tmp [ 16 ] =
iqd4nnjnc2n . bfaefzzyat [ 0 ] ; tmp [ 17 ] = iqd4nnjnc2n . bfaefzzyat [ 1 ]
; tmp [ 18 ] = iqd4nnjnc2n . bfaefzzyat [ 2 ] ; tmp [ 19 ] = iqd4nnjnc2n .
bfaefzzyat [ 3 ] ; tmp_p [ 5 ] = 20 ; tmp [ 20 ] = iqd4nnjnc2n . b10z030dj4 [
0 ] ; tmp [ 21 ] = iqd4nnjnc2n . b10z030dj4 [ 1 ] ; tmp [ 22 ] = iqd4nnjnc2n
. b10z030dj4 [ 2 ] ; tmp [ 23 ] = iqd4nnjnc2n . b10z030dj4 [ 3 ] ; tmp_p [ 6
] = 24 ; simulationData -> mData -> mInputValues . mN = 24 ; simulationData
-> mData -> mInputValues . mX = & tmp [ 0 ] ; simulationData -> mData ->
mInputOffsets . mN = 7 ; simulationData -> mData -> mInputOffsets . mX = &
tmp_p [ 0 ] ; simulationData -> mData -> mOutputs . mN = 24 ; simulationData
-> mData -> mOutputs . mX = & iqd4nnjnc2n . ifpjipjhob [ 0 ] ; simulationData
-> mData -> mSampleHits . mN = 0 ; simulationData -> mData -> mSampleHits .
mX = NULL ; simulationData -> mData -> mIsFundamentalSampleHit = false ;
simulationData -> mData -> mTolerances . mN = 0 ; simulationData -> mData ->
mTolerances . mX = NULL ; simulationData -> mData -> mCstateHasChanged =
false ; simulator = ( NeslSimulator * ) l1kpu4wb4rx . es1n0xuy5w ;
diagnosticManager = ( NeuDiagnosticManager * ) l1kpu4wb4rx . pryqdadyrt ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; tmp_e = ne_simulator_method ( simulator , NESL_SIM_OUTPUTS ,
simulationData , diagnosticManager ) ; if ( tmp_e != 0 ) { first_output =
error_buffer_is_empty ( ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ;
if ( first_output ) { msg = rtw_diagnostics_msg ( diagnosticTree ) ;
ssSetErrorStatus ( nehesmkint -> _mdlRefSfcnS , msg ) ; } } if (
rtmIsMajorTimeStep ( nehesmkint ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( nehesmkint -> _mdlRefSfcnS ) ; }
simulationData = ( NeslSimulationData * ) l1kpu4wb4rx . kiq53exfqv ; time_p =
rtmGetTaskTime ( nehesmkint , 0 ) ; simulationData -> mData -> mTime . mN = 1
; simulationData -> mData -> mTime . mX = & time_p ; simulationData -> mData
-> mContStates . mN = 0 ; simulationData -> mData -> mContStates . mX = NULL
; simulationData -> mData -> mDiscStates . mN = 0 ; simulationData -> mData
-> mDiscStates . mX = & l1kpu4wb4rx . no0lkkst0o ; simulationData -> mData ->
mModeVector . mN = 0 ; simulationData -> mData -> mModeVector . mX = &
l1kpu4wb4rx . kzyw5zlnoa ; first_output = false ; simulationData -> mData ->
mFoundZcEvents = first_output ; simulationData -> mData -> mIsMajorTimeStep =
rtmIsMajorTimeStep ( nehesmkint ) ; first_output = _ssGetSolverAssertCheck (
nehesmkint -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsSolverAssertCheck = first_output ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; simulationData -> mData ->
mIsComputingJacobian = false ; simulationData -> mData -> mIsEvaluatingF0 =
false ; simulationData -> mData -> mIsSolverRequestingReset = false ; tmp_m [
0 ] = 0 ; tmp_i [ 0 ] = iqd4nnjnc2n . hhczjtzyj5 [ 0 ] ; tmp_i [ 1 ] =
iqd4nnjnc2n . hhczjtzyj5 [ 1 ] ; tmp_i [ 2 ] = iqd4nnjnc2n . hhczjtzyj5 [ 2 ]
; tmp_i [ 3 ] = iqd4nnjnc2n . hhczjtzyj5 [ 3 ] ; tmp_m [ 1 ] = 4 ; tmp_i [ 4
] = iqd4nnjnc2n . imtlp51aqd [ 0 ] ; tmp_i [ 5 ] = iqd4nnjnc2n . imtlp51aqd [
1 ] ; tmp_i [ 6 ] = iqd4nnjnc2n . imtlp51aqd [ 2 ] ; tmp_i [ 7 ] =
iqd4nnjnc2n . imtlp51aqd [ 3 ] ; tmp_m [ 2 ] = 8 ; tmp_i [ 8 ] = iqd4nnjnc2n
. oe1dnrny2q [ 0 ] ; tmp_i [ 9 ] = iqd4nnjnc2n . oe1dnrny2q [ 1 ] ; tmp_i [
10 ] = iqd4nnjnc2n . oe1dnrny2q [ 2 ] ; tmp_i [ 11 ] = iqd4nnjnc2n .
oe1dnrny2q [ 3 ] ; tmp_m [ 3 ] = 12 ; tmp_i [ 12 ] = iqd4nnjnc2n . e3os4rwhiv
[ 0 ] ; tmp_i [ 13 ] = iqd4nnjnc2n . e3os4rwhiv [ 1 ] ; tmp_i [ 14 ] =
iqd4nnjnc2n . e3os4rwhiv [ 2 ] ; tmp_i [ 15 ] = iqd4nnjnc2n . e3os4rwhiv [ 3
] ; tmp_m [ 4 ] = 16 ; tmp_i [ 16 ] = iqd4nnjnc2n . bfaefzzyat [ 0 ] ; tmp_i
[ 17 ] = iqd4nnjnc2n . bfaefzzyat [ 1 ] ; tmp_i [ 18 ] = iqd4nnjnc2n .
bfaefzzyat [ 2 ] ; tmp_i [ 19 ] = iqd4nnjnc2n . bfaefzzyat [ 3 ] ; tmp_m [ 5
] = 20 ; tmp_i [ 20 ] = iqd4nnjnc2n . b10z030dj4 [ 0 ] ; tmp_i [ 21 ] =
iqd4nnjnc2n . b10z030dj4 [ 1 ] ; tmp_i [ 22 ] = iqd4nnjnc2n . b10z030dj4 [ 2
] ; tmp_i [ 23 ] = iqd4nnjnc2n . b10z030dj4 [ 3 ] ; tmp_m [ 6 ] = 24 ; memcpy
( & tmp_i [ 24 ] , & iqd4nnjnc2n . ifpjipjhob [ 0 ] , 24U * sizeof ( real_T )
) ; tmp_m [ 7 ] = 48 ; simulationData -> mData -> mInputValues . mN = 48 ;
simulationData -> mData -> mInputValues . mX = & tmp_i [ 0 ] ; simulationData
-> mData -> mInputOffsets . mN = 8 ; simulationData -> mData -> mInputOffsets
. mX = & tmp_m [ 0 ] ; simulationData -> mData -> mOutputs . mN = 12 ;
simulationData -> mData -> mOutputs . mX = & iqd4nnjnc2n . inqhzhb0pg [ 0 ] ;
simulationData -> mData -> mSampleHits . mN = 0 ; simulationData -> mData ->
mSampleHits . mX = NULL ; simulationData -> mData -> mIsFundamentalSampleHit
= false ; simulationData -> mData -> mTolerances . mN = 0 ; simulationData ->
mData -> mTolerances . mX = NULL ; simulationData -> mData ->
mCstateHasChanged = false ; simulator = ( NeslSimulator * ) l1kpu4wb4rx .
lbpm3d2oh5 ; diagnosticManager = ( NeuDiagnosticManager * ) l1kpu4wb4rx .
hnzbntkygs ; diagnosticTree = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; tmp_e = ne_simulator_method ( simulator ,
NESL_SIM_OUTPUTS , simulationData , diagnosticManager ) ; if ( tmp_e != 0 ) {
first_output = error_buffer_is_empty ( ssGetErrorStatus ( nehesmkint ->
_mdlRefSfcnS ) ) ; if ( first_output ) { msg = rtw_diagnostics_msg (
diagnosticTree ) ; ssSetErrorStatus ( nehesmkint -> _mdlRefSfcnS , msg ) ; }
} if ( rtmIsMajorTimeStep ( nehesmkint ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( nehesmkint -> _mdlRefSfcnS ) ; }
iqd4nnjnc2n . k02mbhlw1t = cy2wstccxe . P_84 * iqd4nnjnc2n . inqhzhb0pg [ 4 ]
; iqd4nnjnc2n . pdhwu31m4v = cy2wstccxe . P_85 * iqd4nnjnc2n . k02mbhlw1t ; *
pboqsovn2d = iqd4nnjnc2n . pdhwu31m4v ; iqd4nnjnc2n . dzzjhrmxmh = cy2wstccxe
. P_86 * iqd4nnjnc2n . inqhzhb0pg [ 6 ] ; iqd4nnjnc2n . cndf4llhki =
cy2wstccxe . P_87 * iqd4nnjnc2n . dzzjhrmxmh ; * lxemy5vpal = iqd4nnjnc2n .
cndf4llhki ; iqd4nnjnc2n . fbdziutlst = cy2wstccxe . P_88 * iqd4nnjnc2n .
inqhzhb0pg [ 8 ] ; iqd4nnjnc2n . g350wynvmb = cy2wstccxe . P_89 * iqd4nnjnc2n
. fbdziutlst ; * d3in4i2zmt = iqd4nnjnc2n . g350wynvmb ; iqd4nnjnc2n .
dtgsdqgg0q = cy2wstccxe . P_90 * iqd4nnjnc2n . inqhzhb0pg [ 10 ] ;
iqd4nnjnc2n . ia5oez2mak = cy2wstccxe . P_91 * iqd4nnjnc2n . dtgsdqgg0q ; *
e4bkxfm024 = iqd4nnjnc2n . ia5oez2mak ; iqd4nnjnc2n . mw0h41hol3 = cy2wstccxe
. P_92 * iqd4nnjnc2n . inqhzhb0pg [ 2 ] ; iqd4nnjnc2n . heefjqovkk =
cy2wstccxe . P_93 * iqd4nnjnc2n . mw0h41hol3 ; * pkowjhpjjk = iqd4nnjnc2n .
heefjqovkk ; iqd4nnjnc2n . iofmmprsur = cy2wstccxe . P_94 * iqd4nnjnc2n .
inqhzhb0pg [ 0 ] ; iqd4nnjnc2n . f2obljhlxv = cy2wstccxe . P_95 * iqd4nnjnc2n
. iofmmprsur ; * elg5jbxlvv = iqd4nnjnc2n . f2obljhlxv ; { SimStruct * rts =
nehesmkint -> childSfunctions [ 0 ] ; sfcnOutputs ( rts , etrgs4mokz [ 0 ] )
; if ( ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } { SimStruct * rts =
nehesmkint -> childSfunctions [ 1 ] ; sfcnOutputs ( rts , etrgs4mokz [ 0 ] )
; if ( ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } { SimStruct * rts =
nehesmkint -> childSfunctions [ 2 ] ; sfcnOutputs ( rts , etrgs4mokz [ 0 ] )
; if ( ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } { SimStruct * rts =
nehesmkint -> childSfunctions [ 3 ] ; sfcnOutputs ( rts , etrgs4mokz [ 0 ] )
; if ( ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } { SimStruct * rts =
nehesmkint -> childSfunctions [ 4 ] ; sfcnOutputs ( rts , etrgs4mokz [ 0 ] )
; if ( ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } { SimStruct * rts =
nehesmkint -> childSfunctions [ 5 ] ; sfcnOutputs ( rts , etrgs4mokz [ 0 ] )
; if ( ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } iqd4nnjnc2n .
ipmgvtmz0p = cy2wstccxe . P_372 * iqd4nnjnc2n . inqhzhb0pg [ 5 ] ;
iqd4nnjnc2n . md1hwdfaw0 = cy2wstccxe . P_373 * iqd4nnjnc2n . inqhzhb0pg [ 7
] ; iqd4nnjnc2n . f2poduj1se = cy2wstccxe . P_374 * iqd4nnjnc2n . inqhzhb0pg
[ 9 ] ; iqd4nnjnc2n . m2n4ar1n2i = cy2wstccxe . P_375 * iqd4nnjnc2n .
inqhzhb0pg [ 11 ] ; iqd4nnjnc2n . gvju2sivxf = cy2wstccxe . P_376 *
iqd4nnjnc2n . inqhzhb0pg [ 3 ] ; iqd4nnjnc2n . lqy11apf3e = cy2wstccxe .
P_377 * iqd4nnjnc2n . inqhzhb0pg [ 1 ] ; first_output = false ; if (
l1kpu4wb4rx . ct1fp3ytps == 0.0 ) { l1kpu4wb4rx . ct1fp3ytps = 1.0 ;
first_output = true ; } if ( first_output ) { localX -> isq3glw5ap =
iqd4nnjnc2n . inqhzhb0pg [ 1 ] ; } iqd4nnjnc2n . dxindqk5ap [ 0 ] = localX ->
isq3glw5ap ; iqd4nnjnc2n . dxindqk5ap [ 1 ] = ( iqd4nnjnc2n . inqhzhb0pg [ 1
] - localX -> isq3glw5ap ) * 1000.0 ; iqd4nnjnc2n . dxindqk5ap [ 2 ] = 0.0 ;
iqd4nnjnc2n . dxindqk5ap [ 3 ] = 0.0 ; first_output = false ; if (
l1kpu4wb4rx . jycpyvgbwk == 0.0 ) { l1kpu4wb4rx . jycpyvgbwk = 1.0 ;
first_output = true ; } if ( first_output ) { localX -> jvjzsnn41x =
iqd4nnjnc2n . inqhzhb0pg [ 3 ] ; } iqd4nnjnc2n . mxdpm2mgmf [ 0 ] = localX ->
jvjzsnn41x ; iqd4nnjnc2n . mxdpm2mgmf [ 1 ] = ( iqd4nnjnc2n . inqhzhb0pg [ 3
] - localX -> jvjzsnn41x ) * 1000.0 ; iqd4nnjnc2n . mxdpm2mgmf [ 2 ] = 0.0 ;
iqd4nnjnc2n . mxdpm2mgmf [ 3 ] = 0.0 ; first_output = false ; if (
l1kpu4wb4rx . ed0zskjjvf == 0.0 ) { l1kpu4wb4rx . ed0zskjjvf = 1.0 ;
first_output = true ; } if ( first_output ) { localX -> aw5so3hvxw =
iqd4nnjnc2n . inqhzhb0pg [ 5 ] ; } iqd4nnjnc2n . m4am5qqyxf [ 0 ] = localX ->
aw5so3hvxw ; iqd4nnjnc2n . m4am5qqyxf [ 1 ] = ( iqd4nnjnc2n . inqhzhb0pg [ 5
] - localX -> aw5so3hvxw ) * 1000.0 ; iqd4nnjnc2n . m4am5qqyxf [ 2 ] = 0.0 ;
iqd4nnjnc2n . m4am5qqyxf [ 3 ] = 0.0 ; first_output = false ; if (
l1kpu4wb4rx . mkl1pjdrap == 0.0 ) { l1kpu4wb4rx . mkl1pjdrap = 1.0 ;
first_output = true ; } if ( first_output ) { localX -> h2c1iqll2l =
iqd4nnjnc2n . inqhzhb0pg [ 7 ] ; } iqd4nnjnc2n . jshfwrvsum [ 0 ] = localX ->
h2c1iqll2l ; iqd4nnjnc2n . jshfwrvsum [ 1 ] = ( iqd4nnjnc2n . inqhzhb0pg [ 7
] - localX -> h2c1iqll2l ) * 1000.0 ; iqd4nnjnc2n . jshfwrvsum [ 2 ] = 0.0 ;
iqd4nnjnc2n . jshfwrvsum [ 3 ] = 0.0 ; first_output = false ; if (
l1kpu4wb4rx . nnm5ezmxoj == 0.0 ) { l1kpu4wb4rx . nnm5ezmxoj = 1.0 ;
first_output = true ; } if ( first_output ) { localX -> gr0t541bm5 =
iqd4nnjnc2n . inqhzhb0pg [ 9 ] ; } iqd4nnjnc2n . opwk0qcg1j [ 0 ] = localX ->
gr0t541bm5 ; iqd4nnjnc2n . opwk0qcg1j [ 1 ] = ( iqd4nnjnc2n . inqhzhb0pg [ 9
] - localX -> gr0t541bm5 ) * 1000.0 ; iqd4nnjnc2n . opwk0qcg1j [ 2 ] = 0.0 ;
iqd4nnjnc2n . opwk0qcg1j [ 3 ] = 0.0 ; first_output = false ; if (
l1kpu4wb4rx . petosikypy == 0.0 ) { l1kpu4wb4rx . petosikypy = 1.0 ;
first_output = true ; } if ( first_output ) { localX -> gbdjq0hbbl =
iqd4nnjnc2n . inqhzhb0pg [ 11 ] ; } iqd4nnjnc2n . kovkup1lbe [ 0 ] = localX
-> gbdjq0hbbl ; iqd4nnjnc2n . kovkup1lbe [ 1 ] = ( iqd4nnjnc2n . inqhzhb0pg [
11 ] - localX -> gbdjq0hbbl ) * 1000.0 ; iqd4nnjnc2n . kovkup1lbe [ 2 ] = 0.0
; iqd4nnjnc2n . kovkup1lbe [ 3 ] = 0.0 ; if ( rtmIsMajorTimeStep ( nehesmkint
) ) { iqd4nnjnc2n . jboflpmlgl = cy2wstccxe . P_72 - iqd4nnjnc2n . dvdfpqupvw
[ 0 ] ; iqd4nnjnc2n . hwmhajtbh2 = ( iqd4nnjnc2n . jboflpmlgl <= cy2wstccxe .
P_378 ) ; iqd4nnjnc2n . e533on3dew = cy2wstccxe . P_73 - iqd4nnjnc2n .
gvxqq2drkr [ 0 ] ; iqd4nnjnc2n . bwnjfsl54j = ( iqd4nnjnc2n . e533on3dew <=
cy2wstccxe . P_379 ) ; if ( rtmIsMajorTimeStep ( nehesmkint ) ) { iqd4nnjnc2n
. oxxrcem11e = * aa5mtdip3u ; } iqd4nnjnc2n . gsbroayuv4 = cy2wstccxe . P_18
* iqd4nnjnc2n . oxxrcem11e ; if ( l1kpu4wb4rx . bepyqlw5qu != 0 ) {
l1kpu4wb4rx . mikve0glkh = iqd4nnjnc2n . gsbroayuv4 ; if ( l1kpu4wb4rx .
mikve0glkh >= cy2wstccxe . P_381 ) { l1kpu4wb4rx . mikve0glkh = cy2wstccxe .
P_381 ; } else { if ( l1kpu4wb4rx . mikve0glkh <= cy2wstccxe . P_382 ) {
l1kpu4wb4rx . mikve0glkh = cy2wstccxe . P_382 ; } } } if ( iqd4nnjnc2n .
bwnjfsl54j || ( l1kpu4wb4rx . dyn5irgyjj != 0 ) ) { l1kpu4wb4rx . mikve0glkh
= iqd4nnjnc2n . gsbroayuv4 ; if ( l1kpu4wb4rx . mikve0glkh >= cy2wstccxe .
P_381 ) { l1kpu4wb4rx . mikve0glkh = cy2wstccxe . P_381 ; } else { if (
l1kpu4wb4rx . mikve0glkh <= cy2wstccxe . P_382 ) { l1kpu4wb4rx . mikve0glkh =
cy2wstccxe . P_382 ; } } } if ( l1kpu4wb4rx . mikve0glkh >= cy2wstccxe .
P_381 ) { l1kpu4wb4rx . mikve0glkh = cy2wstccxe . P_381 ; } else { if (
l1kpu4wb4rx . mikve0glkh <= cy2wstccxe . P_382 ) { l1kpu4wb4rx . mikve0glkh =
cy2wstccxe . P_382 ; } } iqd4nnjnc2n . ex5jwcruri = l1kpu4wb4rx . mikve0glkh
; u0 = iqd4nnjnc2n . ex5jwcruri ; u1 = cy2wstccxe . P_384 ; u2 = cy2wstccxe .
P_383 ; if ( u0 > u2 ) { iqd4nnjnc2n . nuophhg5zj = u2 ; } else if ( u0 < u1
) { iqd4nnjnc2n . nuophhg5zj = u1 ; } else { iqd4nnjnc2n . nuophhg5zj = u0 ;
} if ( rtmIsMajorTimeStep ( nehesmkint ) ) { iqd4nnjnc2n . eaqsdmtsbk =
iqd4nnjnc2n . cndf4llhki ; } iqd4nnjnc2n . ixesed2ean = iqd4nnjnc2n .
nuophhg5zj - iqd4nnjnc2n . eaqsdmtsbk ; iqd4nnjnc2n . d3mpqgab3u = cy2wstccxe
. P_48 * iqd4nnjnc2n . ixesed2ean ; iqd4nnjnc2n . fprvc2pkb5 = l1kpu4wb4rx .
ccquv3ehj4 ; iqd4nnjnc2n . jbqxn5zlnu = cy2wstccxe . P_30 * iqd4nnjnc2n .
ixesed2ean ; iqd4nnjnc2n . m4yl5vpts2 = l1kpu4wb4rx . pbidohzefw ;
iqd4nnjnc2n . a4ijmg00rn = iqd4nnjnc2n . jbqxn5zlnu - iqd4nnjnc2n .
m4yl5vpts2 ; iqd4nnjnc2n . cqom2nhmk2 = cy2wstccxe . P_60 * iqd4nnjnc2n .
a4ijmg00rn ; iqd4nnjnc2n . lkxcfhia4s = ( iqd4nnjnc2n . d3mpqgab3u +
iqd4nnjnc2n . fprvc2pkb5 ) + iqd4nnjnc2n . cqom2nhmk2 ; u1 = - cy2wstccxe .
P_66 ; u0 = iqd4nnjnc2n . lkxcfhia4s ; u2 = cy2wstccxe . P_66 ; if ( u0 > u2
) { iqd4nnjnc2n . ckpkttb0zm = u2 ; } else if ( u0 < u1 ) { iqd4nnjnc2n .
ckpkttb0zm = u1 ; } else { iqd4nnjnc2n . ckpkttb0zm = u0 ; } iqd4nnjnc2n .
iuco14ytiq = cy2wstccxe . P_387 * iqd4nnjnc2n . ckpkttb0zm ; iqd4nnjnc2n .
lb5otvwgy1 = cy2wstccxe . P_19 * iqd4nnjnc2n . iuco14ytiq ; if ( l1kpu4wb4rx
. hritc1babc != 0 ) { l1kpu4wb4rx . lzgpy1pmbg = iqd4nnjnc2n . lb5otvwgy1 ;
if ( l1kpu4wb4rx . lzgpy1pmbg >= cy2wstccxe . P_389 ) { l1kpu4wb4rx .
lzgpy1pmbg = cy2wstccxe . P_389 ; } else { if ( l1kpu4wb4rx . lzgpy1pmbg <=
cy2wstccxe . P_390 ) { l1kpu4wb4rx . lzgpy1pmbg = cy2wstccxe . P_390 ; } } }
if ( iqd4nnjnc2n . hwmhajtbh2 || ( l1kpu4wb4rx . kayrm3qjer != 0 ) ) {
l1kpu4wb4rx . lzgpy1pmbg = iqd4nnjnc2n . lb5otvwgy1 ; if ( l1kpu4wb4rx .
lzgpy1pmbg >= cy2wstccxe . P_389 ) { l1kpu4wb4rx . lzgpy1pmbg = cy2wstccxe .
P_389 ; } else { if ( l1kpu4wb4rx . lzgpy1pmbg <= cy2wstccxe . P_390 ) {
l1kpu4wb4rx . lzgpy1pmbg = cy2wstccxe . P_390 ; } } } if ( l1kpu4wb4rx .
lzgpy1pmbg >= cy2wstccxe . P_389 ) { l1kpu4wb4rx . lzgpy1pmbg = cy2wstccxe .
P_389 ; } else { if ( l1kpu4wb4rx . lzgpy1pmbg <= cy2wstccxe . P_390 ) {
l1kpu4wb4rx . lzgpy1pmbg = cy2wstccxe . P_390 ; } } iqd4nnjnc2n . j43t334fqb
= l1kpu4wb4rx . lzgpy1pmbg ; u0 = iqd4nnjnc2n . j43t334fqb ; u1 = cy2wstccxe
. P_392 ; u2 = cy2wstccxe . P_391 ; if ( u0 > u2 ) { iqd4nnjnc2n . aqqltp4gox
= u2 ; } else if ( u0 < u1 ) { iqd4nnjnc2n . aqqltp4gox = u1 ; } else {
iqd4nnjnc2n . aqqltp4gox = u0 ; } if ( rtmIsMajorTimeStep ( nehesmkint ) ) {
iqd4nnjnc2n . bsso1gl4sz = iqd4nnjnc2n . md1hwdfaw0 ; } iqd4nnjnc2n .
ccvzquveq4 = cy2wstccxe . P_393 * iqd4nnjnc2n . bsso1gl4sz ; iqd4nnjnc2n .
ga313eveon = iqd4nnjnc2n . aqqltp4gox - iqd4nnjnc2n . ccvzquveq4 ;
iqd4nnjnc2n . am5rwkyguj = cy2wstccxe . P_49 * iqd4nnjnc2n . ga313eveon ;
iqd4nnjnc2n . j2rqyakskv = l1kpu4wb4rx . ndcz2pevdt ; iqd4nnjnc2n .
f5elnixfao = iqd4nnjnc2n . am5rwkyguj + iqd4nnjnc2n . j2rqyakskv ;
iqd4nnjnc2n . asnfpaduo0 = iqd4nnjnc2n . f5elnixfao ; } if (
rtmIsMajorTimeStep ( nehesmkint ) ) { l1kpu4wb4rx . e2xmk045t3 = iqd4nnjnc2n
. asnfpaduo0 ; } first_output = false ; if ( l1kpu4wb4rx . ceeqqvhrmq == 0.0
) { l1kpu4wb4rx . ceeqqvhrmq = 1.0 ; first_output = true ; } if (
first_output ) { localX -> jeypibejzj [ 0 ] = l1kpu4wb4rx . e2xmk045t3 ;
localX -> jeypibejzj [ 1 ] = 0.0 ; } iqd4nnjnc2n . mxwazunugj [ 0 ] = localX
-> jeypibejzj [ 0 ] ; iqd4nnjnc2n . mxwazunugj [ 1 ] = localX -> jeypibejzj [
1 ] ; iqd4nnjnc2n . mxwazunugj [ 2 ] = ( ( l1kpu4wb4rx . e2xmk045t3 - localX
-> jeypibejzj [ 0 ] ) * 1000.0 - 2.0 * localX -> jeypibejzj [ 1 ] ) * 1000.0
; iqd4nnjnc2n . mxwazunugj [ 3 ] = 0.0 ; if ( rtmIsMajorTimeStep ( nehesmkint
) ) { iqd4nnjnc2n . cs1qx4pkft = cy2wstccxe . P_74 - iqd4nnjnc2n . ecllldohtk
[ 0 ] ; iqd4nnjnc2n . icvmqhdxij = ( iqd4nnjnc2n . cs1qx4pkft <= cy2wstccxe .
P_395 ) ; iqd4nnjnc2n . jynkr5zc5k = cy2wstccxe . P_75 - iqd4nnjnc2n .
lglx1tyi3w [ 0 ] ; iqd4nnjnc2n . bdsmqsg0a3 = ( iqd4nnjnc2n . jynkr5zc5k <=
cy2wstccxe . P_396 ) ; if ( rtmIsMajorTimeStep ( nehesmkint ) ) { iqd4nnjnc2n
. dggq1ftd4d = * kmigltnqf0 ; } iqd4nnjnc2n . cc1ikppcoe = cy2wstccxe . P_20
* iqd4nnjnc2n . dggq1ftd4d ; if ( l1kpu4wb4rx . jpgsqiqfhq != 0 ) {
l1kpu4wb4rx . grtf40g3km = iqd4nnjnc2n . cc1ikppcoe ; if ( l1kpu4wb4rx .
grtf40g3km >= cy2wstccxe . P_398 ) { l1kpu4wb4rx . grtf40g3km = cy2wstccxe .
P_398 ; } else { if ( l1kpu4wb4rx . grtf40g3km <= cy2wstccxe . P_399 ) {
l1kpu4wb4rx . grtf40g3km = cy2wstccxe . P_399 ; } } } if ( iqd4nnjnc2n .
bdsmqsg0a3 || ( l1kpu4wb4rx . h2jjjrmgpx != 0 ) ) { l1kpu4wb4rx . grtf40g3km
= iqd4nnjnc2n . cc1ikppcoe ; if ( l1kpu4wb4rx . grtf40g3km >= cy2wstccxe .
P_398 ) { l1kpu4wb4rx . grtf40g3km = cy2wstccxe . P_398 ; } else { if (
l1kpu4wb4rx . grtf40g3km <= cy2wstccxe . P_399 ) { l1kpu4wb4rx . grtf40g3km =
cy2wstccxe . P_399 ; } } } if ( l1kpu4wb4rx . grtf40g3km >= cy2wstccxe .
P_398 ) { l1kpu4wb4rx . grtf40g3km = cy2wstccxe . P_398 ; } else { if (
l1kpu4wb4rx . grtf40g3km <= cy2wstccxe . P_399 ) { l1kpu4wb4rx . grtf40g3km =
cy2wstccxe . P_399 ; } } iqd4nnjnc2n . gup53f13wt = l1kpu4wb4rx . grtf40g3km
; u0 = iqd4nnjnc2n . gup53f13wt ; u1 = cy2wstccxe . P_401 ; u2 = cy2wstccxe .
P_400 ; if ( u0 > u2 ) { iqd4nnjnc2n . cjiwv41dtz = u2 ; } else if ( u0 < u1
) { iqd4nnjnc2n . cjiwv41dtz = u1 ; } else { iqd4nnjnc2n . cjiwv41dtz = u0 ;
} if ( rtmIsMajorTimeStep ( nehesmkint ) ) { iqd4nnjnc2n . cyvfcuag0d =
iqd4nnjnc2n . ia5oez2mak ; } iqd4nnjnc2n . owxogzl3qh = iqd4nnjnc2n .
cjiwv41dtz - iqd4nnjnc2n . cyvfcuag0d ; iqd4nnjnc2n . oj2hrval0l = cy2wstccxe
. P_50 * iqd4nnjnc2n . owxogzl3qh ; iqd4nnjnc2n . lpkm4pkk2g = l1kpu4wb4rx .
ipoqi0vxan ; iqd4nnjnc2n . cpjebkyeqd = cy2wstccxe . P_31 * iqd4nnjnc2n .
owxogzl3qh ; iqd4nnjnc2n . f5acbxbbxd = l1kpu4wb4rx . h5eac0mibo ;
iqd4nnjnc2n . igwxrnhwvy = iqd4nnjnc2n . cpjebkyeqd - iqd4nnjnc2n .
f5acbxbbxd ; iqd4nnjnc2n . euxeitc2fq = cy2wstccxe . P_61 * iqd4nnjnc2n .
igwxrnhwvy ; iqd4nnjnc2n . iphsvwpxoz = ( iqd4nnjnc2n . oj2hrval0l +
iqd4nnjnc2n . lpkm4pkk2g ) + iqd4nnjnc2n . euxeitc2fq ; u1 = - cy2wstccxe .
P_67 ; u0 = iqd4nnjnc2n . iphsvwpxoz ; u2 = cy2wstccxe . P_67 ; if ( u0 > u2
) { iqd4nnjnc2n . en3mr1o540 = u2 ; } else if ( u0 < u1 ) { iqd4nnjnc2n .
en3mr1o540 = u1 ; } else { iqd4nnjnc2n . en3mr1o540 = u0 ; } iqd4nnjnc2n .
jpx50ffdto = cy2wstccxe . P_404 * iqd4nnjnc2n . en3mr1o540 ; iqd4nnjnc2n .
hihw2kx10l = cy2wstccxe . P_21 * iqd4nnjnc2n . jpx50ffdto ; if ( l1kpu4wb4rx
. n1umrqm4ou != 0 ) { l1kpu4wb4rx . pa4czare1d = iqd4nnjnc2n . hihw2kx10l ;
if ( l1kpu4wb4rx . pa4czare1d >= cy2wstccxe . P_406 ) { l1kpu4wb4rx .
pa4czare1d = cy2wstccxe . P_406 ; } else { if ( l1kpu4wb4rx . pa4czare1d <=
cy2wstccxe . P_407 ) { l1kpu4wb4rx . pa4czare1d = cy2wstccxe . P_407 ; } } }
if ( iqd4nnjnc2n . icvmqhdxij || ( l1kpu4wb4rx . n1r0ywaznf != 0 ) ) {
l1kpu4wb4rx . pa4czare1d = iqd4nnjnc2n . hihw2kx10l ; if ( l1kpu4wb4rx .
pa4czare1d >= cy2wstccxe . P_406 ) { l1kpu4wb4rx . pa4czare1d = cy2wstccxe .
P_406 ; } else { if ( l1kpu4wb4rx . pa4czare1d <= cy2wstccxe . P_407 ) {
l1kpu4wb4rx . pa4czare1d = cy2wstccxe . P_407 ; } } } if ( l1kpu4wb4rx .
pa4czare1d >= cy2wstccxe . P_406 ) { l1kpu4wb4rx . pa4czare1d = cy2wstccxe .
P_406 ; } else { if ( l1kpu4wb4rx . pa4czare1d <= cy2wstccxe . P_407 ) {
l1kpu4wb4rx . pa4czare1d = cy2wstccxe . P_407 ; } } iqd4nnjnc2n . ddtdb5154z
= l1kpu4wb4rx . pa4czare1d ; u0 = iqd4nnjnc2n . ddtdb5154z ; u1 = cy2wstccxe
. P_409 ; u2 = cy2wstccxe . P_408 ; if ( u0 > u2 ) { iqd4nnjnc2n . lxk3aawz4t
= u2 ; } else if ( u0 < u1 ) { iqd4nnjnc2n . lxk3aawz4t = u1 ; } else {
iqd4nnjnc2n . lxk3aawz4t = u0 ; } if ( rtmIsMajorTimeStep ( nehesmkint ) ) {
iqd4nnjnc2n . eoirmu0eq4 = iqd4nnjnc2n . m2n4ar1n2i ; } iqd4nnjnc2n .
oguy5fkfpw = cy2wstccxe . P_410 * iqd4nnjnc2n . eoirmu0eq4 ; iqd4nnjnc2n .
fw0cndgkar = iqd4nnjnc2n . lxk3aawz4t - iqd4nnjnc2n . oguy5fkfpw ;
iqd4nnjnc2n . c53gujuucy = cy2wstccxe . P_51 * iqd4nnjnc2n . fw0cndgkar ;
iqd4nnjnc2n . ixxkxmji23 = l1kpu4wb4rx . ckwjuadpca ; iqd4nnjnc2n .
amfuazduqp = iqd4nnjnc2n . c53gujuucy + iqd4nnjnc2n . ixxkxmji23 ;
iqd4nnjnc2n . psaggqmu0j = iqd4nnjnc2n . amfuazduqp ; } if (
rtmIsMajorTimeStep ( nehesmkint ) ) { l1kpu4wb4rx . eh1viw32xa = iqd4nnjnc2n
. psaggqmu0j ; } first_output = false ; if ( l1kpu4wb4rx . froc5u33zh == 0.0
) { l1kpu4wb4rx . froc5u33zh = 1.0 ; first_output = true ; } if (
first_output ) { localX -> j2rvpdswec [ 0 ] = l1kpu4wb4rx . eh1viw32xa ;
localX -> j2rvpdswec [ 1 ] = 0.0 ; } iqd4nnjnc2n . l5ozfby1n1 [ 0 ] = localX
-> j2rvpdswec [ 0 ] ; iqd4nnjnc2n . l5ozfby1n1 [ 1 ] = localX -> j2rvpdswec [
1 ] ; iqd4nnjnc2n . l5ozfby1n1 [ 2 ] = ( ( l1kpu4wb4rx . eh1viw32xa - localX
-> j2rvpdswec [ 0 ] ) * 1000.0 - 2.0 * localX -> j2rvpdswec [ 1 ] ) * 1000.0
; iqd4nnjnc2n . l5ozfby1n1 [ 3 ] = 0.0 ; if ( rtmIsMajorTimeStep ( nehesmkint
) ) { iqd4nnjnc2n . cbn5w5msnc = cy2wstccxe . P_76 - iqd4nnjnc2n . ni2moweccg
[ 0 ] ; iqd4nnjnc2n . dfgizgbrra = ( iqd4nnjnc2n . cbn5w5msnc <= cy2wstccxe .
P_412 ) ; iqd4nnjnc2n . clczo1piy5 = cy2wstccxe . P_77 - iqd4nnjnc2n .
gimccxcbis [ 0 ] ; iqd4nnjnc2n . aajfu1lxi5 = ( iqd4nnjnc2n . clczo1piy5 <=
cy2wstccxe . P_413 ) ; if ( rtmIsMajorTimeStep ( nehesmkint ) ) { iqd4nnjnc2n
. pabuhk1ylg = * ialgy4wl0y ; } iqd4nnjnc2n . m2w4u0arlu = cy2wstccxe . P_22
* iqd4nnjnc2n . pabuhk1ylg ; if ( l1kpu4wb4rx . akgp3l4qdu != 0 ) {
l1kpu4wb4rx . ouygc4kcvb = iqd4nnjnc2n . m2w4u0arlu ; if ( l1kpu4wb4rx .
ouygc4kcvb >= cy2wstccxe . P_415 ) { l1kpu4wb4rx . ouygc4kcvb = cy2wstccxe .
P_415 ; } else { if ( l1kpu4wb4rx . ouygc4kcvb <= cy2wstccxe . P_416 ) {
l1kpu4wb4rx . ouygc4kcvb = cy2wstccxe . P_416 ; } } } if ( iqd4nnjnc2n .
aajfu1lxi5 || ( l1kpu4wb4rx . alglf53p5h != 0 ) ) { l1kpu4wb4rx . ouygc4kcvb
= iqd4nnjnc2n . m2w4u0arlu ; if ( l1kpu4wb4rx . ouygc4kcvb >= cy2wstccxe .
P_415 ) { l1kpu4wb4rx . ouygc4kcvb = cy2wstccxe . P_415 ; } else { if (
l1kpu4wb4rx . ouygc4kcvb <= cy2wstccxe . P_416 ) { l1kpu4wb4rx . ouygc4kcvb =
cy2wstccxe . P_416 ; } } } if ( l1kpu4wb4rx . ouygc4kcvb >= cy2wstccxe .
P_415 ) { l1kpu4wb4rx . ouygc4kcvb = cy2wstccxe . P_415 ; } else { if (
l1kpu4wb4rx . ouygc4kcvb <= cy2wstccxe . P_416 ) { l1kpu4wb4rx . ouygc4kcvb =
cy2wstccxe . P_416 ; } } iqd4nnjnc2n . ntwpnpylm1 = l1kpu4wb4rx . ouygc4kcvb
; u0 = iqd4nnjnc2n . ntwpnpylm1 ; u1 = cy2wstccxe . P_418 ; u2 = cy2wstccxe .
P_417 ; if ( u0 > u2 ) { iqd4nnjnc2n . fs3dc0tbpl = u2 ; } else if ( u0 < u1
) { iqd4nnjnc2n . fs3dc0tbpl = u1 ; } else { iqd4nnjnc2n . fs3dc0tbpl = u0 ;
} if ( rtmIsMajorTimeStep ( nehesmkint ) ) { iqd4nnjnc2n . cjvyflecdr =
iqd4nnjnc2n . f2obljhlxv ; } iqd4nnjnc2n . mvmmo5i5vd = iqd4nnjnc2n .
fs3dc0tbpl - iqd4nnjnc2n . cjvyflecdr ; iqd4nnjnc2n . e5ie1xjwrq = cy2wstccxe
. P_52 * iqd4nnjnc2n . mvmmo5i5vd ; iqd4nnjnc2n . nn2c4c4duw = l1kpu4wb4rx .
kjml2jdhog ; iqd4nnjnc2n . kktzaybug1 = cy2wstccxe . P_32 * iqd4nnjnc2n .
mvmmo5i5vd ; iqd4nnjnc2n . ee11anycsp = l1kpu4wb4rx . onzlg3sfc1 ;
iqd4nnjnc2n . jcjabgspcb = iqd4nnjnc2n . kktzaybug1 - iqd4nnjnc2n .
ee11anycsp ; iqd4nnjnc2n . nzchhvzjwf = cy2wstccxe . P_62 * iqd4nnjnc2n .
jcjabgspcb ; iqd4nnjnc2n . ob51ukz2bm = ( iqd4nnjnc2n . e5ie1xjwrq +
iqd4nnjnc2n . nn2c4c4duw ) + iqd4nnjnc2n . nzchhvzjwf ; u1 = - cy2wstccxe .
P_68 ; u0 = iqd4nnjnc2n . ob51ukz2bm ; u2 = cy2wstccxe . P_68 ; if ( u0 > u2
) { iqd4nnjnc2n . aoi5sx3qcq = u2 ; } else if ( u0 < u1 ) { iqd4nnjnc2n .
aoi5sx3qcq = u1 ; } else { iqd4nnjnc2n . aoi5sx3qcq = u0 ; } iqd4nnjnc2n .
kinhb41jtj = cy2wstccxe . P_421 * iqd4nnjnc2n . aoi5sx3qcq ; iqd4nnjnc2n .
kplrhafmh3 = cy2wstccxe . P_23 * iqd4nnjnc2n . kinhb41jtj ; if ( l1kpu4wb4rx
. nw11erxd40 != 0 ) { l1kpu4wb4rx . dsxwjihxvj = iqd4nnjnc2n . kplrhafmh3 ;
if ( l1kpu4wb4rx . dsxwjihxvj >= cy2wstccxe . P_423 ) { l1kpu4wb4rx .
dsxwjihxvj = cy2wstccxe . P_423 ; } else { if ( l1kpu4wb4rx . dsxwjihxvj <=
cy2wstccxe . P_424 ) { l1kpu4wb4rx . dsxwjihxvj = cy2wstccxe . P_424 ; } } }
if ( iqd4nnjnc2n . dfgizgbrra || ( l1kpu4wb4rx . mmmkxfaf4h != 0 ) ) {
l1kpu4wb4rx . dsxwjihxvj = iqd4nnjnc2n . kplrhafmh3 ; if ( l1kpu4wb4rx .
dsxwjihxvj >= cy2wstccxe . P_423 ) { l1kpu4wb4rx . dsxwjihxvj = cy2wstccxe .
P_423 ; } else { if ( l1kpu4wb4rx . dsxwjihxvj <= cy2wstccxe . P_424 ) {
l1kpu4wb4rx . dsxwjihxvj = cy2wstccxe . P_424 ; } } } if ( l1kpu4wb4rx .
dsxwjihxvj >= cy2wstccxe . P_423 ) { l1kpu4wb4rx . dsxwjihxvj = cy2wstccxe .
P_423 ; } else { if ( l1kpu4wb4rx . dsxwjihxvj <= cy2wstccxe . P_424 ) {
l1kpu4wb4rx . dsxwjihxvj = cy2wstccxe . P_424 ; } } iqd4nnjnc2n . nm0gzkykgc
= l1kpu4wb4rx . dsxwjihxvj ; u0 = iqd4nnjnc2n . nm0gzkykgc ; u1 = cy2wstccxe
. P_426 ; u2 = cy2wstccxe . P_425 ; if ( u0 > u2 ) { iqd4nnjnc2n . d3bcnxa0ko
= u2 ; } else if ( u0 < u1 ) { iqd4nnjnc2n . d3bcnxa0ko = u1 ; } else {
iqd4nnjnc2n . d3bcnxa0ko = u0 ; } if ( rtmIsMajorTimeStep ( nehesmkint ) ) {
iqd4nnjnc2n . n3hickxmon = iqd4nnjnc2n . lqy11apf3e ; } iqd4nnjnc2n .
nuvirjsljk = cy2wstccxe . P_427 * iqd4nnjnc2n . n3hickxmon ; iqd4nnjnc2n .
pqudmcvigc = iqd4nnjnc2n . d3bcnxa0ko - iqd4nnjnc2n . nuvirjsljk ;
iqd4nnjnc2n . cxtvdmho2w = cy2wstccxe . P_53 * iqd4nnjnc2n . pqudmcvigc ;
iqd4nnjnc2n . pgojyqs2kb = l1kpu4wb4rx . aqmkm5qp10 ; iqd4nnjnc2n .
jq2t1vws1o = iqd4nnjnc2n . cxtvdmho2w + iqd4nnjnc2n . pgojyqs2kb ;
iqd4nnjnc2n . mvuwiian3j = iqd4nnjnc2n . jq2t1vws1o ; } if (
rtmIsMajorTimeStep ( nehesmkint ) ) { l1kpu4wb4rx . mssfecnie3 = iqd4nnjnc2n
. mvuwiian3j ; } first_output = false ; if ( l1kpu4wb4rx . g2b0tbo4r5 == 0.0
) { l1kpu4wb4rx . g2b0tbo4r5 = 1.0 ; first_output = true ; } if (
first_output ) { localX -> j1sqmhdxq5 [ 0 ] = l1kpu4wb4rx . mssfecnie3 ;
localX -> j1sqmhdxq5 [ 1 ] = 0.0 ; } iqd4nnjnc2n . ppdvvvhxwt [ 0 ] = localX
-> j1sqmhdxq5 [ 0 ] ; iqd4nnjnc2n . ppdvvvhxwt [ 1 ] = localX -> j1sqmhdxq5 [
1 ] ; iqd4nnjnc2n . ppdvvvhxwt [ 2 ] = ( ( l1kpu4wb4rx . mssfecnie3 - localX
-> j1sqmhdxq5 [ 0 ] ) * 1000.0 - 2.0 * localX -> j1sqmhdxq5 [ 1 ] ) * 1000.0
; iqd4nnjnc2n . ppdvvvhxwt [ 3 ] = 0.0 ; if ( rtmIsMajorTimeStep ( nehesmkint
) ) { iqd4nnjnc2n . evydgbi4vg = cy2wstccxe . P_78 - iqd4nnjnc2n . laxrqi2iig
[ 0 ] ; iqd4nnjnc2n . dkq3kdkhqf = ( iqd4nnjnc2n . evydgbi4vg <= cy2wstccxe .
P_429 ) ; iqd4nnjnc2n . dxksw5kbg2 = cy2wstccxe . P_79 - iqd4nnjnc2n .
dfa1yu3sfp [ 0 ] ; iqd4nnjnc2n . flladf3o4m = ( iqd4nnjnc2n . dxksw5kbg2 <=
cy2wstccxe . P_430 ) ; if ( rtmIsMajorTimeStep ( nehesmkint ) ) { iqd4nnjnc2n
. fhq2gw2vcg = * ep31hvib5x ; } iqd4nnjnc2n . nauwt2pif4 = cy2wstccxe . P_24
* iqd4nnjnc2n . fhq2gw2vcg ; if ( l1kpu4wb4rx . dceylbyzbv != 0 ) {
l1kpu4wb4rx . kj4m4y1hwn = iqd4nnjnc2n . nauwt2pif4 ; if ( l1kpu4wb4rx .
kj4m4y1hwn >= cy2wstccxe . P_432 ) { l1kpu4wb4rx . kj4m4y1hwn = cy2wstccxe .
P_432 ; } else { if ( l1kpu4wb4rx . kj4m4y1hwn <= cy2wstccxe . P_433 ) {
l1kpu4wb4rx . kj4m4y1hwn = cy2wstccxe . P_433 ; } } } if ( iqd4nnjnc2n .
flladf3o4m || ( l1kpu4wb4rx . bmhe2rp2ug != 0 ) ) { l1kpu4wb4rx . kj4m4y1hwn
= iqd4nnjnc2n . nauwt2pif4 ; if ( l1kpu4wb4rx . kj4m4y1hwn >= cy2wstccxe .
P_432 ) { l1kpu4wb4rx . kj4m4y1hwn = cy2wstccxe . P_432 ; } else { if (
l1kpu4wb4rx . kj4m4y1hwn <= cy2wstccxe . P_433 ) { l1kpu4wb4rx . kj4m4y1hwn =
cy2wstccxe . P_433 ; } } } if ( l1kpu4wb4rx . kj4m4y1hwn >= cy2wstccxe .
P_432 ) { l1kpu4wb4rx . kj4m4y1hwn = cy2wstccxe . P_432 ; } else { if (
l1kpu4wb4rx . kj4m4y1hwn <= cy2wstccxe . P_433 ) { l1kpu4wb4rx . kj4m4y1hwn =
cy2wstccxe . P_433 ; } } iqd4nnjnc2n . bsoahlrjiv = l1kpu4wb4rx . kj4m4y1hwn
; u0 = iqd4nnjnc2n . bsoahlrjiv ; u1 = cy2wstccxe . P_435 ; u2 = cy2wstccxe .
P_434 ; if ( u0 > u2 ) { iqd4nnjnc2n . fb2s2obyf0 = u2 ; } else if ( u0 < u1
) { iqd4nnjnc2n . fb2s2obyf0 = u1 ; } else { iqd4nnjnc2n . fb2s2obyf0 = u0 ;
} if ( rtmIsMajorTimeStep ( nehesmkint ) ) { iqd4nnjnc2n . j44l5nmvh1 =
iqd4nnjnc2n . heefjqovkk ; } iqd4nnjnc2n . iqbavtlu0x = iqd4nnjnc2n .
fb2s2obyf0 - iqd4nnjnc2n . j44l5nmvh1 ; iqd4nnjnc2n . cugk41zl3m = cy2wstccxe
. P_54 * iqd4nnjnc2n . iqbavtlu0x ; iqd4nnjnc2n . h3sgdlsv1k = l1kpu4wb4rx .
daodt1zxg3 ; iqd4nnjnc2n . cy1ksr03v3 = cy2wstccxe . P_33 * iqd4nnjnc2n .
iqbavtlu0x ; iqd4nnjnc2n . eity53wqmz = l1kpu4wb4rx . k2jw35opgq ;
iqd4nnjnc2n . nv0ihfsqee = iqd4nnjnc2n . cy1ksr03v3 - iqd4nnjnc2n .
eity53wqmz ; iqd4nnjnc2n . bmsqajkl3i = cy2wstccxe . P_63 * iqd4nnjnc2n .
nv0ihfsqee ; iqd4nnjnc2n . dkiwzssrrd = ( iqd4nnjnc2n . cugk41zl3m +
iqd4nnjnc2n . h3sgdlsv1k ) + iqd4nnjnc2n . bmsqajkl3i ; u1 = - cy2wstccxe .
P_69 ; u0 = iqd4nnjnc2n . dkiwzssrrd ; u2 = cy2wstccxe . P_69 ; if ( u0 > u2
) { iqd4nnjnc2n . et1bih2zwh = u2 ; } else if ( u0 < u1 ) { iqd4nnjnc2n .
et1bih2zwh = u1 ; } else { iqd4nnjnc2n . et1bih2zwh = u0 ; } iqd4nnjnc2n .
cg3hcg53ow = cy2wstccxe . P_438 * iqd4nnjnc2n . et1bih2zwh ; iqd4nnjnc2n .
mz1mdyrpzb = cy2wstccxe . P_25 * iqd4nnjnc2n . cg3hcg53ow ; if ( l1kpu4wb4rx
. epxooln5rc != 0 ) { l1kpu4wb4rx . e0gmlv2sjn = iqd4nnjnc2n . mz1mdyrpzb ;
if ( l1kpu4wb4rx . e0gmlv2sjn >= cy2wstccxe . P_440 ) { l1kpu4wb4rx .
e0gmlv2sjn = cy2wstccxe . P_440 ; } else { if ( l1kpu4wb4rx . e0gmlv2sjn <=
cy2wstccxe . P_441 ) { l1kpu4wb4rx . e0gmlv2sjn = cy2wstccxe . P_441 ; } } }
if ( iqd4nnjnc2n . dkq3kdkhqf || ( l1kpu4wb4rx . g5es2g4qos != 0 ) ) {
l1kpu4wb4rx . e0gmlv2sjn = iqd4nnjnc2n . mz1mdyrpzb ; if ( l1kpu4wb4rx .
e0gmlv2sjn >= cy2wstccxe . P_440 ) { l1kpu4wb4rx . e0gmlv2sjn = cy2wstccxe .
P_440 ; } else { if ( l1kpu4wb4rx . e0gmlv2sjn <= cy2wstccxe . P_441 ) {
l1kpu4wb4rx . e0gmlv2sjn = cy2wstccxe . P_441 ; } } } if ( l1kpu4wb4rx .
e0gmlv2sjn >= cy2wstccxe . P_440 ) { l1kpu4wb4rx . e0gmlv2sjn = cy2wstccxe .
P_440 ; } else { if ( l1kpu4wb4rx . e0gmlv2sjn <= cy2wstccxe . P_441 ) {
l1kpu4wb4rx . e0gmlv2sjn = cy2wstccxe . P_441 ; } } iqd4nnjnc2n . eqlmw30r4b
= l1kpu4wb4rx . e0gmlv2sjn ; u0 = iqd4nnjnc2n . eqlmw30r4b ; u1 = cy2wstccxe
. P_443 ; u2 = cy2wstccxe . P_442 ; if ( u0 > u2 ) { iqd4nnjnc2n . gqofhs32zl
= u2 ; } else if ( u0 < u1 ) { iqd4nnjnc2n . gqofhs32zl = u1 ; } else {
iqd4nnjnc2n . gqofhs32zl = u0 ; } if ( rtmIsMajorTimeStep ( nehesmkint ) ) {
iqd4nnjnc2n . ewk2raypbg = iqd4nnjnc2n . gvju2sivxf ; } iqd4nnjnc2n .
n41gnetfgk = cy2wstccxe . P_444 * iqd4nnjnc2n . ewk2raypbg ; iqd4nnjnc2n .
bcqlwdbs5s = iqd4nnjnc2n . gqofhs32zl - iqd4nnjnc2n . n41gnetfgk ;
iqd4nnjnc2n . hulk0vkayl = cy2wstccxe . P_55 * iqd4nnjnc2n . bcqlwdbs5s ;
iqd4nnjnc2n . gtb0t3ry1y = l1kpu4wb4rx . limd3gdwcq ; iqd4nnjnc2n .
e3cqs5nhjw = iqd4nnjnc2n . hulk0vkayl + iqd4nnjnc2n . gtb0t3ry1y ;
iqd4nnjnc2n . hev050xsp2 = iqd4nnjnc2n . e3cqs5nhjw ; } if (
rtmIsMajorTimeStep ( nehesmkint ) ) { l1kpu4wb4rx . nngs2uucok = iqd4nnjnc2n
. hev050xsp2 ; } first_output = false ; if ( l1kpu4wb4rx . awmyjetxto == 0.0
) { l1kpu4wb4rx . awmyjetxto = 1.0 ; first_output = true ; } if (
first_output ) { localX -> lwkodegk1s [ 0 ] = l1kpu4wb4rx . nngs2uucok ;
localX -> lwkodegk1s [ 1 ] = 0.0 ; } iqd4nnjnc2n . gh10p1ptww [ 0 ] = localX
-> lwkodegk1s [ 0 ] ; iqd4nnjnc2n . gh10p1ptww [ 1 ] = localX -> lwkodegk1s [
1 ] ; iqd4nnjnc2n . gh10p1ptww [ 2 ] = ( ( l1kpu4wb4rx . nngs2uucok - localX
-> lwkodegk1s [ 0 ] ) * 1000.0 - 2.0 * localX -> lwkodegk1s [ 1 ] ) * 1000.0
; iqd4nnjnc2n . gh10p1ptww [ 3 ] = 0.0 ; if ( rtmIsMajorTimeStep ( nehesmkint
) ) { iqd4nnjnc2n . g3kokdjcok = cy2wstccxe . P_80 - iqd4nnjnc2n . bbvyttcgmj
[ 0 ] ; iqd4nnjnc2n . npzqjhst13 = ( iqd4nnjnc2n . g3kokdjcok <= cy2wstccxe .
P_446 ) ; iqd4nnjnc2n . ghuaibncue = cy2wstccxe . P_81 - iqd4nnjnc2n .
nd2k2c1rii [ 0 ] ; iqd4nnjnc2n . kyctfbwiil = ( iqd4nnjnc2n . ghuaibncue <=
cy2wstccxe . P_447 ) ; if ( rtmIsMajorTimeStep ( nehesmkint ) ) { iqd4nnjnc2n
. pwp32mkxmp = * plr0vvmgxv ; } iqd4nnjnc2n . el0u4ptz3m = cy2wstccxe . P_26
* iqd4nnjnc2n . pwp32mkxmp ; if ( l1kpu4wb4rx . bbvyyfxxc2 != 0 ) {
l1kpu4wb4rx . jjqy4wbyuk = iqd4nnjnc2n . el0u4ptz3m ; if ( l1kpu4wb4rx .
jjqy4wbyuk >= cy2wstccxe . P_449 ) { l1kpu4wb4rx . jjqy4wbyuk = cy2wstccxe .
P_449 ; } else { if ( l1kpu4wb4rx . jjqy4wbyuk <= cy2wstccxe . P_450 ) {
l1kpu4wb4rx . jjqy4wbyuk = cy2wstccxe . P_450 ; } } } if ( iqd4nnjnc2n .
kyctfbwiil || ( l1kpu4wb4rx . flp2r32tjj != 0 ) ) { l1kpu4wb4rx . jjqy4wbyuk
= iqd4nnjnc2n . el0u4ptz3m ; if ( l1kpu4wb4rx . jjqy4wbyuk >= cy2wstccxe .
P_449 ) { l1kpu4wb4rx . jjqy4wbyuk = cy2wstccxe . P_449 ; } else { if (
l1kpu4wb4rx . jjqy4wbyuk <= cy2wstccxe . P_450 ) { l1kpu4wb4rx . jjqy4wbyuk =
cy2wstccxe . P_450 ; } } } if ( l1kpu4wb4rx . jjqy4wbyuk >= cy2wstccxe .
P_449 ) { l1kpu4wb4rx . jjqy4wbyuk = cy2wstccxe . P_449 ; } else { if (
l1kpu4wb4rx . jjqy4wbyuk <= cy2wstccxe . P_450 ) { l1kpu4wb4rx . jjqy4wbyuk =
cy2wstccxe . P_450 ; } } iqd4nnjnc2n . if2de54hzv = l1kpu4wb4rx . jjqy4wbyuk
; u0 = iqd4nnjnc2n . if2de54hzv ; u1 = cy2wstccxe . P_452 ; u2 = cy2wstccxe .
P_451 ; if ( u0 > u2 ) { iqd4nnjnc2n . nmgje50msd = u2 ; } else if ( u0 < u1
) { iqd4nnjnc2n . nmgje50msd = u1 ; } else { iqd4nnjnc2n . nmgje50msd = u0 ;
} if ( rtmIsMajorTimeStep ( nehesmkint ) ) { iqd4nnjnc2n . p0ws55j4kv =
iqd4nnjnc2n . pdhwu31m4v ; } iqd4nnjnc2n . my0xq3oeng = iqd4nnjnc2n .
nmgje50msd - iqd4nnjnc2n . p0ws55j4kv ; iqd4nnjnc2n . ijhvoblfqp = cy2wstccxe
. P_56 * iqd4nnjnc2n . my0xq3oeng ; iqd4nnjnc2n . ichqtsmstf = l1kpu4wb4rx .
lgzj3kmwmk ; iqd4nnjnc2n . lq2qrnvgbd = cy2wstccxe . P_34 * iqd4nnjnc2n .
my0xq3oeng ; iqd4nnjnc2n . ltaelwvlfx = l1kpu4wb4rx . o32wlonvfn ;
iqd4nnjnc2n . i35bda5fqu = iqd4nnjnc2n . lq2qrnvgbd - iqd4nnjnc2n .
ltaelwvlfx ; iqd4nnjnc2n . euwsshzwsz = cy2wstccxe . P_64 * iqd4nnjnc2n .
i35bda5fqu ; iqd4nnjnc2n . euc1541upk = ( iqd4nnjnc2n . ijhvoblfqp +
iqd4nnjnc2n . ichqtsmstf ) + iqd4nnjnc2n . euwsshzwsz ; u1 = - cy2wstccxe .
P_70 ; u0 = iqd4nnjnc2n . euc1541upk ; u2 = cy2wstccxe . P_70 ; if ( u0 > u2
) { iqd4nnjnc2n . nwbgtuxij0 = u2 ; } else if ( u0 < u1 ) { iqd4nnjnc2n .
nwbgtuxij0 = u1 ; } else { iqd4nnjnc2n . nwbgtuxij0 = u0 ; } iqd4nnjnc2n .
p54vogxihi = cy2wstccxe . P_455 * iqd4nnjnc2n . nwbgtuxij0 ; iqd4nnjnc2n .
ma3bvfapft = cy2wstccxe . P_27 * iqd4nnjnc2n . p54vogxihi ; if ( l1kpu4wb4rx
. etz51dx5fm != 0 ) { l1kpu4wb4rx . d5gswgg44w = iqd4nnjnc2n . ma3bvfapft ;
if ( l1kpu4wb4rx . d5gswgg44w >= cy2wstccxe . P_457 ) { l1kpu4wb4rx .
d5gswgg44w = cy2wstccxe . P_457 ; } else { if ( l1kpu4wb4rx . d5gswgg44w <=
cy2wstccxe . P_458 ) { l1kpu4wb4rx . d5gswgg44w = cy2wstccxe . P_458 ; } } }
if ( iqd4nnjnc2n . npzqjhst13 || ( l1kpu4wb4rx . gyifh2fi2t != 0 ) ) {
l1kpu4wb4rx . d5gswgg44w = iqd4nnjnc2n . ma3bvfapft ; if ( l1kpu4wb4rx .
d5gswgg44w >= cy2wstccxe . P_457 ) { l1kpu4wb4rx . d5gswgg44w = cy2wstccxe .
P_457 ; } else { if ( l1kpu4wb4rx . d5gswgg44w <= cy2wstccxe . P_458 ) {
l1kpu4wb4rx . d5gswgg44w = cy2wstccxe . P_458 ; } } } if ( l1kpu4wb4rx .
d5gswgg44w >= cy2wstccxe . P_457 ) { l1kpu4wb4rx . d5gswgg44w = cy2wstccxe .
P_457 ; } else { if ( l1kpu4wb4rx . d5gswgg44w <= cy2wstccxe . P_458 ) {
l1kpu4wb4rx . d5gswgg44w = cy2wstccxe . P_458 ; } } iqd4nnjnc2n . eqzd1gajqp
= l1kpu4wb4rx . d5gswgg44w ; u0 = iqd4nnjnc2n . eqzd1gajqp ; u1 = cy2wstccxe
. P_460 ; u2 = cy2wstccxe . P_459 ; if ( u0 > u2 ) { iqd4nnjnc2n . pwrnqu13gx
= u2 ; } else if ( u0 < u1 ) { iqd4nnjnc2n . pwrnqu13gx = u1 ; } else {
iqd4nnjnc2n . pwrnqu13gx = u0 ; } if ( rtmIsMajorTimeStep ( nehesmkint ) ) {
iqd4nnjnc2n . o0f4tiqguw = iqd4nnjnc2n . ipmgvtmz0p ; } iqd4nnjnc2n .
buswlgzps3 = cy2wstccxe . P_461 * iqd4nnjnc2n . o0f4tiqguw ; iqd4nnjnc2n .
osjyiqh0ob = iqd4nnjnc2n . pwrnqu13gx - iqd4nnjnc2n . buswlgzps3 ;
iqd4nnjnc2n . bw05k0mpda = cy2wstccxe . P_57 * iqd4nnjnc2n . osjyiqh0ob ;
iqd4nnjnc2n . auykwk5il3 = l1kpu4wb4rx . cwuv444nvd ; iqd4nnjnc2n .
nfaiw5glsx = iqd4nnjnc2n . bw05k0mpda + iqd4nnjnc2n . auykwk5il3 ;
iqd4nnjnc2n . kneg4z3eqy = iqd4nnjnc2n . nfaiw5glsx ; } if (
rtmIsMajorTimeStep ( nehesmkint ) ) { l1kpu4wb4rx . p2mtfvoju0 = iqd4nnjnc2n
. kneg4z3eqy ; } first_output = false ; if ( l1kpu4wb4rx . au1qch111s == 0.0
) { l1kpu4wb4rx . au1qch111s = 1.0 ; first_output = true ; } if (
first_output ) { localX -> kq4hzt5vr1 [ 0 ] = l1kpu4wb4rx . p2mtfvoju0 ;
localX -> kq4hzt5vr1 [ 1 ] = 0.0 ; } iqd4nnjnc2n . pwdpdq4j44 [ 0 ] = localX
-> kq4hzt5vr1 [ 0 ] ; iqd4nnjnc2n . pwdpdq4j44 [ 1 ] = localX -> kq4hzt5vr1 [
1 ] ; iqd4nnjnc2n . pwdpdq4j44 [ 2 ] = ( ( l1kpu4wb4rx . p2mtfvoju0 - localX
-> kq4hzt5vr1 [ 0 ] ) * 1000.0 - 2.0 * localX -> kq4hzt5vr1 [ 1 ] ) * 1000.0
; iqd4nnjnc2n . pwdpdq4j44 [ 3 ] = 0.0 ; if ( rtmIsMajorTimeStep ( nehesmkint
) ) { iqd4nnjnc2n . fef4xn2fp5 = cy2wstccxe . P_82 - iqd4nnjnc2n . huiknpmeom
[ 0 ] ; iqd4nnjnc2n . jngqdlisiv = ( iqd4nnjnc2n . fef4xn2fp5 <= cy2wstccxe .
P_463 ) ; iqd4nnjnc2n . lclhh42nxp = cy2wstccxe . P_83 - iqd4nnjnc2n .
mj5b4ytj5n [ 0 ] ; iqd4nnjnc2n . c2vlvnfzj2 = ( iqd4nnjnc2n . lclhh42nxp <=
cy2wstccxe . P_464 ) ; if ( rtmIsMajorTimeStep ( nehesmkint ) ) { iqd4nnjnc2n
. hazyu5dee4 = * juh3rnjpfo ; } iqd4nnjnc2n . bmymblppux = cy2wstccxe . P_28
* iqd4nnjnc2n . hazyu5dee4 ; if ( l1kpu4wb4rx . axinhpqqcc != 0 ) {
l1kpu4wb4rx . eiqgdqqruu = iqd4nnjnc2n . bmymblppux ; if ( l1kpu4wb4rx .
eiqgdqqruu >= cy2wstccxe . P_466 ) { l1kpu4wb4rx . eiqgdqqruu = cy2wstccxe .
P_466 ; } else { if ( l1kpu4wb4rx . eiqgdqqruu <= cy2wstccxe . P_467 ) {
l1kpu4wb4rx . eiqgdqqruu = cy2wstccxe . P_467 ; } } } if ( iqd4nnjnc2n .
c2vlvnfzj2 || ( l1kpu4wb4rx . cct53vt3uw != 0 ) ) { l1kpu4wb4rx . eiqgdqqruu
= iqd4nnjnc2n . bmymblppux ; if ( l1kpu4wb4rx . eiqgdqqruu >= cy2wstccxe .
P_466 ) { l1kpu4wb4rx . eiqgdqqruu = cy2wstccxe . P_466 ; } else { if (
l1kpu4wb4rx . eiqgdqqruu <= cy2wstccxe . P_467 ) { l1kpu4wb4rx . eiqgdqqruu =
cy2wstccxe . P_467 ; } } } if ( l1kpu4wb4rx . eiqgdqqruu >= cy2wstccxe .
P_466 ) { l1kpu4wb4rx . eiqgdqqruu = cy2wstccxe . P_466 ; } else { if (
l1kpu4wb4rx . eiqgdqqruu <= cy2wstccxe . P_467 ) { l1kpu4wb4rx . eiqgdqqruu =
cy2wstccxe . P_467 ; } } iqd4nnjnc2n . mtsky5ga42 = l1kpu4wb4rx . eiqgdqqruu
; u0 = iqd4nnjnc2n . mtsky5ga42 ; u1 = cy2wstccxe . P_469 ; u2 = cy2wstccxe .
P_468 ; if ( u0 > u2 ) { iqd4nnjnc2n . irzj1knv2x = u2 ; } else if ( u0 < u1
) { iqd4nnjnc2n . irzj1knv2x = u1 ; } else { iqd4nnjnc2n . irzj1knv2x = u0 ;
} if ( rtmIsMajorTimeStep ( nehesmkint ) ) { iqd4nnjnc2n . b5cyprxpem =
iqd4nnjnc2n . g350wynvmb ; } iqd4nnjnc2n . oqgie4xmek = iqd4nnjnc2n .
irzj1knv2x - iqd4nnjnc2n . b5cyprxpem ; iqd4nnjnc2n . fcda1empap = cy2wstccxe
. P_58 * iqd4nnjnc2n . oqgie4xmek ; iqd4nnjnc2n . pibccbzglq = l1kpu4wb4rx .
arjxbzyxfd ; iqd4nnjnc2n . mgwutfxaxu = cy2wstccxe . P_35 * iqd4nnjnc2n .
oqgie4xmek ; iqd4nnjnc2n . apu1zqolri = l1kpu4wb4rx . iep3kan2rd ;
iqd4nnjnc2n . pctkrqa5uw = iqd4nnjnc2n . mgwutfxaxu - iqd4nnjnc2n .
apu1zqolri ; iqd4nnjnc2n . n31zxbxxwf = cy2wstccxe . P_65 * iqd4nnjnc2n .
pctkrqa5uw ; iqd4nnjnc2n . cdv3ygqxjn = ( iqd4nnjnc2n . fcda1empap +
iqd4nnjnc2n . pibccbzglq ) + iqd4nnjnc2n . n31zxbxxwf ; u1 = - cy2wstccxe .
P_71 ; u0 = iqd4nnjnc2n . cdv3ygqxjn ; u2 = cy2wstccxe . P_71 ; if ( u0 > u2
) { iqd4nnjnc2n . hmdjfbj2px = u2 ; } else if ( u0 < u1 ) { iqd4nnjnc2n .
hmdjfbj2px = u1 ; } else { iqd4nnjnc2n . hmdjfbj2px = u0 ; } iqd4nnjnc2n .
bv43glsamx = cy2wstccxe . P_472 * iqd4nnjnc2n . hmdjfbj2px ; iqd4nnjnc2n .
bcpoonnq4a = cy2wstccxe . P_29 * iqd4nnjnc2n . bv43glsamx ; if ( l1kpu4wb4rx
. h1d4piegmo != 0 ) { l1kpu4wb4rx . m42uoygnhd = iqd4nnjnc2n . bcpoonnq4a ;
if ( l1kpu4wb4rx . m42uoygnhd >= cy2wstccxe . P_474 ) { l1kpu4wb4rx .
m42uoygnhd = cy2wstccxe . P_474 ; } else { if ( l1kpu4wb4rx . m42uoygnhd <=
cy2wstccxe . P_475 ) { l1kpu4wb4rx . m42uoygnhd = cy2wstccxe . P_475 ; } } }
if ( iqd4nnjnc2n . jngqdlisiv || ( l1kpu4wb4rx . ithaa4tvwx != 0 ) ) {
l1kpu4wb4rx . m42uoygnhd = iqd4nnjnc2n . bcpoonnq4a ; if ( l1kpu4wb4rx .
m42uoygnhd >= cy2wstccxe . P_474 ) { l1kpu4wb4rx . m42uoygnhd = cy2wstccxe .
P_474 ; } else { if ( l1kpu4wb4rx . m42uoygnhd <= cy2wstccxe . P_475 ) {
l1kpu4wb4rx . m42uoygnhd = cy2wstccxe . P_475 ; } } } if ( l1kpu4wb4rx .
m42uoygnhd >= cy2wstccxe . P_474 ) { l1kpu4wb4rx . m42uoygnhd = cy2wstccxe .
P_474 ; } else { if ( l1kpu4wb4rx . m42uoygnhd <= cy2wstccxe . P_475 ) {
l1kpu4wb4rx . m42uoygnhd = cy2wstccxe . P_475 ; } } iqd4nnjnc2n . pvnmppu5sq
= l1kpu4wb4rx . m42uoygnhd ; u0 = iqd4nnjnc2n . pvnmppu5sq ; u1 = cy2wstccxe
. P_477 ; u2 = cy2wstccxe . P_476 ; if ( u0 > u2 ) { iqd4nnjnc2n . nweukartad
= u2 ; } else if ( u0 < u1 ) { iqd4nnjnc2n . nweukartad = u1 ; } else {
iqd4nnjnc2n . nweukartad = u0 ; } if ( rtmIsMajorTimeStep ( nehesmkint ) ) {
iqd4nnjnc2n . osk5s5rhdj = iqd4nnjnc2n . f2poduj1se ; } iqd4nnjnc2n .
n531orgl43 = cy2wstccxe . P_478 * iqd4nnjnc2n . osk5s5rhdj ; iqd4nnjnc2n .
jdtpfzobve = iqd4nnjnc2n . nweukartad - iqd4nnjnc2n . n531orgl43 ;
iqd4nnjnc2n . ow0zitwej4 = cy2wstccxe . P_59 * iqd4nnjnc2n . jdtpfzobve ;
iqd4nnjnc2n . azh5omjcfp = l1kpu4wb4rx . ajirvaztbv ; iqd4nnjnc2n .
natbjm3v0a = iqd4nnjnc2n . ow0zitwej4 + iqd4nnjnc2n . azh5omjcfp ;
iqd4nnjnc2n . ehvgzznjj4 = iqd4nnjnc2n . natbjm3v0a ; } if (
rtmIsMajorTimeStep ( nehesmkint ) ) { l1kpu4wb4rx . kt2l00xp53 = iqd4nnjnc2n
. ehvgzznjj4 ; } first_output = false ; if ( l1kpu4wb4rx . koqig0mkgk == 0.0
) { l1kpu4wb4rx . koqig0mkgk = 1.0 ; first_output = true ; } if (
first_output ) { localX -> lijaeympzu [ 0 ] = l1kpu4wb4rx . kt2l00xp53 ;
localX -> lijaeympzu [ 1 ] = 0.0 ; } iqd4nnjnc2n . g4fwetwo31 [ 0 ] = localX
-> lijaeympzu [ 0 ] ; iqd4nnjnc2n . g4fwetwo31 [ 1 ] = localX -> lijaeympzu [
1 ] ; iqd4nnjnc2n . g4fwetwo31 [ 2 ] = ( ( l1kpu4wb4rx . kt2l00xp53 - localX
-> lijaeympzu [ 0 ] ) * 1000.0 - 2.0 * localX -> lijaeympzu [ 1 ] ) * 1000.0
; iqd4nnjnc2n . g4fwetwo31 [ 3 ] = 0.0 ; simulationData = (
NeslSimulationData * ) l1kpu4wb4rx . bilgsbrgvi ; time_e = rtmGetTaskTime (
nehesmkint , 0 ) ; simulationData -> mData -> mTime . mN = 1 ; simulationData
-> mData -> mTime . mX = & time_e ; simulationData -> mData -> mContStates .
mN = 30 ; simulationData -> mData -> mContStates . mX = & localX ->
lrmmgwl4ze [ 0 ] ; simulationData -> mData -> mDiscStates . mN = 0 ;
simulationData -> mData -> mDiscStates . mX = & l1kpu4wb4rx . ebgm2o4pem ;
simulationData -> mData -> mModeVector . mN = 6 ; simulationData -> mData ->
mModeVector . mX = & l1kpu4wb4rx . dvaxfxyujx [ 0 ] ; first_output = false ;
simulationData -> mData -> mFoundZcEvents = first_output ; simulationData ->
mData -> mIsMajorTimeStep = rtmIsMajorTimeStep ( nehesmkint ) ; first_output
= _ssGetSolverAssertCheck ( nehesmkint -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = first_output ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; first_output = ssIsSolverComputingJacobian (
nehesmkint -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsComputingJacobian = first_output ; simulationData -> mData ->
mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian ( nehesmkint -> _mdlRefSfcnS
) != 0 ) ; simulationData -> mData -> mIsSolverRequestingReset = false ;
tmp_j [ 0 ] = 0 ; tmp_g [ 0 ] = iqd4nnjnc2n . dxindqk5ap [ 0 ] ; tmp_g [ 1 ]
= iqd4nnjnc2n . dxindqk5ap [ 1 ] ; tmp_g [ 2 ] = iqd4nnjnc2n . dxindqk5ap [ 2
] ; tmp_g [ 3 ] = iqd4nnjnc2n . dxindqk5ap [ 3 ] ; tmp_j [ 1 ] = 4 ; tmp_g [
4 ] = iqd4nnjnc2n . mxdpm2mgmf [ 0 ] ; tmp_g [ 5 ] = iqd4nnjnc2n . mxdpm2mgmf
[ 1 ] ; tmp_g [ 6 ] = iqd4nnjnc2n . mxdpm2mgmf [ 2 ] ; tmp_g [ 7 ] =
iqd4nnjnc2n . mxdpm2mgmf [ 3 ] ; tmp_j [ 2 ] = 8 ; tmp_g [ 8 ] = iqd4nnjnc2n
. m4am5qqyxf [ 0 ] ; tmp_g [ 9 ] = iqd4nnjnc2n . m4am5qqyxf [ 1 ] ; tmp_g [
10 ] = iqd4nnjnc2n . m4am5qqyxf [ 2 ] ; tmp_g [ 11 ] = iqd4nnjnc2n .
m4am5qqyxf [ 3 ] ; tmp_j [ 3 ] = 12 ; tmp_g [ 12 ] = iqd4nnjnc2n . jshfwrvsum
[ 0 ] ; tmp_g [ 13 ] = iqd4nnjnc2n . jshfwrvsum [ 1 ] ; tmp_g [ 14 ] =
iqd4nnjnc2n . jshfwrvsum [ 2 ] ; tmp_g [ 15 ] = iqd4nnjnc2n . jshfwrvsum [ 3
] ; tmp_j [ 4 ] = 16 ; tmp_g [ 16 ] = iqd4nnjnc2n . opwk0qcg1j [ 0 ] ; tmp_g
[ 17 ] = iqd4nnjnc2n . opwk0qcg1j [ 1 ] ; tmp_g [ 18 ] = iqd4nnjnc2n .
opwk0qcg1j [ 2 ] ; tmp_g [ 19 ] = iqd4nnjnc2n . opwk0qcg1j [ 3 ] ; tmp_j [ 5
] = 20 ; tmp_g [ 20 ] = iqd4nnjnc2n . kovkup1lbe [ 0 ] ; tmp_g [ 21 ] =
iqd4nnjnc2n . kovkup1lbe [ 1 ] ; tmp_g [ 22 ] = iqd4nnjnc2n . kovkup1lbe [ 2
] ; tmp_g [ 23 ] = iqd4nnjnc2n . kovkup1lbe [ 3 ] ; tmp_j [ 6 ] = 24 ; tmp_g
[ 24 ] = iqd4nnjnc2n . mxwazunugj [ 0 ] ; tmp_g [ 25 ] = iqd4nnjnc2n .
mxwazunugj [ 1 ] ; tmp_g [ 26 ] = iqd4nnjnc2n . mxwazunugj [ 2 ] ; tmp_g [ 27
] = iqd4nnjnc2n . mxwazunugj [ 3 ] ; tmp_j [ 7 ] = 28 ; tmp_g [ 28 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 0 ] ; tmp_g [ 29 ] = iqd4nnjnc2n . l5ozfby1n1 [ 1
] ; tmp_g [ 30 ] = iqd4nnjnc2n . l5ozfby1n1 [ 2 ] ; tmp_g [ 31 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 3 ] ; tmp_j [ 8 ] = 32 ; tmp_g [ 32 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 0 ] ; tmp_g [ 33 ] = iqd4nnjnc2n . ppdvvvhxwt [ 1
] ; tmp_g [ 34 ] = iqd4nnjnc2n . ppdvvvhxwt [ 2 ] ; tmp_g [ 35 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 3 ] ; tmp_j [ 9 ] = 36 ; tmp_g [ 36 ] =
iqd4nnjnc2n . gh10p1ptww [ 0 ] ; tmp_g [ 37 ] = iqd4nnjnc2n . gh10p1ptww [ 1
] ; tmp_g [ 38 ] = iqd4nnjnc2n . gh10p1ptww [ 2 ] ; tmp_g [ 39 ] =
iqd4nnjnc2n . gh10p1ptww [ 3 ] ; tmp_j [ 10 ] = 40 ; tmp_g [ 40 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 0 ] ; tmp_g [ 41 ] = iqd4nnjnc2n . pwdpdq4j44 [ 1
] ; tmp_g [ 42 ] = iqd4nnjnc2n . pwdpdq4j44 [ 2 ] ; tmp_g [ 43 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 3 ] ; tmp_j [ 11 ] = 44 ; tmp_g [ 44 ] =
iqd4nnjnc2n . g4fwetwo31 [ 0 ] ; tmp_g [ 45 ] = iqd4nnjnc2n . g4fwetwo31 [ 1
] ; tmp_g [ 46 ] = iqd4nnjnc2n . g4fwetwo31 [ 2 ] ; tmp_g [ 47 ] =
iqd4nnjnc2n . g4fwetwo31 [ 3 ] ; tmp_j [ 12 ] = 48 ; simulationData -> mData
-> mInputValues . mN = 48 ; simulationData -> mData -> mInputValues . mX = &
tmp_g [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 13 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_j [ 0 ] ;
simulationData -> mData -> mOutputs . mN = 36 ; simulationData -> mData ->
mOutputs . mX = & iqd4nnjnc2n . a3m0ks3p0y [ 0 ] ; simulationData -> mData ->
mSampleHits . mN = 0 ; simulationData -> mData -> mSampleHits . mX = NULL ;
simulationData -> mData -> mIsFundamentalSampleHit = false ; simulationData
-> mData -> mTolerances . mN = 0 ; simulationData -> mData -> mTolerances .
mX = NULL ; simulationData -> mData -> mCstateHasChanged = false ; simulator
= ( NeslSimulator * ) l1kpu4wb4rx . gajog0hbzz ; diagnosticManager = (
NeuDiagnosticManager * ) l1kpu4wb4rx . hczaoupcph ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_e =
ne_simulator_method ( simulator , NESL_SIM_OUTPUTS , simulationData ,
diagnosticManager ) ; if ( tmp_e != 0 ) { first_output =
error_buffer_is_empty ( ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ;
if ( first_output ) { msg = rtw_diagnostics_msg ( diagnosticTree ) ;
ssSetErrorStatus ( nehesmkint -> _mdlRefSfcnS , msg ) ; } } if (
rtmIsMajorTimeStep ( nehesmkint ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( nehesmkint -> _mdlRefSfcnS ) ; }
simulationData = ( NeslSimulationData * ) l1kpu4wb4rx . nia05kgprc ; time_i =
rtmGetTaskTime ( nehesmkint , 0 ) ; simulationData -> mData -> mTime . mN = 1
; simulationData -> mData -> mTime . mX = & time_i ; simulationData -> mData
-> mContStates . mN = 0 ; simulationData -> mData -> mContStates . mX = NULL
; simulationData -> mData -> mDiscStates . mN = 0 ; simulationData -> mData
-> mDiscStates . mX = & l1kpu4wb4rx . bztbsebwen ; simulationData -> mData ->
mModeVector . mN = 0 ; simulationData -> mData -> mModeVector . mX = &
l1kpu4wb4rx . krzcukqncn ; first_output = false ; simulationData -> mData ->
mFoundZcEvents = first_output ; simulationData -> mData -> mIsMajorTimeStep =
rtmIsMajorTimeStep ( nehesmkint ) ; first_output = _ssGetSolverAssertCheck (
nehesmkint -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsSolverAssertCheck = first_output ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; simulationData -> mData ->
mIsComputingJacobian = false ; simulationData -> mData -> mIsEvaluatingF0 =
false ; simulationData -> mData -> mIsSolverRequestingReset = false ; tmp_c [
0 ] = 0 ; tmp_f [ 0 ] = iqd4nnjnc2n . dxindqk5ap [ 0 ] ; tmp_f [ 1 ] =
iqd4nnjnc2n . dxindqk5ap [ 1 ] ; tmp_f [ 2 ] = iqd4nnjnc2n . dxindqk5ap [ 2 ]
; tmp_f [ 3 ] = iqd4nnjnc2n . dxindqk5ap [ 3 ] ; tmp_c [ 1 ] = 4 ; tmp_f [ 4
] = iqd4nnjnc2n . mxdpm2mgmf [ 0 ] ; tmp_f [ 5 ] = iqd4nnjnc2n . mxdpm2mgmf [
1 ] ; tmp_f [ 6 ] = iqd4nnjnc2n . mxdpm2mgmf [ 2 ] ; tmp_f [ 7 ] =
iqd4nnjnc2n . mxdpm2mgmf [ 3 ] ; tmp_c [ 2 ] = 8 ; tmp_f [ 8 ] = iqd4nnjnc2n
. m4am5qqyxf [ 0 ] ; tmp_f [ 9 ] = iqd4nnjnc2n . m4am5qqyxf [ 1 ] ; tmp_f [
10 ] = iqd4nnjnc2n . m4am5qqyxf [ 2 ] ; tmp_f [ 11 ] = iqd4nnjnc2n .
m4am5qqyxf [ 3 ] ; tmp_c [ 3 ] = 12 ; tmp_f [ 12 ] = iqd4nnjnc2n . jshfwrvsum
[ 0 ] ; tmp_f [ 13 ] = iqd4nnjnc2n . jshfwrvsum [ 1 ] ; tmp_f [ 14 ] =
iqd4nnjnc2n . jshfwrvsum [ 2 ] ; tmp_f [ 15 ] = iqd4nnjnc2n . jshfwrvsum [ 3
] ; tmp_c [ 4 ] = 16 ; tmp_f [ 16 ] = iqd4nnjnc2n . opwk0qcg1j [ 0 ] ; tmp_f
[ 17 ] = iqd4nnjnc2n . opwk0qcg1j [ 1 ] ; tmp_f [ 18 ] = iqd4nnjnc2n .
opwk0qcg1j [ 2 ] ; tmp_f [ 19 ] = iqd4nnjnc2n . opwk0qcg1j [ 3 ] ; tmp_c [ 5
] = 20 ; tmp_f [ 20 ] = iqd4nnjnc2n . kovkup1lbe [ 0 ] ; tmp_f [ 21 ] =
iqd4nnjnc2n . kovkup1lbe [ 1 ] ; tmp_f [ 22 ] = iqd4nnjnc2n . kovkup1lbe [ 2
] ; tmp_f [ 23 ] = iqd4nnjnc2n . kovkup1lbe [ 3 ] ; tmp_c [ 6 ] = 24 ; tmp_f
[ 24 ] = iqd4nnjnc2n . mxwazunugj [ 0 ] ; tmp_f [ 25 ] = iqd4nnjnc2n .
mxwazunugj [ 1 ] ; tmp_f [ 26 ] = iqd4nnjnc2n . mxwazunugj [ 2 ] ; tmp_f [ 27
] = iqd4nnjnc2n . mxwazunugj [ 3 ] ; tmp_c [ 7 ] = 28 ; tmp_f [ 28 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 0 ] ; tmp_f [ 29 ] = iqd4nnjnc2n . l5ozfby1n1 [ 1
] ; tmp_f [ 30 ] = iqd4nnjnc2n . l5ozfby1n1 [ 2 ] ; tmp_f [ 31 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 3 ] ; tmp_c [ 8 ] = 32 ; tmp_f [ 32 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 0 ] ; tmp_f [ 33 ] = iqd4nnjnc2n . ppdvvvhxwt [ 1
] ; tmp_f [ 34 ] = iqd4nnjnc2n . ppdvvvhxwt [ 2 ] ; tmp_f [ 35 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 3 ] ; tmp_c [ 9 ] = 36 ; tmp_f [ 36 ] =
iqd4nnjnc2n . gh10p1ptww [ 0 ] ; tmp_f [ 37 ] = iqd4nnjnc2n . gh10p1ptww [ 1
] ; tmp_f [ 38 ] = iqd4nnjnc2n . gh10p1ptww [ 2 ] ; tmp_f [ 39 ] =
iqd4nnjnc2n . gh10p1ptww [ 3 ] ; tmp_c [ 10 ] = 40 ; tmp_f [ 40 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 0 ] ; tmp_f [ 41 ] = iqd4nnjnc2n . pwdpdq4j44 [ 1
] ; tmp_f [ 42 ] = iqd4nnjnc2n . pwdpdq4j44 [ 2 ] ; tmp_f [ 43 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 3 ] ; tmp_c [ 11 ] = 44 ; tmp_f [ 44 ] =
iqd4nnjnc2n . g4fwetwo31 [ 0 ] ; tmp_f [ 45 ] = iqd4nnjnc2n . g4fwetwo31 [ 1
] ; tmp_f [ 46 ] = iqd4nnjnc2n . g4fwetwo31 [ 2 ] ; tmp_f [ 47 ] =
iqd4nnjnc2n . g4fwetwo31 [ 3 ] ; tmp_c [ 12 ] = 48 ; memcpy ( & tmp_f [ 48 ]
, & iqd4nnjnc2n . a3m0ks3p0y [ 0 ] , 36U * sizeof ( real_T ) ) ; tmp_c [ 13 ]
= 84 ; simulationData -> mData -> mInputValues . mN = 84 ; simulationData ->
mData -> mInputValues . mX = & tmp_f [ 0 ] ; simulationData -> mData ->
mInputOffsets . mN = 14 ; simulationData -> mData -> mInputOffsets . mX = &
tmp_c [ 0 ] ; simulationData -> mData -> mOutputs . mN = 18 ; simulationData
-> mData -> mOutputs . mX = & iqd4nnjnc2n . one4ycp0a5 [ 0 ] ; simulationData
-> mData -> mSampleHits . mN = 0 ; simulationData -> mData -> mSampleHits .
mX = NULL ; simulationData -> mData -> mIsFundamentalSampleHit = false ;
simulationData -> mData -> mTolerances . mN = 0 ; simulationData -> mData ->
mTolerances . mX = NULL ; simulationData -> mData -> mCstateHasChanged =
false ; simulator = ( NeslSimulator * ) l1kpu4wb4rx . ew4t3cugld ;
diagnosticManager = ( NeuDiagnosticManager * ) l1kpu4wb4rx . mihmamakpr ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; tmp_e = ne_simulator_method ( simulator , NESL_SIM_OUTPUTS ,
simulationData , diagnosticManager ) ; if ( tmp_e != 0 ) { first_output =
error_buffer_is_empty ( ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ;
if ( first_output ) { msg = rtw_diagnostics_msg ( diagnosticTree ) ;
ssSetErrorStatus ( nehesmkint -> _mdlRefSfcnS , msg ) ; } } if (
rtmIsMajorTimeStep ( nehesmkint ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( nehesmkint -> _mdlRefSfcnS ) ; }
iqd4nnjnc2n . hhczjtzyj5 [ 0 ] = iqd4nnjnc2n . one4ycp0a5 [ 0 ] ; iqd4nnjnc2n
. hhczjtzyj5 [ 1 ] = 0.0 ; iqd4nnjnc2n . hhczjtzyj5 [ 2 ] = 0.0 ; iqd4nnjnc2n
. hhczjtzyj5 [ 3 ] = 0.0 ; iqd4nnjnc2n . imtlp51aqd [ 0 ] = iqd4nnjnc2n .
one4ycp0a5 [ 1 ] ; iqd4nnjnc2n . imtlp51aqd [ 1 ] = 0.0 ; iqd4nnjnc2n .
imtlp51aqd [ 2 ] = 0.0 ; iqd4nnjnc2n . imtlp51aqd [ 3 ] = 0.0 ; iqd4nnjnc2n .
oe1dnrny2q [ 0 ] = iqd4nnjnc2n . one4ycp0a5 [ 2 ] ; iqd4nnjnc2n . oe1dnrny2q
[ 1 ] = 0.0 ; iqd4nnjnc2n . oe1dnrny2q [ 2 ] = 0.0 ; iqd4nnjnc2n . oe1dnrny2q
[ 3 ] = 0.0 ; iqd4nnjnc2n . e3os4rwhiv [ 0 ] = iqd4nnjnc2n . one4ycp0a5 [ 3 ]
; iqd4nnjnc2n . e3os4rwhiv [ 1 ] = 0.0 ; iqd4nnjnc2n . e3os4rwhiv [ 2 ] = 0.0
; iqd4nnjnc2n . e3os4rwhiv [ 3 ] = 0.0 ; iqd4nnjnc2n . bfaefzzyat [ 0 ] =
iqd4nnjnc2n . one4ycp0a5 [ 4 ] ; iqd4nnjnc2n . bfaefzzyat [ 1 ] = 0.0 ;
iqd4nnjnc2n . bfaefzzyat [ 2 ] = 0.0 ; iqd4nnjnc2n . bfaefzzyat [ 3 ] = 0.0 ;
iqd4nnjnc2n . b10z030dj4 [ 0 ] = iqd4nnjnc2n . one4ycp0a5 [ 5 ] ; iqd4nnjnc2n
. b10z030dj4 [ 1 ] = 0.0 ; iqd4nnjnc2n . b10z030dj4 [ 2 ] = 0.0 ; iqd4nnjnc2n
. b10z030dj4 [ 3 ] = 0.0 ; iqd4nnjnc2n . do2div5dmu = cy2wstccxe . P_480 *
iqd4nnjnc2n . one4ycp0a5 [ 7 ] ; iqd4nnjnc2n . inbc5rmj0k = cy2wstccxe .
P_481 * iqd4nnjnc2n . one4ycp0a5 [ 15 ] ; iqd4nnjnc2n . datlkjknld =
cy2wstccxe . P_482 * iqd4nnjnc2n . inbc5rmj0k ; iqd4nnjnc2n . ltqcojipph =
cy2wstccxe . P_483 * iqd4nnjnc2n . do2div5dmu ; iqd4nnjnc2n . nlm325sgjs =
cy2wstccxe . P_484 * iqd4nnjnc2n . one4ycp0a5 [ 9 ] ; iqd4nnjnc2n .
ahkt3v2tkj = cy2wstccxe . P_485 * iqd4nnjnc2n . nlm325sgjs ; iqd4nnjnc2n .
lnviaa3aja = cy2wstccxe . P_486 * iqd4nnjnc2n . one4ycp0a5 [ 13 ] ;
iqd4nnjnc2n . pjmyemwyst = cy2wstccxe . P_487 * iqd4nnjnc2n . lnviaa3aja ;
iqd4nnjnc2n . lvgwomq1ya = cy2wstccxe . P_488 * iqd4nnjnc2n . one4ycp0a5 [ 11
] ; iqd4nnjnc2n . kwvx5icu52 = cy2wstccxe . P_489 * iqd4nnjnc2n . lvgwomq1ya
; iqd4nnjnc2n . aklkh2iyp2 = cy2wstccxe . P_490 * iqd4nnjnc2n . one4ycp0a5 [
17 ] ; iqd4nnjnc2n . l00kscgz5x = cy2wstccxe . P_491 * iqd4nnjnc2n .
aklkh2iyp2 ; if ( rtmIsMajorTimeStep ( nehesmkint ) ) { u1 =
muDoubleScalarMax ( iqd4nnjnc2n . gvxqq2drkr [ 0 ] , cy2wstccxe . P_73 ) ;
iqd4nnjnc2n . p2jg50l41x = u1 ; iqd4nnjnc2n . dzs221sche = ( real_T ) (
iqd4nnjnc2n . p2jg50l41x == 0.0 ) * 2.2204460492503131e-16 + iqd4nnjnc2n .
p2jg50l41x ; iqd4nnjnc2n . om1dpdvyxj = iqd4nnjnc2n . gsbroayuv4 -
iqd4nnjnc2n . nuophhg5zj ; iqd4nnjnc2n . l24gr3t25r = 1.0 / iqd4nnjnc2n .
dzs221sche * iqd4nnjnc2n . om1dpdvyxj ; iqd4nnjnc2n . fgqlt0352h = cy2wstccxe
. P_36 * iqd4nnjnc2n . ixesed2ean ; u1 = muDoubleScalarMax ( iqd4nnjnc2n .
lglx1tyi3w [ 0 ] , cy2wstccxe . P_75 ) ; iqd4nnjnc2n . gsoejj5gry = u1 ;
iqd4nnjnc2n . ak2zdkdvjm = ( real_T ) ( iqd4nnjnc2n . gsoejj5gry == 0.0 ) *
2.2204460492503131e-16 + iqd4nnjnc2n . gsoejj5gry ; iqd4nnjnc2n . no0iooeye4
= iqd4nnjnc2n . cc1ikppcoe - iqd4nnjnc2n . cjiwv41dtz ; iqd4nnjnc2n .
cmfmx0kuqh = 1.0 / iqd4nnjnc2n . ak2zdkdvjm * iqd4nnjnc2n . no0iooeye4 ;
iqd4nnjnc2n . bqdylagldh = cy2wstccxe . P_37 * iqd4nnjnc2n . owxogzl3qh ; u1
= muDoubleScalarMax ( iqd4nnjnc2n . gimccxcbis [ 0 ] , cy2wstccxe . P_77 ) ;
iqd4nnjnc2n . cygpl2eh3n = u1 ; iqd4nnjnc2n . eokjyir44v = ( real_T ) (
iqd4nnjnc2n . cygpl2eh3n == 0.0 ) * 2.2204460492503131e-16 + iqd4nnjnc2n .
cygpl2eh3n ; iqd4nnjnc2n . dunjupvfq0 = iqd4nnjnc2n . m2w4u0arlu -
iqd4nnjnc2n . fs3dc0tbpl ; iqd4nnjnc2n . jtqezz3n5v = 1.0 / iqd4nnjnc2n .
eokjyir44v * iqd4nnjnc2n . dunjupvfq0 ; iqd4nnjnc2n . d4ckjpxf4d = cy2wstccxe
. P_38 * iqd4nnjnc2n . mvmmo5i5vd ; u1 = muDoubleScalarMax ( iqd4nnjnc2n .
dfa1yu3sfp [ 0 ] , cy2wstccxe . P_79 ) ; iqd4nnjnc2n . jfrwhhaoxa = u1 ;
iqd4nnjnc2n . jwy0sllq0r = ( real_T ) ( iqd4nnjnc2n . jfrwhhaoxa == 0.0 ) *
2.2204460492503131e-16 + iqd4nnjnc2n . jfrwhhaoxa ; iqd4nnjnc2n . isxtmltnln
= iqd4nnjnc2n . nauwt2pif4 - iqd4nnjnc2n . fb2s2obyf0 ; iqd4nnjnc2n .
bi2q4i3qsl = 1.0 / iqd4nnjnc2n . jwy0sllq0r * iqd4nnjnc2n . isxtmltnln ;
iqd4nnjnc2n . bd4upxutxh = cy2wstccxe . P_39 * iqd4nnjnc2n . iqbavtlu0x ; u1
= muDoubleScalarMax ( iqd4nnjnc2n . nd2k2c1rii [ 0 ] , cy2wstccxe . P_81 ) ;
iqd4nnjnc2n . op3kzfupwu = u1 ; iqd4nnjnc2n . ac5tg4zqmv = ( real_T ) (
iqd4nnjnc2n . op3kzfupwu == 0.0 ) * 2.2204460492503131e-16 + iqd4nnjnc2n .
op3kzfupwu ; iqd4nnjnc2n . o1p24pcmux = iqd4nnjnc2n . el0u4ptz3m -
iqd4nnjnc2n . nmgje50msd ; iqd4nnjnc2n . mmdwsrlci3 = 1.0 / iqd4nnjnc2n .
ac5tg4zqmv * iqd4nnjnc2n . o1p24pcmux ; iqd4nnjnc2n . hyezcvutd0 = cy2wstccxe
. P_40 * iqd4nnjnc2n . my0xq3oeng ; u1 = muDoubleScalarMax ( iqd4nnjnc2n .
mj5b4ytj5n [ 0 ] , cy2wstccxe . P_83 ) ; iqd4nnjnc2n . krazaowazm = u1 ;
iqd4nnjnc2n . h5dhbabhyc = ( real_T ) ( iqd4nnjnc2n . krazaowazm == 0.0 ) *
2.2204460492503131e-16 + iqd4nnjnc2n . krazaowazm ; iqd4nnjnc2n . gocnlro3ua
= iqd4nnjnc2n . bmymblppux - iqd4nnjnc2n . irzj1knv2x ; iqd4nnjnc2n .
dr00wzmmfp = 1.0 / iqd4nnjnc2n . h5dhbabhyc * iqd4nnjnc2n . gocnlro3ua ;
iqd4nnjnc2n . pllzd1yzu1 = cy2wstccxe . P_41 * iqd4nnjnc2n . oqgie4xmek ; u1
= muDoubleScalarMax ( iqd4nnjnc2n . dvdfpqupvw [ 0 ] , cy2wstccxe . P_72 ) ;
iqd4nnjnc2n . goceextyjn = u1 ; iqd4nnjnc2n . bsldqtkyrx = ( real_T ) (
iqd4nnjnc2n . goceextyjn == 0.0 ) * 2.2204460492503131e-16 + iqd4nnjnc2n .
goceextyjn ; iqd4nnjnc2n . m33loiozqp = iqd4nnjnc2n . lb5otvwgy1 -
iqd4nnjnc2n . aqqltp4gox ; iqd4nnjnc2n . dtzo3eih3h = 1.0 / iqd4nnjnc2n .
bsldqtkyrx * iqd4nnjnc2n . m33loiozqp ; iqd4nnjnc2n . by0cvwg5fo = cy2wstccxe
. P_42 * iqd4nnjnc2n . ga313eveon ; u1 = muDoubleScalarMax ( iqd4nnjnc2n .
ecllldohtk [ 0 ] , cy2wstccxe . P_74 ) ; iqd4nnjnc2n . grfgj4ibi4 = u1 ;
iqd4nnjnc2n . o50nw3ugmm = ( real_T ) ( iqd4nnjnc2n . grfgj4ibi4 == 0.0 ) *
2.2204460492503131e-16 + iqd4nnjnc2n . grfgj4ibi4 ; iqd4nnjnc2n . fkurul1irj
= iqd4nnjnc2n . hihw2kx10l - iqd4nnjnc2n . lxk3aawz4t ; iqd4nnjnc2n .
ktj3bc45nf = 1.0 / iqd4nnjnc2n . o50nw3ugmm * iqd4nnjnc2n . fkurul1irj ;
iqd4nnjnc2n . ll2bp3mzb5 = cy2wstccxe . P_43 * iqd4nnjnc2n . fw0cndgkar ; u1
= muDoubleScalarMax ( iqd4nnjnc2n . ni2moweccg [ 0 ] , cy2wstccxe . P_76 ) ;
iqd4nnjnc2n . azkpe3xngh = u1 ; iqd4nnjnc2n . bplheqo1n1 = ( real_T ) (
iqd4nnjnc2n . azkpe3xngh == 0.0 ) * 2.2204460492503131e-16 + iqd4nnjnc2n .
azkpe3xngh ; iqd4nnjnc2n . iqorpfqvex = iqd4nnjnc2n . kplrhafmh3 -
iqd4nnjnc2n . d3bcnxa0ko ; iqd4nnjnc2n . dfhhva0f3s = 1.0 / iqd4nnjnc2n .
bplheqo1n1 * iqd4nnjnc2n . iqorpfqvex ; iqd4nnjnc2n . bmjg0kms3r = cy2wstccxe
. P_44 * iqd4nnjnc2n . pqudmcvigc ; u1 = muDoubleScalarMax ( iqd4nnjnc2n .
laxrqi2iig [ 0 ] , cy2wstccxe . P_78 ) ; iqd4nnjnc2n . nbvso2z4hg = u1 ;
iqd4nnjnc2n . itxq3inszm = ( real_T ) ( iqd4nnjnc2n . nbvso2z4hg == 0.0 ) *
2.2204460492503131e-16 + iqd4nnjnc2n . nbvso2z4hg ; iqd4nnjnc2n . ijctsqavfk
= iqd4nnjnc2n . mz1mdyrpzb - iqd4nnjnc2n . gqofhs32zl ; iqd4nnjnc2n .
hb4rbdqlcw = 1.0 / iqd4nnjnc2n . itxq3inszm * iqd4nnjnc2n . ijctsqavfk ;
iqd4nnjnc2n . eiic0jvpln = cy2wstccxe . P_45 * iqd4nnjnc2n . bcqlwdbs5s ; u1
= muDoubleScalarMax ( iqd4nnjnc2n . bbvyttcgmj [ 0 ] , cy2wstccxe . P_80 ) ;
iqd4nnjnc2n . eohyobbmek = u1 ; iqd4nnjnc2n . m2kpw0vl0e = ( real_T ) (
iqd4nnjnc2n . eohyobbmek == 0.0 ) * 2.2204460492503131e-16 + iqd4nnjnc2n .
eohyobbmek ; iqd4nnjnc2n . m0f3jhv5qh = iqd4nnjnc2n . ma3bvfapft -
iqd4nnjnc2n . pwrnqu13gx ; iqd4nnjnc2n . jsrt3bznjs = 1.0 / iqd4nnjnc2n .
m2kpw0vl0e * iqd4nnjnc2n . m0f3jhv5qh ; iqd4nnjnc2n . muix2l5juf = cy2wstccxe
. P_46 * iqd4nnjnc2n . osjyiqh0ob ; u1 = muDoubleScalarMax ( iqd4nnjnc2n .
huiknpmeom [ 0 ] , cy2wstccxe . P_82 ) ; iqd4nnjnc2n . feo1305x5l = u1 ;
iqd4nnjnc2n . fdlp20qiat = ( real_T ) ( iqd4nnjnc2n . feo1305x5l == 0.0 ) *
2.2204460492503131e-16 + iqd4nnjnc2n . feo1305x5l ; iqd4nnjnc2n . hot10qhgpk
= iqd4nnjnc2n . bcpoonnq4a - iqd4nnjnc2n . nweukartad ; iqd4nnjnc2n .
hdtqbblv4p = 1.0 / iqd4nnjnc2n . fdlp20qiat * iqd4nnjnc2n . hot10qhgpk ;
iqd4nnjnc2n . ogguiilgfn = cy2wstccxe . P_47 * iqd4nnjnc2n . jdtpfzobve ; } }
void a5w1dgbmqf ( real_T * localX_ ) { k2snwiamgb * const nehesmkint = & (
ope1wg3cbz . rtm ) ; pig3puin4o2 * localX = ( pig3puin4o2 * ) localX_ ;
NeslSimulationData * simulationData ; real_T time ; boolean_T tmp ; real_T
tmp_p [ 24 ] ; int_T tmp_e [ 7 ] ; NeslSimulator * simulator ;
NeuDiagnosticManager * diagnosticManager ; NeuDiagnosticTree * diagnosticTree
; int32_T tmp_i ; char * msg ; real_T time_p ; real_T tmp_m [ 48 ] ; int_T
tmp_g [ 13 ] ; simulationData = ( NeslSimulationData * ) l1kpu4wb4rx .
mtmd51jfqa ; time = rtmGetTaskTime ( nehesmkint , 0 ) ; simulationData ->
mData -> mTime . mN = 1 ; simulationData -> mData -> mTime . mX = & time ;
simulationData -> mData -> mContStates . mN = 24 ; simulationData -> mData ->
mContStates . mX = & localX -> kvq2o0kyuy [ 0 ] ; simulationData -> mData ->
mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX = &
l1kpu4wb4rx . i3bqhqdooa ; simulationData -> mData -> mModeVector . mN = 0 ;
simulationData -> mData -> mModeVector . mX = & l1kpu4wb4rx . psdfuxjdsv ;
tmp = false ; simulationData -> mData -> mFoundZcEvents = tmp ;
simulationData -> mData -> mIsMajorTimeStep = rtmIsMajorTimeStep ( nehesmkint
) ; tmp = _ssGetSolverAssertCheck ( nehesmkint -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsSolverAssertCheck = tmp ; simulationData ->
mData -> mIsSolverCheckingCIC = false ; tmp = ssIsSolverComputingJacobian (
nehesmkint -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsComputingJacobian = tmp ; simulationData -> mData -> mIsEvaluatingF0 = (
ssGetEvaluatingF0ForJacobian ( nehesmkint -> _mdlRefSfcnS ) != 0 ) ;
simulationData -> mData -> mIsSolverRequestingReset = false ; tmp_e [ 0 ] = 0
; tmp_p [ 0 ] = iqd4nnjnc2n . hhczjtzyj5 [ 0 ] ; tmp_p [ 1 ] = iqd4nnjnc2n .
hhczjtzyj5 [ 1 ] ; tmp_p [ 2 ] = iqd4nnjnc2n . hhczjtzyj5 [ 2 ] ; tmp_p [ 3 ]
= iqd4nnjnc2n . hhczjtzyj5 [ 3 ] ; tmp_e [ 1 ] = 4 ; tmp_p [ 4 ] =
iqd4nnjnc2n . imtlp51aqd [ 0 ] ; tmp_p [ 5 ] = iqd4nnjnc2n . imtlp51aqd [ 1 ]
; tmp_p [ 6 ] = iqd4nnjnc2n . imtlp51aqd [ 2 ] ; tmp_p [ 7 ] = iqd4nnjnc2n .
imtlp51aqd [ 3 ] ; tmp_e [ 2 ] = 8 ; tmp_p [ 8 ] = iqd4nnjnc2n . oe1dnrny2q [
0 ] ; tmp_p [ 9 ] = iqd4nnjnc2n . oe1dnrny2q [ 1 ] ; tmp_p [ 10 ] =
iqd4nnjnc2n . oe1dnrny2q [ 2 ] ; tmp_p [ 11 ] = iqd4nnjnc2n . oe1dnrny2q [ 3
] ; tmp_e [ 3 ] = 12 ; tmp_p [ 12 ] = iqd4nnjnc2n . e3os4rwhiv [ 0 ] ; tmp_p
[ 13 ] = iqd4nnjnc2n . e3os4rwhiv [ 1 ] ; tmp_p [ 14 ] = iqd4nnjnc2n .
e3os4rwhiv [ 2 ] ; tmp_p [ 15 ] = iqd4nnjnc2n . e3os4rwhiv [ 3 ] ; tmp_e [ 4
] = 16 ; tmp_p [ 16 ] = iqd4nnjnc2n . bfaefzzyat [ 0 ] ; tmp_p [ 17 ] =
iqd4nnjnc2n . bfaefzzyat [ 1 ] ; tmp_p [ 18 ] = iqd4nnjnc2n . bfaefzzyat [ 2
] ; tmp_p [ 19 ] = iqd4nnjnc2n . bfaefzzyat [ 3 ] ; tmp_e [ 5 ] = 20 ; tmp_p
[ 20 ] = iqd4nnjnc2n . b10z030dj4 [ 0 ] ; tmp_p [ 21 ] = iqd4nnjnc2n .
b10z030dj4 [ 1 ] ; tmp_p [ 22 ] = iqd4nnjnc2n . b10z030dj4 [ 2 ] ; tmp_p [ 23
] = iqd4nnjnc2n . b10z030dj4 [ 3 ] ; tmp_e [ 6 ] = 24 ; simulationData ->
mData -> mInputValues . mN = 24 ; simulationData -> mData -> mInputValues .
mX = & tmp_p [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 7 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_e [ 0 ] ; simulator = (
NeslSimulator * ) l1kpu4wb4rx . es1n0xuy5w ; diagnosticManager = (
NeuDiagnosticManager * ) l1kpu4wb4rx . pryqdadyrt ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_i =
ne_simulator_method ( simulator , NESL_SIM_UPDATE , simulationData ,
diagnosticManager ) ; if ( tmp_i != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } if ( rtmIsMajorTimeStep ( nehesmkint ) ) {
l1kpu4wb4rx . bepyqlw5qu = 0U ; l1kpu4wb4rx . mikve0glkh += cy2wstccxe .
P_380 * iqd4nnjnc2n . l24gr3t25r ; if ( l1kpu4wb4rx . mikve0glkh >=
cy2wstccxe . P_381 ) { l1kpu4wb4rx . mikve0glkh = cy2wstccxe . P_381 ; } else
{ if ( l1kpu4wb4rx . mikve0glkh <= cy2wstccxe . P_382 ) { l1kpu4wb4rx .
mikve0glkh = cy2wstccxe . P_382 ; } } l1kpu4wb4rx . dyn5irgyjj = ( int8_T )
iqd4nnjnc2n . bwnjfsl54j ; l1kpu4wb4rx . ccquv3ehj4 += cy2wstccxe . P_385 *
iqd4nnjnc2n . fgqlt0352h ; l1kpu4wb4rx . pbidohzefw += cy2wstccxe . P_386 *
iqd4nnjnc2n . cqom2nhmk2 ; l1kpu4wb4rx . hritc1babc = 0U ; l1kpu4wb4rx .
lzgpy1pmbg += cy2wstccxe . P_388 * iqd4nnjnc2n . dtzo3eih3h ; if (
l1kpu4wb4rx . lzgpy1pmbg >= cy2wstccxe . P_389 ) { l1kpu4wb4rx . lzgpy1pmbg =
cy2wstccxe . P_389 ; } else { if ( l1kpu4wb4rx . lzgpy1pmbg <= cy2wstccxe .
P_390 ) { l1kpu4wb4rx . lzgpy1pmbg = cy2wstccxe . P_390 ; } } l1kpu4wb4rx .
kayrm3qjer = ( int8_T ) iqd4nnjnc2n . hwmhajtbh2 ; l1kpu4wb4rx . ndcz2pevdt
+= cy2wstccxe . P_394 * iqd4nnjnc2n . by0cvwg5fo ; l1kpu4wb4rx . jpgsqiqfhq =
0U ; l1kpu4wb4rx . grtf40g3km += cy2wstccxe . P_397 * iqd4nnjnc2n .
cmfmx0kuqh ; if ( l1kpu4wb4rx . grtf40g3km >= cy2wstccxe . P_398 ) {
l1kpu4wb4rx . grtf40g3km = cy2wstccxe . P_398 ; } else { if ( l1kpu4wb4rx .
grtf40g3km <= cy2wstccxe . P_399 ) { l1kpu4wb4rx . grtf40g3km = cy2wstccxe .
P_399 ; } } l1kpu4wb4rx . h2jjjrmgpx = ( int8_T ) iqd4nnjnc2n . bdsmqsg0a3 ;
l1kpu4wb4rx . ipoqi0vxan += cy2wstccxe . P_402 * iqd4nnjnc2n . bqdylagldh ;
l1kpu4wb4rx . h5eac0mibo += cy2wstccxe . P_403 * iqd4nnjnc2n . euxeitc2fq ;
l1kpu4wb4rx . n1umrqm4ou = 0U ; l1kpu4wb4rx . pa4czare1d += cy2wstccxe .
P_405 * iqd4nnjnc2n . ktj3bc45nf ; if ( l1kpu4wb4rx . pa4czare1d >=
cy2wstccxe . P_406 ) { l1kpu4wb4rx . pa4czare1d = cy2wstccxe . P_406 ; } else
{ if ( l1kpu4wb4rx . pa4czare1d <= cy2wstccxe . P_407 ) { l1kpu4wb4rx .
pa4czare1d = cy2wstccxe . P_407 ; } } l1kpu4wb4rx . n1r0ywaznf = ( int8_T )
iqd4nnjnc2n . icvmqhdxij ; l1kpu4wb4rx . ckwjuadpca += cy2wstccxe . P_411 *
iqd4nnjnc2n . ll2bp3mzb5 ; l1kpu4wb4rx . akgp3l4qdu = 0U ; l1kpu4wb4rx .
ouygc4kcvb += cy2wstccxe . P_414 * iqd4nnjnc2n . jtqezz3n5v ; if (
l1kpu4wb4rx . ouygc4kcvb >= cy2wstccxe . P_415 ) { l1kpu4wb4rx . ouygc4kcvb =
cy2wstccxe . P_415 ; } else { if ( l1kpu4wb4rx . ouygc4kcvb <= cy2wstccxe .
P_416 ) { l1kpu4wb4rx . ouygc4kcvb = cy2wstccxe . P_416 ; } } l1kpu4wb4rx .
alglf53p5h = ( int8_T ) iqd4nnjnc2n . aajfu1lxi5 ; l1kpu4wb4rx . kjml2jdhog
+= cy2wstccxe . P_419 * iqd4nnjnc2n . d4ckjpxf4d ; l1kpu4wb4rx . onzlg3sfc1
+= cy2wstccxe . P_420 * iqd4nnjnc2n . nzchhvzjwf ; l1kpu4wb4rx . nw11erxd40 =
0U ; l1kpu4wb4rx . dsxwjihxvj += cy2wstccxe . P_422 * iqd4nnjnc2n .
dfhhva0f3s ; if ( l1kpu4wb4rx . dsxwjihxvj >= cy2wstccxe . P_423 ) {
l1kpu4wb4rx . dsxwjihxvj = cy2wstccxe . P_423 ; } else { if ( l1kpu4wb4rx .
dsxwjihxvj <= cy2wstccxe . P_424 ) { l1kpu4wb4rx . dsxwjihxvj = cy2wstccxe .
P_424 ; } } l1kpu4wb4rx . mmmkxfaf4h = ( int8_T ) iqd4nnjnc2n . dfgizgbrra ;
l1kpu4wb4rx . aqmkm5qp10 += cy2wstccxe . P_428 * iqd4nnjnc2n . bmjg0kms3r ;
l1kpu4wb4rx . dceylbyzbv = 0U ; l1kpu4wb4rx . kj4m4y1hwn += cy2wstccxe .
P_431 * iqd4nnjnc2n . bi2q4i3qsl ; if ( l1kpu4wb4rx . kj4m4y1hwn >=
cy2wstccxe . P_432 ) { l1kpu4wb4rx . kj4m4y1hwn = cy2wstccxe . P_432 ; } else
{ if ( l1kpu4wb4rx . kj4m4y1hwn <= cy2wstccxe . P_433 ) { l1kpu4wb4rx .
kj4m4y1hwn = cy2wstccxe . P_433 ; } } l1kpu4wb4rx . bmhe2rp2ug = ( int8_T )
iqd4nnjnc2n . flladf3o4m ; l1kpu4wb4rx . daodt1zxg3 += cy2wstccxe . P_436 *
iqd4nnjnc2n . bd4upxutxh ; l1kpu4wb4rx . k2jw35opgq += cy2wstccxe . P_437 *
iqd4nnjnc2n . bmsqajkl3i ; l1kpu4wb4rx . epxooln5rc = 0U ; l1kpu4wb4rx .
e0gmlv2sjn += cy2wstccxe . P_439 * iqd4nnjnc2n . hb4rbdqlcw ; if (
l1kpu4wb4rx . e0gmlv2sjn >= cy2wstccxe . P_440 ) { l1kpu4wb4rx . e0gmlv2sjn =
cy2wstccxe . P_440 ; } else { if ( l1kpu4wb4rx . e0gmlv2sjn <= cy2wstccxe .
P_441 ) { l1kpu4wb4rx . e0gmlv2sjn = cy2wstccxe . P_441 ; } } l1kpu4wb4rx .
g5es2g4qos = ( int8_T ) iqd4nnjnc2n . dkq3kdkhqf ; l1kpu4wb4rx . limd3gdwcq
+= cy2wstccxe . P_445 * iqd4nnjnc2n . eiic0jvpln ; l1kpu4wb4rx . bbvyyfxxc2 =
0U ; l1kpu4wb4rx . jjqy4wbyuk += cy2wstccxe . P_448 * iqd4nnjnc2n .
mmdwsrlci3 ; if ( l1kpu4wb4rx . jjqy4wbyuk >= cy2wstccxe . P_449 ) {
l1kpu4wb4rx . jjqy4wbyuk = cy2wstccxe . P_449 ; } else { if ( l1kpu4wb4rx .
jjqy4wbyuk <= cy2wstccxe . P_450 ) { l1kpu4wb4rx . jjqy4wbyuk = cy2wstccxe .
P_450 ; } } l1kpu4wb4rx . flp2r32tjj = ( int8_T ) iqd4nnjnc2n . kyctfbwiil ;
l1kpu4wb4rx . lgzj3kmwmk += cy2wstccxe . P_453 * iqd4nnjnc2n . hyezcvutd0 ;
l1kpu4wb4rx . o32wlonvfn += cy2wstccxe . P_454 * iqd4nnjnc2n . euwsshzwsz ;
l1kpu4wb4rx . etz51dx5fm = 0U ; l1kpu4wb4rx . d5gswgg44w += cy2wstccxe .
P_456 * iqd4nnjnc2n . jsrt3bznjs ; if ( l1kpu4wb4rx . d5gswgg44w >=
cy2wstccxe . P_457 ) { l1kpu4wb4rx . d5gswgg44w = cy2wstccxe . P_457 ; } else
{ if ( l1kpu4wb4rx . d5gswgg44w <= cy2wstccxe . P_458 ) { l1kpu4wb4rx .
d5gswgg44w = cy2wstccxe . P_458 ; } } l1kpu4wb4rx . gyifh2fi2t = ( int8_T )
iqd4nnjnc2n . npzqjhst13 ; l1kpu4wb4rx . cwuv444nvd += cy2wstccxe . P_462 *
iqd4nnjnc2n . muix2l5juf ; l1kpu4wb4rx . axinhpqqcc = 0U ; l1kpu4wb4rx .
eiqgdqqruu += cy2wstccxe . P_465 * iqd4nnjnc2n . dr00wzmmfp ; if (
l1kpu4wb4rx . eiqgdqqruu >= cy2wstccxe . P_466 ) { l1kpu4wb4rx . eiqgdqqruu =
cy2wstccxe . P_466 ; } else { if ( l1kpu4wb4rx . eiqgdqqruu <= cy2wstccxe .
P_467 ) { l1kpu4wb4rx . eiqgdqqruu = cy2wstccxe . P_467 ; } } l1kpu4wb4rx .
cct53vt3uw = ( int8_T ) iqd4nnjnc2n . c2vlvnfzj2 ; l1kpu4wb4rx . arjxbzyxfd
+= cy2wstccxe . P_470 * iqd4nnjnc2n . pllzd1yzu1 ; l1kpu4wb4rx . iep3kan2rd
+= cy2wstccxe . P_471 * iqd4nnjnc2n . n31zxbxxwf ; l1kpu4wb4rx . h1d4piegmo =
0U ; l1kpu4wb4rx . m42uoygnhd += cy2wstccxe . P_473 * iqd4nnjnc2n .
hdtqbblv4p ; if ( l1kpu4wb4rx . m42uoygnhd >= cy2wstccxe . P_474 ) {
l1kpu4wb4rx . m42uoygnhd = cy2wstccxe . P_474 ; } else { if ( l1kpu4wb4rx .
m42uoygnhd <= cy2wstccxe . P_475 ) { l1kpu4wb4rx . m42uoygnhd = cy2wstccxe .
P_475 ; } } l1kpu4wb4rx . ithaa4tvwx = ( int8_T ) iqd4nnjnc2n . jngqdlisiv ;
l1kpu4wb4rx . ajirvaztbv += cy2wstccxe . P_479 * iqd4nnjnc2n . ogguiilgfn ; }
simulationData = ( NeslSimulationData * ) l1kpu4wb4rx . bilgsbrgvi ; time_p =
rtmGetTaskTime ( nehesmkint , 0 ) ; simulationData -> mData -> mTime . mN = 1
; simulationData -> mData -> mTime . mX = & time_p ; simulationData -> mData
-> mContStates . mN = 30 ; simulationData -> mData -> mContStates . mX = &
localX -> lrmmgwl4ze [ 0 ] ; simulationData -> mData -> mDiscStates . mN = 0
; simulationData -> mData -> mDiscStates . mX = & l1kpu4wb4rx . ebgm2o4pem ;
simulationData -> mData -> mModeVector . mN = 6 ; simulationData -> mData ->
mModeVector . mX = & l1kpu4wb4rx . dvaxfxyujx [ 0 ] ; tmp = false ;
simulationData -> mData -> mFoundZcEvents = tmp ; simulationData -> mData ->
mIsMajorTimeStep = rtmIsMajorTimeStep ( nehesmkint ) ; tmp =
_ssGetSolverAssertCheck ( nehesmkint -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; tmp = ssIsSolverComputingJacobian ( nehesmkint
-> _mdlRefSfcnS ) ; simulationData -> mData -> mIsComputingJacobian = tmp ;
simulationData -> mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian (
nehesmkint -> _mdlRefSfcnS ) != 0 ) ; simulationData -> mData ->
mIsSolverRequestingReset = false ; tmp_g [ 0 ] = 0 ; tmp_m [ 0 ] =
iqd4nnjnc2n . dxindqk5ap [ 0 ] ; tmp_m [ 1 ] = iqd4nnjnc2n . dxindqk5ap [ 1 ]
; tmp_m [ 2 ] = iqd4nnjnc2n . dxindqk5ap [ 2 ] ; tmp_m [ 3 ] = iqd4nnjnc2n .
dxindqk5ap [ 3 ] ; tmp_g [ 1 ] = 4 ; tmp_m [ 4 ] = iqd4nnjnc2n . mxdpm2mgmf [
0 ] ; tmp_m [ 5 ] = iqd4nnjnc2n . mxdpm2mgmf [ 1 ] ; tmp_m [ 6 ] =
iqd4nnjnc2n . mxdpm2mgmf [ 2 ] ; tmp_m [ 7 ] = iqd4nnjnc2n . mxdpm2mgmf [ 3 ]
; tmp_g [ 2 ] = 8 ; tmp_m [ 8 ] = iqd4nnjnc2n . m4am5qqyxf [ 0 ] ; tmp_m [ 9
] = iqd4nnjnc2n . m4am5qqyxf [ 1 ] ; tmp_m [ 10 ] = iqd4nnjnc2n . m4am5qqyxf
[ 2 ] ; tmp_m [ 11 ] = iqd4nnjnc2n . m4am5qqyxf [ 3 ] ; tmp_g [ 3 ] = 12 ;
tmp_m [ 12 ] = iqd4nnjnc2n . jshfwrvsum [ 0 ] ; tmp_m [ 13 ] = iqd4nnjnc2n .
jshfwrvsum [ 1 ] ; tmp_m [ 14 ] = iqd4nnjnc2n . jshfwrvsum [ 2 ] ; tmp_m [ 15
] = iqd4nnjnc2n . jshfwrvsum [ 3 ] ; tmp_g [ 4 ] = 16 ; tmp_m [ 16 ] =
iqd4nnjnc2n . opwk0qcg1j [ 0 ] ; tmp_m [ 17 ] = iqd4nnjnc2n . opwk0qcg1j [ 1
] ; tmp_m [ 18 ] = iqd4nnjnc2n . opwk0qcg1j [ 2 ] ; tmp_m [ 19 ] =
iqd4nnjnc2n . opwk0qcg1j [ 3 ] ; tmp_g [ 5 ] = 20 ; tmp_m [ 20 ] =
iqd4nnjnc2n . kovkup1lbe [ 0 ] ; tmp_m [ 21 ] = iqd4nnjnc2n . kovkup1lbe [ 1
] ; tmp_m [ 22 ] = iqd4nnjnc2n . kovkup1lbe [ 2 ] ; tmp_m [ 23 ] =
iqd4nnjnc2n . kovkup1lbe [ 3 ] ; tmp_g [ 6 ] = 24 ; tmp_m [ 24 ] =
iqd4nnjnc2n . mxwazunugj [ 0 ] ; tmp_m [ 25 ] = iqd4nnjnc2n . mxwazunugj [ 1
] ; tmp_m [ 26 ] = iqd4nnjnc2n . mxwazunugj [ 2 ] ; tmp_m [ 27 ] =
iqd4nnjnc2n . mxwazunugj [ 3 ] ; tmp_g [ 7 ] = 28 ; tmp_m [ 28 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 0 ] ; tmp_m [ 29 ] = iqd4nnjnc2n . l5ozfby1n1 [ 1
] ; tmp_m [ 30 ] = iqd4nnjnc2n . l5ozfby1n1 [ 2 ] ; tmp_m [ 31 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 3 ] ; tmp_g [ 8 ] = 32 ; tmp_m [ 32 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 0 ] ; tmp_m [ 33 ] = iqd4nnjnc2n . ppdvvvhxwt [ 1
] ; tmp_m [ 34 ] = iqd4nnjnc2n . ppdvvvhxwt [ 2 ] ; tmp_m [ 35 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 3 ] ; tmp_g [ 9 ] = 36 ; tmp_m [ 36 ] =
iqd4nnjnc2n . gh10p1ptww [ 0 ] ; tmp_m [ 37 ] = iqd4nnjnc2n . gh10p1ptww [ 1
] ; tmp_m [ 38 ] = iqd4nnjnc2n . gh10p1ptww [ 2 ] ; tmp_m [ 39 ] =
iqd4nnjnc2n . gh10p1ptww [ 3 ] ; tmp_g [ 10 ] = 40 ; tmp_m [ 40 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 0 ] ; tmp_m [ 41 ] = iqd4nnjnc2n . pwdpdq4j44 [ 1
] ; tmp_m [ 42 ] = iqd4nnjnc2n . pwdpdq4j44 [ 2 ] ; tmp_m [ 43 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 3 ] ; tmp_g [ 11 ] = 44 ; tmp_m [ 44 ] =
iqd4nnjnc2n . g4fwetwo31 [ 0 ] ; tmp_m [ 45 ] = iqd4nnjnc2n . g4fwetwo31 [ 1
] ; tmp_m [ 46 ] = iqd4nnjnc2n . g4fwetwo31 [ 2 ] ; tmp_m [ 47 ] =
iqd4nnjnc2n . g4fwetwo31 [ 3 ] ; tmp_g [ 12 ] = 48 ; simulationData -> mData
-> mInputValues . mN = 48 ; simulationData -> mData -> mInputValues . mX = &
tmp_m [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 13 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_g [ 0 ] ; simulator = (
NeslSimulator * ) l1kpu4wb4rx . gajog0hbzz ; diagnosticManager = (
NeuDiagnosticManager * ) l1kpu4wb4rx . hczaoupcph ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_i =
ne_simulator_method ( simulator , NESL_SIM_UPDATE , simulationData ,
diagnosticManager ) ; if ( tmp_i != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } } void o2iluetqck ( real_T * localX_ , real_T *
localXdot_ ) { k2snwiamgb * const nehesmkint = & ( ope1wg3cbz . rtm ) ;
pig3puin4o2 * localX = ( pig3puin4o2 * ) localX_ ; pvccj5rupnx * localXdot =
( pvccj5rupnx * ) localXdot_ ; NeslSimulationData * simulationData ; real_T
time ; boolean_T tmp ; real_T tmp_p [ 24 ] ; int_T tmp_e [ 7 ] ;
NeslSimulator * simulator ; NeuDiagnosticManager * diagnosticManager ;
NeuDiagnosticTree * diagnosticTree ; int32_T tmp_i ; char * msg ; real_T
time_p ; real_T tmp_m [ 48 ] ; int_T tmp_g [ 13 ] ; simulationData = (
NeslSimulationData * ) l1kpu4wb4rx . mtmd51jfqa ; time = rtmGetTaskTime (
nehesmkint , 0 ) ; simulationData -> mData -> mTime . mN = 1 ; simulationData
-> mData -> mTime . mX = & time ; simulationData -> mData -> mContStates . mN
= 24 ; simulationData -> mData -> mContStates . mX = & localX -> kvq2o0kyuy [
0 ] ; simulationData -> mData -> mDiscStates . mN = 0 ; simulationData ->
mData -> mDiscStates . mX = & l1kpu4wb4rx . i3bqhqdooa ; simulationData ->
mData -> mModeVector . mN = 0 ; simulationData -> mData -> mModeVector . mX =
& l1kpu4wb4rx . psdfuxjdsv ; tmp = false ; simulationData -> mData ->
mFoundZcEvents = tmp ; simulationData -> mData -> mIsMajorTimeStep =
rtmIsMajorTimeStep ( nehesmkint ) ; tmp = _ssGetSolverAssertCheck (
nehesmkint -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsSolverAssertCheck = tmp ; simulationData -> mData -> mIsSolverCheckingCIC
= false ; tmp = ssIsSolverComputingJacobian ( nehesmkint -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsComputingJacobian = tmp ; simulationData ->
mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian ( nehesmkint ->
_mdlRefSfcnS ) != 0 ) ; simulationData -> mData -> mIsSolverRequestingReset =
false ; tmp_e [ 0 ] = 0 ; tmp_p [ 0 ] = iqd4nnjnc2n . hhczjtzyj5 [ 0 ] ;
tmp_p [ 1 ] = iqd4nnjnc2n . hhczjtzyj5 [ 1 ] ; tmp_p [ 2 ] = iqd4nnjnc2n .
hhczjtzyj5 [ 2 ] ; tmp_p [ 3 ] = iqd4nnjnc2n . hhczjtzyj5 [ 3 ] ; tmp_e [ 1 ]
= 4 ; tmp_p [ 4 ] = iqd4nnjnc2n . imtlp51aqd [ 0 ] ; tmp_p [ 5 ] =
iqd4nnjnc2n . imtlp51aqd [ 1 ] ; tmp_p [ 6 ] = iqd4nnjnc2n . imtlp51aqd [ 2 ]
; tmp_p [ 7 ] = iqd4nnjnc2n . imtlp51aqd [ 3 ] ; tmp_e [ 2 ] = 8 ; tmp_p [ 8
] = iqd4nnjnc2n . oe1dnrny2q [ 0 ] ; tmp_p [ 9 ] = iqd4nnjnc2n . oe1dnrny2q [
1 ] ; tmp_p [ 10 ] = iqd4nnjnc2n . oe1dnrny2q [ 2 ] ; tmp_p [ 11 ] =
iqd4nnjnc2n . oe1dnrny2q [ 3 ] ; tmp_e [ 3 ] = 12 ; tmp_p [ 12 ] =
iqd4nnjnc2n . e3os4rwhiv [ 0 ] ; tmp_p [ 13 ] = iqd4nnjnc2n . e3os4rwhiv [ 1
] ; tmp_p [ 14 ] = iqd4nnjnc2n . e3os4rwhiv [ 2 ] ; tmp_p [ 15 ] =
iqd4nnjnc2n . e3os4rwhiv [ 3 ] ; tmp_e [ 4 ] = 16 ; tmp_p [ 16 ] =
iqd4nnjnc2n . bfaefzzyat [ 0 ] ; tmp_p [ 17 ] = iqd4nnjnc2n . bfaefzzyat [ 1
] ; tmp_p [ 18 ] = iqd4nnjnc2n . bfaefzzyat [ 2 ] ; tmp_p [ 19 ] =
iqd4nnjnc2n . bfaefzzyat [ 3 ] ; tmp_e [ 5 ] = 20 ; tmp_p [ 20 ] =
iqd4nnjnc2n . b10z030dj4 [ 0 ] ; tmp_p [ 21 ] = iqd4nnjnc2n . b10z030dj4 [ 1
] ; tmp_p [ 22 ] = iqd4nnjnc2n . b10z030dj4 [ 2 ] ; tmp_p [ 23 ] =
iqd4nnjnc2n . b10z030dj4 [ 3 ] ; tmp_e [ 6 ] = 24 ; simulationData -> mData
-> mInputValues . mN = 24 ; simulationData -> mData -> mInputValues . mX = &
tmp_p [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 7 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_e [ 0 ] ;
simulationData -> mData -> mDx . mN = 24 ; simulationData -> mData -> mDx .
mX = & localXdot -> kvq2o0kyuy [ 0 ] ; simulator = ( NeslSimulator * )
l1kpu4wb4rx . es1n0xuy5w ; diagnosticManager = ( NeuDiagnosticManager * )
l1kpu4wb4rx . pryqdadyrt ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_i =
ne_simulator_method ( simulator , NESL_SIM_DERIVATIVES , simulationData ,
diagnosticManager ) ; if ( tmp_i != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } localXdot -> isq3glw5ap = ( iqd4nnjnc2n .
inqhzhb0pg [ 1 ] - localX -> isq3glw5ap ) * 1000.0 ; localXdot -> jvjzsnn41x
= ( iqd4nnjnc2n . inqhzhb0pg [ 3 ] - localX -> jvjzsnn41x ) * 1000.0 ;
localXdot -> aw5so3hvxw = ( iqd4nnjnc2n . inqhzhb0pg [ 5 ] - localX ->
aw5so3hvxw ) * 1000.0 ; localXdot -> h2c1iqll2l = ( iqd4nnjnc2n . inqhzhb0pg
[ 7 ] - localX -> h2c1iqll2l ) * 1000.0 ; localXdot -> gr0t541bm5 = (
iqd4nnjnc2n . inqhzhb0pg [ 9 ] - localX -> gr0t541bm5 ) * 1000.0 ; localXdot
-> gbdjq0hbbl = ( iqd4nnjnc2n . inqhzhb0pg [ 11 ] - localX -> gbdjq0hbbl ) *
1000.0 ; localXdot -> jeypibejzj [ 0 ] = localX -> jeypibejzj [ 1 ] ;
localXdot -> jeypibejzj [ 1 ] = ( ( l1kpu4wb4rx . e2xmk045t3 - localX ->
jeypibejzj [ 0 ] ) * 1000.0 - 2.0 * localX -> jeypibejzj [ 1 ] ) * 1000.0 ;
localXdot -> j2rvpdswec [ 0 ] = localX -> j2rvpdswec [ 1 ] ; localXdot ->
j2rvpdswec [ 1 ] = ( ( l1kpu4wb4rx . eh1viw32xa - localX -> j2rvpdswec [ 0 ]
) * 1000.0 - 2.0 * localX -> j2rvpdswec [ 1 ] ) * 1000.0 ; localXdot ->
j1sqmhdxq5 [ 0 ] = localX -> j1sqmhdxq5 [ 1 ] ; localXdot -> j1sqmhdxq5 [ 1 ]
= ( ( l1kpu4wb4rx . mssfecnie3 - localX -> j1sqmhdxq5 [ 0 ] ) * 1000.0 - 2.0
* localX -> j1sqmhdxq5 [ 1 ] ) * 1000.0 ; localXdot -> lwkodegk1s [ 0 ] =
localX -> lwkodegk1s [ 1 ] ; localXdot -> lwkodegk1s [ 1 ] = ( ( l1kpu4wb4rx
. nngs2uucok - localX -> lwkodegk1s [ 0 ] ) * 1000.0 - 2.0 * localX ->
lwkodegk1s [ 1 ] ) * 1000.0 ; localXdot -> kq4hzt5vr1 [ 0 ] = localX ->
kq4hzt5vr1 [ 1 ] ; localXdot -> kq4hzt5vr1 [ 1 ] = ( ( l1kpu4wb4rx .
p2mtfvoju0 - localX -> kq4hzt5vr1 [ 0 ] ) * 1000.0 - 2.0 * localX ->
kq4hzt5vr1 [ 1 ] ) * 1000.0 ; localXdot -> lijaeympzu [ 0 ] = localX ->
lijaeympzu [ 1 ] ; localXdot -> lijaeympzu [ 1 ] = ( ( l1kpu4wb4rx .
kt2l00xp53 - localX -> lijaeympzu [ 0 ] ) * 1000.0 - 2.0 * localX ->
lijaeympzu [ 1 ] ) * 1000.0 ; simulationData = ( NeslSimulationData * )
l1kpu4wb4rx . bilgsbrgvi ; time_p = rtmGetTaskTime ( nehesmkint , 0 ) ;
simulationData -> mData -> mTime . mN = 1 ; simulationData -> mData -> mTime
. mX = & time_p ; simulationData -> mData -> mContStates . mN = 30 ;
simulationData -> mData -> mContStates . mX = & localX -> lrmmgwl4ze [ 0 ] ;
simulationData -> mData -> mDiscStates . mN = 0 ; simulationData -> mData ->
mDiscStates . mX = & l1kpu4wb4rx . ebgm2o4pem ; simulationData -> mData ->
mModeVector . mN = 6 ; simulationData -> mData -> mModeVector . mX = &
l1kpu4wb4rx . dvaxfxyujx [ 0 ] ; tmp = false ; simulationData -> mData ->
mFoundZcEvents = tmp ; simulationData -> mData -> mIsMajorTimeStep =
rtmIsMajorTimeStep ( nehesmkint ) ; tmp = _ssGetSolverAssertCheck (
nehesmkint -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsSolverAssertCheck = tmp ; simulationData -> mData -> mIsSolverCheckingCIC
= false ; tmp = ssIsSolverComputingJacobian ( nehesmkint -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsComputingJacobian = tmp ; simulationData ->
mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian ( nehesmkint ->
_mdlRefSfcnS ) != 0 ) ; simulationData -> mData -> mIsSolverRequestingReset =
false ; tmp_g [ 0 ] = 0 ; tmp_m [ 0 ] = iqd4nnjnc2n . dxindqk5ap [ 0 ] ;
tmp_m [ 1 ] = iqd4nnjnc2n . dxindqk5ap [ 1 ] ; tmp_m [ 2 ] = iqd4nnjnc2n .
dxindqk5ap [ 2 ] ; tmp_m [ 3 ] = iqd4nnjnc2n . dxindqk5ap [ 3 ] ; tmp_g [ 1 ]
= 4 ; tmp_m [ 4 ] = iqd4nnjnc2n . mxdpm2mgmf [ 0 ] ; tmp_m [ 5 ] =
iqd4nnjnc2n . mxdpm2mgmf [ 1 ] ; tmp_m [ 6 ] = iqd4nnjnc2n . mxdpm2mgmf [ 2 ]
; tmp_m [ 7 ] = iqd4nnjnc2n . mxdpm2mgmf [ 3 ] ; tmp_g [ 2 ] = 8 ; tmp_m [ 8
] = iqd4nnjnc2n . m4am5qqyxf [ 0 ] ; tmp_m [ 9 ] = iqd4nnjnc2n . m4am5qqyxf [
1 ] ; tmp_m [ 10 ] = iqd4nnjnc2n . m4am5qqyxf [ 2 ] ; tmp_m [ 11 ] =
iqd4nnjnc2n . m4am5qqyxf [ 3 ] ; tmp_g [ 3 ] = 12 ; tmp_m [ 12 ] =
iqd4nnjnc2n . jshfwrvsum [ 0 ] ; tmp_m [ 13 ] = iqd4nnjnc2n . jshfwrvsum [ 1
] ; tmp_m [ 14 ] = iqd4nnjnc2n . jshfwrvsum [ 2 ] ; tmp_m [ 15 ] =
iqd4nnjnc2n . jshfwrvsum [ 3 ] ; tmp_g [ 4 ] = 16 ; tmp_m [ 16 ] =
iqd4nnjnc2n . opwk0qcg1j [ 0 ] ; tmp_m [ 17 ] = iqd4nnjnc2n . opwk0qcg1j [ 1
] ; tmp_m [ 18 ] = iqd4nnjnc2n . opwk0qcg1j [ 2 ] ; tmp_m [ 19 ] =
iqd4nnjnc2n . opwk0qcg1j [ 3 ] ; tmp_g [ 5 ] = 20 ; tmp_m [ 20 ] =
iqd4nnjnc2n . kovkup1lbe [ 0 ] ; tmp_m [ 21 ] = iqd4nnjnc2n . kovkup1lbe [ 1
] ; tmp_m [ 22 ] = iqd4nnjnc2n . kovkup1lbe [ 2 ] ; tmp_m [ 23 ] =
iqd4nnjnc2n . kovkup1lbe [ 3 ] ; tmp_g [ 6 ] = 24 ; tmp_m [ 24 ] =
iqd4nnjnc2n . mxwazunugj [ 0 ] ; tmp_m [ 25 ] = iqd4nnjnc2n . mxwazunugj [ 1
] ; tmp_m [ 26 ] = iqd4nnjnc2n . mxwazunugj [ 2 ] ; tmp_m [ 27 ] =
iqd4nnjnc2n . mxwazunugj [ 3 ] ; tmp_g [ 7 ] = 28 ; tmp_m [ 28 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 0 ] ; tmp_m [ 29 ] = iqd4nnjnc2n . l5ozfby1n1 [ 1
] ; tmp_m [ 30 ] = iqd4nnjnc2n . l5ozfby1n1 [ 2 ] ; tmp_m [ 31 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 3 ] ; tmp_g [ 8 ] = 32 ; tmp_m [ 32 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 0 ] ; tmp_m [ 33 ] = iqd4nnjnc2n . ppdvvvhxwt [ 1
] ; tmp_m [ 34 ] = iqd4nnjnc2n . ppdvvvhxwt [ 2 ] ; tmp_m [ 35 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 3 ] ; tmp_g [ 9 ] = 36 ; tmp_m [ 36 ] =
iqd4nnjnc2n . gh10p1ptww [ 0 ] ; tmp_m [ 37 ] = iqd4nnjnc2n . gh10p1ptww [ 1
] ; tmp_m [ 38 ] = iqd4nnjnc2n . gh10p1ptww [ 2 ] ; tmp_m [ 39 ] =
iqd4nnjnc2n . gh10p1ptww [ 3 ] ; tmp_g [ 10 ] = 40 ; tmp_m [ 40 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 0 ] ; tmp_m [ 41 ] = iqd4nnjnc2n . pwdpdq4j44 [ 1
] ; tmp_m [ 42 ] = iqd4nnjnc2n . pwdpdq4j44 [ 2 ] ; tmp_m [ 43 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 3 ] ; tmp_g [ 11 ] = 44 ; tmp_m [ 44 ] =
iqd4nnjnc2n . g4fwetwo31 [ 0 ] ; tmp_m [ 45 ] = iqd4nnjnc2n . g4fwetwo31 [ 1
] ; tmp_m [ 46 ] = iqd4nnjnc2n . g4fwetwo31 [ 2 ] ; tmp_m [ 47 ] =
iqd4nnjnc2n . g4fwetwo31 [ 3 ] ; tmp_g [ 12 ] = 48 ; simulationData -> mData
-> mInputValues . mN = 48 ; simulationData -> mData -> mInputValues . mX = &
tmp_m [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 13 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_g [ 0 ] ;
simulationData -> mData -> mDx . mN = 30 ; simulationData -> mData -> mDx .
mX = & localXdot -> lrmmgwl4ze [ 0 ] ; simulator = ( NeslSimulator * )
l1kpu4wb4rx . gajog0hbzz ; diagnosticManager = ( NeuDiagnosticManager * )
l1kpu4wb4rx . hczaoupcph ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_i =
ne_simulator_method ( simulator , NESL_SIM_DERIVATIVES , simulationData ,
diagnosticManager ) ; if ( tmp_i != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } } void ciavwlvtml ( real_T * localX_ ) {
k2snwiamgb * const nehesmkint = & ( ope1wg3cbz . rtm ) ; pig3puin4o2 * localX
= ( pig3puin4o2 * ) localX_ ; NeslSimulationData * simulationData ; real_T
time ; boolean_T tmp ; real_T tmp_p [ 24 ] ; int_T tmp_e [ 7 ] ;
NeslSimulator * simulator ; NeuDiagnosticManager * diagnosticManager ;
NeuDiagnosticTree * diagnosticTree ; int32_T tmp_i ; char * msg ; real_T
time_p ; real_T tmp_m [ 48 ] ; int_T tmp_g [ 13 ] ; simulationData = (
NeslSimulationData * ) l1kpu4wb4rx . mtmd51jfqa ; time = rtmGetTaskTime (
nehesmkint , 0 ) ; simulationData -> mData -> mTime . mN = 1 ; simulationData
-> mData -> mTime . mX = & time ; simulationData -> mData -> mContStates . mN
= 24 ; simulationData -> mData -> mContStates . mX = & localX -> kvq2o0kyuy [
0 ] ; simulationData -> mData -> mDiscStates . mN = 0 ; simulationData ->
mData -> mDiscStates . mX = & l1kpu4wb4rx . i3bqhqdooa ; simulationData ->
mData -> mModeVector . mN = 0 ; simulationData -> mData -> mModeVector . mX =
& l1kpu4wb4rx . psdfuxjdsv ; tmp = false ; simulationData -> mData ->
mFoundZcEvents = tmp ; simulationData -> mData -> mIsMajorTimeStep =
rtmIsMajorTimeStep ( nehesmkint ) ; tmp = _ssGetSolverAssertCheck (
nehesmkint -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsSolverAssertCheck = tmp ; simulationData -> mData -> mIsSolverCheckingCIC
= false ; tmp = ssIsSolverComputingJacobian ( nehesmkint -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsComputingJacobian = tmp ; simulationData ->
mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian ( nehesmkint ->
_mdlRefSfcnS ) != 0 ) ; simulationData -> mData -> mIsSolverRequestingReset =
false ; tmp_e [ 0 ] = 0 ; tmp_p [ 0 ] = iqd4nnjnc2n . hhczjtzyj5 [ 0 ] ;
tmp_p [ 1 ] = iqd4nnjnc2n . hhczjtzyj5 [ 1 ] ; tmp_p [ 2 ] = iqd4nnjnc2n .
hhczjtzyj5 [ 2 ] ; tmp_p [ 3 ] = iqd4nnjnc2n . hhczjtzyj5 [ 3 ] ; tmp_e [ 1 ]
= 4 ; tmp_p [ 4 ] = iqd4nnjnc2n . imtlp51aqd [ 0 ] ; tmp_p [ 5 ] =
iqd4nnjnc2n . imtlp51aqd [ 1 ] ; tmp_p [ 6 ] = iqd4nnjnc2n . imtlp51aqd [ 2 ]
; tmp_p [ 7 ] = iqd4nnjnc2n . imtlp51aqd [ 3 ] ; tmp_e [ 2 ] = 8 ; tmp_p [ 8
] = iqd4nnjnc2n . oe1dnrny2q [ 0 ] ; tmp_p [ 9 ] = iqd4nnjnc2n . oe1dnrny2q [
1 ] ; tmp_p [ 10 ] = iqd4nnjnc2n . oe1dnrny2q [ 2 ] ; tmp_p [ 11 ] =
iqd4nnjnc2n . oe1dnrny2q [ 3 ] ; tmp_e [ 3 ] = 12 ; tmp_p [ 12 ] =
iqd4nnjnc2n . e3os4rwhiv [ 0 ] ; tmp_p [ 13 ] = iqd4nnjnc2n . e3os4rwhiv [ 1
] ; tmp_p [ 14 ] = iqd4nnjnc2n . e3os4rwhiv [ 2 ] ; tmp_p [ 15 ] =
iqd4nnjnc2n . e3os4rwhiv [ 3 ] ; tmp_e [ 4 ] = 16 ; tmp_p [ 16 ] =
iqd4nnjnc2n . bfaefzzyat [ 0 ] ; tmp_p [ 17 ] = iqd4nnjnc2n . bfaefzzyat [ 1
] ; tmp_p [ 18 ] = iqd4nnjnc2n . bfaefzzyat [ 2 ] ; tmp_p [ 19 ] =
iqd4nnjnc2n . bfaefzzyat [ 3 ] ; tmp_e [ 5 ] = 20 ; tmp_p [ 20 ] =
iqd4nnjnc2n . b10z030dj4 [ 0 ] ; tmp_p [ 21 ] = iqd4nnjnc2n . b10z030dj4 [ 1
] ; tmp_p [ 22 ] = iqd4nnjnc2n . b10z030dj4 [ 2 ] ; tmp_p [ 23 ] =
iqd4nnjnc2n . b10z030dj4 [ 3 ] ; tmp_e [ 6 ] = 24 ; simulationData -> mData
-> mInputValues . mN = 24 ; simulationData -> mData -> mInputValues . mX = &
tmp_p [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 7 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_e [ 0 ] ; simulator = (
NeslSimulator * ) l1kpu4wb4rx . es1n0xuy5w ; diagnosticManager = (
NeuDiagnosticManager * ) l1kpu4wb4rx . pryqdadyrt ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_i =
ne_simulator_method ( simulator , NESL_SIM_PROJECTION , simulationData ,
diagnosticManager ) ; if ( tmp_i != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } simulationData = ( NeslSimulationData * )
l1kpu4wb4rx . bilgsbrgvi ; time_p = rtmGetTaskTime ( nehesmkint , 0 ) ;
simulationData -> mData -> mTime . mN = 1 ; simulationData -> mData -> mTime
. mX = & time_p ; simulationData -> mData -> mContStates . mN = 30 ;
simulationData -> mData -> mContStates . mX = & localX -> lrmmgwl4ze [ 0 ] ;
simulationData -> mData -> mDiscStates . mN = 0 ; simulationData -> mData ->
mDiscStates . mX = & l1kpu4wb4rx . ebgm2o4pem ; simulationData -> mData ->
mModeVector . mN = 6 ; simulationData -> mData -> mModeVector . mX = &
l1kpu4wb4rx . dvaxfxyujx [ 0 ] ; tmp = false ; simulationData -> mData ->
mFoundZcEvents = tmp ; simulationData -> mData -> mIsMajorTimeStep =
rtmIsMajorTimeStep ( nehesmkint ) ; tmp = _ssGetSolverAssertCheck (
nehesmkint -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsSolverAssertCheck = tmp ; simulationData -> mData -> mIsSolverCheckingCIC
= false ; tmp = ssIsSolverComputingJacobian ( nehesmkint -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsComputingJacobian = tmp ; simulationData ->
mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian ( nehesmkint ->
_mdlRefSfcnS ) != 0 ) ; simulationData -> mData -> mIsSolverRequestingReset =
false ; tmp_g [ 0 ] = 0 ; tmp_m [ 0 ] = iqd4nnjnc2n . dxindqk5ap [ 0 ] ;
tmp_m [ 1 ] = iqd4nnjnc2n . dxindqk5ap [ 1 ] ; tmp_m [ 2 ] = iqd4nnjnc2n .
dxindqk5ap [ 2 ] ; tmp_m [ 3 ] = iqd4nnjnc2n . dxindqk5ap [ 3 ] ; tmp_g [ 1 ]
= 4 ; tmp_m [ 4 ] = iqd4nnjnc2n . mxdpm2mgmf [ 0 ] ; tmp_m [ 5 ] =
iqd4nnjnc2n . mxdpm2mgmf [ 1 ] ; tmp_m [ 6 ] = iqd4nnjnc2n . mxdpm2mgmf [ 2 ]
; tmp_m [ 7 ] = iqd4nnjnc2n . mxdpm2mgmf [ 3 ] ; tmp_g [ 2 ] = 8 ; tmp_m [ 8
] = iqd4nnjnc2n . m4am5qqyxf [ 0 ] ; tmp_m [ 9 ] = iqd4nnjnc2n . m4am5qqyxf [
1 ] ; tmp_m [ 10 ] = iqd4nnjnc2n . m4am5qqyxf [ 2 ] ; tmp_m [ 11 ] =
iqd4nnjnc2n . m4am5qqyxf [ 3 ] ; tmp_g [ 3 ] = 12 ; tmp_m [ 12 ] =
iqd4nnjnc2n . jshfwrvsum [ 0 ] ; tmp_m [ 13 ] = iqd4nnjnc2n . jshfwrvsum [ 1
] ; tmp_m [ 14 ] = iqd4nnjnc2n . jshfwrvsum [ 2 ] ; tmp_m [ 15 ] =
iqd4nnjnc2n . jshfwrvsum [ 3 ] ; tmp_g [ 4 ] = 16 ; tmp_m [ 16 ] =
iqd4nnjnc2n . opwk0qcg1j [ 0 ] ; tmp_m [ 17 ] = iqd4nnjnc2n . opwk0qcg1j [ 1
] ; tmp_m [ 18 ] = iqd4nnjnc2n . opwk0qcg1j [ 2 ] ; tmp_m [ 19 ] =
iqd4nnjnc2n . opwk0qcg1j [ 3 ] ; tmp_g [ 5 ] = 20 ; tmp_m [ 20 ] =
iqd4nnjnc2n . kovkup1lbe [ 0 ] ; tmp_m [ 21 ] = iqd4nnjnc2n . kovkup1lbe [ 1
] ; tmp_m [ 22 ] = iqd4nnjnc2n . kovkup1lbe [ 2 ] ; tmp_m [ 23 ] =
iqd4nnjnc2n . kovkup1lbe [ 3 ] ; tmp_g [ 6 ] = 24 ; tmp_m [ 24 ] =
iqd4nnjnc2n . mxwazunugj [ 0 ] ; tmp_m [ 25 ] = iqd4nnjnc2n . mxwazunugj [ 1
] ; tmp_m [ 26 ] = iqd4nnjnc2n . mxwazunugj [ 2 ] ; tmp_m [ 27 ] =
iqd4nnjnc2n . mxwazunugj [ 3 ] ; tmp_g [ 7 ] = 28 ; tmp_m [ 28 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 0 ] ; tmp_m [ 29 ] = iqd4nnjnc2n . l5ozfby1n1 [ 1
] ; tmp_m [ 30 ] = iqd4nnjnc2n . l5ozfby1n1 [ 2 ] ; tmp_m [ 31 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 3 ] ; tmp_g [ 8 ] = 32 ; tmp_m [ 32 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 0 ] ; tmp_m [ 33 ] = iqd4nnjnc2n . ppdvvvhxwt [ 1
] ; tmp_m [ 34 ] = iqd4nnjnc2n . ppdvvvhxwt [ 2 ] ; tmp_m [ 35 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 3 ] ; tmp_g [ 9 ] = 36 ; tmp_m [ 36 ] =
iqd4nnjnc2n . gh10p1ptww [ 0 ] ; tmp_m [ 37 ] = iqd4nnjnc2n . gh10p1ptww [ 1
] ; tmp_m [ 38 ] = iqd4nnjnc2n . gh10p1ptww [ 2 ] ; tmp_m [ 39 ] =
iqd4nnjnc2n . gh10p1ptww [ 3 ] ; tmp_g [ 10 ] = 40 ; tmp_m [ 40 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 0 ] ; tmp_m [ 41 ] = iqd4nnjnc2n . pwdpdq4j44 [ 1
] ; tmp_m [ 42 ] = iqd4nnjnc2n . pwdpdq4j44 [ 2 ] ; tmp_m [ 43 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 3 ] ; tmp_g [ 11 ] = 44 ; tmp_m [ 44 ] =
iqd4nnjnc2n . g4fwetwo31 [ 0 ] ; tmp_m [ 45 ] = iqd4nnjnc2n . g4fwetwo31 [ 1
] ; tmp_m [ 46 ] = iqd4nnjnc2n . g4fwetwo31 [ 2 ] ; tmp_m [ 47 ] =
iqd4nnjnc2n . g4fwetwo31 [ 3 ] ; tmp_g [ 12 ] = 48 ; simulationData -> mData
-> mInputValues . mN = 48 ; simulationData -> mData -> mInputValues . mX = &
tmp_m [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 13 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_g [ 0 ] ; simulator = (
NeslSimulator * ) l1kpu4wb4rx . gajog0hbzz ; diagnosticManager = (
NeuDiagnosticManager * ) l1kpu4wb4rx . hczaoupcph ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_i =
ne_simulator_method ( simulator , NESL_SIM_PROJECTION , simulationData ,
diagnosticManager ) ; if ( tmp_i != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } } void ci0rchb45g ( real_T * localX_ , real_T *
localXdot_ ) { k2snwiamgb * const nehesmkint = & ( ope1wg3cbz . rtm ) ;
pig3puin4o2 * localX = ( pig3puin4o2 * ) localX_ ; pvccj5rupnx * localXdot =
( pvccj5rupnx * ) localXdot_ ; NeslSimulationData * simulationData ; real_T
time ; boolean_T tmp ; real_T tmp_p [ 24 ] ; int_T tmp_e [ 7 ] ;
NeslSimulator * simulator ; NeuDiagnosticManager * diagnosticManager ;
NeuDiagnosticTree * diagnosticTree ; int32_T tmp_i ; char * msg ; real_T
time_p ; real_T tmp_m [ 48 ] ; int_T tmp_g [ 13 ] ; simulationData = (
NeslSimulationData * ) l1kpu4wb4rx . mtmd51jfqa ; time = rtmGetTaskTime (
nehesmkint , 0 ) ; simulationData -> mData -> mTime . mN = 1 ; simulationData
-> mData -> mTime . mX = & time ; simulationData -> mData -> mContStates . mN
= 24 ; simulationData -> mData -> mContStates . mX = & localX -> kvq2o0kyuy [
0 ] ; simulationData -> mData -> mDiscStates . mN = 0 ; simulationData ->
mData -> mDiscStates . mX = & l1kpu4wb4rx . i3bqhqdooa ; simulationData ->
mData -> mModeVector . mN = 0 ; simulationData -> mData -> mModeVector . mX =
& l1kpu4wb4rx . psdfuxjdsv ; tmp = false ; simulationData -> mData ->
mFoundZcEvents = tmp ; simulationData -> mData -> mIsMajorTimeStep =
rtmIsMajorTimeStep ( nehesmkint ) ; tmp = _ssGetSolverAssertCheck (
nehesmkint -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsSolverAssertCheck = tmp ; simulationData -> mData -> mIsSolverCheckingCIC
= false ; tmp = ssIsSolverComputingJacobian ( nehesmkint -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsComputingJacobian = tmp ; simulationData ->
mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian ( nehesmkint ->
_mdlRefSfcnS ) != 0 ) ; simulationData -> mData -> mIsSolverRequestingReset =
false ; tmp_e [ 0 ] = 0 ; tmp_p [ 0 ] = iqd4nnjnc2n . hhczjtzyj5 [ 0 ] ;
tmp_p [ 1 ] = iqd4nnjnc2n . hhczjtzyj5 [ 1 ] ; tmp_p [ 2 ] = iqd4nnjnc2n .
hhczjtzyj5 [ 2 ] ; tmp_p [ 3 ] = iqd4nnjnc2n . hhczjtzyj5 [ 3 ] ; tmp_e [ 1 ]
= 4 ; tmp_p [ 4 ] = iqd4nnjnc2n . imtlp51aqd [ 0 ] ; tmp_p [ 5 ] =
iqd4nnjnc2n . imtlp51aqd [ 1 ] ; tmp_p [ 6 ] = iqd4nnjnc2n . imtlp51aqd [ 2 ]
; tmp_p [ 7 ] = iqd4nnjnc2n . imtlp51aqd [ 3 ] ; tmp_e [ 2 ] = 8 ; tmp_p [ 8
] = iqd4nnjnc2n . oe1dnrny2q [ 0 ] ; tmp_p [ 9 ] = iqd4nnjnc2n . oe1dnrny2q [
1 ] ; tmp_p [ 10 ] = iqd4nnjnc2n . oe1dnrny2q [ 2 ] ; tmp_p [ 11 ] =
iqd4nnjnc2n . oe1dnrny2q [ 3 ] ; tmp_e [ 3 ] = 12 ; tmp_p [ 12 ] =
iqd4nnjnc2n . e3os4rwhiv [ 0 ] ; tmp_p [ 13 ] = iqd4nnjnc2n . e3os4rwhiv [ 1
] ; tmp_p [ 14 ] = iqd4nnjnc2n . e3os4rwhiv [ 2 ] ; tmp_p [ 15 ] =
iqd4nnjnc2n . e3os4rwhiv [ 3 ] ; tmp_e [ 4 ] = 16 ; tmp_p [ 16 ] =
iqd4nnjnc2n . bfaefzzyat [ 0 ] ; tmp_p [ 17 ] = iqd4nnjnc2n . bfaefzzyat [ 1
] ; tmp_p [ 18 ] = iqd4nnjnc2n . bfaefzzyat [ 2 ] ; tmp_p [ 19 ] =
iqd4nnjnc2n . bfaefzzyat [ 3 ] ; tmp_e [ 5 ] = 20 ; tmp_p [ 20 ] =
iqd4nnjnc2n . b10z030dj4 [ 0 ] ; tmp_p [ 21 ] = iqd4nnjnc2n . b10z030dj4 [ 1
] ; tmp_p [ 22 ] = iqd4nnjnc2n . b10z030dj4 [ 2 ] ; tmp_p [ 23 ] =
iqd4nnjnc2n . b10z030dj4 [ 3 ] ; tmp_e [ 6 ] = 24 ; simulationData -> mData
-> mInputValues . mN = 24 ; simulationData -> mData -> mInputValues . mX = &
tmp_p [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 7 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_e [ 0 ] ;
simulationData -> mData -> mDx . mN = 24 ; simulationData -> mData -> mDx .
mX = & localXdot -> kvq2o0kyuy [ 0 ] ; simulator = ( NeslSimulator * )
l1kpu4wb4rx . es1n0xuy5w ; diagnosticManager = ( NeuDiagnosticManager * )
l1kpu4wb4rx . pryqdadyrt ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_i =
ne_simulator_method ( simulator , NESL_SIM_DERIVATIVES , simulationData ,
diagnosticManager ) ; if ( tmp_i != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } localXdot -> isq3glw5ap = ( iqd4nnjnc2n .
inqhzhb0pg [ 1 ] - localX -> isq3glw5ap ) * 1000.0 ; localXdot -> jvjzsnn41x
= ( iqd4nnjnc2n . inqhzhb0pg [ 3 ] - localX -> jvjzsnn41x ) * 1000.0 ;
localXdot -> aw5so3hvxw = ( iqd4nnjnc2n . inqhzhb0pg [ 5 ] - localX ->
aw5so3hvxw ) * 1000.0 ; localXdot -> h2c1iqll2l = ( iqd4nnjnc2n . inqhzhb0pg
[ 7 ] - localX -> h2c1iqll2l ) * 1000.0 ; localXdot -> gr0t541bm5 = (
iqd4nnjnc2n . inqhzhb0pg [ 9 ] - localX -> gr0t541bm5 ) * 1000.0 ; localXdot
-> gbdjq0hbbl = ( iqd4nnjnc2n . inqhzhb0pg [ 11 ] - localX -> gbdjq0hbbl ) *
1000.0 ; localXdot -> jeypibejzj [ 0 ] = localX -> jeypibejzj [ 1 ] ;
localXdot -> jeypibejzj [ 1 ] = ( ( l1kpu4wb4rx . e2xmk045t3 - localX ->
jeypibejzj [ 0 ] ) * 1000.0 - 2.0 * localX -> jeypibejzj [ 1 ] ) * 1000.0 ;
localXdot -> j2rvpdswec [ 0 ] = localX -> j2rvpdswec [ 1 ] ; localXdot ->
j2rvpdswec [ 1 ] = ( ( l1kpu4wb4rx . eh1viw32xa - localX -> j2rvpdswec [ 0 ]
) * 1000.0 - 2.0 * localX -> j2rvpdswec [ 1 ] ) * 1000.0 ; localXdot ->
j1sqmhdxq5 [ 0 ] = localX -> j1sqmhdxq5 [ 1 ] ; localXdot -> j1sqmhdxq5 [ 1 ]
= ( ( l1kpu4wb4rx . mssfecnie3 - localX -> j1sqmhdxq5 [ 0 ] ) * 1000.0 - 2.0
* localX -> j1sqmhdxq5 [ 1 ] ) * 1000.0 ; localXdot -> lwkodegk1s [ 0 ] =
localX -> lwkodegk1s [ 1 ] ; localXdot -> lwkodegk1s [ 1 ] = ( ( l1kpu4wb4rx
. nngs2uucok - localX -> lwkodegk1s [ 0 ] ) * 1000.0 - 2.0 * localX ->
lwkodegk1s [ 1 ] ) * 1000.0 ; localXdot -> kq4hzt5vr1 [ 0 ] = localX ->
kq4hzt5vr1 [ 1 ] ; localXdot -> kq4hzt5vr1 [ 1 ] = ( ( l1kpu4wb4rx .
p2mtfvoju0 - localX -> kq4hzt5vr1 [ 0 ] ) * 1000.0 - 2.0 * localX ->
kq4hzt5vr1 [ 1 ] ) * 1000.0 ; localXdot -> lijaeympzu [ 0 ] = localX ->
lijaeympzu [ 1 ] ; localXdot -> lijaeympzu [ 1 ] = ( ( l1kpu4wb4rx .
kt2l00xp53 - localX -> lijaeympzu [ 0 ] ) * 1000.0 - 2.0 * localX ->
lijaeympzu [ 1 ] ) * 1000.0 ; simulationData = ( NeslSimulationData * )
l1kpu4wb4rx . bilgsbrgvi ; time_p = rtmGetTaskTime ( nehesmkint , 0 ) ;
simulationData -> mData -> mTime . mN = 1 ; simulationData -> mData -> mTime
. mX = & time_p ; simulationData -> mData -> mContStates . mN = 30 ;
simulationData -> mData -> mContStates . mX = & localX -> lrmmgwl4ze [ 0 ] ;
simulationData -> mData -> mDiscStates . mN = 0 ; simulationData -> mData ->
mDiscStates . mX = & l1kpu4wb4rx . ebgm2o4pem ; simulationData -> mData ->
mModeVector . mN = 6 ; simulationData -> mData -> mModeVector . mX = &
l1kpu4wb4rx . dvaxfxyujx [ 0 ] ; tmp = false ; simulationData -> mData ->
mFoundZcEvents = tmp ; simulationData -> mData -> mIsMajorTimeStep =
rtmIsMajorTimeStep ( nehesmkint ) ; tmp = _ssGetSolverAssertCheck (
nehesmkint -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsSolverAssertCheck = tmp ; simulationData -> mData -> mIsSolverCheckingCIC
= false ; tmp = ssIsSolverComputingJacobian ( nehesmkint -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsComputingJacobian = tmp ; simulationData ->
mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian ( nehesmkint ->
_mdlRefSfcnS ) != 0 ) ; simulationData -> mData -> mIsSolverRequestingReset =
false ; tmp_g [ 0 ] = 0 ; tmp_m [ 0 ] = iqd4nnjnc2n . dxindqk5ap [ 0 ] ;
tmp_m [ 1 ] = iqd4nnjnc2n . dxindqk5ap [ 1 ] ; tmp_m [ 2 ] = iqd4nnjnc2n .
dxindqk5ap [ 2 ] ; tmp_m [ 3 ] = iqd4nnjnc2n . dxindqk5ap [ 3 ] ; tmp_g [ 1 ]
= 4 ; tmp_m [ 4 ] = iqd4nnjnc2n . mxdpm2mgmf [ 0 ] ; tmp_m [ 5 ] =
iqd4nnjnc2n . mxdpm2mgmf [ 1 ] ; tmp_m [ 6 ] = iqd4nnjnc2n . mxdpm2mgmf [ 2 ]
; tmp_m [ 7 ] = iqd4nnjnc2n . mxdpm2mgmf [ 3 ] ; tmp_g [ 2 ] = 8 ; tmp_m [ 8
] = iqd4nnjnc2n . m4am5qqyxf [ 0 ] ; tmp_m [ 9 ] = iqd4nnjnc2n . m4am5qqyxf [
1 ] ; tmp_m [ 10 ] = iqd4nnjnc2n . m4am5qqyxf [ 2 ] ; tmp_m [ 11 ] =
iqd4nnjnc2n . m4am5qqyxf [ 3 ] ; tmp_g [ 3 ] = 12 ; tmp_m [ 12 ] =
iqd4nnjnc2n . jshfwrvsum [ 0 ] ; tmp_m [ 13 ] = iqd4nnjnc2n . jshfwrvsum [ 1
] ; tmp_m [ 14 ] = iqd4nnjnc2n . jshfwrvsum [ 2 ] ; tmp_m [ 15 ] =
iqd4nnjnc2n . jshfwrvsum [ 3 ] ; tmp_g [ 4 ] = 16 ; tmp_m [ 16 ] =
iqd4nnjnc2n . opwk0qcg1j [ 0 ] ; tmp_m [ 17 ] = iqd4nnjnc2n . opwk0qcg1j [ 1
] ; tmp_m [ 18 ] = iqd4nnjnc2n . opwk0qcg1j [ 2 ] ; tmp_m [ 19 ] =
iqd4nnjnc2n . opwk0qcg1j [ 3 ] ; tmp_g [ 5 ] = 20 ; tmp_m [ 20 ] =
iqd4nnjnc2n . kovkup1lbe [ 0 ] ; tmp_m [ 21 ] = iqd4nnjnc2n . kovkup1lbe [ 1
] ; tmp_m [ 22 ] = iqd4nnjnc2n . kovkup1lbe [ 2 ] ; tmp_m [ 23 ] =
iqd4nnjnc2n . kovkup1lbe [ 3 ] ; tmp_g [ 6 ] = 24 ; tmp_m [ 24 ] =
iqd4nnjnc2n . mxwazunugj [ 0 ] ; tmp_m [ 25 ] = iqd4nnjnc2n . mxwazunugj [ 1
] ; tmp_m [ 26 ] = iqd4nnjnc2n . mxwazunugj [ 2 ] ; tmp_m [ 27 ] =
iqd4nnjnc2n . mxwazunugj [ 3 ] ; tmp_g [ 7 ] = 28 ; tmp_m [ 28 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 0 ] ; tmp_m [ 29 ] = iqd4nnjnc2n . l5ozfby1n1 [ 1
] ; tmp_m [ 30 ] = iqd4nnjnc2n . l5ozfby1n1 [ 2 ] ; tmp_m [ 31 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 3 ] ; tmp_g [ 8 ] = 32 ; tmp_m [ 32 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 0 ] ; tmp_m [ 33 ] = iqd4nnjnc2n . ppdvvvhxwt [ 1
] ; tmp_m [ 34 ] = iqd4nnjnc2n . ppdvvvhxwt [ 2 ] ; tmp_m [ 35 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 3 ] ; tmp_g [ 9 ] = 36 ; tmp_m [ 36 ] =
iqd4nnjnc2n . gh10p1ptww [ 0 ] ; tmp_m [ 37 ] = iqd4nnjnc2n . gh10p1ptww [ 1
] ; tmp_m [ 38 ] = iqd4nnjnc2n . gh10p1ptww [ 2 ] ; tmp_m [ 39 ] =
iqd4nnjnc2n . gh10p1ptww [ 3 ] ; tmp_g [ 10 ] = 40 ; tmp_m [ 40 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 0 ] ; tmp_m [ 41 ] = iqd4nnjnc2n . pwdpdq4j44 [ 1
] ; tmp_m [ 42 ] = iqd4nnjnc2n . pwdpdq4j44 [ 2 ] ; tmp_m [ 43 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 3 ] ; tmp_g [ 11 ] = 44 ; tmp_m [ 44 ] =
iqd4nnjnc2n . g4fwetwo31 [ 0 ] ; tmp_m [ 45 ] = iqd4nnjnc2n . g4fwetwo31 [ 1
] ; tmp_m [ 46 ] = iqd4nnjnc2n . g4fwetwo31 [ 2 ] ; tmp_m [ 47 ] =
iqd4nnjnc2n . g4fwetwo31 [ 3 ] ; tmp_g [ 12 ] = 48 ; simulationData -> mData
-> mInputValues . mN = 48 ; simulationData -> mData -> mInputValues . mX = &
tmp_m [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 13 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_g [ 0 ] ;
simulationData -> mData -> mDx . mN = 30 ; simulationData -> mData -> mDx .
mX = & localXdot -> lrmmgwl4ze [ 0 ] ; simulator = ( NeslSimulator * )
l1kpu4wb4rx . gajog0hbzz ; diagnosticManager = ( NeuDiagnosticManager * )
l1kpu4wb4rx . hczaoupcph ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_i =
ne_simulator_method ( simulator , NESL_SIM_FORCINGFUNCTION , simulationData ,
diagnosticManager ) ; if ( tmp_i != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } } void kja25six4i ( real_T * localX_ ) {
k2snwiamgb * const nehesmkint = & ( ope1wg3cbz . rtm ) ; pig3puin4o2 * localX
= ( pig3puin4o2 * ) localX_ ; NeslSimulationData * simulationData ; real_T
time ; boolean_T tmp ; real_T tmp_p [ 48 ] ; int_T tmp_e [ 13 ] ; real_T *
tmp_i ; NeslSimulator * simulator ; NeuDiagnosticManager * diagnosticManager
; NeuDiagnosticTree * diagnosticTree ; int32_T tmp_m ; char * msg ;
simulationData = ( NeslSimulationData * ) l1kpu4wb4rx . bilgsbrgvi ; time =
rtmGetTaskTime ( nehesmkint , 0 ) ; simulationData -> mData -> mTime . mN = 1
; simulationData -> mData -> mTime . mX = & time ; simulationData -> mData ->
mContStates . mN = 30 ; simulationData -> mData -> mContStates . mX = &
localX -> lrmmgwl4ze [ 0 ] ; simulationData -> mData -> mDiscStates . mN = 0
; simulationData -> mData -> mDiscStates . mX = & l1kpu4wb4rx . ebgm2o4pem ;
simulationData -> mData -> mModeVector . mN = 6 ; simulationData -> mData ->
mModeVector . mX = & l1kpu4wb4rx . dvaxfxyujx [ 0 ] ; tmp = false ;
simulationData -> mData -> mFoundZcEvents = tmp ; simulationData -> mData ->
mIsMajorTimeStep = rtmIsMajorTimeStep ( nehesmkint ) ; tmp =
_ssGetSolverAssertCheck ( nehesmkint -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; tmp = ssIsSolverComputingJacobian ( nehesmkint
-> _mdlRefSfcnS ) ; simulationData -> mData -> mIsComputingJacobian = tmp ;
simulationData -> mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian (
nehesmkint -> _mdlRefSfcnS ) != 0 ) ; simulationData -> mData ->
mIsSolverRequestingReset = false ; tmp_e [ 0 ] = 0 ; tmp_p [ 0 ] =
iqd4nnjnc2n . dxindqk5ap [ 0 ] ; tmp_p [ 1 ] = iqd4nnjnc2n . dxindqk5ap [ 1 ]
; tmp_p [ 2 ] = iqd4nnjnc2n . dxindqk5ap [ 2 ] ; tmp_p [ 3 ] = iqd4nnjnc2n .
dxindqk5ap [ 3 ] ; tmp_e [ 1 ] = 4 ; tmp_p [ 4 ] = iqd4nnjnc2n . mxdpm2mgmf [
0 ] ; tmp_p [ 5 ] = iqd4nnjnc2n . mxdpm2mgmf [ 1 ] ; tmp_p [ 6 ] =
iqd4nnjnc2n . mxdpm2mgmf [ 2 ] ; tmp_p [ 7 ] = iqd4nnjnc2n . mxdpm2mgmf [ 3 ]
; tmp_e [ 2 ] = 8 ; tmp_p [ 8 ] = iqd4nnjnc2n . m4am5qqyxf [ 0 ] ; tmp_p [ 9
] = iqd4nnjnc2n . m4am5qqyxf [ 1 ] ; tmp_p [ 10 ] = iqd4nnjnc2n . m4am5qqyxf
[ 2 ] ; tmp_p [ 11 ] = iqd4nnjnc2n . m4am5qqyxf [ 3 ] ; tmp_e [ 3 ] = 12 ;
tmp_p [ 12 ] = iqd4nnjnc2n . jshfwrvsum [ 0 ] ; tmp_p [ 13 ] = iqd4nnjnc2n .
jshfwrvsum [ 1 ] ; tmp_p [ 14 ] = iqd4nnjnc2n . jshfwrvsum [ 2 ] ; tmp_p [ 15
] = iqd4nnjnc2n . jshfwrvsum [ 3 ] ; tmp_e [ 4 ] = 16 ; tmp_p [ 16 ] =
iqd4nnjnc2n . opwk0qcg1j [ 0 ] ; tmp_p [ 17 ] = iqd4nnjnc2n . opwk0qcg1j [ 1
] ; tmp_p [ 18 ] = iqd4nnjnc2n . opwk0qcg1j [ 2 ] ; tmp_p [ 19 ] =
iqd4nnjnc2n . opwk0qcg1j [ 3 ] ; tmp_e [ 5 ] = 20 ; tmp_p [ 20 ] =
iqd4nnjnc2n . kovkup1lbe [ 0 ] ; tmp_p [ 21 ] = iqd4nnjnc2n . kovkup1lbe [ 1
] ; tmp_p [ 22 ] = iqd4nnjnc2n . kovkup1lbe [ 2 ] ; tmp_p [ 23 ] =
iqd4nnjnc2n . kovkup1lbe [ 3 ] ; tmp_e [ 6 ] = 24 ; tmp_p [ 24 ] =
iqd4nnjnc2n . mxwazunugj [ 0 ] ; tmp_p [ 25 ] = iqd4nnjnc2n . mxwazunugj [ 1
] ; tmp_p [ 26 ] = iqd4nnjnc2n . mxwazunugj [ 2 ] ; tmp_p [ 27 ] =
iqd4nnjnc2n . mxwazunugj [ 3 ] ; tmp_e [ 7 ] = 28 ; tmp_p [ 28 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 0 ] ; tmp_p [ 29 ] = iqd4nnjnc2n . l5ozfby1n1 [ 1
] ; tmp_p [ 30 ] = iqd4nnjnc2n . l5ozfby1n1 [ 2 ] ; tmp_p [ 31 ] =
iqd4nnjnc2n . l5ozfby1n1 [ 3 ] ; tmp_e [ 8 ] = 32 ; tmp_p [ 32 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 0 ] ; tmp_p [ 33 ] = iqd4nnjnc2n . ppdvvvhxwt [ 1
] ; tmp_p [ 34 ] = iqd4nnjnc2n . ppdvvvhxwt [ 2 ] ; tmp_p [ 35 ] =
iqd4nnjnc2n . ppdvvvhxwt [ 3 ] ; tmp_e [ 9 ] = 36 ; tmp_p [ 36 ] =
iqd4nnjnc2n . gh10p1ptww [ 0 ] ; tmp_p [ 37 ] = iqd4nnjnc2n . gh10p1ptww [ 1
] ; tmp_p [ 38 ] = iqd4nnjnc2n . gh10p1ptww [ 2 ] ; tmp_p [ 39 ] =
iqd4nnjnc2n . gh10p1ptww [ 3 ] ; tmp_e [ 10 ] = 40 ; tmp_p [ 40 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 0 ] ; tmp_p [ 41 ] = iqd4nnjnc2n . pwdpdq4j44 [ 1
] ; tmp_p [ 42 ] = iqd4nnjnc2n . pwdpdq4j44 [ 2 ] ; tmp_p [ 43 ] =
iqd4nnjnc2n . pwdpdq4j44 [ 3 ] ; tmp_e [ 11 ] = 44 ; tmp_p [ 44 ] =
iqd4nnjnc2n . g4fwetwo31 [ 0 ] ; tmp_p [ 45 ] = iqd4nnjnc2n . g4fwetwo31 [ 1
] ; tmp_p [ 46 ] = iqd4nnjnc2n . g4fwetwo31 [ 2 ] ; tmp_p [ 47 ] =
iqd4nnjnc2n . g4fwetwo31 [ 3 ] ; tmp_e [ 12 ] = 48 ; simulationData -> mData
-> mInputValues . mN = 48 ; simulationData -> mData -> mInputValues . mX = &
tmp_p [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 13 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_e [ 0 ] ; tmp_i =
nehesmkint -> massMatrixBasePr ; tmp_i = double_pointer_shift ( tmp_i ,
l1kpu4wb4rx . kqn0icr3hm ) ; simulationData -> mData -> mMassMatrixPr . mN =
18 ; simulationData -> mData -> mMassMatrixPr . mX = tmp_i ; simulator = (
NeslSimulator * ) l1kpu4wb4rx . gajog0hbzz ; diagnosticManager = (
NeuDiagnosticManager * ) l1kpu4wb4rx . hczaoupcph ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_m =
ne_simulator_method ( simulator , NESL_SIM_MASSMATRIX , simulationData ,
diagnosticManager ) ; if ( tmp_m != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( nehesmkint -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( nehesmkint ->
_mdlRefSfcnS , msg ) ; } } } void i51jvolrrc ( void ) { k2snwiamgb * const
nehesmkint = & ( ope1wg3cbz . rtm ) ; if ( ! slIsRapidAcceleratorSimulating (
) ) { SimStruct * rts = nehesmkint -> childSfunctions [ 0 ] ; { mxArray *
param = _ssGetSFcnParam ( rts , 0 ) ; if ( ! mxIsEmpty ( param ) ) {
mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 0 , NULL ) ; } } { mxArray
* param = _ssGetSFcnParam ( rts , 1 ) ; if ( ! mxIsEmpty ( param ) ) {
mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 1 , NULL ) ; } } { mxArray
* param = _ssGetSFcnParam ( rts , 2 ) ; if ( ! mxIsEmpty ( param ) ) {
mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 2 , NULL ) ; } } { mxArray
* param = _ssGetSFcnParam ( rts , 3 ) ; if ( ! mxIsEmpty ( param ) ) {
mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 3 , NULL ) ; } } { mxArray
* param = _ssGetSFcnParam ( rts , 4 ) ; if ( ! mxIsEmpty ( param ) ) {
mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 4 , NULL ) ; } } { mxArray
* param = _ssGetSFcnParam ( rts , 5 ) ; if ( ! mxIsEmpty ( param ) ) {
mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 5 , NULL ) ; } } { mxArray
* param = _ssGetSFcnParam ( rts , 6 ) ; if ( ! mxIsEmpty ( param ) ) {
mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 6 , NULL ) ; } } { mxArray
* param = _ssGetSFcnParam ( rts , 7 ) ; if ( ! mxIsEmpty ( param ) ) {
mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 7 , NULL ) ; } } { mxArray
* param = _ssGetSFcnParam ( rts , 8 ) ; if ( ! mxIsEmpty ( param ) ) {
mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 8 , NULL ) ; } } { mxArray
* param = _ssGetSFcnParam ( rts , 9 ) ; if ( ! mxIsEmpty ( param ) ) {
mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 9 , NULL ) ; } } { mxArray
* param = _ssGetSFcnParam ( rts , 10 ) ; if ( ! mxIsEmpty ( param ) ) {
mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 10 , NULL ) ; } } {
mxArray * param = _ssGetSFcnParam ( rts , 11 ) ; if ( ! mxIsEmpty ( param ) )
{ mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 11 , NULL ) ; } } {
mxArray * param = _ssGetSFcnParam ( rts , 12 ) ; if ( ! mxIsEmpty ( param ) )
{ mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 12 , NULL ) ; } } {
mxArray * param = _ssGetSFcnParam ( rts , 13 ) ; if ( ! mxIsEmpty ( param ) )
{ mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 13 , NULL ) ; } } {
mxArray * param = _ssGetSFcnParam ( rts , 14 ) ; if ( ! mxIsEmpty ( param ) )
{ mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 14 , NULL ) ; } } {
mxArray * param = _ssGetSFcnParam ( rts , 15 ) ; if ( ! mxIsEmpty ( param ) )
{ mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 15 , NULL ) ; } } {
mxArray * param = _ssGetSFcnParam ( rts , 16 ) ; if ( ! mxIsEmpty ( param ) )
{ mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 16 , NULL ) ; } } {
mxArray * param = _ssGetSFcnParam ( rts , 17 ) ; if ( ! mxIsEmpty ( param ) )
{ mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 17 , NULL ) ; } } {
mxArray * param = _ssGetSFcnParam ( rts , 18 ) ; if ( ! mxIsEmpty ( param ) )
{ mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 18 , NULL ) ; } } {
mxArray * param = _ssGetSFcnParam ( rts , 19 ) ; if ( ! mxIsEmpty ( param ) )
{ mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 19 , NULL ) ; } } {
mxArray * param = _ssGetSFcnParam ( rts , 20 ) ; if ( ! mxIsEmpty ( param ) )
{ mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 20 , NULL ) ; } } {
mxArray * param = _ssGetSFcnParam ( rts , 21 ) ; if ( ! mxIsEmpty ( param ) )
{ mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 21 , NULL ) ; } } {
mxArray * param = _ssGetSFcnParam ( rts , 22 ) ; if ( ! mxIsEmpty ( param ) )
{ mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 22 , NULL ) ; } } } if (
! slIsRapidAcceleratorSimulating ( ) ) { SimStruct * rts = nehesmkint ->
childSfunctions [ 1 ] ; { mxArray * param = _ssGetSFcnParam ( rts , 0 ) ; if
( ! mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts
, 0 , NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 1 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 1
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 2 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 2
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 3 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 3
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 4 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 4
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 5 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 5
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 6 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 6
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 7 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 7
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 8 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 8
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 9 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 9
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 10 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 10
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 11 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 11
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 12 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 12
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 13 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 13
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 14 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 14
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 15 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 15
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 16 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 16
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 17 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 17
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 18 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 18
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 19 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 19
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 20 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 20
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 21 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 21
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 22 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 22
, NULL ) ; } } } if ( ! slIsRapidAcceleratorSimulating ( ) ) { SimStruct *
rts = nehesmkint -> childSfunctions [ 2 ] ; { mxArray * param =
_ssGetSFcnParam ( rts , 0 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 0 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 1 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 1 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 2 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 2 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 3 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 3 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 4 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 4 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 5 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 5 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 6 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 6 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 7 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 7 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 8 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 8 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 9 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 9 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 10 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 10 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 11 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 11 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 12 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 12 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 13 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 13 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 14 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 14 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 15 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 15 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 16 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 16 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 17 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 17 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 18 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 18 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 19 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 19 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 20 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 20 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 21 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 21 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 22 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 22 , NULL ) ; } } } if ( !
slIsRapidAcceleratorSimulating ( ) ) { SimStruct * rts = nehesmkint ->
childSfunctions [ 3 ] ; { mxArray * param = _ssGetSFcnParam ( rts , 0 ) ; if
( ! mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts
, 0 , NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 1 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 1
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 2 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 2
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 3 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 3
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 4 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 4
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 5 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 5
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 6 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 6
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 7 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 7
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 8 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 8
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 9 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 9
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 10 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 10
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 11 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 11
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 12 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 12
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 13 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 13
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 14 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 14
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 15 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 15
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 16 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 16
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 17 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 17
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 18 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 18
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 19 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 19
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 20 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 20
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 21 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 21
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 22 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 22
, NULL ) ; } } } if ( ! slIsRapidAcceleratorSimulating ( ) ) { SimStruct *
rts = nehesmkint -> childSfunctions [ 4 ] ; { mxArray * param =
_ssGetSFcnParam ( rts , 0 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 0 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 1 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 1 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 2 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 2 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 3 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 3 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 4 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 4 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 5 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 5 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 6 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 6 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 7 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 7 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 8 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 8 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 9 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray (
param ) ; _ssSetSFcnParam ( rts , 9 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 10 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 10 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 11 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 11 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 12 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 12 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 13 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 13 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 14 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 14 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 15 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 15 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 16 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 16 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 17 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 17 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 18 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 18 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 19 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 19 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 20 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 20 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 21 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 21 , NULL ) ; } } { mxArray * param =
_ssGetSFcnParam ( rts , 22 ) ; if ( ! mxIsEmpty ( param ) ) { mxDestroyArray
( param ) ; _ssSetSFcnParam ( rts , 22 , NULL ) ; } } } if ( !
slIsRapidAcceleratorSimulating ( ) ) { SimStruct * rts = nehesmkint ->
childSfunctions [ 5 ] ; { mxArray * param = _ssGetSFcnParam ( rts , 0 ) ; if
( ! mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts
, 0 , NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 1 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 1
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 2 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 2
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 3 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 3
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 4 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 4
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 5 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 5
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 6 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 6
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 7 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 7
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 8 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 8
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 9 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 9
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 10 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 10
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 11 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 11
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 12 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 12
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 13 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 13
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 14 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 14
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 15 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 15
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 16 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 16
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 17 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 17
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 18 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 18
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 19 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 19
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 20 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 20
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 21 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 21
, NULL ) ; } } { mxArray * param = _ssGetSFcnParam ( rts , 22 ) ; if ( !
mxIsEmpty ( param ) ) { mxDestroyArray ( param ) ; _ssSetSFcnParam ( rts , 22
, NULL ) ; } } } } void cnzzkdsgp5 ( void ) { k2snwiamgb * const nehesmkint =
& ( ope1wg3cbz . rtm ) ; NeuDiagnosticManager * diagnosticManager ;
NeslSimulationData * simulationData ; diagnosticManager = (
NeuDiagnosticManager * ) l1kpu4wb4rx . pryqdadyrt ;
neu_destroy_diagnostic_manager ( diagnosticManager ) ; simulationData = (
NeslSimulationData * ) l1kpu4wb4rx . mtmd51jfqa ;
nesl_destroy_simulation_data ( simulationData ) ; nesl_erase_simulator (
"closedLoop/Plant/Robot/Solver Configuration_1" ) ; diagnosticManager = (
NeuDiagnosticManager * ) l1kpu4wb4rx . hnzbntkygs ;
neu_destroy_diagnostic_manager ( diagnosticManager ) ; simulationData = (
NeslSimulationData * ) l1kpu4wb4rx . kiq53exfqv ;
nesl_destroy_simulation_data ( simulationData ) ; nesl_erase_simulator (
"closedLoop/Plant/Robot/Solver Configuration_1" ) ; { SimStruct * rts =
nehesmkint -> childSfunctions [ 0 ] ; sfcnTerminate ( rts ) ; } { SimStruct *
rts = nehesmkint -> childSfunctions [ 1 ] ; sfcnTerminate ( rts ) ; } {
SimStruct * rts = nehesmkint -> childSfunctions [ 2 ] ; sfcnTerminate ( rts )
; } { SimStruct * rts = nehesmkint -> childSfunctions [ 3 ] ; sfcnTerminate (
rts ) ; } { SimStruct * rts = nehesmkint -> childSfunctions [ 4 ] ;
sfcnTerminate ( rts ) ; } { SimStruct * rts = nehesmkint -> childSfunctions [
5 ] ; sfcnTerminate ( rts ) ; } diagnosticManager = ( NeuDiagnosticManager *
) l1kpu4wb4rx . hczaoupcph ; neu_destroy_diagnostic_manager (
diagnosticManager ) ; simulationData = ( NeslSimulationData * ) l1kpu4wb4rx .
bilgsbrgvi ; nesl_destroy_simulation_data ( simulationData ) ;
nesl_erase_simulator ( "closedLoop/Plant/Robot/Solver Configuration_2" ) ;
diagnosticManager = ( NeuDiagnosticManager * ) l1kpu4wb4rx . mihmamakpr ;
neu_destroy_diagnostic_manager ( diagnosticManager ) ; simulationData = (
NeslSimulationData * ) l1kpu4wb4rx . nia05kgprc ;
nesl_destroy_simulation_data ( simulationData ) ; nesl_erase_simulator (
"closedLoop/Plant/Robot/Solver Configuration_2" ) ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( nehesmkint ->
_mdlRefSfcnS , "closedLoop" , "SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" )
; } }
#if defined(MATLAB_MEX_FILE) || defined(RT_MALLOC)
static int_T RegNumInputPorts ( SimStruct * S , int_T nInputPorts ) {
_ssSetNumInputPorts ( S , nInputPorts ) ; return true ; } static int_T
RegNumOutputPorts ( SimStruct * S , int_T nOutputPorts ) {
_ssSetNumOutputPorts ( S , nOutputPorts ) ; return true ; } static int_T
FcnSetErrorStatus ( const SimStruct * S , DTypeId arg2 ) { static char msg [
256 ] ; if ( strlen ( ssGetModelName ( S ) ) < 128 ) { sprintf ( msg ,
 "S-function %s does not have a tlc file. It cannot use macros that access regDataType field in simstruct."
, ssGetModelName ( S ) ) ; } else { sprintf ( msg ,
 "A S-function does not have a tlc file. It cannot use macros that access regDataType field in simstruct."
) ; } ssSetErrorStatus ( S , msg ) ; UNUSED_PARAMETER ( arg2 ) ; return 0 ; }
#endif
void iqau2xj2y1 ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , real_T * localX_ , real_T * localMM , void * sysRanPtr , int
contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T *
rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { k2snwiamgb *
const nehesmkint = & ( ope1wg3cbz . rtm ) ; pig3puin4o2 * localX = (
pig3puin4o2 * ) localX_ ; rt_InitInfAndNaN ( sizeof ( real_T ) ) ; cy2wstccxe
. P_66 = rtInf ; cy2wstccxe . P_67 = rtInf ; cy2wstccxe . P_70 = rtInf ;
cy2wstccxe . P_71 = rtInf ; cy2wstccxe . P_381 = rtInf ; cy2wstccxe . P_382 =
rtMinusInf ; cy2wstccxe . P_383 = rtInf ; cy2wstccxe . P_384 = rtMinusInf ;
cy2wstccxe . P_389 = rtInf ; cy2wstccxe . P_390 = rtMinusInf ; cy2wstccxe .
P_391 = rtInf ; cy2wstccxe . P_392 = rtMinusInf ; cy2wstccxe . P_398 = rtInf
; cy2wstccxe . P_399 = rtMinusInf ; cy2wstccxe . P_400 = rtInf ; cy2wstccxe .
P_401 = rtMinusInf ; cy2wstccxe . P_406 = rtInf ; cy2wstccxe . P_407 =
rtMinusInf ; cy2wstccxe . P_408 = rtInf ; cy2wstccxe . P_409 = rtMinusInf ;
cy2wstccxe . P_415 = rtInf ; cy2wstccxe . P_416 = rtMinusInf ; cy2wstccxe .
P_417 = rtInf ; cy2wstccxe . P_418 = rtMinusInf ; cy2wstccxe . P_423 = rtInf
; cy2wstccxe . P_424 = rtMinusInf ; cy2wstccxe . P_425 = rtInf ; cy2wstccxe .
P_426 = rtMinusInf ; cy2wstccxe . P_432 = rtInf ; cy2wstccxe . P_433 =
rtMinusInf ; cy2wstccxe . P_434 = rtInf ; cy2wstccxe . P_435 = rtMinusInf ;
cy2wstccxe . P_440 = rtInf ; cy2wstccxe . P_441 = rtMinusInf ; cy2wstccxe .
P_442 = rtInf ; cy2wstccxe . P_443 = rtMinusInf ; cy2wstccxe . P_449 = rtInf
; cy2wstccxe . P_450 = rtMinusInf ; cy2wstccxe . P_451 = rtInf ; cy2wstccxe .
P_452 = rtMinusInf ; cy2wstccxe . P_457 = rtInf ; cy2wstccxe . P_458 =
rtMinusInf ; cy2wstccxe . P_459 = rtInf ; cy2wstccxe . P_460 = rtMinusInf ;
cy2wstccxe . P_466 = rtInf ; cy2wstccxe . P_467 = rtMinusInf ; cy2wstccxe .
P_468 = rtInf ; cy2wstccxe . P_469 = rtMinusInf ; cy2wstccxe . P_474 = rtInf
; cy2wstccxe . P_475 = rtMinusInf ; cy2wstccxe . P_476 = rtInf ; cy2wstccxe .
P_477 = rtMinusInf ; ( void ) memset ( ( void * ) nehesmkint , 0 , sizeof (
k2snwiamgb ) ) ; { int_T * mdlTsMap = nehesmkint -> Timing .
sampleTimeTaskIDArray ; mdlTsMap [ 0 ] = 0 ; mdlTsMap [ 1 ] = 1 ; nehesmkint
-> Timing . sampleTimeTaskIDPtr = ( & mdlTsMap [ 0 ] ) ; nehesmkint -> Timing
. sampleTimes = ( & nehesmkint -> Timing . sampleTimesArray [ 0 ] ) ;
nehesmkint -> Timing . offsetTimes = ( & nehesmkint -> Timing .
offsetTimesArray [ 0 ] ) ; nehesmkint -> Timing . sampleTimes [ 0 ] = ( 0.0 )
; nehesmkint -> Timing . sampleTimes [ 1 ] = ( 0.0025 ) ; nehesmkint ->
Timing . offsetTimes [ 0 ] = ( 0.0 ) ; nehesmkint -> Timing . offsetTimes [ 1
] = ( 0.0 ) ; } { int_T * mdlSampleHits = nehesmkint -> Timing .
sampleHitArray ; mdlSampleHits [ 0 ] = 1 ; mdlSampleHits [ 1 ] = 1 ;
nehesmkint -> Timing . sampleHits = ( & mdlSampleHits [ 0 ] ) ; } etrgs4mokz
[ 0 ] = mdlref_TID0 ; etrgs4mokz [ 1 ] = mdlref_TID1 ; nehesmkint ->
_mdlRefSfcnS = ( _mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ slmrRunPluginEvent ( nehesmkint -> _mdlRefSfcnS , "closedLoop" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } nehesmkint -> solverInfoPtr =
( & nehesmkint -> solverInfo ) ; nehesmkint -> Timing . stepSize = ( 0.0025 )
; rtsiSetFixedStepSize ( & nehesmkint -> solverInfo , 0.0025 ) ;
rtsiSetSolverMode ( & nehesmkint -> solverInfo , SOLVER_MODE_SINGLETASKING )
; ( void ) memset ( ( ( void * ) & iqd4nnjnc2n ) , 0 , sizeof ( mrno05akddg )
) ; { int32_T i ; for ( i = 0 ; i < 24 ; i ++ ) { iqd4nnjnc2n . ifpjipjhob [
i ] = 0.0 ; } for ( i = 0 ; i < 12 ; i ++ ) { iqd4nnjnc2n . inqhzhb0pg [ i ]
= 0.0 ; } for ( i = 0 ; i < 36 ; i ++ ) { iqd4nnjnc2n . a3m0ks3p0y [ i ] =
0.0 ; } for ( i = 0 ; i < 18 ; i ++ ) { iqd4nnjnc2n . one4ycp0a5 [ i ] = 0.0
; } iqd4nnjnc2n . k02mbhlw1t = 0.0 ; iqd4nnjnc2n . pdhwu31m4v = 0.0 ;
iqd4nnjnc2n . dzzjhrmxmh = 0.0 ; iqd4nnjnc2n . cndf4llhki = 0.0 ; iqd4nnjnc2n
. fbdziutlst = 0.0 ; iqd4nnjnc2n . g350wynvmb = 0.0 ; iqd4nnjnc2n .
dtgsdqgg0q = 0.0 ; iqd4nnjnc2n . ia5oez2mak = 0.0 ; iqd4nnjnc2n . mw0h41hol3
= 0.0 ; iqd4nnjnc2n . heefjqovkk = 0.0 ; iqd4nnjnc2n . iofmmprsur = 0.0 ;
iqd4nnjnc2n . f2obljhlxv = 0.0 ; iqd4nnjnc2n . ipmgvtmz0p = 0.0 ; iqd4nnjnc2n
. md1hwdfaw0 = 0.0 ; iqd4nnjnc2n . f2poduj1se = 0.0 ; iqd4nnjnc2n .
m2n4ar1n2i = 0.0 ; iqd4nnjnc2n . gvju2sivxf = 0.0 ; iqd4nnjnc2n . lqy11apf3e
= 0.0 ; iqd4nnjnc2n . dxindqk5ap [ 0 ] = 0.0 ; iqd4nnjnc2n . dxindqk5ap [ 1 ]
= 0.0 ; iqd4nnjnc2n . dxindqk5ap [ 2 ] = 0.0 ; iqd4nnjnc2n . dxindqk5ap [ 3 ]
= 0.0 ; iqd4nnjnc2n . mxdpm2mgmf [ 0 ] = 0.0 ; iqd4nnjnc2n . mxdpm2mgmf [ 1 ]
= 0.0 ; iqd4nnjnc2n . mxdpm2mgmf [ 2 ] = 0.0 ; iqd4nnjnc2n . mxdpm2mgmf [ 3 ]
= 0.0 ; iqd4nnjnc2n . m4am5qqyxf [ 0 ] = 0.0 ; iqd4nnjnc2n . m4am5qqyxf [ 1 ]
= 0.0 ; iqd4nnjnc2n . m4am5qqyxf [ 2 ] = 0.0 ; iqd4nnjnc2n . m4am5qqyxf [ 3 ]
= 0.0 ; iqd4nnjnc2n . jshfwrvsum [ 0 ] = 0.0 ; iqd4nnjnc2n . jshfwrvsum [ 1 ]
= 0.0 ; iqd4nnjnc2n . jshfwrvsum [ 2 ] = 0.0 ; iqd4nnjnc2n . jshfwrvsum [ 3 ]
= 0.0 ; iqd4nnjnc2n . opwk0qcg1j [ 0 ] = 0.0 ; iqd4nnjnc2n . opwk0qcg1j [ 1 ]
= 0.0 ; iqd4nnjnc2n . opwk0qcg1j [ 2 ] = 0.0 ; iqd4nnjnc2n . opwk0qcg1j [ 3 ]
= 0.0 ; iqd4nnjnc2n . kovkup1lbe [ 0 ] = 0.0 ; iqd4nnjnc2n . kovkup1lbe [ 1 ]
= 0.0 ; iqd4nnjnc2n . kovkup1lbe [ 2 ] = 0.0 ; iqd4nnjnc2n . kovkup1lbe [ 3 ]
= 0.0 ; iqd4nnjnc2n . dvdfpqupvw [ 0 ] = 0.0 ; iqd4nnjnc2n . dvdfpqupvw [ 1 ]
= 0.0 ; iqd4nnjnc2n . jboflpmlgl = 0.0 ; iqd4nnjnc2n . gvxqq2drkr [ 0 ] = 0.0
; iqd4nnjnc2n . gvxqq2drkr [ 1 ] = 0.0 ; iqd4nnjnc2n . e533on3dew = 0.0 ;
iqd4nnjnc2n . oxxrcem11e = 0.0 ; iqd4nnjnc2n . gsbroayuv4 = 0.0 ; iqd4nnjnc2n
. ex5jwcruri = 0.0 ; iqd4nnjnc2n . nuophhg5zj = 0.0 ; iqd4nnjnc2n .
eaqsdmtsbk = 0.0 ; iqd4nnjnc2n . ixesed2ean = 0.0 ; iqd4nnjnc2n . d3mpqgab3u
= 0.0 ; iqd4nnjnc2n . fprvc2pkb5 = 0.0 ; iqd4nnjnc2n . jbqxn5zlnu = 0.0 ;
iqd4nnjnc2n . m4yl5vpts2 = 0.0 ; iqd4nnjnc2n . a4ijmg00rn = 0.0 ; iqd4nnjnc2n
. cqom2nhmk2 = 0.0 ; iqd4nnjnc2n . lkxcfhia4s = 0.0 ; iqd4nnjnc2n .
ckpkttb0zm = 0.0 ; iqd4nnjnc2n . iuco14ytiq = 0.0 ; iqd4nnjnc2n . lb5otvwgy1
= 0.0 ; iqd4nnjnc2n . j43t334fqb = 0.0 ; iqd4nnjnc2n . aqqltp4gox = 0.0 ;
iqd4nnjnc2n . bsso1gl4sz = 0.0 ; iqd4nnjnc2n . ccvzquveq4 = 0.0 ; iqd4nnjnc2n
. ga313eveon = 0.0 ; iqd4nnjnc2n . am5rwkyguj = 0.0 ; iqd4nnjnc2n .
j2rqyakskv = 0.0 ; iqd4nnjnc2n . f5elnixfao = 0.0 ; iqd4nnjnc2n . asnfpaduo0
= 0.0 ; iqd4nnjnc2n . mxwazunugj [ 0 ] = 0.0 ; iqd4nnjnc2n . mxwazunugj [ 1 ]
= 0.0 ; iqd4nnjnc2n . mxwazunugj [ 2 ] = 0.0 ; iqd4nnjnc2n . mxwazunugj [ 3 ]
= 0.0 ; iqd4nnjnc2n . ecllldohtk [ 0 ] = 0.0 ; iqd4nnjnc2n . ecllldohtk [ 1 ]
= 0.0 ; iqd4nnjnc2n . cs1qx4pkft = 0.0 ; iqd4nnjnc2n . lglx1tyi3w [ 0 ] = 0.0
; iqd4nnjnc2n . lglx1tyi3w [ 1 ] = 0.0 ; iqd4nnjnc2n . jynkr5zc5k = 0.0 ;
iqd4nnjnc2n . dggq1ftd4d = 0.0 ; iqd4nnjnc2n . cc1ikppcoe = 0.0 ; iqd4nnjnc2n
. gup53f13wt = 0.0 ; iqd4nnjnc2n . cjiwv41dtz = 0.0 ; iqd4nnjnc2n .
cyvfcuag0d = 0.0 ; iqd4nnjnc2n . owxogzl3qh = 0.0 ; iqd4nnjnc2n . oj2hrval0l
= 0.0 ; iqd4nnjnc2n . lpkm4pkk2g = 0.0 ; iqd4nnjnc2n . cpjebkyeqd = 0.0 ;
iqd4nnjnc2n . f5acbxbbxd = 0.0 ; iqd4nnjnc2n . igwxrnhwvy = 0.0 ; iqd4nnjnc2n
. euxeitc2fq = 0.0 ; iqd4nnjnc2n . iphsvwpxoz = 0.0 ; iqd4nnjnc2n .
en3mr1o540 = 0.0 ; iqd4nnjnc2n . jpx50ffdto = 0.0 ; iqd4nnjnc2n . hihw2kx10l
= 0.0 ; iqd4nnjnc2n . ddtdb5154z = 0.0 ; iqd4nnjnc2n . lxk3aawz4t = 0.0 ;
iqd4nnjnc2n . eoirmu0eq4 = 0.0 ; iqd4nnjnc2n . oguy5fkfpw = 0.0 ; iqd4nnjnc2n
. fw0cndgkar = 0.0 ; iqd4nnjnc2n . c53gujuucy = 0.0 ; iqd4nnjnc2n .
ixxkxmji23 = 0.0 ; iqd4nnjnc2n . amfuazduqp = 0.0 ; iqd4nnjnc2n . psaggqmu0j
= 0.0 ; iqd4nnjnc2n . l5ozfby1n1 [ 0 ] = 0.0 ; iqd4nnjnc2n . l5ozfby1n1 [ 1 ]
= 0.0 ; iqd4nnjnc2n . l5ozfby1n1 [ 2 ] = 0.0 ; iqd4nnjnc2n . l5ozfby1n1 [ 3 ]
= 0.0 ; iqd4nnjnc2n . ni2moweccg [ 0 ] = 0.0 ; iqd4nnjnc2n . ni2moweccg [ 1 ]
= 0.0 ; iqd4nnjnc2n . cbn5w5msnc = 0.0 ; iqd4nnjnc2n . gimccxcbis [ 0 ] = 0.0
; iqd4nnjnc2n . gimccxcbis [ 1 ] = 0.0 ; iqd4nnjnc2n . clczo1piy5 = 0.0 ;
iqd4nnjnc2n . pabuhk1ylg = 0.0 ; iqd4nnjnc2n . m2w4u0arlu = 0.0 ; iqd4nnjnc2n
. ntwpnpylm1 = 0.0 ; iqd4nnjnc2n . fs3dc0tbpl = 0.0 ; iqd4nnjnc2n .
cjvyflecdr = 0.0 ; iqd4nnjnc2n . mvmmo5i5vd = 0.0 ; iqd4nnjnc2n . e5ie1xjwrq
= 0.0 ; iqd4nnjnc2n . nn2c4c4duw = 0.0 ; iqd4nnjnc2n . kktzaybug1 = 0.0 ;
iqd4nnjnc2n . ee11anycsp = 0.0 ; iqd4nnjnc2n . jcjabgspcb = 0.0 ; iqd4nnjnc2n
. nzchhvzjwf = 0.0 ; iqd4nnjnc2n . ob51ukz2bm = 0.0 ; iqd4nnjnc2n .
aoi5sx3qcq = 0.0 ; iqd4nnjnc2n . kinhb41jtj = 0.0 ; iqd4nnjnc2n . kplrhafmh3
= 0.0 ; iqd4nnjnc2n . nm0gzkykgc = 0.0 ; iqd4nnjnc2n . d3bcnxa0ko = 0.0 ;
iqd4nnjnc2n . n3hickxmon = 0.0 ; iqd4nnjnc2n . nuvirjsljk = 0.0 ; iqd4nnjnc2n
. pqudmcvigc = 0.0 ; iqd4nnjnc2n . cxtvdmho2w = 0.0 ; iqd4nnjnc2n .
pgojyqs2kb = 0.0 ; iqd4nnjnc2n . jq2t1vws1o = 0.0 ; iqd4nnjnc2n . mvuwiian3j
= 0.0 ; iqd4nnjnc2n . ppdvvvhxwt [ 0 ] = 0.0 ; iqd4nnjnc2n . ppdvvvhxwt [ 1 ]
= 0.0 ; iqd4nnjnc2n . ppdvvvhxwt [ 2 ] = 0.0 ; iqd4nnjnc2n . ppdvvvhxwt [ 3 ]
= 0.0 ; iqd4nnjnc2n . laxrqi2iig [ 0 ] = 0.0 ; iqd4nnjnc2n . laxrqi2iig [ 1 ]
= 0.0 ; iqd4nnjnc2n . evydgbi4vg = 0.0 ; iqd4nnjnc2n . dfa1yu3sfp [ 0 ] = 0.0
; iqd4nnjnc2n . dfa1yu3sfp [ 1 ] = 0.0 ; iqd4nnjnc2n . dxksw5kbg2 = 0.0 ;
iqd4nnjnc2n . fhq2gw2vcg = 0.0 ; iqd4nnjnc2n . nauwt2pif4 = 0.0 ; iqd4nnjnc2n
. bsoahlrjiv = 0.0 ; iqd4nnjnc2n . fb2s2obyf0 = 0.0 ; iqd4nnjnc2n .
j44l5nmvh1 = 0.0 ; iqd4nnjnc2n . iqbavtlu0x = 0.0 ; iqd4nnjnc2n . cugk41zl3m
= 0.0 ; iqd4nnjnc2n . h3sgdlsv1k = 0.0 ; iqd4nnjnc2n . cy1ksr03v3 = 0.0 ;
iqd4nnjnc2n . eity53wqmz = 0.0 ; iqd4nnjnc2n . nv0ihfsqee = 0.0 ; iqd4nnjnc2n
. bmsqajkl3i = 0.0 ; iqd4nnjnc2n . dkiwzssrrd = 0.0 ; iqd4nnjnc2n .
et1bih2zwh = 0.0 ; iqd4nnjnc2n . cg3hcg53ow = 0.0 ; iqd4nnjnc2n . mz1mdyrpzb
= 0.0 ; iqd4nnjnc2n . eqlmw30r4b = 0.0 ; iqd4nnjnc2n . gqofhs32zl = 0.0 ;
iqd4nnjnc2n . ewk2raypbg = 0.0 ; iqd4nnjnc2n . n41gnetfgk = 0.0 ; iqd4nnjnc2n
. bcqlwdbs5s = 0.0 ; iqd4nnjnc2n . hulk0vkayl = 0.0 ; iqd4nnjnc2n .
gtb0t3ry1y = 0.0 ; iqd4nnjnc2n . e3cqs5nhjw = 0.0 ; iqd4nnjnc2n . hev050xsp2
= 0.0 ; iqd4nnjnc2n . gh10p1ptww [ 0 ] = 0.0 ; iqd4nnjnc2n . gh10p1ptww [ 1 ]
= 0.0 ; iqd4nnjnc2n . gh10p1ptww [ 2 ] = 0.0 ; iqd4nnjnc2n . gh10p1ptww [ 3 ]
= 0.0 ; iqd4nnjnc2n . bbvyttcgmj [ 0 ] = 0.0 ; iqd4nnjnc2n . bbvyttcgmj [ 1 ]
= 0.0 ; iqd4nnjnc2n . g3kokdjcok = 0.0 ; iqd4nnjnc2n . nd2k2c1rii [ 0 ] = 0.0
; iqd4nnjnc2n . nd2k2c1rii [ 1 ] = 0.0 ; iqd4nnjnc2n . ghuaibncue = 0.0 ;
iqd4nnjnc2n . pwp32mkxmp = 0.0 ; iqd4nnjnc2n . el0u4ptz3m = 0.0 ; iqd4nnjnc2n
. if2de54hzv = 0.0 ; iqd4nnjnc2n . nmgje50msd = 0.0 ; iqd4nnjnc2n .
p0ws55j4kv = 0.0 ; iqd4nnjnc2n . my0xq3oeng = 0.0 ; iqd4nnjnc2n . ijhvoblfqp
= 0.0 ; iqd4nnjnc2n . ichqtsmstf = 0.0 ; iqd4nnjnc2n . lq2qrnvgbd = 0.0 ;
iqd4nnjnc2n . ltaelwvlfx = 0.0 ; iqd4nnjnc2n . i35bda5fqu = 0.0 ; iqd4nnjnc2n
. euwsshzwsz = 0.0 ; iqd4nnjnc2n . euc1541upk = 0.0 ; iqd4nnjnc2n .
nwbgtuxij0 = 0.0 ; iqd4nnjnc2n . p54vogxihi = 0.0 ; iqd4nnjnc2n . ma3bvfapft
= 0.0 ; iqd4nnjnc2n . eqzd1gajqp = 0.0 ; iqd4nnjnc2n . pwrnqu13gx = 0.0 ;
iqd4nnjnc2n . o0f4tiqguw = 0.0 ; iqd4nnjnc2n . buswlgzps3 = 0.0 ; iqd4nnjnc2n
. osjyiqh0ob = 0.0 ; iqd4nnjnc2n . bw05k0mpda = 0.0 ; iqd4nnjnc2n .
auykwk5il3 = 0.0 ; iqd4nnjnc2n . nfaiw5glsx = 0.0 ; iqd4nnjnc2n . kneg4z3eqy
= 0.0 ; iqd4nnjnc2n . pwdpdq4j44 [ 0 ] = 0.0 ; iqd4nnjnc2n . pwdpdq4j44 [ 1 ]
= 0.0 ; iqd4nnjnc2n . pwdpdq4j44 [ 2 ] = 0.0 ; iqd4nnjnc2n . pwdpdq4j44 [ 3 ]
= 0.0 ; iqd4nnjnc2n . huiknpmeom [ 0 ] = 0.0 ; iqd4nnjnc2n . huiknpmeom [ 1 ]
= 0.0 ; iqd4nnjnc2n . fef4xn2fp5 = 0.0 ; iqd4nnjnc2n . mj5b4ytj5n [ 0 ] = 0.0
; iqd4nnjnc2n . mj5b4ytj5n [ 1 ] = 0.0 ; iqd4nnjnc2n . lclhh42nxp = 0.0 ;
iqd4nnjnc2n . hazyu5dee4 = 0.0 ; iqd4nnjnc2n . bmymblppux = 0.0 ; iqd4nnjnc2n
. mtsky5ga42 = 0.0 ; iqd4nnjnc2n . irzj1knv2x = 0.0 ; iqd4nnjnc2n .
b5cyprxpem = 0.0 ; iqd4nnjnc2n . oqgie4xmek = 0.0 ; iqd4nnjnc2n . fcda1empap
= 0.0 ; iqd4nnjnc2n . pibccbzglq = 0.0 ; iqd4nnjnc2n . mgwutfxaxu = 0.0 ;
iqd4nnjnc2n . apu1zqolri = 0.0 ; iqd4nnjnc2n . pctkrqa5uw = 0.0 ; iqd4nnjnc2n
. n31zxbxxwf = 0.0 ; iqd4nnjnc2n . cdv3ygqxjn = 0.0 ; iqd4nnjnc2n .
hmdjfbj2px = 0.0 ; iqd4nnjnc2n . bv43glsamx = 0.0 ; iqd4nnjnc2n . bcpoonnq4a
= 0.0 ; iqd4nnjnc2n . pvnmppu5sq = 0.0 ; iqd4nnjnc2n . nweukartad = 0.0 ;
iqd4nnjnc2n . osk5s5rhdj = 0.0 ; iqd4nnjnc2n . n531orgl43 = 0.0 ; iqd4nnjnc2n
. jdtpfzobve = 0.0 ; iqd4nnjnc2n . ow0zitwej4 = 0.0 ; iqd4nnjnc2n .
azh5omjcfp = 0.0 ; iqd4nnjnc2n . natbjm3v0a = 0.0 ; iqd4nnjnc2n . ehvgzznjj4
= 0.0 ; iqd4nnjnc2n . g4fwetwo31 [ 0 ] = 0.0 ; iqd4nnjnc2n . g4fwetwo31 [ 1 ]
= 0.0 ; iqd4nnjnc2n . g4fwetwo31 [ 2 ] = 0.0 ; iqd4nnjnc2n . g4fwetwo31 [ 3 ]
= 0.0 ; iqd4nnjnc2n . hhczjtzyj5 [ 0 ] = 0.0 ; iqd4nnjnc2n . hhczjtzyj5 [ 1 ]
= 0.0 ; iqd4nnjnc2n . hhczjtzyj5 [ 2 ] = 0.0 ; iqd4nnjnc2n . hhczjtzyj5 [ 3 ]
= 0.0 ; iqd4nnjnc2n . imtlp51aqd [ 0 ] = 0.0 ; iqd4nnjnc2n . imtlp51aqd [ 1 ]
= 0.0 ; iqd4nnjnc2n . imtlp51aqd [ 2 ] = 0.0 ; iqd4nnjnc2n . imtlp51aqd [ 3 ]
= 0.0 ; iqd4nnjnc2n . oe1dnrny2q [ 0 ] = 0.0 ; iqd4nnjnc2n . oe1dnrny2q [ 1 ]
= 0.0 ; iqd4nnjnc2n . oe1dnrny2q [ 2 ] = 0.0 ; iqd4nnjnc2n . oe1dnrny2q [ 3 ]
= 0.0 ; iqd4nnjnc2n . e3os4rwhiv [ 0 ] = 0.0 ; iqd4nnjnc2n . e3os4rwhiv [ 1 ]
= 0.0 ; iqd4nnjnc2n . e3os4rwhiv [ 2 ] = 0.0 ; iqd4nnjnc2n . e3os4rwhiv [ 3 ]
= 0.0 ; iqd4nnjnc2n . bfaefzzyat [ 0 ] = 0.0 ; iqd4nnjnc2n . bfaefzzyat [ 1 ]
= 0.0 ; iqd4nnjnc2n . bfaefzzyat [ 2 ] = 0.0 ; iqd4nnjnc2n . bfaefzzyat [ 3 ]
= 0.0 ; iqd4nnjnc2n . b10z030dj4 [ 0 ] = 0.0 ; iqd4nnjnc2n . b10z030dj4 [ 1 ]
= 0.0 ; iqd4nnjnc2n . b10z030dj4 [ 2 ] = 0.0 ; iqd4nnjnc2n . b10z030dj4 [ 3 ]
= 0.0 ; iqd4nnjnc2n . do2div5dmu = 0.0 ; iqd4nnjnc2n . inbc5rmj0k = 0.0 ;
iqd4nnjnc2n . datlkjknld = 0.0 ; iqd4nnjnc2n . ltqcojipph = 0.0 ; iqd4nnjnc2n
. nlm325sgjs = 0.0 ; iqd4nnjnc2n . ahkt3v2tkj = 0.0 ; iqd4nnjnc2n .
lnviaa3aja = 0.0 ; iqd4nnjnc2n . pjmyemwyst = 0.0 ; iqd4nnjnc2n . lvgwomq1ya
= 0.0 ; iqd4nnjnc2n . kwvx5icu52 = 0.0 ; iqd4nnjnc2n . aklkh2iyp2 = 0.0 ;
iqd4nnjnc2n . l00kscgz5x = 0.0 ; iqd4nnjnc2n . p2jg50l41x = 0.0 ; iqd4nnjnc2n
. dzs221sche = 0.0 ; iqd4nnjnc2n . om1dpdvyxj = 0.0 ; iqd4nnjnc2n .
l24gr3t25r = 0.0 ; iqd4nnjnc2n . fgqlt0352h = 0.0 ; iqd4nnjnc2n . gsoejj5gry
= 0.0 ; iqd4nnjnc2n . ak2zdkdvjm = 0.0 ; iqd4nnjnc2n . no0iooeye4 = 0.0 ;
iqd4nnjnc2n . cmfmx0kuqh = 0.0 ; iqd4nnjnc2n . bqdylagldh = 0.0 ; iqd4nnjnc2n
. cygpl2eh3n = 0.0 ; iqd4nnjnc2n . eokjyir44v = 0.0 ; iqd4nnjnc2n .
dunjupvfq0 = 0.0 ; iqd4nnjnc2n . jtqezz3n5v = 0.0 ; iqd4nnjnc2n . d4ckjpxf4d
= 0.0 ; iqd4nnjnc2n . jfrwhhaoxa = 0.0 ; iqd4nnjnc2n . jwy0sllq0r = 0.0 ;
iqd4nnjnc2n . isxtmltnln = 0.0 ; iqd4nnjnc2n . bi2q4i3qsl = 0.0 ; iqd4nnjnc2n
. bd4upxutxh = 0.0 ; iqd4nnjnc2n . op3kzfupwu = 0.0 ; iqd4nnjnc2n .
ac5tg4zqmv = 0.0 ; iqd4nnjnc2n . o1p24pcmux = 0.0 ; iqd4nnjnc2n . mmdwsrlci3
= 0.0 ; iqd4nnjnc2n . hyezcvutd0 = 0.0 ; iqd4nnjnc2n . krazaowazm = 0.0 ;
iqd4nnjnc2n . h5dhbabhyc = 0.0 ; iqd4nnjnc2n . gocnlro3ua = 0.0 ; iqd4nnjnc2n
. dr00wzmmfp = 0.0 ; iqd4nnjnc2n . pllzd1yzu1 = 0.0 ; iqd4nnjnc2n .
goceextyjn = 0.0 ; iqd4nnjnc2n . bsldqtkyrx = 0.0 ; iqd4nnjnc2n . m33loiozqp
= 0.0 ; iqd4nnjnc2n . dtzo3eih3h = 0.0 ; iqd4nnjnc2n . by0cvwg5fo = 0.0 ;
iqd4nnjnc2n . grfgj4ibi4 = 0.0 ; iqd4nnjnc2n . o50nw3ugmm = 0.0 ; iqd4nnjnc2n
. fkurul1irj = 0.0 ; iqd4nnjnc2n . ktj3bc45nf = 0.0 ; iqd4nnjnc2n .
ll2bp3mzb5 = 0.0 ; iqd4nnjnc2n . azkpe3xngh = 0.0 ; iqd4nnjnc2n . bplheqo1n1
= 0.0 ; iqd4nnjnc2n . iqorpfqvex = 0.0 ; iqd4nnjnc2n . dfhhva0f3s = 0.0 ;
iqd4nnjnc2n . bmjg0kms3r = 0.0 ; iqd4nnjnc2n . nbvso2z4hg = 0.0 ; iqd4nnjnc2n
. itxq3inszm = 0.0 ; iqd4nnjnc2n . ijctsqavfk = 0.0 ; iqd4nnjnc2n .
hb4rbdqlcw = 0.0 ; iqd4nnjnc2n . eiic0jvpln = 0.0 ; iqd4nnjnc2n . eohyobbmek
= 0.0 ; iqd4nnjnc2n . m2kpw0vl0e = 0.0 ; iqd4nnjnc2n . m0f3jhv5qh = 0.0 ;
iqd4nnjnc2n . jsrt3bznjs = 0.0 ; iqd4nnjnc2n . muix2l5juf = 0.0 ; iqd4nnjnc2n
. feo1305x5l = 0.0 ; iqd4nnjnc2n . fdlp20qiat = 0.0 ; iqd4nnjnc2n .
hot10qhgpk = 0.0 ; iqd4nnjnc2n . hdtqbblv4p = 0.0 ; iqd4nnjnc2n . ogguiilgfn
= 0.0 ; } ( void ) memset ( ( void * ) & l1kpu4wb4rx , 0 , sizeof (
ar4cvowam3t ) ) ; l1kpu4wb4rx . hlha5jwilk = 0.0 ; l1kpu4wb4rx . ct1fp3ytps =
0.0 ; l1kpu4wb4rx . hbxvwhds10 = 0.0 ; l1kpu4wb4rx . jycpyvgbwk = 0.0 ;
l1kpu4wb4rx . pvzgszxw0h = 0.0 ; l1kpu4wb4rx . ed0zskjjvf = 0.0 ; l1kpu4wb4rx
. kdbgqe1rl0 = 0.0 ; l1kpu4wb4rx . mkl1pjdrap = 0.0 ; l1kpu4wb4rx .
ckaxc2yuzj = 0.0 ; l1kpu4wb4rx . nnm5ezmxoj = 0.0 ; l1kpu4wb4rx . icxmsd205h
= 0.0 ; l1kpu4wb4rx . petosikypy = 0.0 ; l1kpu4wb4rx . mikve0glkh = 0.0 ;
l1kpu4wb4rx . ccquv3ehj4 = 0.0 ; l1kpu4wb4rx . pbidohzefw = 0.0 ; l1kpu4wb4rx
. lzgpy1pmbg = 0.0 ; l1kpu4wb4rx . ndcz2pevdt = 0.0 ; l1kpu4wb4rx .
e2xmk045t3 = 0.0 ; l1kpu4wb4rx . ceeqqvhrmq = 0.0 ; l1kpu4wb4rx . grtf40g3km
= 0.0 ; l1kpu4wb4rx . ipoqi0vxan = 0.0 ; l1kpu4wb4rx . h5eac0mibo = 0.0 ;
l1kpu4wb4rx . pa4czare1d = 0.0 ; l1kpu4wb4rx . ckwjuadpca = 0.0 ; l1kpu4wb4rx
. eh1viw32xa = 0.0 ; l1kpu4wb4rx . froc5u33zh = 0.0 ; l1kpu4wb4rx .
ouygc4kcvb = 0.0 ; l1kpu4wb4rx . kjml2jdhog = 0.0 ; l1kpu4wb4rx . onzlg3sfc1
= 0.0 ; l1kpu4wb4rx . dsxwjihxvj = 0.0 ; l1kpu4wb4rx . aqmkm5qp10 = 0.0 ;
l1kpu4wb4rx . mssfecnie3 = 0.0 ; l1kpu4wb4rx . g2b0tbo4r5 = 0.0 ; l1kpu4wb4rx
. kj4m4y1hwn = 0.0 ; l1kpu4wb4rx . daodt1zxg3 = 0.0 ; l1kpu4wb4rx .
k2jw35opgq = 0.0 ; l1kpu4wb4rx . e0gmlv2sjn = 0.0 ; l1kpu4wb4rx . limd3gdwcq
= 0.0 ; l1kpu4wb4rx . nngs2uucok = 0.0 ; l1kpu4wb4rx . awmyjetxto = 0.0 ;
l1kpu4wb4rx . jjqy4wbyuk = 0.0 ; l1kpu4wb4rx . lgzj3kmwmk = 0.0 ; l1kpu4wb4rx
. o32wlonvfn = 0.0 ; l1kpu4wb4rx . d5gswgg44w = 0.0 ; l1kpu4wb4rx .
cwuv444nvd = 0.0 ; l1kpu4wb4rx . p2mtfvoju0 = 0.0 ; l1kpu4wb4rx . au1qch111s
= 0.0 ; l1kpu4wb4rx . eiqgdqqruu = 0.0 ; l1kpu4wb4rx . arjxbzyxfd = 0.0 ;
l1kpu4wb4rx . iep3kan2rd = 0.0 ; l1kpu4wb4rx . m42uoygnhd = 0.0 ; l1kpu4wb4rx
. ajirvaztbv = 0.0 ; l1kpu4wb4rx . kt2l00xp53 = 0.0 ; l1kpu4wb4rx .
koqig0mkgk = 0.0 ; l1kpu4wb4rx . g2joetjd4n [ 0 ] = 0.0 ; l1kpu4wb4rx .
g2joetjd4n [ 1 ] = 0.0 ; l1kpu4wb4rx . ajl2ukv15n [ 0 ] = 0.0 ; l1kpu4wb4rx .
ajl2ukv15n [ 1 ] = 0.0 ; l1kpu4wb4rx . byfchznm5b [ 0 ] = 0.0 ; l1kpu4wb4rx .
byfchznm5b [ 1 ] = 0.0 ; l1kpu4wb4rx . di3hvnfgwf [ 0 ] = 0.0 ; l1kpu4wb4rx .
di3hvnfgwf [ 1 ] = 0.0 ; l1kpu4wb4rx . bu5ibyt3ar [ 0 ] = 0.0 ; l1kpu4wb4rx .
bu5ibyt3ar [ 1 ] = 0.0 ; l1kpu4wb4rx . kxgtmxa2p2 [ 0 ] = 0.0 ; l1kpu4wb4rx .
kxgtmxa2p2 [ 1 ] = 0.0 ; l1kpu4wb4rx . i3bqhqdooa = 0.0 ; l1kpu4wb4rx .
no0lkkst0o = 0.0 ; l1kpu4wb4rx . ebgm2o4pem = 0.0 ; l1kpu4wb4rx . bztbsebwen
= 0.0 ; closedLoop_InitializeDataMapInfo ( nehesmkint , localX , sysRanPtr ,
contextTid ) ; { nehesmkint -> massMatrixBasePr = localMM ; l1kpu4wb4rx .
kqn0icr3hm = 42 ; } nehesmkint -> Sizes . numSFcns = ( 6 ) ; { ( void )
memset ( ( void * ) & nehesmkint -> NonInlinedSFcns . childSFunctions [ 0 ] ,
0 , 6 * sizeof ( SimStruct ) ) ; nehesmkint -> childSfunctions = ( &
nehesmkint -> NonInlinedSFcns . childSFunctionPtrs [ 0 ] ) ; { int_T i ; for
( i = 0 ; i < 6 ; i ++ ) { nehesmkint -> childSfunctions [ i ] = ( &
nehesmkint -> NonInlinedSFcns . childSFunctions [ i ] ) ; } } { SimStruct *
rts = nehesmkint -> childSfunctions [ 0 ] ; time_T * sfcnPeriod = nehesmkint
-> NonInlinedSFcns . Sfcn0 . sfcnPeriod ; time_T * sfcnOffset = nehesmkint ->
NonInlinedSFcns . Sfcn0 . sfcnOffset ; int_T * sfcnTsMap = nehesmkint ->
NonInlinedSFcns . Sfcn0 . sfcnTsMap ; ( void ) memset ( ( void * ) sfcnPeriod
, 0 , sizeof ( time_T ) * 1 ) ; ( void ) memset ( ( void * ) sfcnOffset , 0 ,
sizeof ( time_T ) * 1 ) ; ssSetSampleTimePtr ( rts , & sfcnPeriod [ 0 ] ) ;
ssSetOffsetTimePtr ( rts , & sfcnOffset [ 0 ] ) ; _ssSetSampleTimeTaskIDPtr (
rts , sfcnTsMap ) ; { ssSetBlkInfo2Ptr ( rts , & nehesmkint ->
NonInlinedSFcns . blkInfo2 [ 0 ] ) ; } _ssSetBlkInfo2PortInfo2Ptr ( rts , &
nehesmkint -> NonInlinedSFcns . inputOutputPortInfo2 [ 0 ] ) ;
ssSetRTWSfcnInfo ( rts , nehesmkint -> sfcnInfo ) ; _ssSetMdlInfoPtr ( rts ,
ssGetMdlInfoPtr ( _mdlRefSfcnS ) ) ; { ssSetModelMethods2 ( rts , &
nehesmkint -> NonInlinedSFcns . methods2 [ 0 ] ) ; } { ssSetModelMethods3 (
rts , & nehesmkint -> NonInlinedSFcns . methods3 [ 0 ] ) ; } {
ssSetModelMethods4 ( rts , & nehesmkint -> NonInlinedSFcns . methods4 [ 0 ] )
; } { ssSetStatesInfo2 ( rts , & nehesmkint -> NonInlinedSFcns . statesInfo2
[ 0 ] ) ; ssSetPeriodicStatesInfo ( rts , & nehesmkint -> NonInlinedSFcns .
periodicStatesInfo [ 0 ] ) ; } ssSetRegNumInputPortsFcn ( rts , (
_ssRegNumInputPortsFcn ) RegNumInputPorts ) ; ssSetRegNumInputPortsFcnArg (
rts , rts ) ; { _ssSetNumInputPorts ( rts , 1 ) ; ssSetPortInfoForInputs (
rts , & nehesmkint -> NonInlinedSFcns . Sfcn0 . inputPortInfo [ 0 ] ) ;
_ssSetPortInfo2ForInputUnits ( rts , & nehesmkint -> NonInlinedSFcns . Sfcn0
. inputPortUnits [ 0 ] ) ; ssSetInputPortUnit ( rts , 0 , 1 ) ;
_ssSetPortInfo2ForInputCoSimAttribute ( rts , & nehesmkint -> NonInlinedSFcns
. Sfcn0 . inputPortCoSimAttribute [ 0 ] ) ;
ssSetInputPortIsContinuousQuantity ( rts , 0 , 0 ) ; { real_T const * *
sfcnUPtrs = ( real_T const * * ) & nehesmkint -> NonInlinedSFcns . Sfcn0 .
UPtrs0 ; sfcnUPtrs [ 0 ] = & iqd4nnjnc2n . pdhwu31m4v ;
_ssSetInputPortSignalPtrs ( rts , 0 , ( InputPtrsType ) & sfcnUPtrs [ 0 ] ) ;
_ssSetInputPortNumDimensions ( rts , 0 , 1 ) ; ssSetInputPortWidth ( rts , 0
, 1 ) ; } } ssSetRegNumOutputPortsFcn ( rts , ( _ssRegNumOutputPortsFcn )
RegNumOutputPorts ) ; ssSetRegNumOutputPortsFcnArg ( rts , rts ) ;
_ssSetModelName ( rts , "scblock" ) ; _ssSetPath ( rts ,
"closedLoop/Plant/Robot/Scope /S-Function" ) ; ssSetRTModel ( rts ,
nehesmkint ) ; _ssSetParentSS ( rts , _mdlRefSfcnS ) ; _ssSetRootSS ( rts ,
ssGetRootSS ( _mdlRefSfcnS ) ) ; ssSetVersion ( rts ,
SIMSTRUCT_VERSION_LEVEL2 ) ; { mxArray * * sfcnParams = ( mxArray * * ) &
nehesmkint -> NonInlinedSFcns . Sfcn0 . params ; _ssSetSFcnParamsCount ( rts
, 23 ) ; _ssSetSFcnParamsPtr ( rts , & sfcnParams [ 0 ] ) ;
#if defined(MATLAB_MEX_FILE)
{ uint_T * attribs = ( uint_T * ) & nehesmkint -> NonInlinedSFcns . Sfcn0 .
attribs ; ssSetSFcnParamAttribsPtr ( rts , & attribs [ 0 ] ) ; ( void )
memset ( ( void * ) & attribs [ 0 ] , 0 , 23 * sizeof ( uint_T ) ) ; }
#endif
if ( ! slIsRapidAcceleratorSimulating ( ) ) { mxArray * param ; int_T i ;
real_T * vals ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_97 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 0 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_99 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 1 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_101 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 2 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_103 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 3 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 2 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) cy2wstccxe . P_105 ;
for ( i = 0 ; i < 2 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 4 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_107 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 5 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_109 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 6 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_111 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 7 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_113 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 8 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_115 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 9 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_117 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 10 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_119 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 11 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_121 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 12 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_123 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 13 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_125 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 14 , param )
; param = mxCreateDoubleMatrix ( 1 , 8 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) cy2wstccxe . P_127 ; for ( i = 0 ; i < 8 ; i ++
) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 15 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 4 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) cy2wstccxe . P_129 ;
for ( i = 0 ; i < 4 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 16 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_131 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 17 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_133 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 18 , param )
; param = mxCreateDoubleMatrix ( 1 , 6 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) cy2wstccxe . P_135 ; for ( i = 0 ; i < 6 ; i ++
) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 19 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_137 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 20 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_139 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 21 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_141 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 22 , param )
; } else { _ssSetSFcnParam ( rts , 0 , ( mxArray * ) cy2wstccxe . P_96 ) ;
_ssSetSFcnParam ( rts , 1 , ( mxArray * ) cy2wstccxe . P_98 ) ;
_ssSetSFcnParam ( rts , 2 , ( mxArray * ) cy2wstccxe . P_100 ) ;
_ssSetSFcnParam ( rts , 3 , ( mxArray * ) cy2wstccxe . P_102 ) ;
_ssSetSFcnParam ( rts , 4 , ( mxArray * ) cy2wstccxe . P_104 ) ;
_ssSetSFcnParam ( rts , 5 , ( mxArray * ) cy2wstccxe . P_106 ) ;
_ssSetSFcnParam ( rts , 6 , ( mxArray * ) cy2wstccxe . P_108 ) ;
_ssSetSFcnParam ( rts , 7 , ( mxArray * ) cy2wstccxe . P_110 ) ;
_ssSetSFcnParam ( rts , 8 , ( mxArray * ) cy2wstccxe . P_112 ) ;
_ssSetSFcnParam ( rts , 9 , ( mxArray * ) cy2wstccxe . P_114 ) ;
_ssSetSFcnParam ( rts , 10 , ( mxArray * ) cy2wstccxe . P_116 ) ;
_ssSetSFcnParam ( rts , 11 , ( mxArray * ) cy2wstccxe . P_118 ) ;
_ssSetSFcnParam ( rts , 12 , ( mxArray * ) cy2wstccxe . P_120 ) ;
_ssSetSFcnParam ( rts , 13 , ( mxArray * ) cy2wstccxe . P_122 ) ;
_ssSetSFcnParam ( rts , 14 , ( mxArray * ) cy2wstccxe . P_124 ) ;
_ssSetSFcnParam ( rts , 15 , ( mxArray * ) cy2wstccxe . P_126 ) ;
_ssSetSFcnParam ( rts , 16 , ( mxArray * ) cy2wstccxe . P_128 ) ;
_ssSetSFcnParam ( rts , 17 , ( mxArray * ) cy2wstccxe . P_130 ) ;
_ssSetSFcnParam ( rts , 18 , ( mxArray * ) cy2wstccxe . P_132 ) ;
_ssSetSFcnParam ( rts , 19 , ( mxArray * ) cy2wstccxe . P_134 ) ;
_ssSetSFcnParam ( rts , 20 , ( mxArray * ) cy2wstccxe . P_136 ) ;
_ssSetSFcnParam ( rts , 21 , ( mxArray * ) cy2wstccxe . P_138 ) ;
_ssSetSFcnParam ( rts , 22 , ( mxArray * ) cy2wstccxe . P_140 ) ; } }
_ssSetIWork ( rts , ( int_T * ) & l1kpu4wb4rx . eiifcbyv3z ) ; { struct
_ssDWorkRecord * dWorkRecord = ( struct _ssDWorkRecord * ) & nehesmkint ->
NonInlinedSFcns . Sfcn0 . dWork ; struct _ssDWorkAuxRecord * dWorkAuxRecord =
( struct _ssDWorkAuxRecord * ) & nehesmkint -> NonInlinedSFcns . Sfcn0 .
dWorkAux ; ssSetSFcnDWork ( rts , dWorkRecord ) ; ssSetSFcnDWorkAux ( rts ,
dWorkAuxRecord ) ; _ssSetNumDWork ( rts , 1 ) ; ssSetDWorkWidth ( rts , 0 , 1
) ; ssSetDWorkDataType ( rts , 0 , SS_INTEGER ) ; ssSetDWorkComplexSignal (
rts , 0 , 0 ) ; _ssSetDWork ( rts , 0 , & l1kpu4wb4rx . eiifcbyv3z ) ; } (
rts ) -> regDataType . arg1 = ( ( void * ) ( rts ) ) ; ( rts ) -> regDataType
. registerFcn = ( ( OldRegisterDataType ) FcnSetErrorStatus ) ; ( rts ) ->
regDataType . getSizeFcn = ( ( GetDataTypeSize ) FcnSetErrorStatus ) ; ( rts
) -> regDataType . getZeroFcn = ( ( GetDataTypeZero ) FcnSetErrorStatus ) ; (
rts ) -> regDataType . getNameFcn = ( ( GetDataTypeName ) FcnSetErrorStatus )
; ( rts ) -> regDataType . getIdFcn = ( ( GetDataTypeId ) FcnSetErrorStatus )
; if ( ! slIsRapidAcceleratorSimulating ( ) ) { int_T i ; mxArray * plhs [ 1
] ; mxArray * prhs [ 4 ] ; double * pr ; volatile int_T * intS = ( int_T * )
& rts ; int_T addrlen = sizeof ( SimStruct * ) ; int_T m = addrlen / sizeof (
int_T ) + 1 ; prhs [ 0 ] = mxCreateDoubleMatrix ( 0 , 0 , mxREAL ) ; prhs [ 1
] = mxCreateDoubleMatrix ( m , 1 , mxREAL ) ; pr = mxGetPr ( prhs [ 1 ] ) ;
for ( i = 0 ; i < m - 1 ; i ++ ) { pr [ i ] = ( double ) intS [ i ] ; } pr [
i ] = ( double ) SIMSTRUCT_VERSION_LEVEL2 ; prhs [ 2 ] = mxCreateDoubleMatrix
( 0 , 0 , mxREAL ) ; prhs [ 3 ] = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
ssSetRegInputPortDimensionInfoFcn ( rts , ( NULL ) ) ;
ssSetRegOutputPortDimensionInfoFcn ( rts , ( NULL ) ) ; mexCallMATLAB ( 1 ,
plhs , 4 , prhs , "scblock" ) ; mxDestroyArray ( plhs [ 0 ] ) ;
mxDestroyArray ( prhs [ 0 ] ) ; mxDestroyArray ( prhs [ 1 ] ) ;
mxDestroyArray ( prhs [ 2 ] ) ; mxDestroyArray ( prhs [ 3 ] ) ; } else {
scblock ( rts ) ; sfcnInitializeSizes ( rts ) ; } sfcnInitializeSampleTimes (
rts ) ; ssSetSampleTime ( rts , 0 , 0.0 ) ; ssSetOffsetTime ( rts , 0 , 0.0 )
; sfcnTsMap [ 0 ] = mdlref_TID0 ; ssSetInputPortWidth ( rts , 0 , 1 ) ;
ssSetInputPortDataType ( rts , 0 , SS_DOUBLE ) ; ssSetInputPortComplexSignal
( rts , 0 , 0 ) ; ssSetInputPortFrameData ( rts , 0 , 0 ) ;
ssSetInputPortUnit ( rts , 0 , 1 ) ; ssSetInputPortIsContinuousQuantity ( rts
, 0 , 0 ) ; ssSetNumNonsampledZCs ( rts , 0 ) ; _ssSetInputPortConnected (
rts , 0 , 1 ) ; _ssSetInputPortBufferDstPort ( rts , 0 , - 1 ) ; } {
SimStruct * rts = nehesmkint -> childSfunctions [ 1 ] ; time_T * sfcnPeriod =
nehesmkint -> NonInlinedSFcns . Sfcn1 . sfcnPeriod ; time_T * sfcnOffset =
nehesmkint -> NonInlinedSFcns . Sfcn1 . sfcnOffset ; int_T * sfcnTsMap =
nehesmkint -> NonInlinedSFcns . Sfcn1 . sfcnTsMap ; ( void ) memset ( ( void
* ) sfcnPeriod , 0 , sizeof ( time_T ) * 1 ) ; ( void ) memset ( ( void * )
sfcnOffset , 0 , sizeof ( time_T ) * 1 ) ; ssSetSampleTimePtr ( rts , &
sfcnPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rts , & sfcnOffset [ 0 ] ) ;
_ssSetSampleTimeTaskIDPtr ( rts , sfcnTsMap ) ; { ssSetBlkInfo2Ptr ( rts , &
nehesmkint -> NonInlinedSFcns . blkInfo2 [ 1 ] ) ; }
_ssSetBlkInfo2PortInfo2Ptr ( rts , & nehesmkint -> NonInlinedSFcns .
inputOutputPortInfo2 [ 1 ] ) ; ssSetRTWSfcnInfo ( rts , nehesmkint ->
sfcnInfo ) ; _ssSetMdlInfoPtr ( rts , ssGetMdlInfoPtr ( _mdlRefSfcnS ) ) ; {
ssSetModelMethods2 ( rts , & nehesmkint -> NonInlinedSFcns . methods2 [ 1 ] )
; } { ssSetModelMethods3 ( rts , & nehesmkint -> NonInlinedSFcns . methods3 [
1 ] ) ; } { ssSetModelMethods4 ( rts , & nehesmkint -> NonInlinedSFcns .
methods4 [ 1 ] ) ; } { ssSetStatesInfo2 ( rts , & nehesmkint ->
NonInlinedSFcns . statesInfo2 [ 1 ] ) ; ssSetPeriodicStatesInfo ( rts , &
nehesmkint -> NonInlinedSFcns . periodicStatesInfo [ 1 ] ) ; }
ssSetRegNumInputPortsFcn ( rts , ( _ssRegNumInputPortsFcn ) RegNumInputPorts
) ; ssSetRegNumInputPortsFcnArg ( rts , rts ) ; { _ssSetNumInputPorts ( rts ,
1 ) ; ssSetPortInfoForInputs ( rts , & nehesmkint -> NonInlinedSFcns . Sfcn1
. inputPortInfo [ 0 ] ) ; _ssSetPortInfo2ForInputUnits ( rts , & nehesmkint
-> NonInlinedSFcns . Sfcn1 . inputPortUnits [ 0 ] ) ; ssSetInputPortUnit (
rts , 0 , 1 ) ; _ssSetPortInfo2ForInputCoSimAttribute ( rts , & nehesmkint ->
NonInlinedSFcns . Sfcn1 . inputPortCoSimAttribute [ 0 ] ) ;
ssSetInputPortIsContinuousQuantity ( rts , 0 , 0 ) ; { real_T const * *
sfcnUPtrs = ( real_T const * * ) & nehesmkint -> NonInlinedSFcns . Sfcn1 .
UPtrs0 ; sfcnUPtrs [ 0 ] = & iqd4nnjnc2n . cndf4llhki ;
_ssSetInputPortSignalPtrs ( rts , 0 , ( InputPtrsType ) & sfcnUPtrs [ 0 ] ) ;
_ssSetInputPortNumDimensions ( rts , 0 , 1 ) ; ssSetInputPortWidth ( rts , 0
, 1 ) ; } } ssSetRegNumOutputPortsFcn ( rts , ( _ssRegNumOutputPortsFcn )
RegNumOutputPorts ) ; ssSetRegNumOutputPortsFcnArg ( rts , rts ) ;
_ssSetModelName ( rts , "scblock" ) ; _ssSetPath ( rts ,
"closedLoop/Plant/Robot/Scope 1/S-Function" ) ; ssSetRTModel ( rts ,
nehesmkint ) ; _ssSetParentSS ( rts , _mdlRefSfcnS ) ; _ssSetRootSS ( rts ,
ssGetRootSS ( _mdlRefSfcnS ) ) ; ssSetVersion ( rts ,
SIMSTRUCT_VERSION_LEVEL2 ) ; { mxArray * * sfcnParams = ( mxArray * * ) &
nehesmkint -> NonInlinedSFcns . Sfcn1 . params ; _ssSetSFcnParamsCount ( rts
, 23 ) ; _ssSetSFcnParamsPtr ( rts , & sfcnParams [ 0 ] ) ;
#if defined(MATLAB_MEX_FILE)
{ uint_T * attribs = ( uint_T * ) & nehesmkint -> NonInlinedSFcns . Sfcn1 .
attribs ; ssSetSFcnParamAttribsPtr ( rts , & attribs [ 0 ] ) ; ( void )
memset ( ( void * ) & attribs [ 0 ] , 0 , 23 * sizeof ( uint_T ) ) ; }
#endif
if ( ! slIsRapidAcceleratorSimulating ( ) ) { mxArray * param ; int_T i ;
real_T * vals ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_143 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 0 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_145 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 1 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_147 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 2 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_149 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 3 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 2 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) cy2wstccxe . P_151 ;
for ( i = 0 ; i < 2 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 4 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_153 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 5 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_155 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 6 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_157 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 7 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_159 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 8 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_161 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 9 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_163 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 10 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_165 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 11 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_167 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 12 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_169 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 13 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_171 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 14 , param )
; param = mxCreateDoubleMatrix ( 1 , 8 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) cy2wstccxe . P_173 ; for ( i = 0 ; i < 8 ; i ++
) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 15 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 4 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) cy2wstccxe . P_175 ;
for ( i = 0 ; i < 4 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 16 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_177 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 17 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_179 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 18 , param )
; param = mxCreateDoubleMatrix ( 1 , 6 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) cy2wstccxe . P_181 ; for ( i = 0 ; i < 6 ; i ++
) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 19 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_183 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 20 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_185 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 21 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_187 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 22 , param )
; } else { _ssSetSFcnParam ( rts , 0 , ( mxArray * ) cy2wstccxe . P_142 ) ;
_ssSetSFcnParam ( rts , 1 , ( mxArray * ) cy2wstccxe . P_144 ) ;
_ssSetSFcnParam ( rts , 2 , ( mxArray * ) cy2wstccxe . P_146 ) ;
_ssSetSFcnParam ( rts , 3 , ( mxArray * ) cy2wstccxe . P_148 ) ;
_ssSetSFcnParam ( rts , 4 , ( mxArray * ) cy2wstccxe . P_150 ) ;
_ssSetSFcnParam ( rts , 5 , ( mxArray * ) cy2wstccxe . P_152 ) ;
_ssSetSFcnParam ( rts , 6 , ( mxArray * ) cy2wstccxe . P_154 ) ;
_ssSetSFcnParam ( rts , 7 , ( mxArray * ) cy2wstccxe . P_156 ) ;
_ssSetSFcnParam ( rts , 8 , ( mxArray * ) cy2wstccxe . P_158 ) ;
_ssSetSFcnParam ( rts , 9 , ( mxArray * ) cy2wstccxe . P_160 ) ;
_ssSetSFcnParam ( rts , 10 , ( mxArray * ) cy2wstccxe . P_162 ) ;
_ssSetSFcnParam ( rts , 11 , ( mxArray * ) cy2wstccxe . P_164 ) ;
_ssSetSFcnParam ( rts , 12 , ( mxArray * ) cy2wstccxe . P_166 ) ;
_ssSetSFcnParam ( rts , 13 , ( mxArray * ) cy2wstccxe . P_168 ) ;
_ssSetSFcnParam ( rts , 14 , ( mxArray * ) cy2wstccxe . P_170 ) ;
_ssSetSFcnParam ( rts , 15 , ( mxArray * ) cy2wstccxe . P_172 ) ;
_ssSetSFcnParam ( rts , 16 , ( mxArray * ) cy2wstccxe . P_174 ) ;
_ssSetSFcnParam ( rts , 17 , ( mxArray * ) cy2wstccxe . P_176 ) ;
_ssSetSFcnParam ( rts , 18 , ( mxArray * ) cy2wstccxe . P_178 ) ;
_ssSetSFcnParam ( rts , 19 , ( mxArray * ) cy2wstccxe . P_180 ) ;
_ssSetSFcnParam ( rts , 20 , ( mxArray * ) cy2wstccxe . P_182 ) ;
_ssSetSFcnParam ( rts , 21 , ( mxArray * ) cy2wstccxe . P_184 ) ;
_ssSetSFcnParam ( rts , 22 , ( mxArray * ) cy2wstccxe . P_186 ) ; } }
_ssSetIWork ( rts , ( int_T * ) & l1kpu4wb4rx . e5wpgchixm ) ; { struct
_ssDWorkRecord * dWorkRecord = ( struct _ssDWorkRecord * ) & nehesmkint ->
NonInlinedSFcns . Sfcn1 . dWork ; struct _ssDWorkAuxRecord * dWorkAuxRecord =
( struct _ssDWorkAuxRecord * ) & nehesmkint -> NonInlinedSFcns . Sfcn1 .
dWorkAux ; ssSetSFcnDWork ( rts , dWorkRecord ) ; ssSetSFcnDWorkAux ( rts ,
dWorkAuxRecord ) ; _ssSetNumDWork ( rts , 1 ) ; ssSetDWorkWidth ( rts , 0 , 1
) ; ssSetDWorkDataType ( rts , 0 , SS_INTEGER ) ; ssSetDWorkComplexSignal (
rts , 0 , 0 ) ; _ssSetDWork ( rts , 0 , & l1kpu4wb4rx . e5wpgchixm ) ; } (
rts ) -> regDataType . arg1 = ( ( void * ) ( rts ) ) ; ( rts ) -> regDataType
. registerFcn = ( ( OldRegisterDataType ) FcnSetErrorStatus ) ; ( rts ) ->
regDataType . getSizeFcn = ( ( GetDataTypeSize ) FcnSetErrorStatus ) ; ( rts
) -> regDataType . getZeroFcn = ( ( GetDataTypeZero ) FcnSetErrorStatus ) ; (
rts ) -> regDataType . getNameFcn = ( ( GetDataTypeName ) FcnSetErrorStatus )
; ( rts ) -> regDataType . getIdFcn = ( ( GetDataTypeId ) FcnSetErrorStatus )
; if ( ! slIsRapidAcceleratorSimulating ( ) ) { int_T i ; mxArray * plhs [ 1
] ; mxArray * prhs [ 4 ] ; double * pr ; volatile int_T * intS = ( int_T * )
& rts ; int_T addrlen = sizeof ( SimStruct * ) ; int_T m = addrlen / sizeof (
int_T ) + 1 ; prhs [ 0 ] = mxCreateDoubleMatrix ( 0 , 0 , mxREAL ) ; prhs [ 1
] = mxCreateDoubleMatrix ( m , 1 , mxREAL ) ; pr = mxGetPr ( prhs [ 1 ] ) ;
for ( i = 0 ; i < m - 1 ; i ++ ) { pr [ i ] = ( double ) intS [ i ] ; } pr [
i ] = ( double ) SIMSTRUCT_VERSION_LEVEL2 ; prhs [ 2 ] = mxCreateDoubleMatrix
( 0 , 0 , mxREAL ) ; prhs [ 3 ] = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
ssSetRegInputPortDimensionInfoFcn ( rts , ( NULL ) ) ;
ssSetRegOutputPortDimensionInfoFcn ( rts , ( NULL ) ) ; mexCallMATLAB ( 1 ,
plhs , 4 , prhs , "scblock" ) ; mxDestroyArray ( plhs [ 0 ] ) ;
mxDestroyArray ( prhs [ 0 ] ) ; mxDestroyArray ( prhs [ 1 ] ) ;
mxDestroyArray ( prhs [ 2 ] ) ; mxDestroyArray ( prhs [ 3 ] ) ; } else {
scblock ( rts ) ; sfcnInitializeSizes ( rts ) ; } sfcnInitializeSampleTimes (
rts ) ; ssSetSampleTime ( rts , 0 , 0.0 ) ; ssSetOffsetTime ( rts , 0 , 0.0 )
; sfcnTsMap [ 0 ] = mdlref_TID0 ; ssSetInputPortWidth ( rts , 0 , 1 ) ;
ssSetInputPortDataType ( rts , 0 , SS_DOUBLE ) ; ssSetInputPortComplexSignal
( rts , 0 , 0 ) ; ssSetInputPortFrameData ( rts , 0 , 0 ) ;
ssSetInputPortUnit ( rts , 0 , 1 ) ; ssSetInputPortIsContinuousQuantity ( rts
, 0 , 0 ) ; ssSetNumNonsampledZCs ( rts , 0 ) ; _ssSetInputPortConnected (
rts , 0 , 1 ) ; _ssSetInputPortBufferDstPort ( rts , 0 , - 1 ) ; } {
SimStruct * rts = nehesmkint -> childSfunctions [ 2 ] ; time_T * sfcnPeriod =
nehesmkint -> NonInlinedSFcns . Sfcn2 . sfcnPeriod ; time_T * sfcnOffset =
nehesmkint -> NonInlinedSFcns . Sfcn2 . sfcnOffset ; int_T * sfcnTsMap =
nehesmkint -> NonInlinedSFcns . Sfcn2 . sfcnTsMap ; ( void ) memset ( ( void
* ) sfcnPeriod , 0 , sizeof ( time_T ) * 1 ) ; ( void ) memset ( ( void * )
sfcnOffset , 0 , sizeof ( time_T ) * 1 ) ; ssSetSampleTimePtr ( rts , &
sfcnPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rts , & sfcnOffset [ 0 ] ) ;
_ssSetSampleTimeTaskIDPtr ( rts , sfcnTsMap ) ; { ssSetBlkInfo2Ptr ( rts , &
nehesmkint -> NonInlinedSFcns . blkInfo2 [ 2 ] ) ; }
_ssSetBlkInfo2PortInfo2Ptr ( rts , & nehesmkint -> NonInlinedSFcns .
inputOutputPortInfo2 [ 2 ] ) ; ssSetRTWSfcnInfo ( rts , nehesmkint ->
sfcnInfo ) ; _ssSetMdlInfoPtr ( rts , ssGetMdlInfoPtr ( _mdlRefSfcnS ) ) ; {
ssSetModelMethods2 ( rts , & nehesmkint -> NonInlinedSFcns . methods2 [ 2 ] )
; } { ssSetModelMethods3 ( rts , & nehesmkint -> NonInlinedSFcns . methods3 [
2 ] ) ; } { ssSetModelMethods4 ( rts , & nehesmkint -> NonInlinedSFcns .
methods4 [ 2 ] ) ; } { ssSetStatesInfo2 ( rts , & nehesmkint ->
NonInlinedSFcns . statesInfo2 [ 2 ] ) ; ssSetPeriodicStatesInfo ( rts , &
nehesmkint -> NonInlinedSFcns . periodicStatesInfo [ 2 ] ) ; }
ssSetRegNumInputPortsFcn ( rts , ( _ssRegNumInputPortsFcn ) RegNumInputPorts
) ; ssSetRegNumInputPortsFcnArg ( rts , rts ) ; { _ssSetNumInputPorts ( rts ,
1 ) ; ssSetPortInfoForInputs ( rts , & nehesmkint -> NonInlinedSFcns . Sfcn2
. inputPortInfo [ 0 ] ) ; _ssSetPortInfo2ForInputUnits ( rts , & nehesmkint
-> NonInlinedSFcns . Sfcn2 . inputPortUnits [ 0 ] ) ; ssSetInputPortUnit (
rts , 0 , 1 ) ; _ssSetPortInfo2ForInputCoSimAttribute ( rts , & nehesmkint ->
NonInlinedSFcns . Sfcn2 . inputPortCoSimAttribute [ 0 ] ) ;
ssSetInputPortIsContinuousQuantity ( rts , 0 , 0 ) ; { real_T const * *
sfcnUPtrs = ( real_T const * * ) & nehesmkint -> NonInlinedSFcns . Sfcn2 .
UPtrs0 ; sfcnUPtrs [ 0 ] = & iqd4nnjnc2n . g350wynvmb ;
_ssSetInputPortSignalPtrs ( rts , 0 , ( InputPtrsType ) & sfcnUPtrs [ 0 ] ) ;
_ssSetInputPortNumDimensions ( rts , 0 , 1 ) ; ssSetInputPortWidth ( rts , 0
, 1 ) ; } } ssSetRegNumOutputPortsFcn ( rts , ( _ssRegNumOutputPortsFcn )
RegNumOutputPorts ) ; ssSetRegNumOutputPortsFcnArg ( rts , rts ) ;
_ssSetModelName ( rts , "scblock" ) ; _ssSetPath ( rts ,
"closedLoop/Plant/Robot/Scope 2/S-Function" ) ; ssSetRTModel ( rts ,
nehesmkint ) ; _ssSetParentSS ( rts , _mdlRefSfcnS ) ; _ssSetRootSS ( rts ,
ssGetRootSS ( _mdlRefSfcnS ) ) ; ssSetVersion ( rts ,
SIMSTRUCT_VERSION_LEVEL2 ) ; { mxArray * * sfcnParams = ( mxArray * * ) &
nehesmkint -> NonInlinedSFcns . Sfcn2 . params ; _ssSetSFcnParamsCount ( rts
, 23 ) ; _ssSetSFcnParamsPtr ( rts , & sfcnParams [ 0 ] ) ;
#if defined(MATLAB_MEX_FILE)
{ uint_T * attribs = ( uint_T * ) & nehesmkint -> NonInlinedSFcns . Sfcn2 .
attribs ; ssSetSFcnParamAttribsPtr ( rts , & attribs [ 0 ] ) ; ( void )
memset ( ( void * ) & attribs [ 0 ] , 0 , 23 * sizeof ( uint_T ) ) ; }
#endif
if ( ! slIsRapidAcceleratorSimulating ( ) ) { mxArray * param ; int_T i ;
real_T * vals ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_189 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 0 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_191 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 1 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_193 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 2 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_195 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 3 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 2 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) cy2wstccxe . P_197 ;
for ( i = 0 ; i < 2 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 4 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_199 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 5 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_201 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 6 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_203 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 7 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_205 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 8 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_207 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 9 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_209 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 10 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_211 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 11 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_213 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 12 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_215 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 13 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_217 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 14 , param )
; param = mxCreateDoubleMatrix ( 1 , 8 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) cy2wstccxe . P_219 ; for ( i = 0 ; i < 8 ; i ++
) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 15 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 4 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) cy2wstccxe . P_221 ;
for ( i = 0 ; i < 4 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 16 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_223 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 17 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_225 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 18 , param )
; param = mxCreateDoubleMatrix ( 1 , 6 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) cy2wstccxe . P_227 ; for ( i = 0 ; i < 6 ; i ++
) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 19 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_229 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 20 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_231 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 21 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_233 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 22 , param )
; } else { _ssSetSFcnParam ( rts , 0 , ( mxArray * ) cy2wstccxe . P_188 ) ;
_ssSetSFcnParam ( rts , 1 , ( mxArray * ) cy2wstccxe . P_190 ) ;
_ssSetSFcnParam ( rts , 2 , ( mxArray * ) cy2wstccxe . P_192 ) ;
_ssSetSFcnParam ( rts , 3 , ( mxArray * ) cy2wstccxe . P_194 ) ;
_ssSetSFcnParam ( rts , 4 , ( mxArray * ) cy2wstccxe . P_196 ) ;
_ssSetSFcnParam ( rts , 5 , ( mxArray * ) cy2wstccxe . P_198 ) ;
_ssSetSFcnParam ( rts , 6 , ( mxArray * ) cy2wstccxe . P_200 ) ;
_ssSetSFcnParam ( rts , 7 , ( mxArray * ) cy2wstccxe . P_202 ) ;
_ssSetSFcnParam ( rts , 8 , ( mxArray * ) cy2wstccxe . P_204 ) ;
_ssSetSFcnParam ( rts , 9 , ( mxArray * ) cy2wstccxe . P_206 ) ;
_ssSetSFcnParam ( rts , 10 , ( mxArray * ) cy2wstccxe . P_208 ) ;
_ssSetSFcnParam ( rts , 11 , ( mxArray * ) cy2wstccxe . P_210 ) ;
_ssSetSFcnParam ( rts , 12 , ( mxArray * ) cy2wstccxe . P_212 ) ;
_ssSetSFcnParam ( rts , 13 , ( mxArray * ) cy2wstccxe . P_214 ) ;
_ssSetSFcnParam ( rts , 14 , ( mxArray * ) cy2wstccxe . P_216 ) ;
_ssSetSFcnParam ( rts , 15 , ( mxArray * ) cy2wstccxe . P_218 ) ;
_ssSetSFcnParam ( rts , 16 , ( mxArray * ) cy2wstccxe . P_220 ) ;
_ssSetSFcnParam ( rts , 17 , ( mxArray * ) cy2wstccxe . P_222 ) ;
_ssSetSFcnParam ( rts , 18 , ( mxArray * ) cy2wstccxe . P_224 ) ;
_ssSetSFcnParam ( rts , 19 , ( mxArray * ) cy2wstccxe . P_226 ) ;
_ssSetSFcnParam ( rts , 20 , ( mxArray * ) cy2wstccxe . P_228 ) ;
_ssSetSFcnParam ( rts , 21 , ( mxArray * ) cy2wstccxe . P_230 ) ;
_ssSetSFcnParam ( rts , 22 , ( mxArray * ) cy2wstccxe . P_232 ) ; } }
_ssSetIWork ( rts , ( int_T * ) & l1kpu4wb4rx . mifzmh1b42 ) ; { struct
_ssDWorkRecord * dWorkRecord = ( struct _ssDWorkRecord * ) & nehesmkint ->
NonInlinedSFcns . Sfcn2 . dWork ; struct _ssDWorkAuxRecord * dWorkAuxRecord =
( struct _ssDWorkAuxRecord * ) & nehesmkint -> NonInlinedSFcns . Sfcn2 .
dWorkAux ; ssSetSFcnDWork ( rts , dWorkRecord ) ; ssSetSFcnDWorkAux ( rts ,
dWorkAuxRecord ) ; _ssSetNumDWork ( rts , 1 ) ; ssSetDWorkWidth ( rts , 0 , 1
) ; ssSetDWorkDataType ( rts , 0 , SS_INTEGER ) ; ssSetDWorkComplexSignal (
rts , 0 , 0 ) ; _ssSetDWork ( rts , 0 , & l1kpu4wb4rx . mifzmh1b42 ) ; } (
rts ) -> regDataType . arg1 = ( ( void * ) ( rts ) ) ; ( rts ) -> regDataType
. registerFcn = ( ( OldRegisterDataType ) FcnSetErrorStatus ) ; ( rts ) ->
regDataType . getSizeFcn = ( ( GetDataTypeSize ) FcnSetErrorStatus ) ; ( rts
) -> regDataType . getZeroFcn = ( ( GetDataTypeZero ) FcnSetErrorStatus ) ; (
rts ) -> regDataType . getNameFcn = ( ( GetDataTypeName ) FcnSetErrorStatus )
; ( rts ) -> regDataType . getIdFcn = ( ( GetDataTypeId ) FcnSetErrorStatus )
; if ( ! slIsRapidAcceleratorSimulating ( ) ) { int_T i ; mxArray * plhs [ 1
] ; mxArray * prhs [ 4 ] ; double * pr ; volatile int_T * intS = ( int_T * )
& rts ; int_T addrlen = sizeof ( SimStruct * ) ; int_T m = addrlen / sizeof (
int_T ) + 1 ; prhs [ 0 ] = mxCreateDoubleMatrix ( 0 , 0 , mxREAL ) ; prhs [ 1
] = mxCreateDoubleMatrix ( m , 1 , mxREAL ) ; pr = mxGetPr ( prhs [ 1 ] ) ;
for ( i = 0 ; i < m - 1 ; i ++ ) { pr [ i ] = ( double ) intS [ i ] ; } pr [
i ] = ( double ) SIMSTRUCT_VERSION_LEVEL2 ; prhs [ 2 ] = mxCreateDoubleMatrix
( 0 , 0 , mxREAL ) ; prhs [ 3 ] = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
ssSetRegInputPortDimensionInfoFcn ( rts , ( NULL ) ) ;
ssSetRegOutputPortDimensionInfoFcn ( rts , ( NULL ) ) ; mexCallMATLAB ( 1 ,
plhs , 4 , prhs , "scblock" ) ; mxDestroyArray ( plhs [ 0 ] ) ;
mxDestroyArray ( prhs [ 0 ] ) ; mxDestroyArray ( prhs [ 1 ] ) ;
mxDestroyArray ( prhs [ 2 ] ) ; mxDestroyArray ( prhs [ 3 ] ) ; } else {
scblock ( rts ) ; sfcnInitializeSizes ( rts ) ; } sfcnInitializeSampleTimes (
rts ) ; ssSetSampleTime ( rts , 0 , 0.0 ) ; ssSetOffsetTime ( rts , 0 , 0.0 )
; sfcnTsMap [ 0 ] = mdlref_TID0 ; ssSetInputPortWidth ( rts , 0 , 1 ) ;
ssSetInputPortDataType ( rts , 0 , SS_DOUBLE ) ; ssSetInputPortComplexSignal
( rts , 0 , 0 ) ; ssSetInputPortFrameData ( rts , 0 , 0 ) ;
ssSetInputPortUnit ( rts , 0 , 1 ) ; ssSetInputPortIsContinuousQuantity ( rts
, 0 , 0 ) ; ssSetNumNonsampledZCs ( rts , 0 ) ; _ssSetInputPortConnected (
rts , 0 , 1 ) ; _ssSetInputPortBufferDstPort ( rts , 0 , - 1 ) ; } {
SimStruct * rts = nehesmkint -> childSfunctions [ 3 ] ; time_T * sfcnPeriod =
nehesmkint -> NonInlinedSFcns . Sfcn3 . sfcnPeriod ; time_T * sfcnOffset =
nehesmkint -> NonInlinedSFcns . Sfcn3 . sfcnOffset ; int_T * sfcnTsMap =
nehesmkint -> NonInlinedSFcns . Sfcn3 . sfcnTsMap ; ( void ) memset ( ( void
* ) sfcnPeriod , 0 , sizeof ( time_T ) * 1 ) ; ( void ) memset ( ( void * )
sfcnOffset , 0 , sizeof ( time_T ) * 1 ) ; ssSetSampleTimePtr ( rts , &
sfcnPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rts , & sfcnOffset [ 0 ] ) ;
_ssSetSampleTimeTaskIDPtr ( rts , sfcnTsMap ) ; { ssSetBlkInfo2Ptr ( rts , &
nehesmkint -> NonInlinedSFcns . blkInfo2 [ 3 ] ) ; }
_ssSetBlkInfo2PortInfo2Ptr ( rts , & nehesmkint -> NonInlinedSFcns .
inputOutputPortInfo2 [ 3 ] ) ; ssSetRTWSfcnInfo ( rts , nehesmkint ->
sfcnInfo ) ; _ssSetMdlInfoPtr ( rts , ssGetMdlInfoPtr ( _mdlRefSfcnS ) ) ; {
ssSetModelMethods2 ( rts , & nehesmkint -> NonInlinedSFcns . methods2 [ 3 ] )
; } { ssSetModelMethods3 ( rts , & nehesmkint -> NonInlinedSFcns . methods3 [
3 ] ) ; } { ssSetModelMethods4 ( rts , & nehesmkint -> NonInlinedSFcns .
methods4 [ 3 ] ) ; } { ssSetStatesInfo2 ( rts , & nehesmkint ->
NonInlinedSFcns . statesInfo2 [ 3 ] ) ; ssSetPeriodicStatesInfo ( rts , &
nehesmkint -> NonInlinedSFcns . periodicStatesInfo [ 3 ] ) ; }
ssSetRegNumInputPortsFcn ( rts , ( _ssRegNumInputPortsFcn ) RegNumInputPorts
) ; ssSetRegNumInputPortsFcnArg ( rts , rts ) ; { _ssSetNumInputPorts ( rts ,
1 ) ; ssSetPortInfoForInputs ( rts , & nehesmkint -> NonInlinedSFcns . Sfcn3
. inputPortInfo [ 0 ] ) ; _ssSetPortInfo2ForInputUnits ( rts , & nehesmkint
-> NonInlinedSFcns . Sfcn3 . inputPortUnits [ 0 ] ) ; ssSetInputPortUnit (
rts , 0 , 1 ) ; _ssSetPortInfo2ForInputCoSimAttribute ( rts , & nehesmkint ->
NonInlinedSFcns . Sfcn3 . inputPortCoSimAttribute [ 0 ] ) ;
ssSetInputPortIsContinuousQuantity ( rts , 0 , 0 ) ; { real_T const * *
sfcnUPtrs = ( real_T const * * ) & nehesmkint -> NonInlinedSFcns . Sfcn3 .
UPtrs0 ; sfcnUPtrs [ 0 ] = & iqd4nnjnc2n . ia5oez2mak ;
_ssSetInputPortSignalPtrs ( rts , 0 , ( InputPtrsType ) & sfcnUPtrs [ 0 ] ) ;
_ssSetInputPortNumDimensions ( rts , 0 , 1 ) ; ssSetInputPortWidth ( rts , 0
, 1 ) ; } } ssSetRegNumOutputPortsFcn ( rts , ( _ssRegNumOutputPortsFcn )
RegNumOutputPorts ) ; ssSetRegNumOutputPortsFcnArg ( rts , rts ) ;
_ssSetModelName ( rts , "scblock" ) ; _ssSetPath ( rts ,
"closedLoop/Plant/Robot/Scope 3/S-Function" ) ; ssSetRTModel ( rts ,
nehesmkint ) ; _ssSetParentSS ( rts , _mdlRefSfcnS ) ; _ssSetRootSS ( rts ,
ssGetRootSS ( _mdlRefSfcnS ) ) ; ssSetVersion ( rts ,
SIMSTRUCT_VERSION_LEVEL2 ) ; { mxArray * * sfcnParams = ( mxArray * * ) &
nehesmkint -> NonInlinedSFcns . Sfcn3 . params ; _ssSetSFcnParamsCount ( rts
, 23 ) ; _ssSetSFcnParamsPtr ( rts , & sfcnParams [ 0 ] ) ;
#if defined(MATLAB_MEX_FILE)
{ uint_T * attribs = ( uint_T * ) & nehesmkint -> NonInlinedSFcns . Sfcn3 .
attribs ; ssSetSFcnParamAttribsPtr ( rts , & attribs [ 0 ] ) ; ( void )
memset ( ( void * ) & attribs [ 0 ] , 0 , 23 * sizeof ( uint_T ) ) ; }
#endif
if ( ! slIsRapidAcceleratorSimulating ( ) ) { mxArray * param ; int_T i ;
real_T * vals ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_235 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 0 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_237 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 1 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_239 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 2 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_241 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 3 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 2 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) cy2wstccxe . P_243 ;
for ( i = 0 ; i < 2 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 4 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_245 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 5 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_247 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 6 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_249 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 7 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_251 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 8 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_253 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 9 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_255 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 10 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_257 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 11 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_259 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 12 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_261 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 13 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_263 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 14 , param )
; param = mxCreateDoubleMatrix ( 1 , 8 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) cy2wstccxe . P_265 ; for ( i = 0 ; i < 8 ; i ++
) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 15 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 4 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) cy2wstccxe . P_267 ;
for ( i = 0 ; i < 4 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 16 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_269 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 17 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_271 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 18 , param )
; param = mxCreateDoubleMatrix ( 1 , 6 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) cy2wstccxe . P_273 ; for ( i = 0 ; i < 6 ; i ++
) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 19 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_275 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 20 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_277 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 21 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_279 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 22 , param )
; } else { _ssSetSFcnParam ( rts , 0 , ( mxArray * ) cy2wstccxe . P_234 ) ;
_ssSetSFcnParam ( rts , 1 , ( mxArray * ) cy2wstccxe . P_236 ) ;
_ssSetSFcnParam ( rts , 2 , ( mxArray * ) cy2wstccxe . P_238 ) ;
_ssSetSFcnParam ( rts , 3 , ( mxArray * ) cy2wstccxe . P_240 ) ;
_ssSetSFcnParam ( rts , 4 , ( mxArray * ) cy2wstccxe . P_242 ) ;
_ssSetSFcnParam ( rts , 5 , ( mxArray * ) cy2wstccxe . P_244 ) ;
_ssSetSFcnParam ( rts , 6 , ( mxArray * ) cy2wstccxe . P_246 ) ;
_ssSetSFcnParam ( rts , 7 , ( mxArray * ) cy2wstccxe . P_248 ) ;
_ssSetSFcnParam ( rts , 8 , ( mxArray * ) cy2wstccxe . P_250 ) ;
_ssSetSFcnParam ( rts , 9 , ( mxArray * ) cy2wstccxe . P_252 ) ;
_ssSetSFcnParam ( rts , 10 , ( mxArray * ) cy2wstccxe . P_254 ) ;
_ssSetSFcnParam ( rts , 11 , ( mxArray * ) cy2wstccxe . P_256 ) ;
_ssSetSFcnParam ( rts , 12 , ( mxArray * ) cy2wstccxe . P_258 ) ;
_ssSetSFcnParam ( rts , 13 , ( mxArray * ) cy2wstccxe . P_260 ) ;
_ssSetSFcnParam ( rts , 14 , ( mxArray * ) cy2wstccxe . P_262 ) ;
_ssSetSFcnParam ( rts , 15 , ( mxArray * ) cy2wstccxe . P_264 ) ;
_ssSetSFcnParam ( rts , 16 , ( mxArray * ) cy2wstccxe . P_266 ) ;
_ssSetSFcnParam ( rts , 17 , ( mxArray * ) cy2wstccxe . P_268 ) ;
_ssSetSFcnParam ( rts , 18 , ( mxArray * ) cy2wstccxe . P_270 ) ;
_ssSetSFcnParam ( rts , 19 , ( mxArray * ) cy2wstccxe . P_272 ) ;
_ssSetSFcnParam ( rts , 20 , ( mxArray * ) cy2wstccxe . P_274 ) ;
_ssSetSFcnParam ( rts , 21 , ( mxArray * ) cy2wstccxe . P_276 ) ;
_ssSetSFcnParam ( rts , 22 , ( mxArray * ) cy2wstccxe . P_278 ) ; } }
_ssSetIWork ( rts , ( int_T * ) & l1kpu4wb4rx . mmcfrrmcvl ) ; { struct
_ssDWorkRecord * dWorkRecord = ( struct _ssDWorkRecord * ) & nehesmkint ->
NonInlinedSFcns . Sfcn3 . dWork ; struct _ssDWorkAuxRecord * dWorkAuxRecord =
( struct _ssDWorkAuxRecord * ) & nehesmkint -> NonInlinedSFcns . Sfcn3 .
dWorkAux ; ssSetSFcnDWork ( rts , dWorkRecord ) ; ssSetSFcnDWorkAux ( rts ,
dWorkAuxRecord ) ; _ssSetNumDWork ( rts , 1 ) ; ssSetDWorkWidth ( rts , 0 , 1
) ; ssSetDWorkDataType ( rts , 0 , SS_INTEGER ) ; ssSetDWorkComplexSignal (
rts , 0 , 0 ) ; _ssSetDWork ( rts , 0 , & l1kpu4wb4rx . mmcfrrmcvl ) ; } (
rts ) -> regDataType . arg1 = ( ( void * ) ( rts ) ) ; ( rts ) -> regDataType
. registerFcn = ( ( OldRegisterDataType ) FcnSetErrorStatus ) ; ( rts ) ->
regDataType . getSizeFcn = ( ( GetDataTypeSize ) FcnSetErrorStatus ) ; ( rts
) -> regDataType . getZeroFcn = ( ( GetDataTypeZero ) FcnSetErrorStatus ) ; (
rts ) -> regDataType . getNameFcn = ( ( GetDataTypeName ) FcnSetErrorStatus )
; ( rts ) -> regDataType . getIdFcn = ( ( GetDataTypeId ) FcnSetErrorStatus )
; if ( ! slIsRapidAcceleratorSimulating ( ) ) { int_T i ; mxArray * plhs [ 1
] ; mxArray * prhs [ 4 ] ; double * pr ; volatile int_T * intS = ( int_T * )
& rts ; int_T addrlen = sizeof ( SimStruct * ) ; int_T m = addrlen / sizeof (
int_T ) + 1 ; prhs [ 0 ] = mxCreateDoubleMatrix ( 0 , 0 , mxREAL ) ; prhs [ 1
] = mxCreateDoubleMatrix ( m , 1 , mxREAL ) ; pr = mxGetPr ( prhs [ 1 ] ) ;
for ( i = 0 ; i < m - 1 ; i ++ ) { pr [ i ] = ( double ) intS [ i ] ; } pr [
i ] = ( double ) SIMSTRUCT_VERSION_LEVEL2 ; prhs [ 2 ] = mxCreateDoubleMatrix
( 0 , 0 , mxREAL ) ; prhs [ 3 ] = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
ssSetRegInputPortDimensionInfoFcn ( rts , ( NULL ) ) ;
ssSetRegOutputPortDimensionInfoFcn ( rts , ( NULL ) ) ; mexCallMATLAB ( 1 ,
plhs , 4 , prhs , "scblock" ) ; mxDestroyArray ( plhs [ 0 ] ) ;
mxDestroyArray ( prhs [ 0 ] ) ; mxDestroyArray ( prhs [ 1 ] ) ;
mxDestroyArray ( prhs [ 2 ] ) ; mxDestroyArray ( prhs [ 3 ] ) ; } else {
scblock ( rts ) ; sfcnInitializeSizes ( rts ) ; } sfcnInitializeSampleTimes (
rts ) ; ssSetSampleTime ( rts , 0 , 0.0 ) ; ssSetOffsetTime ( rts , 0 , 0.0 )
; sfcnTsMap [ 0 ] = mdlref_TID0 ; ssSetInputPortWidth ( rts , 0 , 1 ) ;
ssSetInputPortDataType ( rts , 0 , SS_DOUBLE ) ; ssSetInputPortComplexSignal
( rts , 0 , 0 ) ; ssSetInputPortFrameData ( rts , 0 , 0 ) ;
ssSetInputPortUnit ( rts , 0 , 1 ) ; ssSetInputPortIsContinuousQuantity ( rts
, 0 , 0 ) ; ssSetNumNonsampledZCs ( rts , 0 ) ; _ssSetInputPortConnected (
rts , 0 , 1 ) ; _ssSetInputPortBufferDstPort ( rts , 0 , - 1 ) ; } {
SimStruct * rts = nehesmkint -> childSfunctions [ 4 ] ; time_T * sfcnPeriod =
nehesmkint -> NonInlinedSFcns . Sfcn4 . sfcnPeriod ; time_T * sfcnOffset =
nehesmkint -> NonInlinedSFcns . Sfcn4 . sfcnOffset ; int_T * sfcnTsMap =
nehesmkint -> NonInlinedSFcns . Sfcn4 . sfcnTsMap ; ( void ) memset ( ( void
* ) sfcnPeriod , 0 , sizeof ( time_T ) * 1 ) ; ( void ) memset ( ( void * )
sfcnOffset , 0 , sizeof ( time_T ) * 1 ) ; ssSetSampleTimePtr ( rts , &
sfcnPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rts , & sfcnOffset [ 0 ] ) ;
_ssSetSampleTimeTaskIDPtr ( rts , sfcnTsMap ) ; { ssSetBlkInfo2Ptr ( rts , &
nehesmkint -> NonInlinedSFcns . blkInfo2 [ 4 ] ) ; }
_ssSetBlkInfo2PortInfo2Ptr ( rts , & nehesmkint -> NonInlinedSFcns .
inputOutputPortInfo2 [ 4 ] ) ; ssSetRTWSfcnInfo ( rts , nehesmkint ->
sfcnInfo ) ; _ssSetMdlInfoPtr ( rts , ssGetMdlInfoPtr ( _mdlRefSfcnS ) ) ; {
ssSetModelMethods2 ( rts , & nehesmkint -> NonInlinedSFcns . methods2 [ 4 ] )
; } { ssSetModelMethods3 ( rts , & nehesmkint -> NonInlinedSFcns . methods3 [
4 ] ) ; } { ssSetModelMethods4 ( rts , & nehesmkint -> NonInlinedSFcns .
methods4 [ 4 ] ) ; } { ssSetStatesInfo2 ( rts , & nehesmkint ->
NonInlinedSFcns . statesInfo2 [ 4 ] ) ; ssSetPeriodicStatesInfo ( rts , &
nehesmkint -> NonInlinedSFcns . periodicStatesInfo [ 4 ] ) ; }
ssSetRegNumInputPortsFcn ( rts , ( _ssRegNumInputPortsFcn ) RegNumInputPorts
) ; ssSetRegNumInputPortsFcnArg ( rts , rts ) ; { _ssSetNumInputPorts ( rts ,
1 ) ; ssSetPortInfoForInputs ( rts , & nehesmkint -> NonInlinedSFcns . Sfcn4
. inputPortInfo [ 0 ] ) ; _ssSetPortInfo2ForInputUnits ( rts , & nehesmkint
-> NonInlinedSFcns . Sfcn4 . inputPortUnits [ 0 ] ) ; ssSetInputPortUnit (
rts , 0 , 1 ) ; _ssSetPortInfo2ForInputCoSimAttribute ( rts , & nehesmkint ->
NonInlinedSFcns . Sfcn4 . inputPortCoSimAttribute [ 0 ] ) ;
ssSetInputPortIsContinuousQuantity ( rts , 0 , 0 ) ; { real_T const * *
sfcnUPtrs = ( real_T const * * ) & nehesmkint -> NonInlinedSFcns . Sfcn4 .
UPtrs0 ; sfcnUPtrs [ 0 ] = & iqd4nnjnc2n . heefjqovkk ;
_ssSetInputPortSignalPtrs ( rts , 0 , ( InputPtrsType ) & sfcnUPtrs [ 0 ] ) ;
_ssSetInputPortNumDimensions ( rts , 0 , 1 ) ; ssSetInputPortWidth ( rts , 0
, 1 ) ; } } ssSetRegNumOutputPortsFcn ( rts , ( _ssRegNumOutputPortsFcn )
RegNumOutputPorts ) ; ssSetRegNumOutputPortsFcnArg ( rts , rts ) ;
_ssSetModelName ( rts , "scblock" ) ; _ssSetPath ( rts ,
"closedLoop/Plant/Robot/Scope 4/S-Function" ) ; ssSetRTModel ( rts ,
nehesmkint ) ; _ssSetParentSS ( rts , _mdlRefSfcnS ) ; _ssSetRootSS ( rts ,
ssGetRootSS ( _mdlRefSfcnS ) ) ; ssSetVersion ( rts ,
SIMSTRUCT_VERSION_LEVEL2 ) ; { mxArray * * sfcnParams = ( mxArray * * ) &
nehesmkint -> NonInlinedSFcns . Sfcn4 . params ; _ssSetSFcnParamsCount ( rts
, 23 ) ; _ssSetSFcnParamsPtr ( rts , & sfcnParams [ 0 ] ) ;
#if defined(MATLAB_MEX_FILE)
{ uint_T * attribs = ( uint_T * ) & nehesmkint -> NonInlinedSFcns . Sfcn4 .
attribs ; ssSetSFcnParamAttribsPtr ( rts , & attribs [ 0 ] ) ; ( void )
memset ( ( void * ) & attribs [ 0 ] , 0 , 23 * sizeof ( uint_T ) ) ; }
#endif
if ( ! slIsRapidAcceleratorSimulating ( ) ) { mxArray * param ; int_T i ;
real_T * vals ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_281 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 0 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_283 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 1 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_285 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 2 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_287 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 3 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 2 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) cy2wstccxe . P_289 ;
for ( i = 0 ; i < 2 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 4 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_291 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 5 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_293 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 6 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_295 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 7 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_297 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 8 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_299 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 9 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_301 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 10 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_303 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 11 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_305 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 12 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_307 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 13 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_309 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 14 , param )
; param = mxCreateDoubleMatrix ( 1 , 8 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) cy2wstccxe . P_311 ; for ( i = 0 ; i < 8 ; i ++
) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 15 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 4 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) cy2wstccxe . P_313 ;
for ( i = 0 ; i < 4 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 16 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_315 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 17 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_317 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 18 , param )
; param = mxCreateDoubleMatrix ( 1 , 6 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) cy2wstccxe . P_319 ; for ( i = 0 ; i < 6 ; i ++
) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 19 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_321 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 20 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_323 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 21 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_325 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 22 , param )
; } else { _ssSetSFcnParam ( rts , 0 , ( mxArray * ) cy2wstccxe . P_280 ) ;
_ssSetSFcnParam ( rts , 1 , ( mxArray * ) cy2wstccxe . P_282 ) ;
_ssSetSFcnParam ( rts , 2 , ( mxArray * ) cy2wstccxe . P_284 ) ;
_ssSetSFcnParam ( rts , 3 , ( mxArray * ) cy2wstccxe . P_286 ) ;
_ssSetSFcnParam ( rts , 4 , ( mxArray * ) cy2wstccxe . P_288 ) ;
_ssSetSFcnParam ( rts , 5 , ( mxArray * ) cy2wstccxe . P_290 ) ;
_ssSetSFcnParam ( rts , 6 , ( mxArray * ) cy2wstccxe . P_292 ) ;
_ssSetSFcnParam ( rts , 7 , ( mxArray * ) cy2wstccxe . P_294 ) ;
_ssSetSFcnParam ( rts , 8 , ( mxArray * ) cy2wstccxe . P_296 ) ;
_ssSetSFcnParam ( rts , 9 , ( mxArray * ) cy2wstccxe . P_298 ) ;
_ssSetSFcnParam ( rts , 10 , ( mxArray * ) cy2wstccxe . P_300 ) ;
_ssSetSFcnParam ( rts , 11 , ( mxArray * ) cy2wstccxe . P_302 ) ;
_ssSetSFcnParam ( rts , 12 , ( mxArray * ) cy2wstccxe . P_304 ) ;
_ssSetSFcnParam ( rts , 13 , ( mxArray * ) cy2wstccxe . P_306 ) ;
_ssSetSFcnParam ( rts , 14 , ( mxArray * ) cy2wstccxe . P_308 ) ;
_ssSetSFcnParam ( rts , 15 , ( mxArray * ) cy2wstccxe . P_310 ) ;
_ssSetSFcnParam ( rts , 16 , ( mxArray * ) cy2wstccxe . P_312 ) ;
_ssSetSFcnParam ( rts , 17 , ( mxArray * ) cy2wstccxe . P_314 ) ;
_ssSetSFcnParam ( rts , 18 , ( mxArray * ) cy2wstccxe . P_316 ) ;
_ssSetSFcnParam ( rts , 19 , ( mxArray * ) cy2wstccxe . P_318 ) ;
_ssSetSFcnParam ( rts , 20 , ( mxArray * ) cy2wstccxe . P_320 ) ;
_ssSetSFcnParam ( rts , 21 , ( mxArray * ) cy2wstccxe . P_322 ) ;
_ssSetSFcnParam ( rts , 22 , ( mxArray * ) cy2wstccxe . P_324 ) ; } }
_ssSetIWork ( rts , ( int_T * ) & l1kpu4wb4rx . cbrf0g0kcz ) ; { struct
_ssDWorkRecord * dWorkRecord = ( struct _ssDWorkRecord * ) & nehesmkint ->
NonInlinedSFcns . Sfcn4 . dWork ; struct _ssDWorkAuxRecord * dWorkAuxRecord =
( struct _ssDWorkAuxRecord * ) & nehesmkint -> NonInlinedSFcns . Sfcn4 .
dWorkAux ; ssSetSFcnDWork ( rts , dWorkRecord ) ; ssSetSFcnDWorkAux ( rts ,
dWorkAuxRecord ) ; _ssSetNumDWork ( rts , 1 ) ; ssSetDWorkWidth ( rts , 0 , 1
) ; ssSetDWorkDataType ( rts , 0 , SS_INTEGER ) ; ssSetDWorkComplexSignal (
rts , 0 , 0 ) ; _ssSetDWork ( rts , 0 , & l1kpu4wb4rx . cbrf0g0kcz ) ; } (
rts ) -> regDataType . arg1 = ( ( void * ) ( rts ) ) ; ( rts ) -> regDataType
. registerFcn = ( ( OldRegisterDataType ) FcnSetErrorStatus ) ; ( rts ) ->
regDataType . getSizeFcn = ( ( GetDataTypeSize ) FcnSetErrorStatus ) ; ( rts
) -> regDataType . getZeroFcn = ( ( GetDataTypeZero ) FcnSetErrorStatus ) ; (
rts ) -> regDataType . getNameFcn = ( ( GetDataTypeName ) FcnSetErrorStatus )
; ( rts ) -> regDataType . getIdFcn = ( ( GetDataTypeId ) FcnSetErrorStatus )
; if ( ! slIsRapidAcceleratorSimulating ( ) ) { int_T i ; mxArray * plhs [ 1
] ; mxArray * prhs [ 4 ] ; double * pr ; volatile int_T * intS = ( int_T * )
& rts ; int_T addrlen = sizeof ( SimStruct * ) ; int_T m = addrlen / sizeof (
int_T ) + 1 ; prhs [ 0 ] = mxCreateDoubleMatrix ( 0 , 0 , mxREAL ) ; prhs [ 1
] = mxCreateDoubleMatrix ( m , 1 , mxREAL ) ; pr = mxGetPr ( prhs [ 1 ] ) ;
for ( i = 0 ; i < m - 1 ; i ++ ) { pr [ i ] = ( double ) intS [ i ] ; } pr [
i ] = ( double ) SIMSTRUCT_VERSION_LEVEL2 ; prhs [ 2 ] = mxCreateDoubleMatrix
( 0 , 0 , mxREAL ) ; prhs [ 3 ] = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
ssSetRegInputPortDimensionInfoFcn ( rts , ( NULL ) ) ;
ssSetRegOutputPortDimensionInfoFcn ( rts , ( NULL ) ) ; mexCallMATLAB ( 1 ,
plhs , 4 , prhs , "scblock" ) ; mxDestroyArray ( plhs [ 0 ] ) ;
mxDestroyArray ( prhs [ 0 ] ) ; mxDestroyArray ( prhs [ 1 ] ) ;
mxDestroyArray ( prhs [ 2 ] ) ; mxDestroyArray ( prhs [ 3 ] ) ; } else {
scblock ( rts ) ; sfcnInitializeSizes ( rts ) ; } sfcnInitializeSampleTimes (
rts ) ; ssSetSampleTime ( rts , 0 , 0.0 ) ; ssSetOffsetTime ( rts , 0 , 0.0 )
; sfcnTsMap [ 0 ] = mdlref_TID0 ; ssSetInputPortWidth ( rts , 0 , 1 ) ;
ssSetInputPortDataType ( rts , 0 , SS_DOUBLE ) ; ssSetInputPortComplexSignal
( rts , 0 , 0 ) ; ssSetInputPortFrameData ( rts , 0 , 0 ) ;
ssSetInputPortUnit ( rts , 0 , 1 ) ; ssSetInputPortIsContinuousQuantity ( rts
, 0 , 0 ) ; ssSetNumNonsampledZCs ( rts , 0 ) ; _ssSetInputPortConnected (
rts , 0 , 1 ) ; _ssSetInputPortBufferDstPort ( rts , 0 , - 1 ) ; } {
SimStruct * rts = nehesmkint -> childSfunctions [ 5 ] ; time_T * sfcnPeriod =
nehesmkint -> NonInlinedSFcns . Sfcn5 . sfcnPeriod ; time_T * sfcnOffset =
nehesmkint -> NonInlinedSFcns . Sfcn5 . sfcnOffset ; int_T * sfcnTsMap =
nehesmkint -> NonInlinedSFcns . Sfcn5 . sfcnTsMap ; ( void ) memset ( ( void
* ) sfcnPeriod , 0 , sizeof ( time_T ) * 1 ) ; ( void ) memset ( ( void * )
sfcnOffset , 0 , sizeof ( time_T ) * 1 ) ; ssSetSampleTimePtr ( rts , &
sfcnPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rts , & sfcnOffset [ 0 ] ) ;
_ssSetSampleTimeTaskIDPtr ( rts , sfcnTsMap ) ; { ssSetBlkInfo2Ptr ( rts , &
nehesmkint -> NonInlinedSFcns . blkInfo2 [ 5 ] ) ; }
_ssSetBlkInfo2PortInfo2Ptr ( rts , & nehesmkint -> NonInlinedSFcns .
inputOutputPortInfo2 [ 5 ] ) ; ssSetRTWSfcnInfo ( rts , nehesmkint ->
sfcnInfo ) ; _ssSetMdlInfoPtr ( rts , ssGetMdlInfoPtr ( _mdlRefSfcnS ) ) ; {
ssSetModelMethods2 ( rts , & nehesmkint -> NonInlinedSFcns . methods2 [ 5 ] )
; } { ssSetModelMethods3 ( rts , & nehesmkint -> NonInlinedSFcns . methods3 [
5 ] ) ; } { ssSetModelMethods4 ( rts , & nehesmkint -> NonInlinedSFcns .
methods4 [ 5 ] ) ; } { ssSetStatesInfo2 ( rts , & nehesmkint ->
NonInlinedSFcns . statesInfo2 [ 5 ] ) ; ssSetPeriodicStatesInfo ( rts , &
nehesmkint -> NonInlinedSFcns . periodicStatesInfo [ 5 ] ) ; }
ssSetRegNumInputPortsFcn ( rts , ( _ssRegNumInputPortsFcn ) RegNumInputPorts
) ; ssSetRegNumInputPortsFcnArg ( rts , rts ) ; { _ssSetNumInputPorts ( rts ,
1 ) ; ssSetPortInfoForInputs ( rts , & nehesmkint -> NonInlinedSFcns . Sfcn5
. inputPortInfo [ 0 ] ) ; _ssSetPortInfo2ForInputUnits ( rts , & nehesmkint
-> NonInlinedSFcns . Sfcn5 . inputPortUnits [ 0 ] ) ; ssSetInputPortUnit (
rts , 0 , 1 ) ; _ssSetPortInfo2ForInputCoSimAttribute ( rts , & nehesmkint ->
NonInlinedSFcns . Sfcn5 . inputPortCoSimAttribute [ 0 ] ) ;
ssSetInputPortIsContinuousQuantity ( rts , 0 , 0 ) ; { real_T const * *
sfcnUPtrs = ( real_T const * * ) & nehesmkint -> NonInlinedSFcns . Sfcn5 .
UPtrs0 ; sfcnUPtrs [ 0 ] = & iqd4nnjnc2n . f2obljhlxv ;
_ssSetInputPortSignalPtrs ( rts , 0 , ( InputPtrsType ) & sfcnUPtrs [ 0 ] ) ;
_ssSetInputPortNumDimensions ( rts , 0 , 1 ) ; ssSetInputPortWidth ( rts , 0
, 1 ) ; } } ssSetRegNumOutputPortsFcn ( rts , ( _ssRegNumOutputPortsFcn )
RegNumOutputPorts ) ; ssSetRegNumOutputPortsFcnArg ( rts , rts ) ;
_ssSetModelName ( rts , "scblock" ) ; _ssSetPath ( rts ,
"closedLoop/Plant/Robot/Scope 5/S-Function" ) ; ssSetRTModel ( rts ,
nehesmkint ) ; _ssSetParentSS ( rts , _mdlRefSfcnS ) ; _ssSetRootSS ( rts ,
ssGetRootSS ( _mdlRefSfcnS ) ) ; ssSetVersion ( rts ,
SIMSTRUCT_VERSION_LEVEL2 ) ; { mxArray * * sfcnParams = ( mxArray * * ) &
nehesmkint -> NonInlinedSFcns . Sfcn5 . params ; _ssSetSFcnParamsCount ( rts
, 23 ) ; _ssSetSFcnParamsPtr ( rts , & sfcnParams [ 0 ] ) ;
#if defined(MATLAB_MEX_FILE)
{ uint_T * attribs = ( uint_T * ) & nehesmkint -> NonInlinedSFcns . Sfcn5 .
attribs ; ssSetSFcnParamAttribsPtr ( rts , & attribs [ 0 ] ) ; ( void )
memset ( ( void * ) & attribs [ 0 ] , 0 , 23 * sizeof ( uint_T ) ) ; }
#endif
if ( ! slIsRapidAcceleratorSimulating ( ) ) { mxArray * param ; int_T i ;
real_T * vals ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_327 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 0 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_329 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 1 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_331 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 2 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_333 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 3 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 2 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) cy2wstccxe . P_335 ;
for ( i = 0 ; i < 2 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 4 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_337 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 5 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_339 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 6 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_341 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 7 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_343 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 8 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_345 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 9 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_347 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 10 , param )
; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) & cy2wstccxe . P_349 ; for ( i = 0 ; i < 1 ; i
++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 11 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_351 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 12 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_353 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 13 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_355 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 14 , param )
; param = mxCreateDoubleMatrix ( 1 , 8 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) cy2wstccxe . P_357 ; for ( i = 0 ; i < 8 ; i ++
) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 15 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 4 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) cy2wstccxe . P_359 ;
for ( i = 0 ; i < 4 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 16 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_361 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 17 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_363 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 18 , param )
; param = mxCreateDoubleMatrix ( 1 , 6 , mxREAL ) ; mexMakeArrayPersistent (
param ) ; vals = ( real_T * ) cy2wstccxe . P_365 ; for ( i = 0 ; i < 6 ; i ++
) { mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 19 ,
param ) ; param = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) & cy2wstccxe . P_367 ;
for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] = vals [ i ] ; }
_ssSetSFcnParam ( rts , 20 , param ) ; param = mxCreateDoubleMatrix ( 1 , 1 ,
mxREAL ) ; mexMakeArrayPersistent ( param ) ; vals = ( real_T * ) &
cy2wstccxe . P_369 ; for ( i = 0 ; i < 1 ; i ++ ) { mxGetPr ( param ) [ i ] =
vals [ i ] ; } _ssSetSFcnParam ( rts , 21 , param ) ; param =
mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ; mexMakeArrayPersistent ( param ) ;
vals = ( real_T * ) & cy2wstccxe . P_371 ; for ( i = 0 ; i < 1 ; i ++ ) {
mxGetPr ( param ) [ i ] = vals [ i ] ; } _ssSetSFcnParam ( rts , 22 , param )
; } else { _ssSetSFcnParam ( rts , 0 , ( mxArray * ) cy2wstccxe . P_326 ) ;
_ssSetSFcnParam ( rts , 1 , ( mxArray * ) cy2wstccxe . P_328 ) ;
_ssSetSFcnParam ( rts , 2 , ( mxArray * ) cy2wstccxe . P_330 ) ;
_ssSetSFcnParam ( rts , 3 , ( mxArray * ) cy2wstccxe . P_332 ) ;
_ssSetSFcnParam ( rts , 4 , ( mxArray * ) cy2wstccxe . P_334 ) ;
_ssSetSFcnParam ( rts , 5 , ( mxArray * ) cy2wstccxe . P_336 ) ;
_ssSetSFcnParam ( rts , 6 , ( mxArray * ) cy2wstccxe . P_338 ) ;
_ssSetSFcnParam ( rts , 7 , ( mxArray * ) cy2wstccxe . P_340 ) ;
_ssSetSFcnParam ( rts , 8 , ( mxArray * ) cy2wstccxe . P_342 ) ;
_ssSetSFcnParam ( rts , 9 , ( mxArray * ) cy2wstccxe . P_344 ) ;
_ssSetSFcnParam ( rts , 10 , ( mxArray * ) cy2wstccxe . P_346 ) ;
_ssSetSFcnParam ( rts , 11 , ( mxArray * ) cy2wstccxe . P_348 ) ;
_ssSetSFcnParam ( rts , 12 , ( mxArray * ) cy2wstccxe . P_350 ) ;
_ssSetSFcnParam ( rts , 13 , ( mxArray * ) cy2wstccxe . P_352 ) ;
_ssSetSFcnParam ( rts , 14 , ( mxArray * ) cy2wstccxe . P_354 ) ;
_ssSetSFcnParam ( rts , 15 , ( mxArray * ) cy2wstccxe . P_356 ) ;
_ssSetSFcnParam ( rts , 16 , ( mxArray * ) cy2wstccxe . P_358 ) ;
_ssSetSFcnParam ( rts , 17 , ( mxArray * ) cy2wstccxe . P_360 ) ;
_ssSetSFcnParam ( rts , 18 , ( mxArray * ) cy2wstccxe . P_362 ) ;
_ssSetSFcnParam ( rts , 19 , ( mxArray * ) cy2wstccxe . P_364 ) ;
_ssSetSFcnParam ( rts , 20 , ( mxArray * ) cy2wstccxe . P_366 ) ;
_ssSetSFcnParam ( rts , 21 , ( mxArray * ) cy2wstccxe . P_368 ) ;
_ssSetSFcnParam ( rts , 22 , ( mxArray * ) cy2wstccxe . P_370 ) ; } }
_ssSetIWork ( rts , ( int_T * ) & l1kpu4wb4rx . la3j00tqdl ) ; { struct
_ssDWorkRecord * dWorkRecord = ( struct _ssDWorkRecord * ) & nehesmkint ->
NonInlinedSFcns . Sfcn5 . dWork ; struct _ssDWorkAuxRecord * dWorkAuxRecord =
( struct _ssDWorkAuxRecord * ) & nehesmkint -> NonInlinedSFcns . Sfcn5 .
dWorkAux ; ssSetSFcnDWork ( rts , dWorkRecord ) ; ssSetSFcnDWorkAux ( rts ,
dWorkAuxRecord ) ; _ssSetNumDWork ( rts , 1 ) ; ssSetDWorkWidth ( rts , 0 , 1
) ; ssSetDWorkDataType ( rts , 0 , SS_INTEGER ) ; ssSetDWorkComplexSignal (
rts , 0 , 0 ) ; _ssSetDWork ( rts , 0 , & l1kpu4wb4rx . la3j00tqdl ) ; } (
rts ) -> regDataType . arg1 = ( ( void * ) ( rts ) ) ; ( rts ) -> regDataType
. registerFcn = ( ( OldRegisterDataType ) FcnSetErrorStatus ) ; ( rts ) ->
regDataType . getSizeFcn = ( ( GetDataTypeSize ) FcnSetErrorStatus ) ; ( rts
) -> regDataType . getZeroFcn = ( ( GetDataTypeZero ) FcnSetErrorStatus ) ; (
rts ) -> regDataType . getNameFcn = ( ( GetDataTypeName ) FcnSetErrorStatus )
; ( rts ) -> regDataType . getIdFcn = ( ( GetDataTypeId ) FcnSetErrorStatus )
; if ( ! slIsRapidAcceleratorSimulating ( ) ) { int_T i ; mxArray * plhs [ 1
] ; mxArray * prhs [ 4 ] ; double * pr ; volatile int_T * intS = ( int_T * )
& rts ; int_T addrlen = sizeof ( SimStruct * ) ; int_T m = addrlen / sizeof (
int_T ) + 1 ; prhs [ 0 ] = mxCreateDoubleMatrix ( 0 , 0 , mxREAL ) ; prhs [ 1
] = mxCreateDoubleMatrix ( m , 1 , mxREAL ) ; pr = mxGetPr ( prhs [ 1 ] ) ;
for ( i = 0 ; i < m - 1 ; i ++ ) { pr [ i ] = ( double ) intS [ i ] ; } pr [
i ] = ( double ) SIMSTRUCT_VERSION_LEVEL2 ; prhs [ 2 ] = mxCreateDoubleMatrix
( 0 , 0 , mxREAL ) ; prhs [ 3 ] = mxCreateDoubleMatrix ( 1 , 1 , mxREAL ) ;
ssSetRegInputPortDimensionInfoFcn ( rts , ( NULL ) ) ;
ssSetRegOutputPortDimensionInfoFcn ( rts , ( NULL ) ) ; mexCallMATLAB ( 1 ,
plhs , 4 , prhs , "scblock" ) ; mxDestroyArray ( plhs [ 0 ] ) ;
mxDestroyArray ( prhs [ 0 ] ) ; mxDestroyArray ( prhs [ 1 ] ) ;
mxDestroyArray ( prhs [ 2 ] ) ; mxDestroyArray ( prhs [ 3 ] ) ; } else {
scblock ( rts ) ; sfcnInitializeSizes ( rts ) ; } sfcnInitializeSampleTimes (
rts ) ; ssSetSampleTime ( rts , 0 , 0.0 ) ; ssSetOffsetTime ( rts , 0 , 0.0 )
; sfcnTsMap [ 0 ] = mdlref_TID0 ; ssSetInputPortWidth ( rts , 0 , 1 ) ;
ssSetInputPortDataType ( rts , 0 , SS_DOUBLE ) ; ssSetInputPortComplexSignal
( rts , 0 , 0 ) ; ssSetInputPortFrameData ( rts , 0 , 0 ) ;
ssSetInputPortUnit ( rts , 0 , 1 ) ; ssSetInputPortIsContinuousQuantity ( rts
, 0 , 0 ) ; ssSetNumNonsampledZCs ( rts , 0 ) ; _ssSetInputPortConnected (
rts , 0 , 1 ) ; _ssSetInputPortBufferDstPort ( rts , 0 , - 1 ) ; } } if ( (
rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL ) ) ) {
rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & ( nehesmkint ->
DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( nehesmkint -> DataMapInfo . mmi ,
rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex ( nehesmkint ->
DataMapInfo . mmi , rt_CSTATEIdx ) ; } } void mr_closedLoop_MdlInfoRegFcn (
SimStruct * mdlRefSfcnS , char_T * modelName , int_T * retVal ) { * retVal =
0 ; { boolean_T regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo (
mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) { } } *
retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName ,
rtMdlInfo_closedLoop , 64 ) ; * retVal = 1 ; } static void
mr_closedLoop_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) ; static void
mr_closedLoop_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_closedLoop_restoreDataFromMxArray ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_closedLoop_restoreDataFromMxArray ( void * destData , const mxArray *
srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_closedLoop_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_closedLoop_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int
j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_closedLoop_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) ; static uint_T
mr_closedLoop_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T ) mxGetScalar (
mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( ( 1u << numBits
) - 1u ) ; } static void mr_closedLoop_cacheDataToMxArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void mr_closedLoop_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_closedLoop_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_closedLoop_restoreDataFromMxArrayWithOffset ( void * destData
, const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_closedLoop_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_closedLoop_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_closedLoop_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_closedLoop_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) { const
uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber (
srcArray , i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u
) ; } mxArray * mr_closedLoop_GetDWork ( ) { static const char *
ssDWFieldNames [ 3 ] = { "iqd4nnjnc2n" , "l1kpu4wb4rx" , "NULL_PrevZCX" , } ;
mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_closedLoop_cacheDataAsMxArray ( ssDW , 0 , 0 , & ( iqd4nnjnc2n ) , sizeof
( iqd4nnjnc2n ) ) ; { static const char * rtdwDataFieldNames [ 103 ] = {
"l1kpu4wb4rx.hlha5jwilk" , "l1kpu4wb4rx.ct1fp3ytps" ,
"l1kpu4wb4rx.hbxvwhds10" , "l1kpu4wb4rx.jycpyvgbwk" ,
"l1kpu4wb4rx.pvzgszxw0h" , "l1kpu4wb4rx.ed0zskjjvf" ,
"l1kpu4wb4rx.kdbgqe1rl0" , "l1kpu4wb4rx.mkl1pjdrap" ,
"l1kpu4wb4rx.ckaxc2yuzj" , "l1kpu4wb4rx.nnm5ezmxoj" ,
"l1kpu4wb4rx.icxmsd205h" , "l1kpu4wb4rx.petosikypy" ,
"l1kpu4wb4rx.mikve0glkh" , "l1kpu4wb4rx.ccquv3ehj4" ,
"l1kpu4wb4rx.pbidohzefw" , "l1kpu4wb4rx.lzgpy1pmbg" ,
"l1kpu4wb4rx.ndcz2pevdt" , "l1kpu4wb4rx.e2xmk045t3" ,
"l1kpu4wb4rx.ceeqqvhrmq" , "l1kpu4wb4rx.grtf40g3km" ,
"l1kpu4wb4rx.ipoqi0vxan" , "l1kpu4wb4rx.h5eac0mibo" ,
"l1kpu4wb4rx.pa4czare1d" , "l1kpu4wb4rx.ckwjuadpca" ,
"l1kpu4wb4rx.eh1viw32xa" , "l1kpu4wb4rx.froc5u33zh" ,
"l1kpu4wb4rx.ouygc4kcvb" , "l1kpu4wb4rx.kjml2jdhog" ,
"l1kpu4wb4rx.onzlg3sfc1" , "l1kpu4wb4rx.dsxwjihxvj" ,
"l1kpu4wb4rx.aqmkm5qp10" , "l1kpu4wb4rx.mssfecnie3" ,
"l1kpu4wb4rx.g2b0tbo4r5" , "l1kpu4wb4rx.kj4m4y1hwn" ,
"l1kpu4wb4rx.daodt1zxg3" , "l1kpu4wb4rx.k2jw35opgq" ,
"l1kpu4wb4rx.e0gmlv2sjn" , "l1kpu4wb4rx.limd3gdwcq" ,
"l1kpu4wb4rx.nngs2uucok" , "l1kpu4wb4rx.awmyjetxto" ,
"l1kpu4wb4rx.jjqy4wbyuk" , "l1kpu4wb4rx.lgzj3kmwmk" ,
"l1kpu4wb4rx.o32wlonvfn" , "l1kpu4wb4rx.d5gswgg44w" ,
"l1kpu4wb4rx.cwuv444nvd" , "l1kpu4wb4rx.p2mtfvoju0" ,
"l1kpu4wb4rx.au1qch111s" , "l1kpu4wb4rx.eiqgdqqruu" ,
"l1kpu4wb4rx.arjxbzyxfd" , "l1kpu4wb4rx.iep3kan2rd" ,
"l1kpu4wb4rx.m42uoygnhd" , "l1kpu4wb4rx.ajirvaztbv" ,
"l1kpu4wb4rx.kt2l00xp53" , "l1kpu4wb4rx.koqig0mkgk" ,
"l1kpu4wb4rx.g2joetjd4n" , "l1kpu4wb4rx.ajl2ukv15n" ,
"l1kpu4wb4rx.byfchznm5b" , "l1kpu4wb4rx.di3hvnfgwf" ,
"l1kpu4wb4rx.bu5ibyt3ar" , "l1kpu4wb4rx.kxgtmxa2p2" ,
"l1kpu4wb4rx.i3bqhqdooa" , "l1kpu4wb4rx.no0lkkst0o" ,
"l1kpu4wb4rx.ebgm2o4pem" , "l1kpu4wb4rx.bztbsebwen" ,
"l1kpu4wb4rx.psdfuxjdsv" , "l1kpu4wb4rx.kzyw5zlnoa" ,
"l1kpu4wb4rx.eiifcbyv3z" , "l1kpu4wb4rx.e5wpgchixm" ,
"l1kpu4wb4rx.mifzmh1b42" , "l1kpu4wb4rx.mmcfrrmcvl" ,
"l1kpu4wb4rx.cbrf0g0kcz" , "l1kpu4wb4rx.la3j00tqdl" ,
"l1kpu4wb4rx.dvaxfxyujx" , "l1kpu4wb4rx.krzcukqncn" ,
"l1kpu4wb4rx.kqn0icr3hm" , "l1kpu4wb4rx.dyn5irgyjj" ,
"l1kpu4wb4rx.kayrm3qjer" , "l1kpu4wb4rx.h2jjjrmgpx" ,
"l1kpu4wb4rx.n1r0ywaznf" , "l1kpu4wb4rx.alglf53p5h" ,
"l1kpu4wb4rx.mmmkxfaf4h" , "l1kpu4wb4rx.bmhe2rp2ug" ,
"l1kpu4wb4rx.g5es2g4qos" , "l1kpu4wb4rx.flp2r32tjj" ,
"l1kpu4wb4rx.gyifh2fi2t" , "l1kpu4wb4rx.cct53vt3uw" ,
"l1kpu4wb4rx.ithaa4tvwx" , "l1kpu4wb4rx.bepyqlw5qu" ,
"l1kpu4wb4rx.hritc1babc" , "l1kpu4wb4rx.jpgsqiqfhq" ,
"l1kpu4wb4rx.n1umrqm4ou" , "l1kpu4wb4rx.akgp3l4qdu" ,
"l1kpu4wb4rx.nw11erxd40" , "l1kpu4wb4rx.dceylbyzbv" ,
"l1kpu4wb4rx.epxooln5rc" , "l1kpu4wb4rx.bbvyyfxxc2" ,
"l1kpu4wb4rx.etz51dx5fm" , "l1kpu4wb4rx.axinhpqqcc" ,
"l1kpu4wb4rx.h1d4piegmo" , "l1kpu4wb4rx.gz005nfpps" ,
"l1kpu4wb4rx.oas3p1lfy5" , "l1kpu4wb4rx.bevqx2fmne" ,
"l1kpu4wb4rx.mfw21nyyvb" , } ; mxArray * rtdwData = mxCreateStructMatrix ( 1
, 1 , 103 , rtdwDataFieldNames ) ; mr_closedLoop_cacheDataAsMxArray (
rtdwData , 0 , 0 , & ( l1kpu4wb4rx . hlha5jwilk ) , sizeof ( l1kpu4wb4rx .
hlha5jwilk ) ) ; mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 1 , & (
l1kpu4wb4rx . ct1fp3ytps ) , sizeof ( l1kpu4wb4rx . ct1fp3ytps ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 2 , & ( l1kpu4wb4rx .
hbxvwhds10 ) , sizeof ( l1kpu4wb4rx . hbxvwhds10 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 3 , & ( l1kpu4wb4rx .
jycpyvgbwk ) , sizeof ( l1kpu4wb4rx . jycpyvgbwk ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 4 , & ( l1kpu4wb4rx .
pvzgszxw0h ) , sizeof ( l1kpu4wb4rx . pvzgszxw0h ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 5 , & ( l1kpu4wb4rx .
ed0zskjjvf ) , sizeof ( l1kpu4wb4rx . ed0zskjjvf ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 6 , & ( l1kpu4wb4rx .
kdbgqe1rl0 ) , sizeof ( l1kpu4wb4rx . kdbgqe1rl0 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 7 , & ( l1kpu4wb4rx .
mkl1pjdrap ) , sizeof ( l1kpu4wb4rx . mkl1pjdrap ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 8 , & ( l1kpu4wb4rx .
ckaxc2yuzj ) , sizeof ( l1kpu4wb4rx . ckaxc2yuzj ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 9 , & ( l1kpu4wb4rx .
nnm5ezmxoj ) , sizeof ( l1kpu4wb4rx . nnm5ezmxoj ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 10 , & ( l1kpu4wb4rx .
icxmsd205h ) , sizeof ( l1kpu4wb4rx . icxmsd205h ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 11 , & ( l1kpu4wb4rx .
petosikypy ) , sizeof ( l1kpu4wb4rx . petosikypy ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 12 , & ( l1kpu4wb4rx .
mikve0glkh ) , sizeof ( l1kpu4wb4rx . mikve0glkh ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 13 , & ( l1kpu4wb4rx .
ccquv3ehj4 ) , sizeof ( l1kpu4wb4rx . ccquv3ehj4 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 14 , & ( l1kpu4wb4rx .
pbidohzefw ) , sizeof ( l1kpu4wb4rx . pbidohzefw ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 15 , & ( l1kpu4wb4rx .
lzgpy1pmbg ) , sizeof ( l1kpu4wb4rx . lzgpy1pmbg ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 16 , & ( l1kpu4wb4rx .
ndcz2pevdt ) , sizeof ( l1kpu4wb4rx . ndcz2pevdt ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 17 , & ( l1kpu4wb4rx .
e2xmk045t3 ) , sizeof ( l1kpu4wb4rx . e2xmk045t3 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 18 , & ( l1kpu4wb4rx .
ceeqqvhrmq ) , sizeof ( l1kpu4wb4rx . ceeqqvhrmq ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 19 , & ( l1kpu4wb4rx .
grtf40g3km ) , sizeof ( l1kpu4wb4rx . grtf40g3km ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 20 , & ( l1kpu4wb4rx .
ipoqi0vxan ) , sizeof ( l1kpu4wb4rx . ipoqi0vxan ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 21 , & ( l1kpu4wb4rx .
h5eac0mibo ) , sizeof ( l1kpu4wb4rx . h5eac0mibo ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 22 , & ( l1kpu4wb4rx .
pa4czare1d ) , sizeof ( l1kpu4wb4rx . pa4czare1d ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 23 , & ( l1kpu4wb4rx .
ckwjuadpca ) , sizeof ( l1kpu4wb4rx . ckwjuadpca ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 24 , & ( l1kpu4wb4rx .
eh1viw32xa ) , sizeof ( l1kpu4wb4rx . eh1viw32xa ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 25 , & ( l1kpu4wb4rx .
froc5u33zh ) , sizeof ( l1kpu4wb4rx . froc5u33zh ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 26 , & ( l1kpu4wb4rx .
ouygc4kcvb ) , sizeof ( l1kpu4wb4rx . ouygc4kcvb ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 27 , & ( l1kpu4wb4rx .
kjml2jdhog ) , sizeof ( l1kpu4wb4rx . kjml2jdhog ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 28 , & ( l1kpu4wb4rx .
onzlg3sfc1 ) , sizeof ( l1kpu4wb4rx . onzlg3sfc1 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 29 , & ( l1kpu4wb4rx .
dsxwjihxvj ) , sizeof ( l1kpu4wb4rx . dsxwjihxvj ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 30 , & ( l1kpu4wb4rx .
aqmkm5qp10 ) , sizeof ( l1kpu4wb4rx . aqmkm5qp10 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 31 , & ( l1kpu4wb4rx .
mssfecnie3 ) , sizeof ( l1kpu4wb4rx . mssfecnie3 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 32 , & ( l1kpu4wb4rx .
g2b0tbo4r5 ) , sizeof ( l1kpu4wb4rx . g2b0tbo4r5 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 33 , & ( l1kpu4wb4rx .
kj4m4y1hwn ) , sizeof ( l1kpu4wb4rx . kj4m4y1hwn ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 34 , & ( l1kpu4wb4rx .
daodt1zxg3 ) , sizeof ( l1kpu4wb4rx . daodt1zxg3 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 35 , & ( l1kpu4wb4rx .
k2jw35opgq ) , sizeof ( l1kpu4wb4rx . k2jw35opgq ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 36 , & ( l1kpu4wb4rx .
e0gmlv2sjn ) , sizeof ( l1kpu4wb4rx . e0gmlv2sjn ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 37 , & ( l1kpu4wb4rx .
limd3gdwcq ) , sizeof ( l1kpu4wb4rx . limd3gdwcq ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 38 , & ( l1kpu4wb4rx .
nngs2uucok ) , sizeof ( l1kpu4wb4rx . nngs2uucok ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 39 , & ( l1kpu4wb4rx .
awmyjetxto ) , sizeof ( l1kpu4wb4rx . awmyjetxto ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 40 , & ( l1kpu4wb4rx .
jjqy4wbyuk ) , sizeof ( l1kpu4wb4rx . jjqy4wbyuk ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 41 , & ( l1kpu4wb4rx .
lgzj3kmwmk ) , sizeof ( l1kpu4wb4rx . lgzj3kmwmk ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 42 , & ( l1kpu4wb4rx .
o32wlonvfn ) , sizeof ( l1kpu4wb4rx . o32wlonvfn ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 43 , & ( l1kpu4wb4rx .
d5gswgg44w ) , sizeof ( l1kpu4wb4rx . d5gswgg44w ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 44 , & ( l1kpu4wb4rx .
cwuv444nvd ) , sizeof ( l1kpu4wb4rx . cwuv444nvd ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 45 , & ( l1kpu4wb4rx .
p2mtfvoju0 ) , sizeof ( l1kpu4wb4rx . p2mtfvoju0 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 46 , & ( l1kpu4wb4rx .
au1qch111s ) , sizeof ( l1kpu4wb4rx . au1qch111s ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 47 , & ( l1kpu4wb4rx .
eiqgdqqruu ) , sizeof ( l1kpu4wb4rx . eiqgdqqruu ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 48 , & ( l1kpu4wb4rx .
arjxbzyxfd ) , sizeof ( l1kpu4wb4rx . arjxbzyxfd ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 49 , & ( l1kpu4wb4rx .
iep3kan2rd ) , sizeof ( l1kpu4wb4rx . iep3kan2rd ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 50 , & ( l1kpu4wb4rx .
m42uoygnhd ) , sizeof ( l1kpu4wb4rx . m42uoygnhd ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 51 , & ( l1kpu4wb4rx .
ajirvaztbv ) , sizeof ( l1kpu4wb4rx . ajirvaztbv ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 52 , & ( l1kpu4wb4rx .
kt2l00xp53 ) , sizeof ( l1kpu4wb4rx . kt2l00xp53 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 53 , & ( l1kpu4wb4rx .
koqig0mkgk ) , sizeof ( l1kpu4wb4rx . koqig0mkgk ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 54 , & ( l1kpu4wb4rx .
g2joetjd4n ) , sizeof ( l1kpu4wb4rx . g2joetjd4n ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 55 , & ( l1kpu4wb4rx .
ajl2ukv15n ) , sizeof ( l1kpu4wb4rx . ajl2ukv15n ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 56 , & ( l1kpu4wb4rx .
byfchznm5b ) , sizeof ( l1kpu4wb4rx . byfchznm5b ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 57 , & ( l1kpu4wb4rx .
di3hvnfgwf ) , sizeof ( l1kpu4wb4rx . di3hvnfgwf ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 58 , & ( l1kpu4wb4rx .
bu5ibyt3ar ) , sizeof ( l1kpu4wb4rx . bu5ibyt3ar ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 59 , & ( l1kpu4wb4rx .
kxgtmxa2p2 ) , sizeof ( l1kpu4wb4rx . kxgtmxa2p2 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 60 , & ( l1kpu4wb4rx .
i3bqhqdooa ) , sizeof ( l1kpu4wb4rx . i3bqhqdooa ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 61 , & ( l1kpu4wb4rx .
no0lkkst0o ) , sizeof ( l1kpu4wb4rx . no0lkkst0o ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 62 , & ( l1kpu4wb4rx .
ebgm2o4pem ) , sizeof ( l1kpu4wb4rx . ebgm2o4pem ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 63 , & ( l1kpu4wb4rx .
bztbsebwen ) , sizeof ( l1kpu4wb4rx . bztbsebwen ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 64 , & ( l1kpu4wb4rx .
psdfuxjdsv ) , sizeof ( l1kpu4wb4rx . psdfuxjdsv ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 65 , & ( l1kpu4wb4rx .
kzyw5zlnoa ) , sizeof ( l1kpu4wb4rx . kzyw5zlnoa ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 66 , & ( l1kpu4wb4rx .
eiifcbyv3z ) , sizeof ( l1kpu4wb4rx . eiifcbyv3z ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 67 , & ( l1kpu4wb4rx .
e5wpgchixm ) , sizeof ( l1kpu4wb4rx . e5wpgchixm ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 68 , & ( l1kpu4wb4rx .
mifzmh1b42 ) , sizeof ( l1kpu4wb4rx . mifzmh1b42 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 69 , & ( l1kpu4wb4rx .
mmcfrrmcvl ) , sizeof ( l1kpu4wb4rx . mmcfrrmcvl ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 70 , & ( l1kpu4wb4rx .
cbrf0g0kcz ) , sizeof ( l1kpu4wb4rx . cbrf0g0kcz ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 71 , & ( l1kpu4wb4rx .
la3j00tqdl ) , sizeof ( l1kpu4wb4rx . la3j00tqdl ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 72 , & ( l1kpu4wb4rx .
dvaxfxyujx ) , sizeof ( l1kpu4wb4rx . dvaxfxyujx ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 73 , & ( l1kpu4wb4rx .
krzcukqncn ) , sizeof ( l1kpu4wb4rx . krzcukqncn ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 74 , & ( l1kpu4wb4rx .
kqn0icr3hm ) , sizeof ( l1kpu4wb4rx . kqn0icr3hm ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 75 , & ( l1kpu4wb4rx .
dyn5irgyjj ) , sizeof ( l1kpu4wb4rx . dyn5irgyjj ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 76 , & ( l1kpu4wb4rx .
kayrm3qjer ) , sizeof ( l1kpu4wb4rx . kayrm3qjer ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 77 , & ( l1kpu4wb4rx .
h2jjjrmgpx ) , sizeof ( l1kpu4wb4rx . h2jjjrmgpx ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 78 , & ( l1kpu4wb4rx .
n1r0ywaznf ) , sizeof ( l1kpu4wb4rx . n1r0ywaznf ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 79 , & ( l1kpu4wb4rx .
alglf53p5h ) , sizeof ( l1kpu4wb4rx . alglf53p5h ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 80 , & ( l1kpu4wb4rx .
mmmkxfaf4h ) , sizeof ( l1kpu4wb4rx . mmmkxfaf4h ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 81 , & ( l1kpu4wb4rx .
bmhe2rp2ug ) , sizeof ( l1kpu4wb4rx . bmhe2rp2ug ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 82 , & ( l1kpu4wb4rx .
g5es2g4qos ) , sizeof ( l1kpu4wb4rx . g5es2g4qos ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 83 , & ( l1kpu4wb4rx .
flp2r32tjj ) , sizeof ( l1kpu4wb4rx . flp2r32tjj ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 84 , & ( l1kpu4wb4rx .
gyifh2fi2t ) , sizeof ( l1kpu4wb4rx . gyifh2fi2t ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 85 , & ( l1kpu4wb4rx .
cct53vt3uw ) , sizeof ( l1kpu4wb4rx . cct53vt3uw ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 86 , & ( l1kpu4wb4rx .
ithaa4tvwx ) , sizeof ( l1kpu4wb4rx . ithaa4tvwx ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 87 , & ( l1kpu4wb4rx .
bepyqlw5qu ) , sizeof ( l1kpu4wb4rx . bepyqlw5qu ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 88 , & ( l1kpu4wb4rx .
hritc1babc ) , sizeof ( l1kpu4wb4rx . hritc1babc ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 89 , & ( l1kpu4wb4rx .
jpgsqiqfhq ) , sizeof ( l1kpu4wb4rx . jpgsqiqfhq ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 90 , & ( l1kpu4wb4rx .
n1umrqm4ou ) , sizeof ( l1kpu4wb4rx . n1umrqm4ou ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 91 , & ( l1kpu4wb4rx .
akgp3l4qdu ) , sizeof ( l1kpu4wb4rx . akgp3l4qdu ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 92 , & ( l1kpu4wb4rx .
nw11erxd40 ) , sizeof ( l1kpu4wb4rx . nw11erxd40 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 93 , & ( l1kpu4wb4rx .
dceylbyzbv ) , sizeof ( l1kpu4wb4rx . dceylbyzbv ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 94 , & ( l1kpu4wb4rx .
epxooln5rc ) , sizeof ( l1kpu4wb4rx . epxooln5rc ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 95 , & ( l1kpu4wb4rx .
bbvyyfxxc2 ) , sizeof ( l1kpu4wb4rx . bbvyyfxxc2 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 96 , & ( l1kpu4wb4rx .
etz51dx5fm ) , sizeof ( l1kpu4wb4rx . etz51dx5fm ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 97 , & ( l1kpu4wb4rx .
axinhpqqcc ) , sizeof ( l1kpu4wb4rx . axinhpqqcc ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 98 , & ( l1kpu4wb4rx .
h1d4piegmo ) , sizeof ( l1kpu4wb4rx . h1d4piegmo ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 99 , & ( l1kpu4wb4rx .
gz005nfpps ) , sizeof ( l1kpu4wb4rx . gz005nfpps ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 100 , & ( l1kpu4wb4rx .
oas3p1lfy5 ) , sizeof ( l1kpu4wb4rx . oas3p1lfy5 ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 101 , & ( l1kpu4wb4rx .
bevqx2fmne ) , sizeof ( l1kpu4wb4rx . bevqx2fmne ) ) ;
mr_closedLoop_cacheDataAsMxArray ( rtdwData , 0 , 102 , & ( l1kpu4wb4rx .
mfw21nyyvb ) , sizeof ( l1kpu4wb4rx . mfw21nyyvb ) ) ; mxSetFieldByNumber (
ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void mr_closedLoop_SetDWork (
const mxArray * ssDW ) { ( void ) ssDW ; mr_closedLoop_restoreDataFromMxArray
( & ( iqd4nnjnc2n ) , ssDW , 0 , 0 , sizeof ( iqd4nnjnc2n ) ) ; { const
mxArray * rtdwData = mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . hlha5jwilk ) ,
rtdwData , 0 , 0 , sizeof ( l1kpu4wb4rx . hlha5jwilk ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . ct1fp3ytps ) ,
rtdwData , 0 , 1 , sizeof ( l1kpu4wb4rx . ct1fp3ytps ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . hbxvwhds10 ) ,
rtdwData , 0 , 2 , sizeof ( l1kpu4wb4rx . hbxvwhds10 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . jycpyvgbwk ) ,
rtdwData , 0 , 3 , sizeof ( l1kpu4wb4rx . jycpyvgbwk ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . pvzgszxw0h ) ,
rtdwData , 0 , 4 , sizeof ( l1kpu4wb4rx . pvzgszxw0h ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . ed0zskjjvf ) ,
rtdwData , 0 , 5 , sizeof ( l1kpu4wb4rx . ed0zskjjvf ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . kdbgqe1rl0 ) ,
rtdwData , 0 , 6 , sizeof ( l1kpu4wb4rx . kdbgqe1rl0 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . mkl1pjdrap ) ,
rtdwData , 0 , 7 , sizeof ( l1kpu4wb4rx . mkl1pjdrap ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . ckaxc2yuzj ) ,
rtdwData , 0 , 8 , sizeof ( l1kpu4wb4rx . ckaxc2yuzj ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . nnm5ezmxoj ) ,
rtdwData , 0 , 9 , sizeof ( l1kpu4wb4rx . nnm5ezmxoj ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . icxmsd205h ) ,
rtdwData , 0 , 10 , sizeof ( l1kpu4wb4rx . icxmsd205h ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . petosikypy ) ,
rtdwData , 0 , 11 , sizeof ( l1kpu4wb4rx . petosikypy ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . mikve0glkh ) ,
rtdwData , 0 , 12 , sizeof ( l1kpu4wb4rx . mikve0glkh ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . ccquv3ehj4 ) ,
rtdwData , 0 , 13 , sizeof ( l1kpu4wb4rx . ccquv3ehj4 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . pbidohzefw ) ,
rtdwData , 0 , 14 , sizeof ( l1kpu4wb4rx . pbidohzefw ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . lzgpy1pmbg ) ,
rtdwData , 0 , 15 , sizeof ( l1kpu4wb4rx . lzgpy1pmbg ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . ndcz2pevdt ) ,
rtdwData , 0 , 16 , sizeof ( l1kpu4wb4rx . ndcz2pevdt ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . e2xmk045t3 ) ,
rtdwData , 0 , 17 , sizeof ( l1kpu4wb4rx . e2xmk045t3 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . ceeqqvhrmq ) ,
rtdwData , 0 , 18 , sizeof ( l1kpu4wb4rx . ceeqqvhrmq ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . grtf40g3km ) ,
rtdwData , 0 , 19 , sizeof ( l1kpu4wb4rx . grtf40g3km ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . ipoqi0vxan ) ,
rtdwData , 0 , 20 , sizeof ( l1kpu4wb4rx . ipoqi0vxan ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . h5eac0mibo ) ,
rtdwData , 0 , 21 , sizeof ( l1kpu4wb4rx . h5eac0mibo ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . pa4czare1d ) ,
rtdwData , 0 , 22 , sizeof ( l1kpu4wb4rx . pa4czare1d ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . ckwjuadpca ) ,
rtdwData , 0 , 23 , sizeof ( l1kpu4wb4rx . ckwjuadpca ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . eh1viw32xa ) ,
rtdwData , 0 , 24 , sizeof ( l1kpu4wb4rx . eh1viw32xa ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . froc5u33zh ) ,
rtdwData , 0 , 25 , sizeof ( l1kpu4wb4rx . froc5u33zh ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . ouygc4kcvb ) ,
rtdwData , 0 , 26 , sizeof ( l1kpu4wb4rx . ouygc4kcvb ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . kjml2jdhog ) ,
rtdwData , 0 , 27 , sizeof ( l1kpu4wb4rx . kjml2jdhog ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . onzlg3sfc1 ) ,
rtdwData , 0 , 28 , sizeof ( l1kpu4wb4rx . onzlg3sfc1 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . dsxwjihxvj ) ,
rtdwData , 0 , 29 , sizeof ( l1kpu4wb4rx . dsxwjihxvj ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . aqmkm5qp10 ) ,
rtdwData , 0 , 30 , sizeof ( l1kpu4wb4rx . aqmkm5qp10 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . mssfecnie3 ) ,
rtdwData , 0 , 31 , sizeof ( l1kpu4wb4rx . mssfecnie3 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . g2b0tbo4r5 ) ,
rtdwData , 0 , 32 , sizeof ( l1kpu4wb4rx . g2b0tbo4r5 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . kj4m4y1hwn ) ,
rtdwData , 0 , 33 , sizeof ( l1kpu4wb4rx . kj4m4y1hwn ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . daodt1zxg3 ) ,
rtdwData , 0 , 34 , sizeof ( l1kpu4wb4rx . daodt1zxg3 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . k2jw35opgq ) ,
rtdwData , 0 , 35 , sizeof ( l1kpu4wb4rx . k2jw35opgq ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . e0gmlv2sjn ) ,
rtdwData , 0 , 36 , sizeof ( l1kpu4wb4rx . e0gmlv2sjn ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . limd3gdwcq ) ,
rtdwData , 0 , 37 , sizeof ( l1kpu4wb4rx . limd3gdwcq ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . nngs2uucok ) ,
rtdwData , 0 , 38 , sizeof ( l1kpu4wb4rx . nngs2uucok ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . awmyjetxto ) ,
rtdwData , 0 , 39 , sizeof ( l1kpu4wb4rx . awmyjetxto ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . jjqy4wbyuk ) ,
rtdwData , 0 , 40 , sizeof ( l1kpu4wb4rx . jjqy4wbyuk ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . lgzj3kmwmk ) ,
rtdwData , 0 , 41 , sizeof ( l1kpu4wb4rx . lgzj3kmwmk ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . o32wlonvfn ) ,
rtdwData , 0 , 42 , sizeof ( l1kpu4wb4rx . o32wlonvfn ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . d5gswgg44w ) ,
rtdwData , 0 , 43 , sizeof ( l1kpu4wb4rx . d5gswgg44w ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . cwuv444nvd ) ,
rtdwData , 0 , 44 , sizeof ( l1kpu4wb4rx . cwuv444nvd ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . p2mtfvoju0 ) ,
rtdwData , 0 , 45 , sizeof ( l1kpu4wb4rx . p2mtfvoju0 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . au1qch111s ) ,
rtdwData , 0 , 46 , sizeof ( l1kpu4wb4rx . au1qch111s ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . eiqgdqqruu ) ,
rtdwData , 0 , 47 , sizeof ( l1kpu4wb4rx . eiqgdqqruu ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . arjxbzyxfd ) ,
rtdwData , 0 , 48 , sizeof ( l1kpu4wb4rx . arjxbzyxfd ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . iep3kan2rd ) ,
rtdwData , 0 , 49 , sizeof ( l1kpu4wb4rx . iep3kan2rd ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . m42uoygnhd ) ,
rtdwData , 0 , 50 , sizeof ( l1kpu4wb4rx . m42uoygnhd ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . ajirvaztbv ) ,
rtdwData , 0 , 51 , sizeof ( l1kpu4wb4rx . ajirvaztbv ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . kt2l00xp53 ) ,
rtdwData , 0 , 52 , sizeof ( l1kpu4wb4rx . kt2l00xp53 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . koqig0mkgk ) ,
rtdwData , 0 , 53 , sizeof ( l1kpu4wb4rx . koqig0mkgk ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . g2joetjd4n ) ,
rtdwData , 0 , 54 , sizeof ( l1kpu4wb4rx . g2joetjd4n ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . ajl2ukv15n ) ,
rtdwData , 0 , 55 , sizeof ( l1kpu4wb4rx . ajl2ukv15n ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . byfchznm5b ) ,
rtdwData , 0 , 56 , sizeof ( l1kpu4wb4rx . byfchznm5b ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . di3hvnfgwf ) ,
rtdwData , 0 , 57 , sizeof ( l1kpu4wb4rx . di3hvnfgwf ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . bu5ibyt3ar ) ,
rtdwData , 0 , 58 , sizeof ( l1kpu4wb4rx . bu5ibyt3ar ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . kxgtmxa2p2 ) ,
rtdwData , 0 , 59 , sizeof ( l1kpu4wb4rx . kxgtmxa2p2 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . i3bqhqdooa ) ,
rtdwData , 0 , 60 , sizeof ( l1kpu4wb4rx . i3bqhqdooa ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . no0lkkst0o ) ,
rtdwData , 0 , 61 , sizeof ( l1kpu4wb4rx . no0lkkst0o ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . ebgm2o4pem ) ,
rtdwData , 0 , 62 , sizeof ( l1kpu4wb4rx . ebgm2o4pem ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . bztbsebwen ) ,
rtdwData , 0 , 63 , sizeof ( l1kpu4wb4rx . bztbsebwen ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . psdfuxjdsv ) ,
rtdwData , 0 , 64 , sizeof ( l1kpu4wb4rx . psdfuxjdsv ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . kzyw5zlnoa ) ,
rtdwData , 0 , 65 , sizeof ( l1kpu4wb4rx . kzyw5zlnoa ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . eiifcbyv3z ) ,
rtdwData , 0 , 66 , sizeof ( l1kpu4wb4rx . eiifcbyv3z ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . e5wpgchixm ) ,
rtdwData , 0 , 67 , sizeof ( l1kpu4wb4rx . e5wpgchixm ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . mifzmh1b42 ) ,
rtdwData , 0 , 68 , sizeof ( l1kpu4wb4rx . mifzmh1b42 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . mmcfrrmcvl ) ,
rtdwData , 0 , 69 , sizeof ( l1kpu4wb4rx . mmcfrrmcvl ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . cbrf0g0kcz ) ,
rtdwData , 0 , 70 , sizeof ( l1kpu4wb4rx . cbrf0g0kcz ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . la3j00tqdl ) ,
rtdwData , 0 , 71 , sizeof ( l1kpu4wb4rx . la3j00tqdl ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . dvaxfxyujx ) ,
rtdwData , 0 , 72 , sizeof ( l1kpu4wb4rx . dvaxfxyujx ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . krzcukqncn ) ,
rtdwData , 0 , 73 , sizeof ( l1kpu4wb4rx . krzcukqncn ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . kqn0icr3hm ) ,
rtdwData , 0 , 74 , sizeof ( l1kpu4wb4rx . kqn0icr3hm ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . dyn5irgyjj ) ,
rtdwData , 0 , 75 , sizeof ( l1kpu4wb4rx . dyn5irgyjj ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . kayrm3qjer ) ,
rtdwData , 0 , 76 , sizeof ( l1kpu4wb4rx . kayrm3qjer ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . h2jjjrmgpx ) ,
rtdwData , 0 , 77 , sizeof ( l1kpu4wb4rx . h2jjjrmgpx ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . n1r0ywaznf ) ,
rtdwData , 0 , 78 , sizeof ( l1kpu4wb4rx . n1r0ywaznf ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . alglf53p5h ) ,
rtdwData , 0 , 79 , sizeof ( l1kpu4wb4rx . alglf53p5h ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . mmmkxfaf4h ) ,
rtdwData , 0 , 80 , sizeof ( l1kpu4wb4rx . mmmkxfaf4h ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . bmhe2rp2ug ) ,
rtdwData , 0 , 81 , sizeof ( l1kpu4wb4rx . bmhe2rp2ug ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . g5es2g4qos ) ,
rtdwData , 0 , 82 , sizeof ( l1kpu4wb4rx . g5es2g4qos ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . flp2r32tjj ) ,
rtdwData , 0 , 83 , sizeof ( l1kpu4wb4rx . flp2r32tjj ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . gyifh2fi2t ) ,
rtdwData , 0 , 84 , sizeof ( l1kpu4wb4rx . gyifh2fi2t ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . cct53vt3uw ) ,
rtdwData , 0 , 85 , sizeof ( l1kpu4wb4rx . cct53vt3uw ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . ithaa4tvwx ) ,
rtdwData , 0 , 86 , sizeof ( l1kpu4wb4rx . ithaa4tvwx ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . bepyqlw5qu ) ,
rtdwData , 0 , 87 , sizeof ( l1kpu4wb4rx . bepyqlw5qu ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . hritc1babc ) ,
rtdwData , 0 , 88 , sizeof ( l1kpu4wb4rx . hritc1babc ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . jpgsqiqfhq ) ,
rtdwData , 0 , 89 , sizeof ( l1kpu4wb4rx . jpgsqiqfhq ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . n1umrqm4ou ) ,
rtdwData , 0 , 90 , sizeof ( l1kpu4wb4rx . n1umrqm4ou ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . akgp3l4qdu ) ,
rtdwData , 0 , 91 , sizeof ( l1kpu4wb4rx . akgp3l4qdu ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . nw11erxd40 ) ,
rtdwData , 0 , 92 , sizeof ( l1kpu4wb4rx . nw11erxd40 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . dceylbyzbv ) ,
rtdwData , 0 , 93 , sizeof ( l1kpu4wb4rx . dceylbyzbv ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . epxooln5rc ) ,
rtdwData , 0 , 94 , sizeof ( l1kpu4wb4rx . epxooln5rc ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . bbvyyfxxc2 ) ,
rtdwData , 0 , 95 , sizeof ( l1kpu4wb4rx . bbvyyfxxc2 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . etz51dx5fm ) ,
rtdwData , 0 , 96 , sizeof ( l1kpu4wb4rx . etz51dx5fm ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . axinhpqqcc ) ,
rtdwData , 0 , 97 , sizeof ( l1kpu4wb4rx . axinhpqqcc ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . h1d4piegmo ) ,
rtdwData , 0 , 98 , sizeof ( l1kpu4wb4rx . h1d4piegmo ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . gz005nfpps ) ,
rtdwData , 0 , 99 , sizeof ( l1kpu4wb4rx . gz005nfpps ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . oas3p1lfy5 ) ,
rtdwData , 0 , 100 , sizeof ( l1kpu4wb4rx . oas3p1lfy5 ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . bevqx2fmne ) ,
rtdwData , 0 , 101 , sizeof ( l1kpu4wb4rx . bevqx2fmne ) ) ;
mr_closedLoop_restoreDataFromMxArray ( & ( l1kpu4wb4rx . mfw21nyyvb ) ,
rtdwData , 0 , 102 , sizeof ( l1kpu4wb4rx . mfw21nyyvb ) ) ; } } void
mr_closedLoop_RegisterSimStateChecksum ( SimStruct * S ) { const uint32_T
chksum [ 4 ] = { 2074945923U , 770756657U , 2138333833U , 3811255059U , } ;
slmrModelRefRegisterSimStateChecksum ( S , "closedLoop" , & chksum [ 0 ] ) ;
} mxArray * mr_closedLoop_GetSimStateDisallowedBlocks ( ) { mxArray * data =
mxCreateCellMatrix ( 8 , 3 ) ; mwIndex subs [ 2 ] , offset ; { static const
char * blockType [ 8 ] = { "SimscapeExecutionBlock" ,
"SimscapeExecutionBlock" , "SimscapeExecutionBlock" ,
"SimscapeExecutionBlock" , "SimscapeExecutionBlock" ,
"SimscapeExecutionBlock" , "SimscapeExecutionBlock" ,
"SimscapeExecutionBlock" , } ; static const char * blockPath [ 8 ] = {
"closedLoop/Plant/Robot/Solver Configuration/EVAL_KEY/STATE_1" ,
"closedLoop/Plant/Robot/Solver Configuration/EVAL_KEY/OUTPUT_1_0" ,
"closedLoop/Plant/Robot/Solver Configuration/EVAL_KEY/STATE_2" ,
"closedLoop/Plant/Robot/Solver Configuration/EVAL_KEY/OUTPUT_2_0" ,
"closedLoop/Plant/Robot/Solver Configuration/EVAL_KEY/OUTPUT_1_0" ,
"closedLoop/Plant/Robot/Solver Configuration/EVAL_KEY/OUTPUT_2_0" ,
"closedLoop/Plant/Robot/Solver Configuration/EVAL_KEY/STATE_1" ,
"closedLoop/Plant/Robot/Solver Configuration/EVAL_KEY/STATE_2" , } ; static
const int reason [ 8 ] = { 0 , 0 , 0 , 0 , 2 , 2 , 2 , 2 , } ; for ( subs [ 0
] = 0 ; subs [ 0 ] < 8 ; ++ ( subs [ 0 ] ) ) { subs [ 1 ] = 0 ; offset =
mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data , offset ,
mxCreateString ( blockType [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 1 ; offset =
mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data , offset ,
mxCreateString ( blockPath [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 2 ; offset =
mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data , offset ,
mxCreateDoubleScalar ( ( double ) reason [ subs [ 0 ] ] ) ) ; } } return data
; } static void * closedLoop_InitRestoreDataPtr = NULL ; void
mr_closedLoop_CreateInitRestoreData ( ) { closedLoop_InitRestoreDataPtr =
utMalloc ( sizeof ( l1kpu4wb4rx ) ) ; memcpy ( closedLoop_InitRestoreDataPtr
, ( void * ) & ( l1kpu4wb4rx ) , sizeof ( l1kpu4wb4rx ) ) ; } void
mr_closedLoop_CopyFromInitRestoreData ( ) { memcpy ( ( void * ) & (
l1kpu4wb4rx ) , closedLoop_InitRestoreDataPtr , sizeof ( l1kpu4wb4rx ) ) ; }
void mr_closedLoop_DestroyInitRestoreData ( ) { utFree (
closedLoop_InitRestoreDataPtr ) ; }
