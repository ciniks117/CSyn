#include "__cf_closedLoop.h"
#ifndef RTW_HEADER_closedLoop_capi_h_
#define RTW_HEADER_closedLoop_capi_h_
#include "closedLoop.h"
extern void closedLoop_InitializeDataMapInfo ( k2snwiamgb * const nehesmkint
, pig3puin4o2 * localX , void * sysRanPtr , int contextTid ) ;
#endif
