#include "__cf_closedLoop.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifndef CLOSEDLOOP_2F6391D8_2_DS_H
#define CLOSEDLOOP_2F6391D8_2_DS_H     1
extern NeDynamicSystem * closedLoop_2f6391d8_2_dae_ds ( PmAllocator *
allocator ) ;
#endif
#ifdef __cplusplus
}
#endif
