#include "__cf_closedLoop.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifndef CLOSEDLOOP_2F6391D8_2_DS_TDXY_P_H
#define CLOSEDLOOP_2F6391D8_2_DS_TDXY_P_H 1
extern int32_T closedLoop_2f6391d8_2_ds_tdxy_p ( const NeDynamicSystem * sys
, const NeDynamicSystemInput * in , NeDsMethodOutput * ou ) ;
#endif
#ifdef __cplusplus
}
#endif
