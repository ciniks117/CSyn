#include "__cf_closedLoop_tuned.h"
#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
void closedLoop_tuned_57a28c5_1_validateRuntimeParameters ( const double *
rtp , int32_T * satFlags ) { ( void ) rtp ; ( void ) satFlags ; } const
NeAssertData * closedLoop_tuned_57a28c5_1_assertData = NULL ;
