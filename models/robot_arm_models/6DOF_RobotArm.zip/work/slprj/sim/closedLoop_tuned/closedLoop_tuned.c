#include "__cf_closedLoop_tuned.h"
#include "closedLoop_tuned_capi.h"
#include "closedLoop_tuned.h"
#include "closedLoop_tuned_private.h"
int_T lsbnhudl31 [ 2 ] ; static RegMdlInfo rtMdlInfo_closedLoop_tuned [ 63 ]
= { { "elvjztouutq" , MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "elvjztouut" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "isdu4mn4lvb" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "kqhtzkn4pup" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "hiuxemmozll" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "id24jk0x2ms" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "pu40142whda" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "oed0kowdm4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "muhdlv5chcc" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "g15cyjnisqa" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "bof3ifvdh33" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "eilavowrwl4" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "n4awau1raf2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "isdu4mn4lv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "kqhtzkn4pu" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "hiuxemmozl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "id24jk0x2m" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "pu40142whd" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "muhdlv5chc" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "g15cyjnisq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "bof3ifvdh3" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "eilavowrwl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "n4awau1raf" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "cl4ckzwyfo" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "bsskyrygm1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "cpsgcdfxop" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "a1stgek52t" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "g3gadye0b3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "gzlvoih4gg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "febppa0s54" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "fh5akag4fo" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "h4fxpncuan" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "ghycukq2fb" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "mromvgiaby" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "ml0xqgpx3s" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "c1zon0qyu1" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "closedLoop_tuned" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL )
} , { "owxjjka5eu3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "pcj55inbahp" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "lsbnhudl31" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "d1slopnfj2d" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "lvuzhhuckmt" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "owxjjka5eu" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "pcj55inbah" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"closedLoop_tuned" } , { "ldanydgdre" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "closedLoop_tuned" } , { "nbzsdh3gog" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "closedLoop_tuned" }
, { "jointTorqueBus" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"jointVelBus" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"jointMotionBus" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"mr_closedLoop_tuned_GetSimStateDisallowedBlocks" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "closedLoop_tuned" } , {
"mr_closedLoop_tuned_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "closedLoop_tuned" } , {
"mr_closedLoop_tuned_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "closedLoop_tuned" } , {
"mr_closedLoop_tuned_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "closedLoop_tuned" } , {
"mr_closedLoop_tuned_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "closedLoop_tuned" } , {
"mr_closedLoop_tuned_extractBitFieldFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "closedLoop_tuned" } , {
"mr_closedLoop_tuned_cacheBitFieldToMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "closedLoop_tuned" } , {
"mr_closedLoop_tuned_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "closedLoop_tuned" } , {
"mr_closedLoop_tuned_cacheDataAsMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "closedLoop_tuned" } , {
"mr_closedLoop_tuned_RegisterSimStateChecksum" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "closedLoop_tuned" } , { "mr_closedLoop_tuned_SetDWork"
, MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "closedLoop_tuned" } , {
"mr_closedLoop_tuned_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , (
void * ) "closedLoop_tuned" } , { "closedLoop_tuned.h" ,
MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL ) } , { "closedLoop_tuned.c" ,
MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * ) "closedLoop_tuned" } } ;
pespwmvr2is bof3ifvdh3 = { 21.0180234727249 , 58.2762205966547 ,
0.20047626148189 , 0.195709489924621 , 0.346600752490046 , 0.223470955257761
, 0.0265288646840578 , 0.000448190430142682 , 0.00337174988064101 ,
0.000419222702982036 , 0.324359106529765 , 0.00097597573827831 ,
0.146143607435002 , 0.00114163073091871 , 0.460092048608168 ,
0.000444755466308859 , 2.06091269945642 , 0.000593032145468798 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 ,
1.0 , 1.0 , 4.00240654506278E-5 , 0.0216415897548656 , 257.755378801474 ,
190.172011630327 , 761.904761904762 , 761.904761904762 , 10.7694124560307 ,
0.0192799899284329 , 9.66802754702183 , 0.00572339896932079 ,
10.7654470599538 , 0.00683255135393729 , 10.7702769040942 ,
0.00659405389444924 , 10.4708336285486 , 0.0360231984902585 ,
10.8442867281081 , 0.0426832255455665 , 0.01 , 0.01 , 0.01 , 0.01 , 0.01 ,
0.01 , 0.01 , 0.01 , 0.01 , 0.01 , 0.01 , 0.01 , 0.0025 , 57.295779513082323
, 0.16666666666666666 , 0.0 , 0.0025 , 0.0 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 ,
57.295779513082323 , 0.0025 , 0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0
, 0.0 , 0.0025 , 57.295779513082323 , 0.16666666666666666 , 0.0 , 0.0025 ,
0.0 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 , 57.295779513082323 , 0.0025 ,
0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0025 ,
57.295779513082323 , 0.16666666666666666 , 0.0 , 0.0025 , 0.0 , 0.0025 , 0.0
, 0.0 , 0.0 , 0.0 , 57.295779513082323 , 0.0025 , 0.16666666666666666 ,
0.0025 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0025 , 57.295779513082323 ,
0.16666666666666666 , 0.0 , 0.0025 , 0.0 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 ,
57.295779513082323 , 0.0025 , 0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0
, 0.0 , 0.0025 , 57.295779513082323 , 0.16666666666666666 , 0.0 , 0.0025 ,
0.0 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 , 57.295779513082323 , 0.0025 ,
0.16666666666666666 , 0.0025 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0025 ,
57.295779513082323 , 0.16666666666666666 , 0.0 , 0.0025 , 0.0 , 0.0025 , 0.0
, 0.0 , 0.0 , 0.0 , 57.295779513082323 , 0.0025 , 0.16666666666666666 ,
0.0025 , 0.0 , 0.0 , 0.0 , 0.0 , 9.5492965855137211 , 6.0 ,
9.5492965855137211 , 6.0 , 9.5492965855137211 , 6.0 , 9.5492965855137211 ,
6.0 , 9.5492965855137211 , 6.0 , 9.5492965855137211 , 6.0 } ; elvjztouutq
elvjztouut ; n4awau1raf2 lvuzhhuckmt ; eilavowrwl4 d1slopnfj2d ; void
c1zon0qyu1 ( void ) { nbzsdh3gog * const hfoeutytij = & ( elvjztouut . rtm )
; if ( ( ssGetSimMode ( hfoeutytij -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL )
&& ( ( hfoeutytij -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void * slioCatalogue =
rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) :
sdiGetSlioCatalogue ( hfoeutytij -> DataMapInfo . mmi . InstanceMap .
fullPath ) ; if ( ! slioCatalogue || ! rtwDisableStreamingToRepository (
slioCatalogue ) ) { if ( slIsRapidAcceleratorSimulating ( ) || ( ssGetSimMode
( hfoeutytij -> _mdlRefSfcnS ) == SS_SIMMODE_NORMAL ) ||
ssRTWGenIsAccelerator ( hfoeutytij -> _mdlRefSfcnS ) ) { {
sdiSignalSourceInfoU srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars (
"i" ) ; sdiLabelU origSigName = sdiGetLabelFromChars ( "i" ) ; sdiLabelU
propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars (
"closedLoop_tuned/Plant/Subsystem/PS-Simulink Converter" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiDims forEachMdlRefDims ;
int_T forEachMdlRefDimsArray [ 32 ] ; sdiLabelU sigName =
sdiGetLabelFromChars ( "i" ) ; sdiAsyncQueueHandle hForEachParent = ( NULL )
; sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; if ( slIsRapidAcceleratorSimulating (
) ) { forEachMdlRefDims . nDims = 0 ; } else { forEachMdlRefDims . nDims =
slSigLogGetForEachDimsForRefModel ( hfoeutytij -> _mdlRefSfcnS ,
forEachMdlRefDimsArray ) ; forEachMdlRefDims . dimensions =
forEachMdlRefDimsArray ; } if ( forEachMdlRefDims . nDims > 0 ) {
hForEachParent = sdiCreateForEachParent ( & srcInfo , hfoeutytij ->
DataMapInfo . mmi . InstanceMap . fullPath , ( NULL ) , loggedName ,
origSigName , propName , & forEachMdlRefDims ) ; sdiUpdateForEachLeafName ( &
srcInfo , hForEachParent ) ; } d1slopnfj2d . ne4l15gebh . AQHandles =
sdiAsyncRepoCreateAsyncioQueue ( hDT , & srcInfo , hfoeutytij -> DataMapInfo
. mmi . InstanceMap . fullPath , "d5a19979-94ac-4607-8970-d99d9be11497" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "A" ) ; if (
d1slopnfj2d . ne4l15gebh . AQHandles ) { sdiSetSignalSampleTimeString (
d1slopnfj2d . ne4l15gebh . AQHandles , "Continuous" , 0.0 , rtmGetTFinal (
hfoeutytij ) ) ; sdiSetRunStartTime ( d1slopnfj2d . ne4l15gebh . AQHandles ,
rtmGetTaskTime ( hfoeutytij , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings (
d1slopnfj2d . ne4l15gebh . AQHandles , 1 , 0 ) ;
sdiAsyncRepoSetSignalExportName ( d1slopnfj2d . ne4l15gebh . AQHandles ,
loggedName , origSigName , propName ) ; if ( forEachMdlRefDims . nDims > 0 )
{ sdiAttachForEachIterationToParent ( hForEachParent , d1slopnfj2d .
ne4l15gebh . AQHandles , ( NULL ) ) ; if ( srcInfo . signalName != sigName )
{ sdiFreeName ( srcInfo . signalName ) ; } } } sdiFreeLabel ( sigName ) ;
sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel (
propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } } } d1slopnfj2d . ne4l15gebh . SlioLTF = (
NULL ) ; { void * treeVector = ( NULL ) ; void * accessor = ( NULL ) ; const
void * signalDescriptor = ( NULL ) ; void * loggingInterval = ( NULL ) ; char
* datasetName = "tmp_raccel_logsout" ; if ( slioCatalogue &&
rtwIsLoggingToFile ( slioCatalogue ) ) { int_T forEachMdlRefDimsArray [ 32 ]
; int_T forEachMdlRefDimsArraySize = 0 ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { forEachMdlRefDimsArraySize =
slSigLogGetForEachDimsForRefModel ( hfoeutytij -> _mdlRefSfcnS ,
forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector ( ) ; { int_T
sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 0 , "i" , "linear" , 0 , (
unsigned int * ) sigDimsArray , 1 , "double" , "A" , "Continuous" , 0.0 ,
rtmGetTFinal ( hfoeutytij ) , treeVector ) ; } signalDescriptor =
rtwGetSignalDescriptor ( treeVector , 1 , 1 , 0 , 1 , "i" , "" , hfoeutytij
-> DataMapInfo . mmi . InstanceMap . fullPath ,
"closedLoop_tuned/Plant/Subsystem/PS-Simulink Converter" , 1 , 0 ,
slioCatalogue , forEachMdlRefDimsArraySize ? ( const uint_T * )
forEachMdlRefDimsArray : ( NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0
) ; if ( ! rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( hfoeutytij ->
DataMapInfo . mmi . InstanceMap . fullPath ,
"closedLoop_tuned/Plant/Subsystem/PS-Simulink Converter" , 1 , "i" ) ; } if (
rtwLoggingOverride ( signalDescriptor , slioCatalogue ) ) { if ( hfoeutytij
-> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo ) { loggingInterval =
rtliGetLoggingInterval ( hfoeutytij -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) ; } else { loggingInterval = sdiGetLoggingIntervals ( hfoeutytij ->
DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = "" ; } accessor
= rtwGetAccessor ( signalDescriptor , loggingInterval ) ; rtwAddR2Client (
accessor , signalDescriptor , slioCatalogue , datasetName , 1 ) ; d1slopnfj2d
. ne4l15gebh . SlioLTF = accessor ; } } } } if ( ( ssGetSimMode ( hfoeutytij
-> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( ( hfoeutytij -> _mdlRefSfcnS
) -> mdlInfo -> rtwgenMode != SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void
* slioCatalogue = rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr (
rt_slioCatalogue ( ) ) : sdiGetSlioCatalogue ( hfoeutytij -> DataMapInfo .
mmi . InstanceMap . fullPath ) ; if ( ! slioCatalogue || !
rtwDisableStreamingToRepository ( slioCatalogue ) ) { if (
slIsRapidAcceleratorSimulating ( ) || ( ssGetSimMode ( hfoeutytij ->
_mdlRefSfcnS ) == SS_SIMMODE_NORMAL ) || ssRTWGenIsAccelerator ( hfoeutytij
-> _mdlRefSfcnS ) ) { { sdiSignalSourceInfoU srcInfo ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"closedLoop_tuned/Plant" ) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" )
; sdiLabelU subPath = sdiGetLabelFromChars ( "" ) ; const char_T * leafUnits
[ 6 ] = { "deg" , "deg" , "deg" , "deg" , "deg" , "deg" } ;
sdiVirtualBusLeafElementInfoU leafElInfo [ 6 ] ; int_T childDimsArray0 [ 1 ]
= { 1 } ; int_T childDimsArray1 [ 1 ] = { 1 } ; int_T childDimsArray2 [ 1 ] =
{ 1 } ; int_T childDimsArray3 [ 1 ] = { 1 } ; int_T childDimsArray4 [ 1 ] = {
1 } ; int_T childDimsArray5 [ 1 ] = { 1 } ; { sdiAsyncRepoDataTypeHandle hDT
= sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 0
] . hDataType = hDT ; leafElInfo [ 0 ] . signalName = sdiGetLabelFromChars (
"jointsAngle.upperArmJointMotion" ) ; leafElInfo [ 0 ] . dims . nDims = 1 ;
leafElInfo [ 0 ] . dims . dimensions = childDimsArray0 ; leafElInfo [ 0 ] .
dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 0 ] . complexity = REAL ;
leafElInfo [ 0 ] . isLinearInterp = 1 ; leafElInfo [ 0 ] . units = leafUnits
[ 0 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 1 ]
. hDataType = hDT ; leafElInfo [ 1 ] . signalName = sdiGetLabelFromChars (
"jointsAngle.foreArmJointMotion" ) ; leafElInfo [ 1 ] . dims . nDims = 1 ;
leafElInfo [ 1 ] . dims . dimensions = childDimsArray1 ; leafElInfo [ 1 ] .
dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 1 ] . complexity = REAL ;
leafElInfo [ 1 ] . isLinearInterp = 1 ; leafElInfo [ 1 ] . units = leafUnits
[ 1 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 2 ]
. hDataType = hDT ; leafElInfo [ 2 ] . signalName = sdiGetLabelFromChars (
"jointsAngle.wristJointMotion" ) ; leafElInfo [ 2 ] . dims . nDims = 1 ;
leafElInfo [ 2 ] . dims . dimensions = childDimsArray2 ; leafElInfo [ 2 ] .
dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 2 ] . complexity = REAL ;
leafElInfo [ 2 ] . isLinearInterp = 1 ; leafElInfo [ 2 ] . units = leafUnits
[ 2 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 3 ]
. hDataType = hDT ; leafElInfo [ 3 ] . signalName = sdiGetLabelFromChars (
"jointsAngle.gripperJointMotion" ) ; leafElInfo [ 3 ] . dims . nDims = 1 ;
leafElInfo [ 3 ] . dims . dimensions = childDimsArray3 ; leafElInfo [ 3 ] .
dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 3 ] . complexity = REAL ;
leafElInfo [ 3 ] . isLinearInterp = 1 ; leafElInfo [ 3 ] . units = leafUnits
[ 3 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 4 ]
. hDataType = hDT ; leafElInfo [ 4 ] . signalName = sdiGetLabelFromChars (
"jointsAngle.rightFingerJointMotion" ) ; leafElInfo [ 4 ] . dims . nDims = 1
; leafElInfo [ 4 ] . dims . dimensions = childDimsArray4 ; leafElInfo [ 4 ] .
dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 4 ] . complexity = REAL ;
leafElInfo [ 4 ] . isLinearInterp = 1 ; leafElInfo [ 4 ] . units = leafUnits
[ 4 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 5 ]
. hDataType = hDT ; leafElInfo [ 5 ] . signalName = sdiGetLabelFromChars (
"jointsAngle.leftFingerJointMotion" ) ; leafElInfo [ 5 ] . dims . nDims = 1 ;
leafElInfo [ 5 ] . dims . dimensions = childDimsArray5 ; leafElInfo [ 5 ] .
dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 5 ] . complexity = REAL ;
leafElInfo [ 5 ] . isLinearInterp = 1 ; leafElInfo [ 5 ] . units = leafUnits
[ 5 ] ; } srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = (
sdiFullBlkPathU ) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ;
srcInfo . subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo .
signalName = sigName ; srcInfo . sigSourceUUID = 0 ;
sdiCreateAsyncQueuesForVirtualBusWithExportSettings ( & srcInfo , hfoeutytij
-> DataMapInfo . mmi . InstanceMap . fullPath ,
"c9389c51-5f28-4676-82b8-ec8e9517351f" , 6 , leafElInfo , & d1slopnfj2d .
h30jmamuoh . AQHandles [ 0 ] , 1 , 0 , "jointsAngle" , "jointsAngle" , "" ) ;
if ( d1slopnfj2d . h30jmamuoh . AQHandles [ 0 ] ) { sdiLabelU loggedName =
sdiGetLabelFromChars ( "jointsAngle" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "jointsAngle" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiSetSignalSampleTimeString ( d1slopnfj2d .
h30jmamuoh . AQHandles [ 0 ] , "Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij
) ) ; sdiSetRunStartTime ( d1slopnfj2d . h30jmamuoh . AQHandles [ 0 ] ,
rtmGetTaskTime ( hfoeutytij , 0 ) ) ; sdiAsyncRepoSetSignalExportSettings (
d1slopnfj2d . h30jmamuoh . AQHandles [ 0 ] , 1 , 0 ) ;
sdiAsyncRepoSetSignalExportName ( d1slopnfj2d . h30jmamuoh . AQHandles [ 0 ]
, loggedName , origSigName , propName ) ; sdiSetSignalSampleTimeString (
d1slopnfj2d . h30jmamuoh . AQHandles [ 1 ] , "Continuous" , 0.0 ,
rtmGetTFinal ( hfoeutytij ) ) ; sdiSetRunStartTime ( d1slopnfj2d . h30jmamuoh
. AQHandles [ 1 ] , rtmGetTaskTime ( hfoeutytij , 0 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( d1slopnfj2d . h30jmamuoh . AQHandles [
1 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( d1slopnfj2d . h30jmamuoh .
AQHandles [ 1 ] , loggedName , origSigName , propName ) ;
sdiSetSignalSampleTimeString ( d1slopnfj2d . h30jmamuoh . AQHandles [ 2 ] ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) ) ; sdiSetRunStartTime (
d1slopnfj2d . h30jmamuoh . AQHandles [ 2 ] , rtmGetTaskTime ( hfoeutytij , 0
) ) ; sdiAsyncRepoSetSignalExportSettings ( d1slopnfj2d . h30jmamuoh .
AQHandles [ 2 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( d1slopnfj2d .
h30jmamuoh . AQHandles [ 2 ] , loggedName , origSigName , propName ) ;
sdiSetSignalSampleTimeString ( d1slopnfj2d . h30jmamuoh . AQHandles [ 3 ] ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) ) ; sdiSetRunStartTime (
d1slopnfj2d . h30jmamuoh . AQHandles [ 3 ] , rtmGetTaskTime ( hfoeutytij , 0
) ) ; sdiAsyncRepoSetSignalExportSettings ( d1slopnfj2d . h30jmamuoh .
AQHandles [ 3 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( d1slopnfj2d .
h30jmamuoh . AQHandles [ 3 ] , loggedName , origSigName , propName ) ;
sdiSetSignalSampleTimeString ( d1slopnfj2d . h30jmamuoh . AQHandles [ 4 ] ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) ) ; sdiSetRunStartTime (
d1slopnfj2d . h30jmamuoh . AQHandles [ 4 ] , rtmGetTaskTime ( hfoeutytij , 0
) ) ; sdiAsyncRepoSetSignalExportSettings ( d1slopnfj2d . h30jmamuoh .
AQHandles [ 4 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( d1slopnfj2d .
h30jmamuoh . AQHandles [ 4 ] , loggedName , origSigName , propName ) ;
sdiSetSignalSampleTimeString ( d1slopnfj2d . h30jmamuoh . AQHandles [ 5 ] ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) ) ; sdiSetRunStartTime (
d1slopnfj2d . h30jmamuoh . AQHandles [ 5 ] , rtmGetTaskTime ( hfoeutytij , 0
) ) ; sdiAsyncRepoSetSignalExportSettings ( d1slopnfj2d . h30jmamuoh .
AQHandles [ 5 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( d1slopnfj2d .
h30jmamuoh . AQHandles [ 5 ] , loggedName , origSigName , propName ) ;
sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel (
propName ) ; } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; sdiFreeName (
leafElInfo [ 0 ] . signalName ) ; sdiFreeName ( leafElInfo [ 1 ] . signalName
) ; sdiFreeName ( leafElInfo [ 2 ] . signalName ) ; sdiFreeName ( leafElInfo
[ 3 ] . signalName ) ; sdiFreeName ( leafElInfo [ 4 ] . signalName ) ;
sdiFreeName ( leafElInfo [ 5 ] . signalName ) ; } } } d1slopnfj2d .
h30jmamuoh . SlioLTF = ( NULL ) ; { void * treeVector = ( NULL ) ; void *
accessor = ( NULL ) ; const void * signalDescriptor = ( NULL ) ; void *
loggingInterval = ( NULL ) ; char * datasetName = "tmp_raccel_logsout" ; if (
slioCatalogue && rtwIsLoggingToFile ( slioCatalogue ) ) { int_T
forEachMdlRefDimsArray [ 32 ] ; int_T forEachMdlRefDimsArraySize = 0 ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { forEachMdlRefDimsArraySize =
slSigLogGetForEachDimsForRefModel ( hfoeutytij -> _mdlRefSfcnS ,
forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector ( ) ; {
rtwAddTopBusNode ( "jointsAngle" , 6 , treeVector ) ; { int_T sigDimsArray [
1 ] = { 1 } ; rtwAddLeafNode ( 0 , "upperArmJointMotion" , "linear" , 0 , (
unsigned int * ) sigDimsArray , 1 , "double" , "deg" , "Continuous" , 0.0 ,
rtmGetTFinal ( hfoeutytij ) , treeVector ) ; } { int_T sigDimsArray [ 1 ] = {
1 } ; rtwAddLeafNode ( 0 , "foreArmJointMotion" , "linear" , 0 , ( unsigned
int * ) sigDimsArray , 1 , "double" , "deg" , "Continuous" , 0.0 ,
rtmGetTFinal ( hfoeutytij ) , treeVector ) ; } { int_T sigDimsArray [ 1 ] = {
1 } ; rtwAddLeafNode ( 0 , "wristJointMotion" , "linear" , 0 , ( unsigned int
* ) sigDimsArray , 1 , "double" , "deg" , "Continuous" , 0.0 , rtmGetTFinal (
hfoeutytij ) , treeVector ) ; } { int_T sigDimsArray [ 1 ] = { 1 } ;
rtwAddLeafNode ( 0 , "gripperJointMotion" , "linear" , 0 , ( unsigned int * )
sigDimsArray , 1 , "double" , "deg" , "Continuous" , 0.0 , rtmGetTFinal (
hfoeutytij ) , treeVector ) ; } { int_T sigDimsArray [ 1 ] = { 1 } ;
rtwAddLeafNode ( 0 , "rightFingerJointMotion" , "linear" , 0 , ( unsigned int
* ) sigDimsArray , 1 , "double" , "deg" , "Continuous" , 0.0 , rtmGetTFinal (
hfoeutytij ) , treeVector ) ; } { int_T sigDimsArray [ 1 ] = { 1 } ;
rtwAddLeafNode ( 0 , "leftFingerJointMotion" , "linear" , 0 , ( unsigned int
* ) sigDimsArray , 1 , "double" , "deg" , "Continuous" , 0.0 , rtmGetTFinal (
hfoeutytij ) , treeVector ) ; } rtwPopNVBusNode ( treeVector ) ; }
signalDescriptor = rtwGetSignalDescriptor ( treeVector , 6 , 1 , 0 , 1 ,
"jointsAngle" , "" , hfoeutytij -> DataMapInfo . mmi . InstanceMap . fullPath
, "closedLoop_tuned/Plant" , 1 , 0 , slioCatalogue ,
forEachMdlRefDimsArraySize ? ( const uint_T * ) forEachMdlRefDimsArray : (
NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0 ) ; if ( !
rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( hfoeutytij -> DataMapInfo .
mmi . InstanceMap . fullPath , "closedLoop_tuned/Plant" , 1 , "jointsAngle" )
; } if ( rtwLoggingOverride ( signalDescriptor , slioCatalogue ) ) { if (
hfoeutytij -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo ) { loggingInterval =
rtliGetLoggingInterval ( hfoeutytij -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) ; } else { loggingInterval = sdiGetLoggingIntervals ( hfoeutytij ->
DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = "" ; } accessor
= rtwGetAccessor ( signalDescriptor , loggingInterval ) ; rtwAddR2Client (
accessor , signalDescriptor , slioCatalogue , datasetName , 1 ) ; d1slopnfj2d
. h30jmamuoh . SlioLTF = accessor ; } } } } if ( ( ssGetSimMode ( hfoeutytij
-> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( ( hfoeutytij -> _mdlRefSfcnS
) -> mdlInfo -> rtwgenMode != SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { void
* slioCatalogue = rt_slioCatalogue ( ) ? rtwGetPointerFromUniquePtr (
rt_slioCatalogue ( ) ) : sdiGetSlioCatalogue ( hfoeutytij -> DataMapInfo .
mmi . InstanceMap . fullPath ) ; if ( ! slioCatalogue || !
rtwDisableStreamingToRepository ( slioCatalogue ) ) { if (
slIsRapidAcceleratorSimulating ( ) || ( ssGetSimMode ( hfoeutytij ->
_mdlRefSfcnS ) == SS_SIMMODE_NORMAL ) || ssRTWGenIsAccelerator ( hfoeutytij
-> _mdlRefSfcnS ) ) { { sdiSignalSourceInfoU srcInfo ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"closedLoop_tuned/r" ) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ;
sdiLabelU subPath = sdiGetLabelFromChars ( "" ) ; const char_T * leafUnits [
6 ] = { "deg" , "deg" , "deg" , "deg" , "deg" , "deg" } ;
sdiVirtualBusLeafElementInfoU leafElInfo [ 6 ] ; int_T childDimsArray0 [ 1 ]
= { 1 } ; int_T childDimsArray1 [ 1 ] = { 1 } ; int_T childDimsArray2 [ 1 ] =
{ 1 } ; int_T childDimsArray3 [ 1 ] = { 1 } ; int_T childDimsArray4 [ 1 ] = {
1 } ; int_T childDimsArray5 [ 1 ] = { 1 } ; { sdiAsyncRepoDataTypeHandle hDT
= sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 0
] . hDataType = hDT ; leafElInfo [ 0 ] . signalName = sdiGetLabelFromChars (
"jointsAngleReference.upperArmJointMotion" ) ; leafElInfo [ 0 ] . dims .
nDims = 1 ; leafElInfo [ 0 ] . dims . dimensions = childDimsArray0 ;
leafElInfo [ 0 ] . dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 0 ] .
complexity = REAL ; leafElInfo [ 0 ] . isLinearInterp = 1 ; leafElInfo [ 0 ]
. units = leafUnits [ 0 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 1 ]
. hDataType = hDT ; leafElInfo [ 1 ] . signalName = sdiGetLabelFromChars (
"jointsAngleReference.foreArmJointMotion" ) ; leafElInfo [ 1 ] . dims . nDims
= 1 ; leafElInfo [ 1 ] . dims . dimensions = childDimsArray1 ; leafElInfo [ 1
] . dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 1 ] . complexity = REAL ;
leafElInfo [ 1 ] . isLinearInterp = 1 ; leafElInfo [ 1 ] . units = leafUnits
[ 1 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 2 ]
. hDataType = hDT ; leafElInfo [ 2 ] . signalName = sdiGetLabelFromChars (
"jointsAngleReference.wristJointMotion" ) ; leafElInfo [ 2 ] . dims . nDims =
1 ; leafElInfo [ 2 ] . dims . dimensions = childDimsArray2 ; leafElInfo [ 2 ]
. dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 2 ] . complexity = REAL ;
leafElInfo [ 2 ] . isLinearInterp = 1 ; leafElInfo [ 2 ] . units = leafUnits
[ 2 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 3 ]
. hDataType = hDT ; leafElInfo [ 3 ] . signalName = sdiGetLabelFromChars (
"jointsAngleReference.gripperJointMotion" ) ; leafElInfo [ 3 ] . dims . nDims
= 1 ; leafElInfo [ 3 ] . dims . dimensions = childDimsArray3 ; leafElInfo [ 3
] . dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 3 ] . complexity = REAL ;
leafElInfo [ 3 ] . isLinearInterp = 1 ; leafElInfo [ 3 ] . units = leafUnits
[ 3 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 4 ]
. hDataType = hDT ; leafElInfo [ 4 ] . signalName = sdiGetLabelFromChars (
"jointsAngleReference.rightFingerJointMotion" ) ; leafElInfo [ 4 ] . dims .
nDims = 1 ; leafElInfo [ 4 ] . dims . dimensions = childDimsArray4 ;
leafElInfo [ 4 ] . dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 4 ] .
complexity = REAL ; leafElInfo [ 4 ] . isLinearInterp = 1 ; leafElInfo [ 4 ]
. units = leafUnits [ 4 ] ; } { sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; leafElInfo [ 5 ]
. hDataType = hDT ; leafElInfo [ 5 ] . signalName = sdiGetLabelFromChars (
"jointsAngleReference.leftFingerJointMotion" ) ; leafElInfo [ 5 ] . dims .
nDims = 1 ; leafElInfo [ 5 ] . dims . dimensions = childDimsArray5 ;
leafElInfo [ 5 ] . dimsMode = DIMENSIONS_MODE_FIXED ; leafElInfo [ 5 ] .
complexity = REAL ; leafElInfo [ 5 ] . isLinearInterp = 1 ; leafElInfo [ 5 ]
. units = leafUnits [ 5 ] ; } srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ;
sdiCreateAsyncQueuesForVirtualBusWithExportSettings ( & srcInfo , hfoeutytij
-> DataMapInfo . mmi . InstanceMap . fullPath ,
"6fef8f2b-1390-4c52-bc14-b184f5ef2503" , 6 , leafElInfo , & d1slopnfj2d .
d1shbopr2m . AQHandles [ 0 ] , 1 , 0 , "jointsAngleReference" ,
"jointsAngleReference" , "" ) ; if ( d1slopnfj2d . d1shbopr2m . AQHandles [ 0
] ) { sdiLabelU loggedName = sdiGetLabelFromChars ( "jointsAngleReference" )
; sdiLabelU origSigName = sdiGetLabelFromChars ( "jointsAngleReference" ) ;
sdiLabelU propName = sdiGetLabelFromChars ( "" ) ;
sdiSetSignalSampleTimeString ( d1slopnfj2d . d1shbopr2m . AQHandles [ 0 ] ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) ) ; sdiSetRunStartTime (
d1slopnfj2d . d1shbopr2m . AQHandles [ 0 ] , rtmGetTaskTime ( hfoeutytij , 0
) ) ; sdiAsyncRepoSetSignalExportSettings ( d1slopnfj2d . d1shbopr2m .
AQHandles [ 0 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( d1slopnfj2d .
d1shbopr2m . AQHandles [ 0 ] , loggedName , origSigName , propName ) ;
sdiSetSignalSampleTimeString ( d1slopnfj2d . d1shbopr2m . AQHandles [ 1 ] ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) ) ; sdiSetRunStartTime (
d1slopnfj2d . d1shbopr2m . AQHandles [ 1 ] , rtmGetTaskTime ( hfoeutytij , 0
) ) ; sdiAsyncRepoSetSignalExportSettings ( d1slopnfj2d . d1shbopr2m .
AQHandles [ 1 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( d1slopnfj2d .
d1shbopr2m . AQHandles [ 1 ] , loggedName , origSigName , propName ) ;
sdiSetSignalSampleTimeString ( d1slopnfj2d . d1shbopr2m . AQHandles [ 2 ] ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) ) ; sdiSetRunStartTime (
d1slopnfj2d . d1shbopr2m . AQHandles [ 2 ] , rtmGetTaskTime ( hfoeutytij , 0
) ) ; sdiAsyncRepoSetSignalExportSettings ( d1slopnfj2d . d1shbopr2m .
AQHandles [ 2 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( d1slopnfj2d .
d1shbopr2m . AQHandles [ 2 ] , loggedName , origSigName , propName ) ;
sdiSetSignalSampleTimeString ( d1slopnfj2d . d1shbopr2m . AQHandles [ 3 ] ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) ) ; sdiSetRunStartTime (
d1slopnfj2d . d1shbopr2m . AQHandles [ 3 ] , rtmGetTaskTime ( hfoeutytij , 0
) ) ; sdiAsyncRepoSetSignalExportSettings ( d1slopnfj2d . d1shbopr2m .
AQHandles [ 3 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( d1slopnfj2d .
d1shbopr2m . AQHandles [ 3 ] , loggedName , origSigName , propName ) ;
sdiSetSignalSampleTimeString ( d1slopnfj2d . d1shbopr2m . AQHandles [ 4 ] ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) ) ; sdiSetRunStartTime (
d1slopnfj2d . d1shbopr2m . AQHandles [ 4 ] , rtmGetTaskTime ( hfoeutytij , 0
) ) ; sdiAsyncRepoSetSignalExportSettings ( d1slopnfj2d . d1shbopr2m .
AQHandles [ 4 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( d1slopnfj2d .
d1shbopr2m . AQHandles [ 4 ] , loggedName , origSigName , propName ) ;
sdiSetSignalSampleTimeString ( d1slopnfj2d . d1shbopr2m . AQHandles [ 5 ] ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) ) ; sdiSetRunStartTime (
d1slopnfj2d . d1shbopr2m . AQHandles [ 5 ] , rtmGetTaskTime ( hfoeutytij , 0
) ) ; sdiAsyncRepoSetSignalExportSettings ( d1slopnfj2d . d1shbopr2m .
AQHandles [ 5 ] , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( d1slopnfj2d .
d1shbopr2m . AQHandles [ 5 ] , loggedName , origSigName , propName ) ;
sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel (
propName ) ; } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; sdiFreeName (
leafElInfo [ 0 ] . signalName ) ; sdiFreeName ( leafElInfo [ 1 ] . signalName
) ; sdiFreeName ( leafElInfo [ 2 ] . signalName ) ; sdiFreeName ( leafElInfo
[ 3 ] . signalName ) ; sdiFreeName ( leafElInfo [ 4 ] . signalName ) ;
sdiFreeName ( leafElInfo [ 5 ] . signalName ) ; } } } d1slopnfj2d .
d1shbopr2m . SlioLTF = ( NULL ) ; { void * treeVector = ( NULL ) ; void *
accessor = ( NULL ) ; const void * signalDescriptor = ( NULL ) ; void *
loggingInterval = ( NULL ) ; char * datasetName = "tmp_raccel_logsout" ; if (
slioCatalogue && rtwIsLoggingToFile ( slioCatalogue ) ) { int_T
forEachMdlRefDimsArray [ 32 ] ; int_T forEachMdlRefDimsArraySize = 0 ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { forEachMdlRefDimsArraySize =
slSigLogGetForEachDimsForRefModel ( hfoeutytij -> _mdlRefSfcnS ,
forEachMdlRefDimsArray ) ; } treeVector = rtwGetTreeVector ( ) ; {
rtwAddTopBusNode ( "jointsAngleReference" , 6 , treeVector ) ; { int_T
sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 0 , "upperArmJointMotion" ,
"linear" , 0 , ( unsigned int * ) sigDimsArray , 1 , "double" , "deg" ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) , treeVector ) ; } { int_T
sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 0 , "foreArmJointMotion" ,
"linear" , 0 , ( unsigned int * ) sigDimsArray , 1 , "double" , "deg" ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) , treeVector ) ; } { int_T
sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 0 , "wristJointMotion" ,
"linear" , 0 , ( unsigned int * ) sigDimsArray , 1 , "double" , "deg" ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) , treeVector ) ; } { int_T
sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 0 , "gripperJointMotion" ,
"linear" , 0 , ( unsigned int * ) sigDimsArray , 1 , "double" , "deg" ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) , treeVector ) ; } { int_T
sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 0 , "rightFingerJointMotion" ,
"linear" , 0 , ( unsigned int * ) sigDimsArray , 1 , "double" , "deg" ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) , treeVector ) ; } { int_T
sigDimsArray [ 1 ] = { 1 } ; rtwAddLeafNode ( 0 , "leftFingerJointMotion" ,
"linear" , 0 , ( unsigned int * ) sigDimsArray , 1 , "double" , "deg" ,
"Continuous" , 0.0 , rtmGetTFinal ( hfoeutytij ) , treeVector ) ; }
rtwPopNVBusNode ( treeVector ) ; } signalDescriptor = rtwGetSignalDescriptor
( treeVector , 6 , 1 , 0 , 1 , "jointsAngleReference" , "" , hfoeutytij ->
DataMapInfo . mmi . InstanceMap . fullPath , "closedLoop_tuned/r" , 1 , 0 ,
slioCatalogue , forEachMdlRefDimsArraySize ? ( const uint_T * )
forEachMdlRefDimsArray : ( NULL ) , forEachMdlRefDimsArraySize , ( NULL ) , 0
) ; if ( ! rt_slioCatalogue ( ) ) { sdiSlioIsLoggingSignal ( hfoeutytij ->
DataMapInfo . mmi . InstanceMap . fullPath , "closedLoop_tuned/r" , 1 ,
"jointsAngleReference" ) ; } if ( rtwLoggingOverride ( signalDescriptor ,
slioCatalogue ) ) { if ( hfoeutytij -> _mdlRefSfcnS -> mdlInfo -> rtwLogInfo
) { loggingInterval = rtliGetLoggingInterval ( hfoeutytij -> _mdlRefSfcnS ->
mdlInfo -> rtwLogInfo ) ; } else { loggingInterval = sdiGetLoggingIntervals (
hfoeutytij -> DataMapInfo . mmi . InstanceMap . fullPath ) ; datasetName = ""
; } accessor = rtwGetAccessor ( signalDescriptor , loggingInterval ) ;
rtwAddR2Client ( accessor , signalDescriptor , slioCatalogue , datasetName ,
1 ) ; d1slopnfj2d . d1shbopr2m . SlioLTF = accessor ; } } } } } void
ghycukq2fb ( void ) { nbzsdh3gog * const hfoeutytij = & ( elvjztouut . rtm )
; boolean_T tmp ; int_T tmp_p ; char * tmp_e ; tmp = true ; if ( tmp ) {
tmp_p = strcmp ( "ode14x" , ssGetSolverName ( hfoeutytij -> _mdlRefSfcnS ) )
; if ( tmp_p != 0 ) { tmp_e = solver_mismatch_message ( "ode14x" ,
ssGetSolverName ( hfoeutytij -> _mdlRefSfcnS ) ) ; ssSetErrorStatus (
hfoeutytij -> _mdlRefSfcnS , tmp_e ) ; } } d1slopnfj2d . lbcqusxymb =
bof3ifvdh3 . P_24 ; d1slopnfj2d . martnwreej = bof3ifvdh3 . P_25 ;
d1slopnfj2d . lbikguphlp = 1U ; d1slopnfj2d . hr3u05iedn = 0 ; d1slopnfj2d .
dlusidt5mu = bof3ifvdh3 . P_18 ; d1slopnfj2d . he40254wch = 1U ; d1slopnfj2d
. fuwgakmpod = 0 ; d1slopnfj2d . nx1wrktxq2 = bof3ifvdh3 . P_26 ; d1slopnfj2d
. lnboystaxq = bof3ifvdh3 . P_27 ; d1slopnfj2d . f01rjososq = 1U ;
d1slopnfj2d . cpjueliazg = 0 ; d1slopnfj2d . gohohcrj54 = bof3ifvdh3 . P_19 ;
d1slopnfj2d . jshht1u2q5 = 1U ; d1slopnfj2d . j1flcekhiz = 0 ; d1slopnfj2d .
hmmcsmj0xw = bof3ifvdh3 . P_28 ; d1slopnfj2d . eat1taflmt = bof3ifvdh3 . P_29
; d1slopnfj2d . m3ypcbfysw = 1U ; d1slopnfj2d . gjsyon5lu1 = 0 ; d1slopnfj2d
. im3cksdclx = bof3ifvdh3 . P_20 ; d1slopnfj2d . iltjdvd4vg = 1U ;
d1slopnfj2d . gtdlxdr5hj = 0 ; d1slopnfj2d . a5avu4h2ix = bof3ifvdh3 . P_30 ;
d1slopnfj2d . mdyqmzjrn0 = bof3ifvdh3 . P_31 ; d1slopnfj2d . d3raebrh43 = 1U
; d1slopnfj2d . ok503kfbwz = 0 ; d1slopnfj2d . jlvuwqbqtq = bof3ifvdh3 . P_21
; d1slopnfj2d . i43yu5fsyu = 1U ; d1slopnfj2d . nvuezdxtzi = 0 ; d1slopnfj2d
. lqn4y02ryj = bof3ifvdh3 . P_32 ; d1slopnfj2d . e1nkcmfeef = bof3ifvdh3 .
P_33 ; d1slopnfj2d . phmwjirefk = 1U ; d1slopnfj2d . kpe2zccxxi = 0 ;
d1slopnfj2d . itkowzvhmy = bof3ifvdh3 . P_22 ; d1slopnfj2d . axj00twaij = 1U
; d1slopnfj2d . imm0zy02qz = 0 ; d1slopnfj2d . jhkfvfo11l = bof3ifvdh3 . P_34
; d1slopnfj2d . ejngdjwvuh = bof3ifvdh3 . P_35 ; d1slopnfj2d . h4yyh4nnql =
1U ; d1slopnfj2d . ogphl1wuml = 0 ; d1slopnfj2d . msarqtw0ej = bof3ifvdh3 .
P_23 ; d1slopnfj2d . jbclgbkabv = 1U ; d1slopnfj2d . mzswpaogfa = 0 ; tmp =
true ; if ( tmp ) { tmp_p = strcmp ( "ode14x" , ssGetSolverName ( hfoeutytij
-> _mdlRefSfcnS ) ) ; if ( tmp_p != 0 ) { tmp_e = solver_mismatch_message (
"ode14x" , ssGetSolverName ( hfoeutytij -> _mdlRefSfcnS ) ) ;
ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , tmp_e ) ; } } } void
h4fxpncuan ( void ) { nbzsdh3gog * const hfoeutytij = & ( elvjztouut . rtm )
; boolean_T tmp ; int_T tmp_p ; char * tmp_e ; tmp = true ; if ( tmp ) {
tmp_p = strcmp ( "ode14x" , ssGetSolverName ( hfoeutytij -> _mdlRefSfcnS ) )
; if ( tmp_p != 0 ) { tmp_e = solver_mismatch_message ( "ode14x" ,
ssGetSolverName ( hfoeutytij -> _mdlRefSfcnS ) ) ; ssSetErrorStatus (
hfoeutytij -> _mdlRefSfcnS , tmp_e ) ; } } d1slopnfj2d . lbcqusxymb =
bof3ifvdh3 . P_24 ; d1slopnfj2d . martnwreej = bof3ifvdh3 . P_25 ;
d1slopnfj2d . lbikguphlp = 1U ; d1slopnfj2d . hr3u05iedn = 0 ; d1slopnfj2d .
dlusidt5mu = bof3ifvdh3 . P_18 ; d1slopnfj2d . he40254wch = 1U ; d1slopnfj2d
. fuwgakmpod = 0 ; d1slopnfj2d . nx1wrktxq2 = bof3ifvdh3 . P_26 ; d1slopnfj2d
. lnboystaxq = bof3ifvdh3 . P_27 ; d1slopnfj2d . f01rjososq = 1U ;
d1slopnfj2d . cpjueliazg = 0 ; d1slopnfj2d . gohohcrj54 = bof3ifvdh3 . P_19 ;
d1slopnfj2d . jshht1u2q5 = 1U ; d1slopnfj2d . j1flcekhiz = 0 ; d1slopnfj2d .
hmmcsmj0xw = bof3ifvdh3 . P_28 ; d1slopnfj2d . eat1taflmt = bof3ifvdh3 . P_29
; d1slopnfj2d . m3ypcbfysw = 1U ; d1slopnfj2d . gjsyon5lu1 = 0 ; d1slopnfj2d
. im3cksdclx = bof3ifvdh3 . P_20 ; d1slopnfj2d . iltjdvd4vg = 1U ;
d1slopnfj2d . gtdlxdr5hj = 0 ; d1slopnfj2d . a5avu4h2ix = bof3ifvdh3 . P_30 ;
d1slopnfj2d . mdyqmzjrn0 = bof3ifvdh3 . P_31 ; d1slopnfj2d . d3raebrh43 = 1U
; d1slopnfj2d . ok503kfbwz = 0 ; d1slopnfj2d . jlvuwqbqtq = bof3ifvdh3 . P_21
; d1slopnfj2d . i43yu5fsyu = 1U ; d1slopnfj2d . nvuezdxtzi = 0 ; d1slopnfj2d
. lqn4y02ryj = bof3ifvdh3 . P_32 ; d1slopnfj2d . e1nkcmfeef = bof3ifvdh3 .
P_33 ; d1slopnfj2d . phmwjirefk = 1U ; d1slopnfj2d . kpe2zccxxi = 0 ;
d1slopnfj2d . itkowzvhmy = bof3ifvdh3 . P_22 ; d1slopnfj2d . axj00twaij = 1U
; d1slopnfj2d . imm0zy02qz = 0 ; d1slopnfj2d . jhkfvfo11l = bof3ifvdh3 . P_34
; d1slopnfj2d . ejngdjwvuh = bof3ifvdh3 . P_35 ; d1slopnfj2d . h4yyh4nnql =
1U ; d1slopnfj2d . ogphl1wuml = 0 ; d1slopnfj2d . msarqtw0ej = bof3ifvdh3 .
P_23 ; d1slopnfj2d . jbclgbkabv = 1U ; d1slopnfj2d . mzswpaogfa = 0 ; tmp =
true ; if ( tmp ) { tmp_p = strcmp ( "ode14x" , ssGetSolverName ( hfoeutytij
-> _mdlRefSfcnS ) ) ; if ( tmp_p != 0 ) { tmp_e = solver_mismatch_message (
"ode14x" , ssGetSolverName ( hfoeutytij -> _mdlRefSfcnS ) ) ;
ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , tmp_e ) ; } } } void
ml0xqgpx3s ( real_T * localX_ ) { nbzsdh3gog * const hfoeutytij = & (
elvjztouut . rtm ) ; pu40142whda * localX = ( pu40142whda * ) localX_ ;
NeslSimulator * tmp ; boolean_T tmp_p ; NeuDiagnosticManager *
diagnosticManager ; NeModelParameters modelParameters ; real_T tmp_e ;
NeuDiagnosticTree * diagnosticTree ; int32_T tmp_i ; char * msg ;
NeslSimulationData * simulationData ; real_T time ; boolean_T tmp_m ; int32_T
tmp_g ; NeModelParameters modelParameters_p ; real_T time_p ;
NeModelParameters modelParameters_e ; real_T time_e ; NeModelParameters
modelParameters_i ; real_T time_i ; NeParameterBundle expl_temp ;
NeParameterBundle expl_temp_p ; real_T time_tmp ; tmp = nesl_lease_simulator
( "closedLoop_tuned/Plant/Robot/Solver Configuration_1" , 0 , 0 ) ;
d1slopnfj2d . bl4aw00lkd = ( void * ) tmp ; tmp_p = pointer_is_null (
d1slopnfj2d . bl4aw00lkd ) ; if ( tmp_p ) {
closedLoop_tuned_57a28c5_1_gateway ( ) ; tmp = nesl_lease_simulator (
"closedLoop_tuned/Plant/Robot/Solver Configuration_1" , 0 , 0 ) ; d1slopnfj2d
. bl4aw00lkd = ( void * ) tmp ; } simulationData =
nesl_create_simulation_data ( ) ; d1slopnfj2d . fwekq1g4wz = ( void * )
simulationData ; diagnosticManager = rtw_create_diagnostics ( ) ; d1slopnfj2d
. ntdusjysav = ( void * ) diagnosticManager ; modelParameters . mSolverType =
NE_SOLVER_TYPE_DAE ; modelParameters . mSolverTolerance = 0.001 ;
modelParameters . mVariableStepSolver = false ; modelParameters .
mFixedStepSize = 0.0025 ; modelParameters . mStartTime = 0.0 ;
modelParameters . mLoadInitialState = false ; modelParameters . mUseSimState
= false ; modelParameters . mLinTrimCompile = false ; modelParameters .
mLoggingMode = SSC_LOGGING_NONE ; modelParameters . mRTWModifiedTimeStamp =
4.76886236E+8 ; tmp_e = 0.001 ; modelParameters . mSolverTolerance = tmp_e ;
tmp_e = 0.0025 ; modelParameters . mFixedStepSize = tmp_e ; tmp_p = false ;
modelParameters . mVariableStepSolver = tmp_p ; diagnosticManager = (
NeuDiagnosticManager * ) d1slopnfj2d . ntdusjysav ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_i =
nesl_initialize_simulator ( ( NeslSimulator * ) d1slopnfj2d . bl4aw00lkd , &
modelParameters , diagnosticManager ) ; if ( tmp_i != 0 ) { tmp_p =
error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij -> _mdlRefSfcnS ) ) ;
if ( tmp_p ) { msg = rtw_diagnostics_msg ( diagnosticTree ) ;
ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; } } expl_temp .
mRealParameters . mN = 0 ; expl_temp . mRealParameters . mX = NULL ;
expl_temp . mLogicalParameters . mN = 0 ; expl_temp . mLogicalParameters . mX
= NULL ; expl_temp . mIntegerParameters . mN = 0 ; expl_temp .
mIntegerParameters . mX = NULL ; expl_temp . mIndexParameters . mN = 0 ;
expl_temp . mIndexParameters . mX = NULL ; nesl_simulator_set_rtps ( (
NeslSimulator * ) d1slopnfj2d . bl4aw00lkd , expl_temp ) ; simulationData = (
NeslSimulationData * ) d1slopnfj2d . fwekq1g4wz ; time_tmp = rtmGetTaskTime (
hfoeutytij , 0 ) ; time = time_tmp ; simulationData -> mData -> mTime . mN =
1 ; simulationData -> mData -> mTime . mX = & time ; simulationData -> mData
-> mContStates . mN = 24 ; simulationData -> mData -> mContStates . mX = &
localX -> lk3sdnwlk1 [ 0 ] ; simulationData -> mData -> mDiscStates . mN = 0
; simulationData -> mData -> mDiscStates . mX = & d1slopnfj2d . fu4515tfei ;
simulationData -> mData -> mModeVector . mN = 0 ; simulationData -> mData ->
mModeVector . mX = & d1slopnfj2d . dlhbeuzmaz ; tmp_p = false ;
simulationData -> mData -> mFoundZcEvents = tmp_p ; tmp_p =
rtmIsMajorTimeStep ( hfoeutytij ) ; simulationData -> mData ->
mIsMajorTimeStep = tmp_p ; tmp_m = _ssGetSolverAssertCheck ( hfoeutytij ->
_mdlRefSfcnS ) ; simulationData -> mData -> mIsSolverAssertCheck = tmp_m ;
simulationData -> mData -> mIsSolverCheckingCIC = false ; tmp_m =
ssIsSolverComputingJacobian ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData
-> mData -> mIsComputingJacobian = tmp_m ; tmp_i =
ssGetEvaluatingF0ForJacobian ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData
-> mData -> mIsEvaluatingF0 = ( tmp_i != 0 ) ; simulationData -> mData ->
mIsSolverRequestingReset = false ; diagnosticManager = ( NeuDiagnosticManager
* ) d1slopnfj2d . ntdusjysav ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_g =
ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d . bl4aw00lkd ,
NESL_SIM_INITIALIZEONCE , simulationData , diagnosticManager ) ; if ( tmp_g
!= 0 ) { tmp_m = error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij ->
_mdlRefSfcnS ) ) ; if ( tmp_m ) { msg = rtw_diagnostics_msg ( diagnosticTree
) ; ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; } } tmp =
nesl_lease_simulator ( "closedLoop_tuned/Plant/Robot/Solver Configuration_1"
, 1 , 0 ) ; d1slopnfj2d . m3y2tcffef = ( void * ) tmp ; tmp_m =
pointer_is_null ( d1slopnfj2d . m3y2tcffef ) ; if ( tmp_m ) {
closedLoop_tuned_57a28c5_1_gateway ( ) ; tmp = nesl_lease_simulator (
"closedLoop_tuned/Plant/Robot/Solver Configuration_1" , 1 , 0 ) ; d1slopnfj2d
. m3y2tcffef = ( void * ) tmp ; } simulationData =
nesl_create_simulation_data ( ) ; d1slopnfj2d . bxx3aunqbh = ( void * )
simulationData ; diagnosticManager = rtw_create_diagnostics ( ) ; d1slopnfj2d
. nbnbmwp5ah = ( void * ) diagnosticManager ; modelParameters_p . mSolverType
= NE_SOLVER_TYPE_DAE ; modelParameters_p . mSolverTolerance = 0.001 ;
modelParameters_p . mVariableStepSolver = false ; modelParameters_p .
mFixedStepSize = 0.0025 ; modelParameters_p . mStartTime = 0.0 ;
modelParameters_p . mLoadInitialState = false ; modelParameters_p .
mUseSimState = false ; modelParameters_p . mLinTrimCompile = false ;
modelParameters_p . mLoggingMode = SSC_LOGGING_NONE ; modelParameters_p .
mRTWModifiedTimeStamp = 4.76886236E+8 ; tmp_e = 0.001 ; modelParameters_p .
mSolverTolerance = tmp_e ; tmp_e = 0.0025 ; modelParameters_p .
mFixedStepSize = tmp_e ; tmp_m = false ; modelParameters_p .
mVariableStepSolver = tmp_m ; diagnosticManager = ( NeuDiagnosticManager * )
d1slopnfj2d . nbnbmwp5ah ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_g =
nesl_initialize_simulator ( ( NeslSimulator * ) d1slopnfj2d . m3y2tcffef , &
modelParameters_p , diagnosticManager ) ; if ( tmp_g != 0 ) { tmp_m =
error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij -> _mdlRefSfcnS ) ) ;
if ( tmp_m ) { msg = rtw_diagnostics_msg ( diagnosticTree ) ;
ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; } } simulationData =
( NeslSimulationData * ) d1slopnfj2d . bxx3aunqbh ; time_p = time_tmp ;
simulationData -> mData -> mTime . mN = 1 ; simulationData -> mData -> mTime
. mX = & time_p ; simulationData -> mData -> mContStates . mN = 0 ;
simulationData -> mData -> mContStates . mX = NULL ; simulationData -> mData
-> mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX = &
d1slopnfj2d . mcnyytj12g ; simulationData -> mData -> mModeVector . mN = 0 ;
simulationData -> mData -> mModeVector . mX = & d1slopnfj2d . emiegndpgn ;
tmp_m = false ; simulationData -> mData -> mFoundZcEvents = tmp_m ;
simulationData -> mData -> mIsMajorTimeStep = tmp_p ; tmp_m =
_ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp_m ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; simulationData -> mData ->
mIsComputingJacobian = false ; simulationData -> mData -> mIsEvaluatingF0 =
false ; simulationData -> mData -> mIsSolverRequestingReset = false ;
diagnosticManager = ( NeuDiagnosticManager * ) d1slopnfj2d . nbnbmwp5ah ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; tmp_g = ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d .
m3y2tcffef , NESL_SIM_INITIALIZEONCE , simulationData , diagnosticManager ) ;
if ( tmp_g != 0 ) { tmp_m = error_buffer_is_empty ( ssGetErrorStatus (
hfoeutytij -> _mdlRefSfcnS ) ) ; if ( tmp_m ) { msg = rtw_diagnostics_msg (
diagnosticTree ) ; ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; }
} lvuzhhuckmt . kbgonrof1r [ 0 ] = 0.0025 ; lvuzhhuckmt . kbgonrof1r [ 1 ] =
0.0 ; lvuzhhuckmt . cpnsm5fki5 [ 0 ] = 0.0025 ; lvuzhhuckmt . cpnsm5fki5 [ 1
] = 0.0 ; lvuzhhuckmt . pf4arwrhyx [ 0 ] = 0.0025 ; lvuzhhuckmt . pf4arwrhyx
[ 1 ] = 0.0 ; lvuzhhuckmt . gs5wyjrzvf [ 0 ] = 0.0025 ; lvuzhhuckmt .
gs5wyjrzvf [ 1 ] = 0.0 ; lvuzhhuckmt . hpivumlrcc [ 0 ] = 0.0025 ;
lvuzhhuckmt . hpivumlrcc [ 1 ] = 0.0 ; lvuzhhuckmt . ezyrayiasu [ 0 ] =
0.0025 ; lvuzhhuckmt . ezyrayiasu [ 1 ] = 0.0 ; lvuzhhuckmt . iamzy5525o [ 0
] = 0.0025 ; lvuzhhuckmt . iamzy5525o [ 1 ] = 0.0 ; lvuzhhuckmt . gkdm5dhsql
[ 0 ] = 0.0025 ; lvuzhhuckmt . gkdm5dhsql [ 1 ] = 0.0 ; lvuzhhuckmt .
gh0ba0iypp [ 0 ] = 0.0025 ; lvuzhhuckmt . gh0ba0iypp [ 1 ] = 0.0 ;
lvuzhhuckmt . it2ouoy2lw [ 0 ] = 0.0025 ; lvuzhhuckmt . it2ouoy2lw [ 1 ] =
0.0 ; lvuzhhuckmt . ljdpmxc04v [ 0 ] = 0.0025 ; lvuzhhuckmt . ljdpmxc04v [ 1
] = 0.0 ; lvuzhhuckmt . gra4msiia2 [ 0 ] = 0.0025 ; lvuzhhuckmt . gra4msiia2
[ 1 ] = 0.0 ; tmp = nesl_lease_simulator (
"closedLoop_tuned/Plant/Robot/Solver Configuration_2" , 0 , 0 ) ; d1slopnfj2d
. gqpntsbwxh = ( void * ) tmp ; tmp_m = pointer_is_null ( d1slopnfj2d .
gqpntsbwxh ) ; if ( tmp_m ) { closedLoop_tuned_57a28c5_2_gateway ( ) ; tmp =
nesl_lease_simulator ( "closedLoop_tuned/Plant/Robot/Solver Configuration_2"
, 0 , 0 ) ; d1slopnfj2d . gqpntsbwxh = ( void * ) tmp ; } simulationData =
nesl_create_simulation_data ( ) ; d1slopnfj2d . dojae3fabx = ( void * )
simulationData ; diagnosticManager = rtw_create_diagnostics ( ) ; d1slopnfj2d
. eqhqru4bkb = ( void * ) diagnosticManager ; modelParameters_e . mSolverType
= NE_SOLVER_TYPE_DAE ; modelParameters_e . mSolverTolerance = 0.001 ;
modelParameters_e . mVariableStepSolver = false ; modelParameters_e .
mFixedStepSize = 0.0025 ; modelParameters_e . mStartTime = 0.0 ;
modelParameters_e . mLoadInitialState = false ; modelParameters_e .
mUseSimState = false ; modelParameters_e . mLinTrimCompile = false ;
modelParameters_e . mLoggingMode = SSC_LOGGING_NONE ; modelParameters_e .
mRTWModifiedTimeStamp = 4.76886236E+8 ; tmp_e = 0.001 ; modelParameters_e .
mSolverTolerance = tmp_e ; tmp_e = 0.0025 ; modelParameters_e .
mFixedStepSize = tmp_e ; tmp_m = false ; modelParameters_e .
mVariableStepSolver = tmp_m ; diagnosticManager = ( NeuDiagnosticManager * )
d1slopnfj2d . eqhqru4bkb ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_g =
nesl_initialize_simulator ( ( NeslSimulator * ) d1slopnfj2d . gqpntsbwxh , &
modelParameters_e , diagnosticManager ) ; if ( tmp_g != 0 ) { tmp_m =
error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij -> _mdlRefSfcnS ) ) ;
if ( tmp_m ) { msg = rtw_diagnostics_msg ( diagnosticTree ) ;
ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; } } expl_temp_p .
mRealParameters . mN = 0 ; expl_temp_p . mRealParameters . mX = NULL ;
expl_temp_p . mLogicalParameters . mN = 0 ; expl_temp_p . mLogicalParameters
. mX = NULL ; expl_temp_p . mIntegerParameters . mN = 0 ; expl_temp_p .
mIntegerParameters . mX = NULL ; expl_temp_p . mIndexParameters . mN = 0 ;
expl_temp_p . mIndexParameters . mX = NULL ; nesl_simulator_set_rtps ( (
NeslSimulator * ) d1slopnfj2d . gqpntsbwxh , expl_temp_p ) ; simulationData =
( NeslSimulationData * ) d1slopnfj2d . dojae3fabx ; time_e = time_tmp ;
simulationData -> mData -> mTime . mN = 1 ; simulationData -> mData -> mTime
. mX = & time_e ; simulationData -> mData -> mContStates . mN = 30 ;
simulationData -> mData -> mContStates . mX = & localX -> kgvozz1pdk [ 0 ] ;
simulationData -> mData -> mDiscStates . mN = 0 ; simulationData -> mData ->
mDiscStates . mX = & d1slopnfj2d . g5juej3g4q ; simulationData -> mData ->
mModeVector . mN = 6 ; simulationData -> mData -> mModeVector . mX = &
d1slopnfj2d . beljpehthd [ 0 ] ; tmp_m = false ; simulationData -> mData ->
mFoundZcEvents = tmp_m ; simulationData -> mData -> mIsMajorTimeStep = tmp_p
; tmp_m = _ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsSolverAssertCheck = tmp_m ; simulationData ->
mData -> mIsSolverCheckingCIC = false ; tmp_m = ssIsSolverComputingJacobian (
hfoeutytij -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsComputingJacobian = tmp_m ; simulationData -> mData -> mIsEvaluatingF0 = (
tmp_i != 0 ) ; simulationData -> mData -> mIsSolverRequestingReset = false ;
diagnosticManager = ( NeuDiagnosticManager * ) d1slopnfj2d . eqhqru4bkb ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; tmp_i = ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d .
gqpntsbwxh , NESL_SIM_INITIALIZEONCE , simulationData , diagnosticManager ) ;
if ( tmp_i != 0 ) { tmp_m = error_buffer_is_empty ( ssGetErrorStatus (
hfoeutytij -> _mdlRefSfcnS ) ) ; if ( tmp_m ) { msg = rtw_diagnostics_msg (
diagnosticTree ) ; ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; }
} tmp = nesl_lease_simulator (
"closedLoop_tuned/Plant/Robot/Solver Configuration_2" , 1 , 0 ) ; d1slopnfj2d
. nbkxol04ay = ( void * ) tmp ; tmp_m = pointer_is_null ( d1slopnfj2d .
nbkxol04ay ) ; if ( tmp_m ) { closedLoop_tuned_57a28c5_2_gateway ( ) ; tmp =
nesl_lease_simulator ( "closedLoop_tuned/Plant/Robot/Solver Configuration_2"
, 1 , 0 ) ; d1slopnfj2d . nbkxol04ay = ( void * ) tmp ; } simulationData =
nesl_create_simulation_data ( ) ; d1slopnfj2d . iacissyba2 = ( void * )
simulationData ; diagnosticManager = rtw_create_diagnostics ( ) ; d1slopnfj2d
. jcs4deobwu = ( void * ) diagnosticManager ; modelParameters_i . mSolverType
= NE_SOLVER_TYPE_DAE ; modelParameters_i . mSolverTolerance = 0.001 ;
modelParameters_i . mVariableStepSolver = false ; modelParameters_i .
mFixedStepSize = 0.0025 ; modelParameters_i . mStartTime = 0.0 ;
modelParameters_i . mLoadInitialState = false ; modelParameters_i .
mUseSimState = false ; modelParameters_i . mLinTrimCompile = false ;
modelParameters_i . mLoggingMode = SSC_LOGGING_NONE ; modelParameters_i .
mRTWModifiedTimeStamp = 4.76886236E+8 ; tmp_e = 0.001 ; modelParameters_i .
mSolverTolerance = tmp_e ; tmp_e = 0.0025 ; modelParameters_i .
mFixedStepSize = tmp_e ; tmp_m = false ; modelParameters_i .
mVariableStepSolver = tmp_m ; diagnosticManager = ( NeuDiagnosticManager * )
d1slopnfj2d . jcs4deobwu ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_i =
nesl_initialize_simulator ( ( NeslSimulator * ) d1slopnfj2d . nbkxol04ay , &
modelParameters_i , diagnosticManager ) ; if ( tmp_i != 0 ) { tmp_m =
error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij -> _mdlRefSfcnS ) ) ;
if ( tmp_m ) { msg = rtw_diagnostics_msg ( diagnosticTree ) ;
ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; } } simulationData =
( NeslSimulationData * ) d1slopnfj2d . iacissyba2 ; time_i = time_tmp ;
simulationData -> mData -> mTime . mN = 1 ; simulationData -> mData -> mTime
. mX = & time_i ; simulationData -> mData -> mContStates . mN = 0 ;
simulationData -> mData -> mContStates . mX = NULL ; simulationData -> mData
-> mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX = &
d1slopnfj2d . owpb4gqr4b ; simulationData -> mData -> mModeVector . mN = 0 ;
simulationData -> mData -> mModeVector . mX = & d1slopnfj2d . jyeac3e5ko ;
tmp_m = false ; simulationData -> mData -> mFoundZcEvents = tmp_m ;
simulationData -> mData -> mIsMajorTimeStep = tmp_p ; tmp_p =
_ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp_p ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; simulationData -> mData ->
mIsComputingJacobian = false ; simulationData -> mData -> mIsEvaluatingF0 =
false ; simulationData -> mData -> mIsSolverRequestingReset = false ;
diagnosticManager = ( NeuDiagnosticManager * ) d1slopnfj2d . jcs4deobwu ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; tmp_i = ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d .
nbkxol04ay , NESL_SIM_INITIALIZEONCE , simulationData , diagnosticManager ) ;
if ( tmp_i != 0 ) { tmp_p = error_buffer_is_empty ( ssGetErrorStatus (
hfoeutytij -> _mdlRefSfcnS ) ) ; if ( tmp_p ) { msg = rtw_diagnostics_msg (
diagnosticTree ) ; ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; }
} } void closedLoop_tuned ( const real_T * eftkqi2uqx , const real_T *
chelevjaju , const real_T * ed1wyjpuuh , const real_T * jrgsipw0bp , const
real_T * m5vh3hyppt , const real_T * kx0yhuedat , real_T * bwngodvth1 ,
real_T * gbdmtjn4mq , real_T * g0sjdawhsf , real_T * mx2sgp3e1r , real_T *
c2lqxtprfq , real_T * boerjqp35i , real_T * localX_ ) { nbzsdh3gog * const
hfoeutytij = & ( elvjztouut . rtm ) ; pu40142whda * localX = ( pu40142whda *
) localX_ ; real_T nkw5nqrk1g ; real_T cpu1qnpswa ; real_T pozjdfxxw2 ;
real_T ccxta0d4z5 ; real_T ivji5cetyn ; real_T btk4cl4ktn ; real_T px1g5x0wqi
; real_T f0vwa3gbu5 ; real_T dfrjctleic ; real_T hsr0jzmjiq ; real_T
gjtzossbcx ; real_T pgosqvvz3o ; real_T ldk1rewpxt ; real_T c1am01xkog ;
real_T baxqb1ibzr ; real_T ikntplev3w ; real_T erdf0qjfzm ; real_T ajkhqw3onn
; NeslSimulationData * simulationData ; real_T time ; boolean_T tmp ; real_T
tmp_p [ 24 ] ; int_T tmp_e [ 7 ] ; NeuDiagnosticManager * diagnosticManager ;
NeuDiagnosticTree * diagnosticTree ; int32_T tmp_i ; char * msg ; real_T
time_p ; real_T tmp_m [ 48 ] ; int_T tmp_g [ 8 ] ; boolean_T first_output ;
real_T time_e ; real_T tmp_j [ 48 ] ; int_T tmp_f [ 13 ] ; real_T time_i ;
real_T tmp_c [ 84 ] ; int_T tmp_k [ 14 ] ; real_T iyxo5o23nr ; real_T
ksow10vbzc ; real_T mj2ek4c0je ; real_T d0iyjnsu3c ; real_T h3irildbji ;
real_T aetrps2hov ; real_T jcbffcprqe ; real_T ldhpz1tpdj ; real_T oyfzaykx2p
; real_T ahlj0qdplx ; real_T jop3tzpvw1 ; real_T nnrad0ft3n ; real_T
dzxcrxorbj ; real_T kjcf0kucej ; real_T pqd2krcdt2 ; real_T g31qikai10 ;
real_T khlonjjenf ; real_T jom0ikpeux ; real_T pxpmtpcpv3 ; real_T ksg2lm4q2x
; real_T fnyljtrcde ; real_T lxcvuijen3 ; real_T egn5e1juvp ; real_T
pacxxwl3ko ; real_T ggyakluv1h ; real_T cl55cdpr1d_p ; real_T bdblm00a4g_p ;
real_T odphm1jgsz_p ; real_T ctyfnsjs3t_p ; real_T keazeynoyg_p ; real_T
ekica1lnpt_p ; real_T oukwyzj1ze_p ; int32_T tmp_b ; simulationData = (
NeslSimulationData * ) d1slopnfj2d . fwekq1g4wz ; ggyakluv1h = rtmGetTaskTime
( hfoeutytij , 0 ) ; time = ggyakluv1h ; simulationData -> mData -> mTime .
mN = 1 ; simulationData -> mData -> mTime . mX = & time ; simulationData ->
mData -> mContStates . mN = 24 ; simulationData -> mData -> mContStates . mX
= & localX -> lk3sdnwlk1 [ 0 ] ; simulationData -> mData -> mDiscStates . mN
= 0 ; simulationData -> mData -> mDiscStates . mX = & d1slopnfj2d .
fu4515tfei ; simulationData -> mData -> mModeVector . mN = 0 ; simulationData
-> mData -> mModeVector . mX = & d1slopnfj2d . dlhbeuzmaz ; tmp = false ;
simulationData -> mData -> mFoundZcEvents = tmp ; tmp = rtmIsMajorTimeStep (
hfoeutytij ) ; simulationData -> mData -> mIsMajorTimeStep = tmp ;
first_output = _ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsSolverAssertCheck = first_output ;
simulationData -> mData -> mIsSolverCheckingCIC = false ; first_output =
ssIsSolverComputingJacobian ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData
-> mData -> mIsComputingJacobian = first_output ; tmp_b =
ssGetEvaluatingF0ForJacobian ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData
-> mData -> mIsEvaluatingF0 = ( tmp_b != 0 ) ; simulationData -> mData ->
mIsSolverRequestingReset = false ; tmp_e [ 0 ] = 0 ; tmp_p [ 0 ] =
lvuzhhuckmt . bs1e5cpoll [ 0 ] ; tmp_p [ 1 ] = lvuzhhuckmt . bs1e5cpoll [ 1 ]
; tmp_p [ 2 ] = lvuzhhuckmt . bs1e5cpoll [ 2 ] ; tmp_p [ 3 ] = lvuzhhuckmt .
bs1e5cpoll [ 3 ] ; tmp_e [ 1 ] = 4 ; tmp_p [ 4 ] = lvuzhhuckmt . k30tufukck [
0 ] ; tmp_p [ 5 ] = lvuzhhuckmt . k30tufukck [ 1 ] ; tmp_p [ 6 ] =
lvuzhhuckmt . k30tufukck [ 2 ] ; tmp_p [ 7 ] = lvuzhhuckmt . k30tufukck [ 3 ]
; tmp_e [ 2 ] = 8 ; tmp_p [ 8 ] = lvuzhhuckmt . a0iis2ayez [ 0 ] ; tmp_p [ 9
] = lvuzhhuckmt . a0iis2ayez [ 1 ] ; tmp_p [ 10 ] = lvuzhhuckmt . a0iis2ayez
[ 2 ] ; tmp_p [ 11 ] = lvuzhhuckmt . a0iis2ayez [ 3 ] ; tmp_e [ 3 ] = 12 ;
tmp_p [ 12 ] = lvuzhhuckmt . kzrjgwxloa [ 0 ] ; tmp_p [ 13 ] = lvuzhhuckmt .
kzrjgwxloa [ 1 ] ; tmp_p [ 14 ] = lvuzhhuckmt . kzrjgwxloa [ 2 ] ; tmp_p [ 15
] = lvuzhhuckmt . kzrjgwxloa [ 3 ] ; tmp_e [ 4 ] = 16 ; tmp_p [ 16 ] =
lvuzhhuckmt . h1mwn5bwbv [ 0 ] ; tmp_p [ 17 ] = lvuzhhuckmt . h1mwn5bwbv [ 1
] ; tmp_p [ 18 ] = lvuzhhuckmt . h1mwn5bwbv [ 2 ] ; tmp_p [ 19 ] =
lvuzhhuckmt . h1mwn5bwbv [ 3 ] ; tmp_e [ 5 ] = 20 ; tmp_p [ 20 ] =
lvuzhhuckmt . dw2p0ylolg [ 0 ] ; tmp_p [ 21 ] = lvuzhhuckmt . dw2p0ylolg [ 1
] ; tmp_p [ 22 ] = lvuzhhuckmt . dw2p0ylolg [ 2 ] ; tmp_p [ 23 ] =
lvuzhhuckmt . dw2p0ylolg [ 3 ] ; tmp_e [ 6 ] = 24 ; simulationData -> mData
-> mInputValues . mN = 24 ; simulationData -> mData -> mInputValues . mX = &
tmp_p [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 7 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_e [ 0 ] ;
simulationData -> mData -> mOutputs . mN = 24 ; simulationData -> mData ->
mOutputs . mX = & lvuzhhuckmt . jxrjelubpn [ 0 ] ; simulationData -> mData ->
mSampleHits . mN = 0 ; simulationData -> mData -> mSampleHits . mX = NULL ;
simulationData -> mData -> mIsFundamentalSampleHit = false ; simulationData
-> mData -> mTolerances . mN = 0 ; simulationData -> mData -> mTolerances .
mX = NULL ; simulationData -> mData -> mCstateHasChanged = false ;
diagnosticManager = ( NeuDiagnosticManager * ) d1slopnfj2d . ntdusjysav ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; tmp_i = ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d .
bl4aw00lkd , NESL_SIM_OUTPUTS , simulationData , diagnosticManager ) ; if (
tmp_i != 0 ) { first_output = error_buffer_is_empty ( ssGetErrorStatus (
hfoeutytij -> _mdlRefSfcnS ) ) ; if ( first_output ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( hfoeutytij ->
_mdlRefSfcnS , msg ) ; } } if ( rtmIsMajorTimeStep ( hfoeutytij ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( hfoeutytij -> _mdlRefSfcnS ) ; }
simulationData = ( NeslSimulationData * ) d1slopnfj2d . bxx3aunqbh ; time_p =
ggyakluv1h ; simulationData -> mData -> mTime . mN = 1 ; simulationData ->
mData -> mTime . mX = & time_p ; simulationData -> mData -> mContStates . mN
= 0 ; simulationData -> mData -> mContStates . mX = NULL ; simulationData ->
mData -> mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX =
& d1slopnfj2d . mcnyytj12g ; simulationData -> mData -> mModeVector . mN = 0
; simulationData -> mData -> mModeVector . mX = & d1slopnfj2d . emiegndpgn ;
first_output = false ; simulationData -> mData -> mFoundZcEvents =
first_output ; simulationData -> mData -> mIsMajorTimeStep = tmp ;
first_output = _ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsSolverAssertCheck = first_output ;
simulationData -> mData -> mIsSolverCheckingCIC = false ; simulationData ->
mData -> mIsComputingJacobian = false ; simulationData -> mData ->
mIsEvaluatingF0 = false ; simulationData -> mData -> mIsSolverRequestingReset
= false ; tmp_g [ 0 ] = 0 ; tmp_m [ 0 ] = lvuzhhuckmt . bs1e5cpoll [ 0 ] ;
tmp_m [ 1 ] = lvuzhhuckmt . bs1e5cpoll [ 1 ] ; tmp_m [ 2 ] = lvuzhhuckmt .
bs1e5cpoll [ 2 ] ; tmp_m [ 3 ] = lvuzhhuckmt . bs1e5cpoll [ 3 ] ; tmp_g [ 1 ]
= 4 ; tmp_m [ 4 ] = lvuzhhuckmt . k30tufukck [ 0 ] ; tmp_m [ 5 ] =
lvuzhhuckmt . k30tufukck [ 1 ] ; tmp_m [ 6 ] = lvuzhhuckmt . k30tufukck [ 2 ]
; tmp_m [ 7 ] = lvuzhhuckmt . k30tufukck [ 3 ] ; tmp_g [ 2 ] = 8 ; tmp_m [ 8
] = lvuzhhuckmt . a0iis2ayez [ 0 ] ; tmp_m [ 9 ] = lvuzhhuckmt . a0iis2ayez [
1 ] ; tmp_m [ 10 ] = lvuzhhuckmt . a0iis2ayez [ 2 ] ; tmp_m [ 11 ] =
lvuzhhuckmt . a0iis2ayez [ 3 ] ; tmp_g [ 3 ] = 12 ; tmp_m [ 12 ] =
lvuzhhuckmt . kzrjgwxloa [ 0 ] ; tmp_m [ 13 ] = lvuzhhuckmt . kzrjgwxloa [ 1
] ; tmp_m [ 14 ] = lvuzhhuckmt . kzrjgwxloa [ 2 ] ; tmp_m [ 15 ] =
lvuzhhuckmt . kzrjgwxloa [ 3 ] ; tmp_g [ 4 ] = 16 ; tmp_m [ 16 ] =
lvuzhhuckmt . h1mwn5bwbv [ 0 ] ; tmp_m [ 17 ] = lvuzhhuckmt . h1mwn5bwbv [ 1
] ; tmp_m [ 18 ] = lvuzhhuckmt . h1mwn5bwbv [ 2 ] ; tmp_m [ 19 ] =
lvuzhhuckmt . h1mwn5bwbv [ 3 ] ; tmp_g [ 5 ] = 20 ; tmp_m [ 20 ] =
lvuzhhuckmt . dw2p0ylolg [ 0 ] ; tmp_m [ 21 ] = lvuzhhuckmt . dw2p0ylolg [ 1
] ; tmp_m [ 22 ] = lvuzhhuckmt . dw2p0ylolg [ 2 ] ; tmp_m [ 23 ] =
lvuzhhuckmt . dw2p0ylolg [ 3 ] ; tmp_g [ 6 ] = 24 ; memcpy ( & tmp_m [ 24 ] ,
& lvuzhhuckmt . jxrjelubpn [ 0 ] , 24U * sizeof ( real_T ) ) ; tmp_g [ 7 ] =
48 ; simulationData -> mData -> mInputValues . mN = 48 ; simulationData ->
mData -> mInputValues . mX = & tmp_m [ 0 ] ; simulationData -> mData ->
mInputOffsets . mN = 8 ; simulationData -> mData -> mInputOffsets . mX = &
tmp_g [ 0 ] ; simulationData -> mData -> mOutputs . mN = 12 ; simulationData
-> mData -> mOutputs . mX = & lvuzhhuckmt . k0xye32kow [ 0 ] ; simulationData
-> mData -> mSampleHits . mN = 0 ; simulationData -> mData -> mSampleHits .
mX = NULL ; simulationData -> mData -> mIsFundamentalSampleHit = false ;
simulationData -> mData -> mTolerances . mN = 0 ; simulationData -> mData ->
mTolerances . mX = NULL ; simulationData -> mData -> mCstateHasChanged =
false ; diagnosticManager = ( NeuDiagnosticManager * ) d1slopnfj2d .
nbnbmwp5ah ; diagnosticTree = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; tmp_i = ne_simulator_method ( ( NeslSimulator * )
d1slopnfj2d . m3y2tcffef , NESL_SIM_OUTPUTS , simulationData ,
diagnosticManager ) ; if ( tmp_i != 0 ) { first_output =
error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij -> _mdlRefSfcnS ) ) ;
if ( first_output ) { msg = rtw_diagnostics_msg ( diagnosticTree ) ;
ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; } } if (
rtmIsMajorTimeStep ( hfoeutytij ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( hfoeutytij -> _mdlRefSfcnS ) ; }
first_output = false ; if ( d1slopnfj2d . kt4uicyvx0 == 0.0 ) { d1slopnfj2d .
kt4uicyvx0 = 1.0 ; first_output = true ; } if ( first_output ) { localX ->
nanyzdwn3h = lvuzhhuckmt . k0xye32kow [ 1 ] ; } lvuzhhuckmt . jv20suu5kg [ 0
] = localX -> nanyzdwn3h ; lvuzhhuckmt . jv20suu5kg [ 1 ] = ( lvuzhhuckmt .
k0xye32kow [ 1 ] - localX -> nanyzdwn3h ) * 1000.0 ; lvuzhhuckmt . jv20suu5kg
[ 2 ] = 0.0 ; lvuzhhuckmt . jv20suu5kg [ 3 ] = 0.0 ; first_output = false ;
if ( d1slopnfj2d . kyfvye0kyh == 0.0 ) { d1slopnfj2d . kyfvye0kyh = 1.0 ;
first_output = true ; } if ( first_output ) { localX -> fvut32tit4 =
lvuzhhuckmt . k0xye32kow [ 3 ] ; } lvuzhhuckmt . mj4gjt33f3 [ 0 ] = localX ->
fvut32tit4 ; lvuzhhuckmt . mj4gjt33f3 [ 1 ] = ( lvuzhhuckmt . k0xye32kow [ 3
] - localX -> fvut32tit4 ) * 1000.0 ; lvuzhhuckmt . mj4gjt33f3 [ 2 ] = 0.0 ;
lvuzhhuckmt . mj4gjt33f3 [ 3 ] = 0.0 ; first_output = false ; if (
d1slopnfj2d . mtrpzv3ygn == 0.0 ) { d1slopnfj2d . mtrpzv3ygn = 1.0 ;
first_output = true ; } if ( first_output ) { localX -> nu35g5ezne =
lvuzhhuckmt . k0xye32kow [ 5 ] ; } lvuzhhuckmt . hwk0u4eoqn [ 0 ] = localX ->
nu35g5ezne ; lvuzhhuckmt . hwk0u4eoqn [ 1 ] = ( lvuzhhuckmt . k0xye32kow [ 5
] - localX -> nu35g5ezne ) * 1000.0 ; lvuzhhuckmt . hwk0u4eoqn [ 2 ] = 0.0 ;
lvuzhhuckmt . hwk0u4eoqn [ 3 ] = 0.0 ; first_output = false ; if (
d1slopnfj2d . czvkwuyek1 == 0.0 ) { d1slopnfj2d . czvkwuyek1 = 1.0 ;
first_output = true ; } if ( first_output ) { localX -> n3zqzpztbu =
lvuzhhuckmt . k0xye32kow [ 7 ] ; } lvuzhhuckmt . mrjmcb1eaq [ 0 ] = localX ->
n3zqzpztbu ; lvuzhhuckmt . mrjmcb1eaq [ 1 ] = ( lvuzhhuckmt . k0xye32kow [ 7
] - localX -> n3zqzpztbu ) * 1000.0 ; lvuzhhuckmt . mrjmcb1eaq [ 2 ] = 0.0 ;
lvuzhhuckmt . mrjmcb1eaq [ 3 ] = 0.0 ; first_output = false ; if (
d1slopnfj2d . muit3a3q1x == 0.0 ) { d1slopnfj2d . muit3a3q1x = 1.0 ;
first_output = true ; } if ( first_output ) { localX -> gm135svjp2 =
lvuzhhuckmt . k0xye32kow [ 9 ] ; } lvuzhhuckmt . lhbimp5kmr [ 0 ] = localX ->
gm135svjp2 ; lvuzhhuckmt . lhbimp5kmr [ 1 ] = ( lvuzhhuckmt . k0xye32kow [ 9
] - localX -> gm135svjp2 ) * 1000.0 ; lvuzhhuckmt . lhbimp5kmr [ 2 ] = 0.0 ;
lvuzhhuckmt . lhbimp5kmr [ 3 ] = 0.0 ; first_output = false ; if (
d1slopnfj2d . luoxgto34c == 0.0 ) { d1slopnfj2d . luoxgto34c = 1.0 ;
first_output = true ; } if ( first_output ) { localX -> nm2azj1trc =
lvuzhhuckmt . k0xye32kow [ 11 ] ; } lvuzhhuckmt . idnqelgv01 [ 0 ] = localX
-> nm2azj1trc ; lvuzhhuckmt . idnqelgv01 [ 1 ] = ( lvuzhhuckmt . k0xye32kow [
11 ] - localX -> nm2azj1trc ) * 1000.0 ; lvuzhhuckmt . idnqelgv01 [ 2 ] = 0.0
; lvuzhhuckmt . idnqelgv01 [ 3 ] = 0.0 ; if ( rtmIsMajorTimeStep ( hfoeutytij
) ) { iyxo5o23nr = d1slopnfj2d . lbcqusxymb ; } cl55cdpr1d_p = bof3ifvdh3 .
P_79 * lvuzhhuckmt . k0xye32kow [ 7 ] ; if ( rtmIsMajorTimeStep ( hfoeutytij
) ) { ksow10vbzc = bof3ifvdh3 . P_80 * cl55cdpr1d_p ; lvuzhhuckmt .
jmr501ypmv = ( bof3ifvdh3 . P_66 - lvuzhhuckmt . kbgonrof1r [ 0 ] <=
bof3ifvdh3 . P_81 ) ; mj2ek4c0je = d1slopnfj2d . martnwreej ; lvuzhhuckmt .
argkaov1kz = ( bof3ifvdh3 . P_67 - lvuzhhuckmt . cpnsm5fki5 [ 0 ] <=
bof3ifvdh3 . P_83 ) ; if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { lvuzhhuckmt
. il2zdrdpzs = * chelevjaju ; } lvuzhhuckmt . a2ld4b11me = bof3ifvdh3 . P_36
* lvuzhhuckmt . il2zdrdpzs ; if ( d1slopnfj2d . lbikguphlp != 0 ) {
d1slopnfj2d . axiqwbld0q = lvuzhhuckmt . a2ld4b11me ; if ( d1slopnfj2d .
axiqwbld0q >= bof3ifvdh3 . P_85 ) { d1slopnfj2d . axiqwbld0q = bof3ifvdh3 .
P_85 ; } else { if ( d1slopnfj2d . axiqwbld0q <= bof3ifvdh3 . P_86 ) {
d1slopnfj2d . axiqwbld0q = bof3ifvdh3 . P_86 ; } } } if ( lvuzhhuckmt .
argkaov1kz || ( d1slopnfj2d . hr3u05iedn != 0 ) ) { d1slopnfj2d . axiqwbld0q
= lvuzhhuckmt . a2ld4b11me ; if ( d1slopnfj2d . axiqwbld0q >= bof3ifvdh3 .
P_85 ) { d1slopnfj2d . axiqwbld0q = bof3ifvdh3 . P_85 ; } else { if (
d1slopnfj2d . axiqwbld0q <= bof3ifvdh3 . P_86 ) { d1slopnfj2d . axiqwbld0q =
bof3ifvdh3 . P_86 ; } } } if ( d1slopnfj2d . axiqwbld0q >= bof3ifvdh3 . P_85
) { d1slopnfj2d . axiqwbld0q = bof3ifvdh3 . P_85 ; } else { if ( d1slopnfj2d
. axiqwbld0q <= bof3ifvdh3 . P_86 ) { d1slopnfj2d . axiqwbld0q = bof3ifvdh3 .
P_86 ; } } if ( d1slopnfj2d . axiqwbld0q > bof3ifvdh3 . P_87 ) { px1g5x0wqi =
bof3ifvdh3 . P_87 ; } else if ( d1slopnfj2d . axiqwbld0q < bof3ifvdh3 . P_88
) { px1g5x0wqi = bof3ifvdh3 . P_88 ; } else { px1g5x0wqi = d1slopnfj2d .
axiqwbld0q ; } } * gbdmtjn4mq = bof3ifvdh3 . P_89 * lvuzhhuckmt . k0xye32kow
[ 6 ] ; if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { bdblm00a4g_p = *
gbdmtjn4mq ; bdblm00a4g_p = px1g5x0wqi - bdblm00a4g_p ; lvuzhhuckmt .
ofsiaytreh = ( bof3ifvdh3 . P_0 * bdblm00a4g_p - d1slopnfj2d . dlusidt5mu ) *
bof3ifvdh3 . P_48 ; lvuzhhuckmt . n3ldelb453 = ( ( bof3ifvdh3 . P_54 *
bdblm00a4g_p + mj2ek4c0je ) + lvuzhhuckmt . ofsiaytreh ) * bof3ifvdh3 . P_91
* bof3ifvdh3 . P_37 ; if ( d1slopnfj2d . he40254wch != 0 ) { d1slopnfj2d .
ftka134rfi = lvuzhhuckmt . n3ldelb453 ; if ( d1slopnfj2d . ftka134rfi >=
bof3ifvdh3 . P_93 ) { d1slopnfj2d . ftka134rfi = bof3ifvdh3 . P_93 ; } else {
if ( d1slopnfj2d . ftka134rfi <= bof3ifvdh3 . P_94 ) { d1slopnfj2d .
ftka134rfi = bof3ifvdh3 . P_94 ; } } } if ( lvuzhhuckmt . jmr501ypmv || (
d1slopnfj2d . fuwgakmpod != 0 ) ) { d1slopnfj2d . ftka134rfi = lvuzhhuckmt .
n3ldelb453 ; if ( d1slopnfj2d . ftka134rfi >= bof3ifvdh3 . P_93 ) {
d1slopnfj2d . ftka134rfi = bof3ifvdh3 . P_93 ; } else { if ( d1slopnfj2d .
ftka134rfi <= bof3ifvdh3 . P_94 ) { d1slopnfj2d . ftka134rfi = bof3ifvdh3 .
P_94 ; } } } if ( d1slopnfj2d . ftka134rfi >= bof3ifvdh3 . P_93 ) {
d1slopnfj2d . ftka134rfi = bof3ifvdh3 . P_93 ; } else { if ( d1slopnfj2d .
ftka134rfi <= bof3ifvdh3 . P_94 ) { d1slopnfj2d . ftka134rfi = bof3ifvdh3 .
P_94 ; } } if ( d1slopnfj2d . ftka134rfi > bof3ifvdh3 . P_95 ) { f0vwa3gbu5 =
bof3ifvdh3 . P_95 ; } else if ( d1slopnfj2d . ftka134rfi < bof3ifvdh3 . P_96
) { f0vwa3gbu5 = bof3ifvdh3 . P_96 ; } else { f0vwa3gbu5 = d1slopnfj2d .
ftka134rfi ; } d0iyjnsu3c = f0vwa3gbu5 - ksow10vbzc ; lvuzhhuckmt .
ngr10hc5m3 = bof3ifvdh3 . P_55 * d0iyjnsu3c + iyxo5o23nr ; } if (
rtmIsMajorTimeStep ( hfoeutytij ) ) { d1slopnfj2d . mfarqvu45m = lvuzhhuckmt
. ngr10hc5m3 ; } first_output = false ; if ( d1slopnfj2d . hylr2w3yna == 0.0
) { d1slopnfj2d . hylr2w3yna = 1.0 ; first_output = true ; } if (
first_output ) { localX -> bpmqwncjfj [ 0 ] = d1slopnfj2d . mfarqvu45m ;
localX -> bpmqwncjfj [ 1 ] = 0.0 ; } lvuzhhuckmt . okzuauvitn [ 0 ] = localX
-> bpmqwncjfj [ 0 ] ; lvuzhhuckmt . okzuauvitn [ 1 ] = localX -> bpmqwncjfj [
1 ] ; lvuzhhuckmt . okzuauvitn [ 2 ] = ( ( d1slopnfj2d . mfarqvu45m - localX
-> bpmqwncjfj [ 0 ] ) * 1000.0 - 2.0 * localX -> bpmqwncjfj [ 1 ] ) * 1000.0
; lvuzhhuckmt . okzuauvitn [ 3 ] = 0.0 ; if ( rtmIsMajorTimeStep ( hfoeutytij
) ) { h3irildbji = d1slopnfj2d . nx1wrktxq2 ; } iyxo5o23nr = bof3ifvdh3 .
P_98 * lvuzhhuckmt . k0xye32kow [ 11 ] ; if ( rtmIsMajorTimeStep ( hfoeutytij
) ) { aetrps2hov = bof3ifvdh3 . P_99 * iyxo5o23nr ; lvuzhhuckmt . ghui4bi0m1
= ( bof3ifvdh3 . P_68 - lvuzhhuckmt . pf4arwrhyx [ 0 ] <= bof3ifvdh3 . P_100
) ; jcbffcprqe = d1slopnfj2d . lnboystaxq ; lvuzhhuckmt . mimrrzjvgj = (
bof3ifvdh3 . P_69 - lvuzhhuckmt . gs5wyjrzvf [ 0 ] <= bof3ifvdh3 . P_102 ) ;
if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { lvuzhhuckmt . d4klkeknc5 = *
jrgsipw0bp ; } lvuzhhuckmt . ab2humyxjs = bof3ifvdh3 . P_38 * lvuzhhuckmt .
d4klkeknc5 ; if ( d1slopnfj2d . f01rjososq != 0 ) { d1slopnfj2d . kva2ijsjip
= lvuzhhuckmt . ab2humyxjs ; if ( d1slopnfj2d . kva2ijsjip >= bof3ifvdh3 .
P_104 ) { d1slopnfj2d . kva2ijsjip = bof3ifvdh3 . P_104 ; } else { if (
d1slopnfj2d . kva2ijsjip <= bof3ifvdh3 . P_105 ) { d1slopnfj2d . kva2ijsjip =
bof3ifvdh3 . P_105 ; } } } if ( lvuzhhuckmt . mimrrzjvgj || ( d1slopnfj2d .
cpjueliazg != 0 ) ) { d1slopnfj2d . kva2ijsjip = lvuzhhuckmt . ab2humyxjs ;
if ( d1slopnfj2d . kva2ijsjip >= bof3ifvdh3 . P_104 ) { d1slopnfj2d .
kva2ijsjip = bof3ifvdh3 . P_104 ; } else { if ( d1slopnfj2d . kva2ijsjip <=
bof3ifvdh3 . P_105 ) { d1slopnfj2d . kva2ijsjip = bof3ifvdh3 . P_105 ; } } }
if ( d1slopnfj2d . kva2ijsjip >= bof3ifvdh3 . P_104 ) { d1slopnfj2d .
kva2ijsjip = bof3ifvdh3 . P_104 ; } else { if ( d1slopnfj2d . kva2ijsjip <=
bof3ifvdh3 . P_105 ) { d1slopnfj2d . kva2ijsjip = bof3ifvdh3 . P_105 ; } } if
( d1slopnfj2d . kva2ijsjip > bof3ifvdh3 . P_106 ) { dfrjctleic = bof3ifvdh3 .
P_106 ; } else if ( d1slopnfj2d . kva2ijsjip < bof3ifvdh3 . P_107 ) {
dfrjctleic = bof3ifvdh3 . P_107 ; } else { dfrjctleic = d1slopnfj2d .
kva2ijsjip ; } } * mx2sgp3e1r = bof3ifvdh3 . P_108 * lvuzhhuckmt . k0xye32kow
[ 10 ] ; if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { odphm1jgsz_p = *
mx2sgp3e1r ; odphm1jgsz_p = dfrjctleic - odphm1jgsz_p ; lvuzhhuckmt .
fpdxc0m2q5 = ( bof3ifvdh3 . P_1 * odphm1jgsz_p - d1slopnfj2d . gohohcrj54 ) *
bof3ifvdh3 . P_49 ; lvuzhhuckmt . iik1ydfzer = ( ( bof3ifvdh3 . P_56 *
odphm1jgsz_p + jcbffcprqe ) + lvuzhhuckmt . fpdxc0m2q5 ) * bof3ifvdh3 . P_110
* bof3ifvdh3 . P_39 ; if ( d1slopnfj2d . jshht1u2q5 != 0 ) { d1slopnfj2d .
mibsc4a2kt = lvuzhhuckmt . iik1ydfzer ; if ( d1slopnfj2d . mibsc4a2kt >=
bof3ifvdh3 . P_112 ) { d1slopnfj2d . mibsc4a2kt = bof3ifvdh3 . P_112 ; } else
{ if ( d1slopnfj2d . mibsc4a2kt <= bof3ifvdh3 . P_113 ) { d1slopnfj2d .
mibsc4a2kt = bof3ifvdh3 . P_113 ; } } } if ( lvuzhhuckmt . ghui4bi0m1 || (
d1slopnfj2d . j1flcekhiz != 0 ) ) { d1slopnfj2d . mibsc4a2kt = lvuzhhuckmt .
iik1ydfzer ; if ( d1slopnfj2d . mibsc4a2kt >= bof3ifvdh3 . P_112 ) {
d1slopnfj2d . mibsc4a2kt = bof3ifvdh3 . P_112 ; } else { if ( d1slopnfj2d .
mibsc4a2kt <= bof3ifvdh3 . P_113 ) { d1slopnfj2d . mibsc4a2kt = bof3ifvdh3 .
P_113 ; } } } if ( d1slopnfj2d . mibsc4a2kt >= bof3ifvdh3 . P_112 ) {
d1slopnfj2d . mibsc4a2kt = bof3ifvdh3 . P_112 ; } else { if ( d1slopnfj2d .
mibsc4a2kt <= bof3ifvdh3 . P_113 ) { d1slopnfj2d . mibsc4a2kt = bof3ifvdh3 .
P_113 ; } } if ( d1slopnfj2d . mibsc4a2kt > bof3ifvdh3 . P_114 ) { hsr0jzmjiq
= bof3ifvdh3 . P_114 ; } else if ( d1slopnfj2d . mibsc4a2kt < bof3ifvdh3 .
P_115 ) { hsr0jzmjiq = bof3ifvdh3 . P_115 ; } else { hsr0jzmjiq = d1slopnfj2d
. mibsc4a2kt ; } ldhpz1tpdj = hsr0jzmjiq - aetrps2hov ; lvuzhhuckmt .
bpvkri3q0b = bof3ifvdh3 . P_57 * ldhpz1tpdj + h3irildbji ; } if (
rtmIsMajorTimeStep ( hfoeutytij ) ) { d1slopnfj2d . jrb1kz3zlg = lvuzhhuckmt
. bpvkri3q0b ; } first_output = false ; if ( d1slopnfj2d . fpo5oixhup == 0.0
) { d1slopnfj2d . fpo5oixhup = 1.0 ; first_output = true ; } if (
first_output ) { localX -> nvdqtjs5r2 [ 0 ] = d1slopnfj2d . jrb1kz3zlg ;
localX -> nvdqtjs5r2 [ 1 ] = 0.0 ; } lvuzhhuckmt . hd5f3jh03c [ 0 ] = localX
-> nvdqtjs5r2 [ 0 ] ; lvuzhhuckmt . hd5f3jh03c [ 1 ] = localX -> nvdqtjs5r2 [
1 ] ; lvuzhhuckmt . hd5f3jh03c [ 2 ] = ( ( d1slopnfj2d . jrb1kz3zlg - localX
-> nvdqtjs5r2 [ 0 ] ) * 1000.0 - 2.0 * localX -> nvdqtjs5r2 [ 1 ] ) * 1000.0
; lvuzhhuckmt . hd5f3jh03c [ 3 ] = 0.0 ; if ( rtmIsMajorTimeStep ( hfoeutytij
) ) { oyfzaykx2p = d1slopnfj2d . hmmcsmj0xw ; } h3irildbji = bof3ifvdh3 .
P_117 * lvuzhhuckmt . k0xye32kow [ 1 ] ; if ( rtmIsMajorTimeStep ( hfoeutytij
) ) { ahlj0qdplx = bof3ifvdh3 . P_118 * h3irildbji ; lvuzhhuckmt . ffbrr0m5qz
= ( bof3ifvdh3 . P_70 - lvuzhhuckmt . hpivumlrcc [ 0 ] <= bof3ifvdh3 . P_119
) ; jop3tzpvw1 = d1slopnfj2d . eat1taflmt ; lvuzhhuckmt . l321nlx0ow = (
bof3ifvdh3 . P_71 - lvuzhhuckmt . ezyrayiasu [ 0 ] <= bof3ifvdh3 . P_121 ) ;
if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { lvuzhhuckmt . hzrrdpmkic = *
kx0yhuedat ; } lvuzhhuckmt . igs4te5eut = bof3ifvdh3 . P_40 * lvuzhhuckmt .
hzrrdpmkic ; if ( d1slopnfj2d . m3ypcbfysw != 0 ) { d1slopnfj2d . akyzgxh1sj
= lvuzhhuckmt . igs4te5eut ; if ( d1slopnfj2d . akyzgxh1sj >= bof3ifvdh3 .
P_123 ) { d1slopnfj2d . akyzgxh1sj = bof3ifvdh3 . P_123 ; } else { if (
d1slopnfj2d . akyzgxh1sj <= bof3ifvdh3 . P_124 ) { d1slopnfj2d . akyzgxh1sj =
bof3ifvdh3 . P_124 ; } } } if ( lvuzhhuckmt . l321nlx0ow || ( d1slopnfj2d .
gjsyon5lu1 != 0 ) ) { d1slopnfj2d . akyzgxh1sj = lvuzhhuckmt . igs4te5eut ;
if ( d1slopnfj2d . akyzgxh1sj >= bof3ifvdh3 . P_123 ) { d1slopnfj2d .
akyzgxh1sj = bof3ifvdh3 . P_123 ; } else { if ( d1slopnfj2d . akyzgxh1sj <=
bof3ifvdh3 . P_124 ) { d1slopnfj2d . akyzgxh1sj = bof3ifvdh3 . P_124 ; } } }
if ( d1slopnfj2d . akyzgxh1sj >= bof3ifvdh3 . P_123 ) { d1slopnfj2d .
akyzgxh1sj = bof3ifvdh3 . P_123 ; } else { if ( d1slopnfj2d . akyzgxh1sj <=
bof3ifvdh3 . P_124 ) { d1slopnfj2d . akyzgxh1sj = bof3ifvdh3 . P_124 ; } } if
( d1slopnfj2d . akyzgxh1sj > bof3ifvdh3 . P_125 ) { gjtzossbcx = bof3ifvdh3 .
P_125 ; } else if ( d1slopnfj2d . akyzgxh1sj < bof3ifvdh3 . P_126 ) {
gjtzossbcx = bof3ifvdh3 . P_126 ; } else { gjtzossbcx = d1slopnfj2d .
akyzgxh1sj ; } } * boerjqp35i = bof3ifvdh3 . P_127 * lvuzhhuckmt . k0xye32kow
[ 0 ] ; if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { ctyfnsjs3t_p = *
boerjqp35i ; ctyfnsjs3t_p = gjtzossbcx - ctyfnsjs3t_p ; lvuzhhuckmt .
kfhz4kh3k1 = ( bof3ifvdh3 . P_2 * ctyfnsjs3t_p - d1slopnfj2d . im3cksdclx ) *
bof3ifvdh3 . P_50 ; lvuzhhuckmt . piuo4l0c3f = ( ( bof3ifvdh3 . P_58 *
ctyfnsjs3t_p + jop3tzpvw1 ) + lvuzhhuckmt . kfhz4kh3k1 ) * bof3ifvdh3 . P_129
* bof3ifvdh3 . P_41 ; if ( d1slopnfj2d . iltjdvd4vg != 0 ) { d1slopnfj2d .
ap5cqbvm1g = lvuzhhuckmt . piuo4l0c3f ; if ( d1slopnfj2d . ap5cqbvm1g >=
bof3ifvdh3 . P_131 ) { d1slopnfj2d . ap5cqbvm1g = bof3ifvdh3 . P_131 ; } else
{ if ( d1slopnfj2d . ap5cqbvm1g <= bof3ifvdh3 . P_132 ) { d1slopnfj2d .
ap5cqbvm1g = bof3ifvdh3 . P_132 ; } } } if ( lvuzhhuckmt . ffbrr0m5qz || (
d1slopnfj2d . gtdlxdr5hj != 0 ) ) { d1slopnfj2d . ap5cqbvm1g = lvuzhhuckmt .
piuo4l0c3f ; if ( d1slopnfj2d . ap5cqbvm1g >= bof3ifvdh3 . P_131 ) {
d1slopnfj2d . ap5cqbvm1g = bof3ifvdh3 . P_131 ; } else { if ( d1slopnfj2d .
ap5cqbvm1g <= bof3ifvdh3 . P_132 ) { d1slopnfj2d . ap5cqbvm1g = bof3ifvdh3 .
P_132 ; } } } if ( d1slopnfj2d . ap5cqbvm1g >= bof3ifvdh3 . P_131 ) {
d1slopnfj2d . ap5cqbvm1g = bof3ifvdh3 . P_131 ; } else { if ( d1slopnfj2d .
ap5cqbvm1g <= bof3ifvdh3 . P_132 ) { d1slopnfj2d . ap5cqbvm1g = bof3ifvdh3 .
P_132 ; } } if ( d1slopnfj2d . ap5cqbvm1g > bof3ifvdh3 . P_133 ) { pgosqvvz3o
= bof3ifvdh3 . P_133 ; } else if ( d1slopnfj2d . ap5cqbvm1g < bof3ifvdh3 .
P_134 ) { pgosqvvz3o = bof3ifvdh3 . P_134 ; } else { pgosqvvz3o = d1slopnfj2d
. ap5cqbvm1g ; } nnrad0ft3n = pgosqvvz3o - ahlj0qdplx ; lvuzhhuckmt .
pvbgkev205 = bof3ifvdh3 . P_59 * nnrad0ft3n + oyfzaykx2p ; } if (
rtmIsMajorTimeStep ( hfoeutytij ) ) { d1slopnfj2d . koqgz4rjix = lvuzhhuckmt
. pvbgkev205 ; } first_output = false ; if ( d1slopnfj2d . mymypzqmu0 == 0.0
) { d1slopnfj2d . mymypzqmu0 = 1.0 ; first_output = true ; } if (
first_output ) { localX -> or3kmp553n [ 0 ] = d1slopnfj2d . koqgz4rjix ;
localX -> or3kmp553n [ 1 ] = 0.0 ; } lvuzhhuckmt . eqathlbtwk [ 0 ] = localX
-> or3kmp553n [ 0 ] ; lvuzhhuckmt . eqathlbtwk [ 1 ] = localX -> or3kmp553n [
1 ] ; lvuzhhuckmt . eqathlbtwk [ 2 ] = ( ( d1slopnfj2d . koqgz4rjix - localX
-> or3kmp553n [ 0 ] ) * 1000.0 - 2.0 * localX -> or3kmp553n [ 1 ] ) * 1000.0
; lvuzhhuckmt . eqathlbtwk [ 3 ] = 0.0 ; if ( rtmIsMajorTimeStep ( hfoeutytij
) ) { dzxcrxorbj = d1slopnfj2d . a5avu4h2ix ; } oyfzaykx2p = bof3ifvdh3 .
P_136 * lvuzhhuckmt . k0xye32kow [ 3 ] ; if ( rtmIsMajorTimeStep ( hfoeutytij
) ) { kjcf0kucej = bof3ifvdh3 . P_137 * oyfzaykx2p ; lvuzhhuckmt . myyre2h0cb
= ( bof3ifvdh3 . P_72 - lvuzhhuckmt . iamzy5525o [ 0 ] <= bof3ifvdh3 . P_138
) ; pqd2krcdt2 = d1slopnfj2d . mdyqmzjrn0 ; lvuzhhuckmt . bjgzy5rjw5 = (
bof3ifvdh3 . P_73 - lvuzhhuckmt . gkdm5dhsql [ 0 ] <= bof3ifvdh3 . P_140 ) ;
if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { lvuzhhuckmt . jkyw0vhmte = *
m5vh3hyppt ; } lvuzhhuckmt . e1nynqow2s = bof3ifvdh3 . P_42 * lvuzhhuckmt .
jkyw0vhmte ; if ( d1slopnfj2d . d3raebrh43 != 0 ) { d1slopnfj2d . eicckovdtk
= lvuzhhuckmt . e1nynqow2s ; if ( d1slopnfj2d . eicckovdtk >= bof3ifvdh3 .
P_142 ) { d1slopnfj2d . eicckovdtk = bof3ifvdh3 . P_142 ; } else { if (
d1slopnfj2d . eicckovdtk <= bof3ifvdh3 . P_143 ) { d1slopnfj2d . eicckovdtk =
bof3ifvdh3 . P_143 ; } } } if ( lvuzhhuckmt . bjgzy5rjw5 || ( d1slopnfj2d .
ok503kfbwz != 0 ) ) { d1slopnfj2d . eicckovdtk = lvuzhhuckmt . e1nynqow2s ;
if ( d1slopnfj2d . eicckovdtk >= bof3ifvdh3 . P_142 ) { d1slopnfj2d .
eicckovdtk = bof3ifvdh3 . P_142 ; } else { if ( d1slopnfj2d . eicckovdtk <=
bof3ifvdh3 . P_143 ) { d1slopnfj2d . eicckovdtk = bof3ifvdh3 . P_143 ; } } }
if ( d1slopnfj2d . eicckovdtk >= bof3ifvdh3 . P_142 ) { d1slopnfj2d .
eicckovdtk = bof3ifvdh3 . P_142 ; } else { if ( d1slopnfj2d . eicckovdtk <=
bof3ifvdh3 . P_143 ) { d1slopnfj2d . eicckovdtk = bof3ifvdh3 . P_143 ; } } if
( d1slopnfj2d . eicckovdtk > bof3ifvdh3 . P_144 ) { ldk1rewpxt = bof3ifvdh3 .
P_144 ; } else if ( d1slopnfj2d . eicckovdtk < bof3ifvdh3 . P_145 ) {
ldk1rewpxt = bof3ifvdh3 . P_145 ; } else { ldk1rewpxt = d1slopnfj2d .
eicckovdtk ; } } * c2lqxtprfq = bof3ifvdh3 . P_146 * lvuzhhuckmt . k0xye32kow
[ 2 ] ; if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { keazeynoyg_p = *
c2lqxtprfq ; keazeynoyg_p = ldk1rewpxt - keazeynoyg_p ; lvuzhhuckmt .
kqn2kxb5sa = ( bof3ifvdh3 . P_3 * keazeynoyg_p - d1slopnfj2d . jlvuwqbqtq ) *
bof3ifvdh3 . P_51 ; lvuzhhuckmt . inzhtyivhd = ( ( bof3ifvdh3 . P_60 *
keazeynoyg_p + pqd2krcdt2 ) + lvuzhhuckmt . kqn2kxb5sa ) * bof3ifvdh3 . P_148
* bof3ifvdh3 . P_43 ; if ( d1slopnfj2d . i43yu5fsyu != 0 ) { d1slopnfj2d .
lau0kxrr3b = lvuzhhuckmt . inzhtyivhd ; if ( d1slopnfj2d . lau0kxrr3b >=
bof3ifvdh3 . P_150 ) { d1slopnfj2d . lau0kxrr3b = bof3ifvdh3 . P_150 ; } else
{ if ( d1slopnfj2d . lau0kxrr3b <= bof3ifvdh3 . P_151 ) { d1slopnfj2d .
lau0kxrr3b = bof3ifvdh3 . P_151 ; } } } if ( lvuzhhuckmt . myyre2h0cb || (
d1slopnfj2d . nvuezdxtzi != 0 ) ) { d1slopnfj2d . lau0kxrr3b = lvuzhhuckmt .
inzhtyivhd ; if ( d1slopnfj2d . lau0kxrr3b >= bof3ifvdh3 . P_150 ) {
d1slopnfj2d . lau0kxrr3b = bof3ifvdh3 . P_150 ; } else { if ( d1slopnfj2d .
lau0kxrr3b <= bof3ifvdh3 . P_151 ) { d1slopnfj2d . lau0kxrr3b = bof3ifvdh3 .
P_151 ; } } } if ( d1slopnfj2d . lau0kxrr3b >= bof3ifvdh3 . P_150 ) {
d1slopnfj2d . lau0kxrr3b = bof3ifvdh3 . P_150 ; } else { if ( d1slopnfj2d .
lau0kxrr3b <= bof3ifvdh3 . P_151 ) { d1slopnfj2d . lau0kxrr3b = bof3ifvdh3 .
P_151 ; } } if ( d1slopnfj2d . lau0kxrr3b > bof3ifvdh3 . P_152 ) { c1am01xkog
= bof3ifvdh3 . P_152 ; } else if ( d1slopnfj2d . lau0kxrr3b < bof3ifvdh3 .
P_153 ) { c1am01xkog = bof3ifvdh3 . P_153 ; } else { c1am01xkog = d1slopnfj2d
. lau0kxrr3b ; } g31qikai10 = c1am01xkog - kjcf0kucej ; lvuzhhuckmt .
ewb3tjnaav = bof3ifvdh3 . P_61 * g31qikai10 + dzxcrxorbj ; } if (
rtmIsMajorTimeStep ( hfoeutytij ) ) { d1slopnfj2d . d00cvtrow5 = lvuzhhuckmt
. ewb3tjnaav ; } first_output = false ; if ( d1slopnfj2d . iioyhpmu2z == 0.0
) { d1slopnfj2d . iioyhpmu2z = 1.0 ; first_output = true ; } if (
first_output ) { localX -> aij4dkucqh [ 0 ] = d1slopnfj2d . d00cvtrow5 ;
localX -> aij4dkucqh [ 1 ] = 0.0 ; } lvuzhhuckmt . o2jluiwonh [ 0 ] = localX
-> aij4dkucqh [ 0 ] ; lvuzhhuckmt . o2jluiwonh [ 1 ] = localX -> aij4dkucqh [
1 ] ; lvuzhhuckmt . o2jluiwonh [ 2 ] = ( ( d1slopnfj2d . d00cvtrow5 - localX
-> aij4dkucqh [ 0 ] ) * 1000.0 - 2.0 * localX -> aij4dkucqh [ 1 ] ) * 1000.0
; lvuzhhuckmt . o2jluiwonh [ 3 ] = 0.0 ; if ( rtmIsMajorTimeStep ( hfoeutytij
) ) { khlonjjenf = d1slopnfj2d . lqn4y02ryj ; } dzxcrxorbj = bof3ifvdh3 .
P_155 * lvuzhhuckmt . k0xye32kow [ 5 ] ; if ( rtmIsMajorTimeStep ( hfoeutytij
) ) { jom0ikpeux = bof3ifvdh3 . P_156 * dzxcrxorbj ; lvuzhhuckmt . f12elwi2je
= ( bof3ifvdh3 . P_74 - lvuzhhuckmt . gh0ba0iypp [ 0 ] <= bof3ifvdh3 . P_157
) ; pxpmtpcpv3 = d1slopnfj2d . e1nkcmfeef ; lvuzhhuckmt . niapjx0yaa = (
bof3ifvdh3 . P_75 - lvuzhhuckmt . it2ouoy2lw [ 0 ] <= bof3ifvdh3 . P_159 ) ;
if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { lvuzhhuckmt . c1cidqyaaz = *
eftkqi2uqx ; } lvuzhhuckmt . mc5bjvku1h = bof3ifvdh3 . P_44 * lvuzhhuckmt .
c1cidqyaaz ; if ( d1slopnfj2d . phmwjirefk != 0 ) { d1slopnfj2d . h2azwddpsi
= lvuzhhuckmt . mc5bjvku1h ; if ( d1slopnfj2d . h2azwddpsi >= bof3ifvdh3 .
P_161 ) { d1slopnfj2d . h2azwddpsi = bof3ifvdh3 . P_161 ; } else { if (
d1slopnfj2d . h2azwddpsi <= bof3ifvdh3 . P_162 ) { d1slopnfj2d . h2azwddpsi =
bof3ifvdh3 . P_162 ; } } } if ( lvuzhhuckmt . niapjx0yaa || ( d1slopnfj2d .
kpe2zccxxi != 0 ) ) { d1slopnfj2d . h2azwddpsi = lvuzhhuckmt . mc5bjvku1h ;
if ( d1slopnfj2d . h2azwddpsi >= bof3ifvdh3 . P_161 ) { d1slopnfj2d .
h2azwddpsi = bof3ifvdh3 . P_161 ; } else { if ( d1slopnfj2d . h2azwddpsi <=
bof3ifvdh3 . P_162 ) { d1slopnfj2d . h2azwddpsi = bof3ifvdh3 . P_162 ; } } }
if ( d1slopnfj2d . h2azwddpsi >= bof3ifvdh3 . P_161 ) { d1slopnfj2d .
h2azwddpsi = bof3ifvdh3 . P_161 ; } else { if ( d1slopnfj2d . h2azwddpsi <=
bof3ifvdh3 . P_162 ) { d1slopnfj2d . h2azwddpsi = bof3ifvdh3 . P_162 ; } } if
( d1slopnfj2d . h2azwddpsi > bof3ifvdh3 . P_163 ) { baxqb1ibzr = bof3ifvdh3 .
P_163 ; } else if ( d1slopnfj2d . h2azwddpsi < bof3ifvdh3 . P_164 ) {
baxqb1ibzr = bof3ifvdh3 . P_164 ; } else { baxqb1ibzr = d1slopnfj2d .
h2azwddpsi ; } } * bwngodvth1 = bof3ifvdh3 . P_165 * lvuzhhuckmt . k0xye32kow
[ 4 ] ; if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { ekica1lnpt_p = *
bwngodvth1 ; ekica1lnpt_p = baxqb1ibzr - ekica1lnpt_p ; lvuzhhuckmt .
jgdhfclmal = ( bof3ifvdh3 . P_4 * ekica1lnpt_p - d1slopnfj2d . itkowzvhmy ) *
bof3ifvdh3 . P_52 ; lvuzhhuckmt . kkjdrofzsj = ( ( bof3ifvdh3 . P_62 *
ekica1lnpt_p + pxpmtpcpv3 ) + lvuzhhuckmt . jgdhfclmal ) * bof3ifvdh3 . P_167
* bof3ifvdh3 . P_45 ; if ( d1slopnfj2d . axj00twaij != 0 ) { d1slopnfj2d .
aqhbkipuc1 = lvuzhhuckmt . kkjdrofzsj ; if ( d1slopnfj2d . aqhbkipuc1 >=
bof3ifvdh3 . P_169 ) { d1slopnfj2d . aqhbkipuc1 = bof3ifvdh3 . P_169 ; } else
{ if ( d1slopnfj2d . aqhbkipuc1 <= bof3ifvdh3 . P_170 ) { d1slopnfj2d .
aqhbkipuc1 = bof3ifvdh3 . P_170 ; } } } if ( lvuzhhuckmt . f12elwi2je || (
d1slopnfj2d . imm0zy02qz != 0 ) ) { d1slopnfj2d . aqhbkipuc1 = lvuzhhuckmt .
kkjdrofzsj ; if ( d1slopnfj2d . aqhbkipuc1 >= bof3ifvdh3 . P_169 ) {
d1slopnfj2d . aqhbkipuc1 = bof3ifvdh3 . P_169 ; } else { if ( d1slopnfj2d .
aqhbkipuc1 <= bof3ifvdh3 . P_170 ) { d1slopnfj2d . aqhbkipuc1 = bof3ifvdh3 .
P_170 ; } } } if ( d1slopnfj2d . aqhbkipuc1 >= bof3ifvdh3 . P_169 ) {
d1slopnfj2d . aqhbkipuc1 = bof3ifvdh3 . P_169 ; } else { if ( d1slopnfj2d .
aqhbkipuc1 <= bof3ifvdh3 . P_170 ) { d1slopnfj2d . aqhbkipuc1 = bof3ifvdh3 .
P_170 ; } } if ( d1slopnfj2d . aqhbkipuc1 > bof3ifvdh3 . P_171 ) { ikntplev3w
= bof3ifvdh3 . P_171 ; } else if ( d1slopnfj2d . aqhbkipuc1 < bof3ifvdh3 .
P_172 ) { ikntplev3w = bof3ifvdh3 . P_172 ; } else { ikntplev3w = d1slopnfj2d
. aqhbkipuc1 ; } ksg2lm4q2x = ikntplev3w - jom0ikpeux ; lvuzhhuckmt .
m0qfxlppqp = bof3ifvdh3 . P_63 * ksg2lm4q2x + khlonjjenf ; } if (
rtmIsMajorTimeStep ( hfoeutytij ) ) { d1slopnfj2d . d2ihml4pca = lvuzhhuckmt
. m0qfxlppqp ; } first_output = false ; if ( d1slopnfj2d . ohubyvobgd == 0.0
) { d1slopnfj2d . ohubyvobgd = 1.0 ; first_output = true ; } if (
first_output ) { localX -> fpzb5mu1i2 [ 0 ] = d1slopnfj2d . d2ihml4pca ;
localX -> fpzb5mu1i2 [ 1 ] = 0.0 ; } lvuzhhuckmt . e23ad5ihp4 [ 0 ] = localX
-> fpzb5mu1i2 [ 0 ] ; lvuzhhuckmt . e23ad5ihp4 [ 1 ] = localX -> fpzb5mu1i2 [
1 ] ; lvuzhhuckmt . e23ad5ihp4 [ 2 ] = ( ( d1slopnfj2d . d2ihml4pca - localX
-> fpzb5mu1i2 [ 0 ] ) * 1000.0 - 2.0 * localX -> fpzb5mu1i2 [ 1 ] ) * 1000.0
; lvuzhhuckmt . e23ad5ihp4 [ 3 ] = 0.0 ; if ( rtmIsMajorTimeStep ( hfoeutytij
) ) { fnyljtrcde = d1slopnfj2d . jhkfvfo11l ; } khlonjjenf = bof3ifvdh3 .
P_174 * lvuzhhuckmt . k0xye32kow [ 9 ] ; if ( rtmIsMajorTimeStep ( hfoeutytij
) ) { lxcvuijen3 = bof3ifvdh3 . P_175 * khlonjjenf ; lvuzhhuckmt . fmhgxbzpod
= ( bof3ifvdh3 . P_76 - lvuzhhuckmt . ljdpmxc04v [ 0 ] <= bof3ifvdh3 . P_176
) ; egn5e1juvp = d1slopnfj2d . ejngdjwvuh ; lvuzhhuckmt . lj554lxonv = (
bof3ifvdh3 . P_77 - lvuzhhuckmt . gra4msiia2 [ 0 ] <= bof3ifvdh3 . P_178 ) ;
if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { lvuzhhuckmt . knazmztaxp = *
ed1wyjpuuh ; } lvuzhhuckmt . hr1vg5j2or = bof3ifvdh3 . P_46 * lvuzhhuckmt .
knazmztaxp ; if ( d1slopnfj2d . h4yyh4nnql != 0 ) { d1slopnfj2d . dztpawf31l
= lvuzhhuckmt . hr1vg5j2or ; if ( d1slopnfj2d . dztpawf31l >= bof3ifvdh3 .
P_180 ) { d1slopnfj2d . dztpawf31l = bof3ifvdh3 . P_180 ; } else { if (
d1slopnfj2d . dztpawf31l <= bof3ifvdh3 . P_181 ) { d1slopnfj2d . dztpawf31l =
bof3ifvdh3 . P_181 ; } } } if ( lvuzhhuckmt . lj554lxonv || ( d1slopnfj2d .
ogphl1wuml != 0 ) ) { d1slopnfj2d . dztpawf31l = lvuzhhuckmt . hr1vg5j2or ;
if ( d1slopnfj2d . dztpawf31l >= bof3ifvdh3 . P_180 ) { d1slopnfj2d .
dztpawf31l = bof3ifvdh3 . P_180 ; } else { if ( d1slopnfj2d . dztpawf31l <=
bof3ifvdh3 . P_181 ) { d1slopnfj2d . dztpawf31l = bof3ifvdh3 . P_181 ; } } }
if ( d1slopnfj2d . dztpawf31l >= bof3ifvdh3 . P_180 ) { d1slopnfj2d .
dztpawf31l = bof3ifvdh3 . P_180 ; } else { if ( d1slopnfj2d . dztpawf31l <=
bof3ifvdh3 . P_181 ) { d1slopnfj2d . dztpawf31l = bof3ifvdh3 . P_181 ; } } if
( d1slopnfj2d . dztpawf31l > bof3ifvdh3 . P_182 ) { erdf0qjfzm = bof3ifvdh3 .
P_182 ; } else if ( d1slopnfj2d . dztpawf31l < bof3ifvdh3 . P_183 ) {
erdf0qjfzm = bof3ifvdh3 . P_183 ; } else { erdf0qjfzm = d1slopnfj2d .
dztpawf31l ; } } * g0sjdawhsf = bof3ifvdh3 . P_184 * lvuzhhuckmt . k0xye32kow
[ 8 ] ; if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { oukwyzj1ze_p = *
g0sjdawhsf ; oukwyzj1ze_p = erdf0qjfzm - oukwyzj1ze_p ; lvuzhhuckmt .
k5ii4pjkz3 = ( bof3ifvdh3 . P_5 * oukwyzj1ze_p - d1slopnfj2d . msarqtw0ej ) *
bof3ifvdh3 . P_53 ; lvuzhhuckmt . eap3iu1d2t = ( ( bof3ifvdh3 . P_64 *
oukwyzj1ze_p + egn5e1juvp ) + lvuzhhuckmt . k5ii4pjkz3 ) * bof3ifvdh3 . P_186
* bof3ifvdh3 . P_47 ; if ( d1slopnfj2d . jbclgbkabv != 0 ) { d1slopnfj2d .
kc4smoweoa = lvuzhhuckmt . eap3iu1d2t ; if ( d1slopnfj2d . kc4smoweoa >=
bof3ifvdh3 . P_188 ) { d1slopnfj2d . kc4smoweoa = bof3ifvdh3 . P_188 ; } else
{ if ( d1slopnfj2d . kc4smoweoa <= bof3ifvdh3 . P_189 ) { d1slopnfj2d .
kc4smoweoa = bof3ifvdh3 . P_189 ; } } } if ( lvuzhhuckmt . fmhgxbzpod || (
d1slopnfj2d . mzswpaogfa != 0 ) ) { d1slopnfj2d . kc4smoweoa = lvuzhhuckmt .
eap3iu1d2t ; if ( d1slopnfj2d . kc4smoweoa >= bof3ifvdh3 . P_188 ) {
d1slopnfj2d . kc4smoweoa = bof3ifvdh3 . P_188 ; } else { if ( d1slopnfj2d .
kc4smoweoa <= bof3ifvdh3 . P_189 ) { d1slopnfj2d . kc4smoweoa = bof3ifvdh3 .
P_189 ; } } } if ( d1slopnfj2d . kc4smoweoa >= bof3ifvdh3 . P_188 ) {
d1slopnfj2d . kc4smoweoa = bof3ifvdh3 . P_188 ; } else { if ( d1slopnfj2d .
kc4smoweoa <= bof3ifvdh3 . P_189 ) { d1slopnfj2d . kc4smoweoa = bof3ifvdh3 .
P_189 ; } } if ( d1slopnfj2d . kc4smoweoa > bof3ifvdh3 . P_190 ) { ajkhqw3onn
= bof3ifvdh3 . P_190 ; } else if ( d1slopnfj2d . kc4smoweoa < bof3ifvdh3 .
P_191 ) { ajkhqw3onn = bof3ifvdh3 . P_191 ; } else { ajkhqw3onn = d1slopnfj2d
. kc4smoweoa ; } pacxxwl3ko = ajkhqw3onn - lxcvuijen3 ; lvuzhhuckmt .
dhka03xnzo = bof3ifvdh3 . P_65 * pacxxwl3ko + fnyljtrcde ; } if (
rtmIsMajorTimeStep ( hfoeutytij ) ) { d1slopnfj2d . psdk3h03r4 = lvuzhhuckmt
. dhka03xnzo ; } first_output = false ; if ( d1slopnfj2d . pojlpslfax == 0.0
) { d1slopnfj2d . pojlpslfax = 1.0 ; first_output = true ; } if (
first_output ) { localX -> mctmaipokl [ 0 ] = d1slopnfj2d . psdk3h03r4 ;
localX -> mctmaipokl [ 1 ] = 0.0 ; } lvuzhhuckmt . ppj0cxlxco [ 0 ] = localX
-> mctmaipokl [ 0 ] ; lvuzhhuckmt . ppj0cxlxco [ 1 ] = localX -> mctmaipokl [
1 ] ; lvuzhhuckmt . ppj0cxlxco [ 2 ] = ( ( d1slopnfj2d . psdk3h03r4 - localX
-> mctmaipokl [ 0 ] ) * 1000.0 - 2.0 * localX -> mctmaipokl [ 1 ] ) * 1000.0
; lvuzhhuckmt . ppj0cxlxco [ 3 ] = 0.0 ; simulationData = (
NeslSimulationData * ) d1slopnfj2d . dojae3fabx ; time_e = ggyakluv1h ;
simulationData -> mData -> mTime . mN = 1 ; simulationData -> mData -> mTime
. mX = & time_e ; simulationData -> mData -> mContStates . mN = 30 ;
simulationData -> mData -> mContStates . mX = & localX -> kgvozz1pdk [ 0 ] ;
simulationData -> mData -> mDiscStates . mN = 0 ; simulationData -> mData ->
mDiscStates . mX = & d1slopnfj2d . g5juej3g4q ; simulationData -> mData ->
mModeVector . mN = 6 ; simulationData -> mData -> mModeVector . mX = &
d1slopnfj2d . beljpehthd [ 0 ] ; first_output = false ; simulationData ->
mData -> mFoundZcEvents = first_output ; simulationData -> mData ->
mIsMajorTimeStep = tmp ; first_output = _ssGetSolverAssertCheck ( hfoeutytij
-> _mdlRefSfcnS ) ; simulationData -> mData -> mIsSolverAssertCheck =
first_output ; simulationData -> mData -> mIsSolverCheckingCIC = false ;
first_output = ssIsSolverComputingJacobian ( hfoeutytij -> _mdlRefSfcnS ) ;
simulationData -> mData -> mIsComputingJacobian = first_output ;
simulationData -> mData -> mIsEvaluatingF0 = ( tmp_b != 0 ) ; simulationData
-> mData -> mIsSolverRequestingReset = false ; tmp_f [ 0 ] = 0 ; tmp_j [ 0 ]
= lvuzhhuckmt . jv20suu5kg [ 0 ] ; tmp_j [ 1 ] = lvuzhhuckmt . jv20suu5kg [ 1
] ; tmp_j [ 2 ] = lvuzhhuckmt . jv20suu5kg [ 2 ] ; tmp_j [ 3 ] = lvuzhhuckmt
. jv20suu5kg [ 3 ] ; tmp_f [ 1 ] = 4 ; tmp_j [ 4 ] = lvuzhhuckmt . mj4gjt33f3
[ 0 ] ; tmp_j [ 5 ] = lvuzhhuckmt . mj4gjt33f3 [ 1 ] ; tmp_j [ 6 ] =
lvuzhhuckmt . mj4gjt33f3 [ 2 ] ; tmp_j [ 7 ] = lvuzhhuckmt . mj4gjt33f3 [ 3 ]
; tmp_f [ 2 ] = 8 ; tmp_j [ 8 ] = lvuzhhuckmt . hwk0u4eoqn [ 0 ] ; tmp_j [ 9
] = lvuzhhuckmt . hwk0u4eoqn [ 1 ] ; tmp_j [ 10 ] = lvuzhhuckmt . hwk0u4eoqn
[ 2 ] ; tmp_j [ 11 ] = lvuzhhuckmt . hwk0u4eoqn [ 3 ] ; tmp_f [ 3 ] = 12 ;
tmp_j [ 12 ] = lvuzhhuckmt . mrjmcb1eaq [ 0 ] ; tmp_j [ 13 ] = lvuzhhuckmt .
mrjmcb1eaq [ 1 ] ; tmp_j [ 14 ] = lvuzhhuckmt . mrjmcb1eaq [ 2 ] ; tmp_j [ 15
] = lvuzhhuckmt . mrjmcb1eaq [ 3 ] ; tmp_f [ 4 ] = 16 ; tmp_j [ 16 ] =
lvuzhhuckmt . lhbimp5kmr [ 0 ] ; tmp_j [ 17 ] = lvuzhhuckmt . lhbimp5kmr [ 1
] ; tmp_j [ 18 ] = lvuzhhuckmt . lhbimp5kmr [ 2 ] ; tmp_j [ 19 ] =
lvuzhhuckmt . lhbimp5kmr [ 3 ] ; tmp_f [ 5 ] = 20 ; tmp_j [ 20 ] =
lvuzhhuckmt . idnqelgv01 [ 0 ] ; tmp_j [ 21 ] = lvuzhhuckmt . idnqelgv01 [ 1
] ; tmp_j [ 22 ] = lvuzhhuckmt . idnqelgv01 [ 2 ] ; tmp_j [ 23 ] =
lvuzhhuckmt . idnqelgv01 [ 3 ] ; tmp_f [ 6 ] = 24 ; tmp_j [ 24 ] =
lvuzhhuckmt . okzuauvitn [ 0 ] ; tmp_j [ 25 ] = lvuzhhuckmt . okzuauvitn [ 1
] ; tmp_j [ 26 ] = lvuzhhuckmt . okzuauvitn [ 2 ] ; tmp_j [ 27 ] =
lvuzhhuckmt . okzuauvitn [ 3 ] ; tmp_f [ 7 ] = 28 ; tmp_j [ 28 ] =
lvuzhhuckmt . hd5f3jh03c [ 0 ] ; tmp_j [ 29 ] = lvuzhhuckmt . hd5f3jh03c [ 1
] ; tmp_j [ 30 ] = lvuzhhuckmt . hd5f3jh03c [ 2 ] ; tmp_j [ 31 ] =
lvuzhhuckmt . hd5f3jh03c [ 3 ] ; tmp_f [ 8 ] = 32 ; tmp_j [ 32 ] =
lvuzhhuckmt . eqathlbtwk [ 0 ] ; tmp_j [ 33 ] = lvuzhhuckmt . eqathlbtwk [ 1
] ; tmp_j [ 34 ] = lvuzhhuckmt . eqathlbtwk [ 2 ] ; tmp_j [ 35 ] =
lvuzhhuckmt . eqathlbtwk [ 3 ] ; tmp_f [ 9 ] = 36 ; tmp_j [ 36 ] =
lvuzhhuckmt . o2jluiwonh [ 0 ] ; tmp_j [ 37 ] = lvuzhhuckmt . o2jluiwonh [ 1
] ; tmp_j [ 38 ] = lvuzhhuckmt . o2jluiwonh [ 2 ] ; tmp_j [ 39 ] =
lvuzhhuckmt . o2jluiwonh [ 3 ] ; tmp_f [ 10 ] = 40 ; tmp_j [ 40 ] =
lvuzhhuckmt . e23ad5ihp4 [ 0 ] ; tmp_j [ 41 ] = lvuzhhuckmt . e23ad5ihp4 [ 1
] ; tmp_j [ 42 ] = lvuzhhuckmt . e23ad5ihp4 [ 2 ] ; tmp_j [ 43 ] =
lvuzhhuckmt . e23ad5ihp4 [ 3 ] ; tmp_f [ 11 ] = 44 ; tmp_j [ 44 ] =
lvuzhhuckmt . ppj0cxlxco [ 0 ] ; tmp_j [ 45 ] = lvuzhhuckmt . ppj0cxlxco [ 1
] ; tmp_j [ 46 ] = lvuzhhuckmt . ppj0cxlxco [ 2 ] ; tmp_j [ 47 ] =
lvuzhhuckmt . ppj0cxlxco [ 3 ] ; tmp_f [ 12 ] = 48 ; simulationData -> mData
-> mInputValues . mN = 48 ; simulationData -> mData -> mInputValues . mX = &
tmp_j [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 13 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_f [ 0 ] ;
simulationData -> mData -> mOutputs . mN = 36 ; simulationData -> mData ->
mOutputs . mX = & lvuzhhuckmt . acyhv10gdn [ 0 ] ; simulationData -> mData ->
mSampleHits . mN = 0 ; simulationData -> mData -> mSampleHits . mX = NULL ;
simulationData -> mData -> mIsFundamentalSampleHit = false ; simulationData
-> mData -> mTolerances . mN = 0 ; simulationData -> mData -> mTolerances .
mX = NULL ; simulationData -> mData -> mCstateHasChanged = false ;
diagnosticManager = ( NeuDiagnosticManager * ) d1slopnfj2d . eqhqru4bkb ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; tmp_b = ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d .
gqpntsbwxh , NESL_SIM_OUTPUTS , simulationData , diagnosticManager ) ; if (
tmp_b != 0 ) { first_output = error_buffer_is_empty ( ssGetErrorStatus (
hfoeutytij -> _mdlRefSfcnS ) ) ; if ( first_output ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( hfoeutytij ->
_mdlRefSfcnS , msg ) ; } } if ( rtmIsMajorTimeStep ( hfoeutytij ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( hfoeutytij -> _mdlRefSfcnS ) ; }
simulationData = ( NeslSimulationData * ) d1slopnfj2d . iacissyba2 ; time_i =
ggyakluv1h ; simulationData -> mData -> mTime . mN = 1 ; simulationData ->
mData -> mTime . mX = & time_i ; simulationData -> mData -> mContStates . mN
= 0 ; simulationData -> mData -> mContStates . mX = NULL ; simulationData ->
mData -> mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX =
& d1slopnfj2d . owpb4gqr4b ; simulationData -> mData -> mModeVector . mN = 0
; simulationData -> mData -> mModeVector . mX = & d1slopnfj2d . jyeac3e5ko ;
first_output = false ; simulationData -> mData -> mFoundZcEvents =
first_output ; simulationData -> mData -> mIsMajorTimeStep = tmp ; tmp =
_ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; simulationData -> mData ->
mIsComputingJacobian = false ; simulationData -> mData -> mIsEvaluatingF0 =
false ; simulationData -> mData -> mIsSolverRequestingReset = false ; tmp_k [
0 ] = 0 ; tmp_c [ 0 ] = lvuzhhuckmt . jv20suu5kg [ 0 ] ; tmp_c [ 1 ] =
lvuzhhuckmt . jv20suu5kg [ 1 ] ; tmp_c [ 2 ] = lvuzhhuckmt . jv20suu5kg [ 2 ]
; tmp_c [ 3 ] = lvuzhhuckmt . jv20suu5kg [ 3 ] ; tmp_k [ 1 ] = 4 ; tmp_c [ 4
] = lvuzhhuckmt . mj4gjt33f3 [ 0 ] ; tmp_c [ 5 ] = lvuzhhuckmt . mj4gjt33f3 [
1 ] ; tmp_c [ 6 ] = lvuzhhuckmt . mj4gjt33f3 [ 2 ] ; tmp_c [ 7 ] =
lvuzhhuckmt . mj4gjt33f3 [ 3 ] ; tmp_k [ 2 ] = 8 ; tmp_c [ 8 ] = lvuzhhuckmt
. hwk0u4eoqn [ 0 ] ; tmp_c [ 9 ] = lvuzhhuckmt . hwk0u4eoqn [ 1 ] ; tmp_c [
10 ] = lvuzhhuckmt . hwk0u4eoqn [ 2 ] ; tmp_c [ 11 ] = lvuzhhuckmt .
hwk0u4eoqn [ 3 ] ; tmp_k [ 3 ] = 12 ; tmp_c [ 12 ] = lvuzhhuckmt . mrjmcb1eaq
[ 0 ] ; tmp_c [ 13 ] = lvuzhhuckmt . mrjmcb1eaq [ 1 ] ; tmp_c [ 14 ] =
lvuzhhuckmt . mrjmcb1eaq [ 2 ] ; tmp_c [ 15 ] = lvuzhhuckmt . mrjmcb1eaq [ 3
] ; tmp_k [ 4 ] = 16 ; tmp_c [ 16 ] = lvuzhhuckmt . lhbimp5kmr [ 0 ] ; tmp_c
[ 17 ] = lvuzhhuckmt . lhbimp5kmr [ 1 ] ; tmp_c [ 18 ] = lvuzhhuckmt .
lhbimp5kmr [ 2 ] ; tmp_c [ 19 ] = lvuzhhuckmt . lhbimp5kmr [ 3 ] ; tmp_k [ 5
] = 20 ; tmp_c [ 20 ] = lvuzhhuckmt . idnqelgv01 [ 0 ] ; tmp_c [ 21 ] =
lvuzhhuckmt . idnqelgv01 [ 1 ] ; tmp_c [ 22 ] = lvuzhhuckmt . idnqelgv01 [ 2
] ; tmp_c [ 23 ] = lvuzhhuckmt . idnqelgv01 [ 3 ] ; tmp_k [ 6 ] = 24 ; tmp_c
[ 24 ] = lvuzhhuckmt . okzuauvitn [ 0 ] ; tmp_c [ 25 ] = lvuzhhuckmt .
okzuauvitn [ 1 ] ; tmp_c [ 26 ] = lvuzhhuckmt . okzuauvitn [ 2 ] ; tmp_c [ 27
] = lvuzhhuckmt . okzuauvitn [ 3 ] ; tmp_k [ 7 ] = 28 ; tmp_c [ 28 ] =
lvuzhhuckmt . hd5f3jh03c [ 0 ] ; tmp_c [ 29 ] = lvuzhhuckmt . hd5f3jh03c [ 1
] ; tmp_c [ 30 ] = lvuzhhuckmt . hd5f3jh03c [ 2 ] ; tmp_c [ 31 ] =
lvuzhhuckmt . hd5f3jh03c [ 3 ] ; tmp_k [ 8 ] = 32 ; tmp_c [ 32 ] =
lvuzhhuckmt . eqathlbtwk [ 0 ] ; tmp_c [ 33 ] = lvuzhhuckmt . eqathlbtwk [ 1
] ; tmp_c [ 34 ] = lvuzhhuckmt . eqathlbtwk [ 2 ] ; tmp_c [ 35 ] =
lvuzhhuckmt . eqathlbtwk [ 3 ] ; tmp_k [ 9 ] = 36 ; tmp_c [ 36 ] =
lvuzhhuckmt . o2jluiwonh [ 0 ] ; tmp_c [ 37 ] = lvuzhhuckmt . o2jluiwonh [ 1
] ; tmp_c [ 38 ] = lvuzhhuckmt . o2jluiwonh [ 2 ] ; tmp_c [ 39 ] =
lvuzhhuckmt . o2jluiwonh [ 3 ] ; tmp_k [ 10 ] = 40 ; tmp_c [ 40 ] =
lvuzhhuckmt . e23ad5ihp4 [ 0 ] ; tmp_c [ 41 ] = lvuzhhuckmt . e23ad5ihp4 [ 1
] ; tmp_c [ 42 ] = lvuzhhuckmt . e23ad5ihp4 [ 2 ] ; tmp_c [ 43 ] =
lvuzhhuckmt . e23ad5ihp4 [ 3 ] ; tmp_k [ 11 ] = 44 ; tmp_c [ 44 ] =
lvuzhhuckmt . ppj0cxlxco [ 0 ] ; tmp_c [ 45 ] = lvuzhhuckmt . ppj0cxlxco [ 1
] ; tmp_c [ 46 ] = lvuzhhuckmt . ppj0cxlxco [ 2 ] ; tmp_c [ 47 ] =
lvuzhhuckmt . ppj0cxlxco [ 3 ] ; tmp_k [ 12 ] = 48 ; memcpy ( & tmp_c [ 48 ]
, & lvuzhhuckmt . acyhv10gdn [ 0 ] , 36U * sizeof ( real_T ) ) ; tmp_k [ 13 ]
= 84 ; simulationData -> mData -> mInputValues . mN = 84 ; simulationData ->
mData -> mInputValues . mX = & tmp_c [ 0 ] ; simulationData -> mData ->
mInputOffsets . mN = 14 ; simulationData -> mData -> mInputOffsets . mX = &
tmp_k [ 0 ] ; simulationData -> mData -> mOutputs . mN = 19 ; simulationData
-> mData -> mOutputs . mX = & lvuzhhuckmt . asd4csvbcs [ 0 ] ; simulationData
-> mData -> mSampleHits . mN = 0 ; simulationData -> mData -> mSampleHits .
mX = NULL ; simulationData -> mData -> mIsFundamentalSampleHit = false ;
simulationData -> mData -> mTolerances . mN = 0 ; simulationData -> mData ->
mTolerances . mX = NULL ; simulationData -> mData -> mCstateHasChanged =
false ; diagnosticManager = ( NeuDiagnosticManager * ) d1slopnfj2d .
jcs4deobwu ; diagnosticTree = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; tmp_b = ne_simulator_method ( ( NeslSimulator * )
d1slopnfj2d . nbkxol04ay , NESL_SIM_OUTPUTS , simulationData ,
diagnosticManager ) ; if ( tmp_b != 0 ) { tmp = error_buffer_is_empty (
ssGetErrorStatus ( hfoeutytij -> _mdlRefSfcnS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( hfoeutytij ->
_mdlRefSfcnS , msg ) ; } } if ( rtmIsMajorTimeStep ( hfoeutytij ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( hfoeutytij -> _mdlRefSfcnS ) ; }
lvuzhhuckmt . bs1e5cpoll [ 0 ] = lvuzhhuckmt . asd4csvbcs [ 0 ] ; lvuzhhuckmt
. bs1e5cpoll [ 1 ] = 0.0 ; lvuzhhuckmt . bs1e5cpoll [ 2 ] = 0.0 ; lvuzhhuckmt
. bs1e5cpoll [ 3 ] = 0.0 ; lvuzhhuckmt . k30tufukck [ 0 ] = lvuzhhuckmt .
asd4csvbcs [ 1 ] ; lvuzhhuckmt . k30tufukck [ 1 ] = 0.0 ; lvuzhhuckmt .
k30tufukck [ 2 ] = 0.0 ; lvuzhhuckmt . k30tufukck [ 3 ] = 0.0 ; lvuzhhuckmt .
a0iis2ayez [ 0 ] = lvuzhhuckmt . asd4csvbcs [ 2 ] ; lvuzhhuckmt . a0iis2ayez
[ 1 ] = 0.0 ; lvuzhhuckmt . a0iis2ayez [ 2 ] = 0.0 ; lvuzhhuckmt . a0iis2ayez
[ 3 ] = 0.0 ; lvuzhhuckmt . kzrjgwxloa [ 0 ] = lvuzhhuckmt . asd4csvbcs [ 3 ]
; lvuzhhuckmt . kzrjgwxloa [ 1 ] = 0.0 ; lvuzhhuckmt . kzrjgwxloa [ 2 ] = 0.0
; lvuzhhuckmt . kzrjgwxloa [ 3 ] = 0.0 ; lvuzhhuckmt . h1mwn5bwbv [ 0 ] =
lvuzhhuckmt . asd4csvbcs [ 4 ] ; lvuzhhuckmt . h1mwn5bwbv [ 1 ] = 0.0 ;
lvuzhhuckmt . h1mwn5bwbv [ 2 ] = 0.0 ; lvuzhhuckmt . h1mwn5bwbv [ 3 ] = 0.0 ;
lvuzhhuckmt . dw2p0ylolg [ 0 ] = lvuzhhuckmt . asd4csvbcs [ 5 ] ; lvuzhhuckmt
. dw2p0ylolg [ 1 ] = 0.0 ; lvuzhhuckmt . dw2p0ylolg [ 2 ] = 0.0 ; lvuzhhuckmt
. dw2p0ylolg [ 3 ] = 0.0 ; { if ( ( d1slopnfj2d . ne4l15gebh . AQHandles ||
d1slopnfj2d . ne4l15gebh . SlioLTF ) && ssGetLogOutput ( hfoeutytij ->
_mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal ( d1slopnfj2d . ne4l15gebh .
AQHandles , d1slopnfj2d . ne4l15gebh . SlioLTF , 0 , rtmGetTaskTime (
hfoeutytij , 0 ) , ( char * ) & lvuzhhuckmt . asd4csvbcs [ 18 ] + 0 ) ; } }
ggyakluv1h = bof3ifvdh3 . P_192 * lvuzhhuckmt . asd4csvbcs [ 7 ] ; nkw5nqrk1g
= bof3ifvdh3 . P_193 * ggyakluv1h ; ggyakluv1h = bof3ifvdh3 . P_194 *
lvuzhhuckmt . asd4csvbcs [ 15 ] ; cpu1qnpswa = bof3ifvdh3 . P_195 *
ggyakluv1h ; ggyakluv1h = bof3ifvdh3 . P_196 * lvuzhhuckmt . asd4csvbcs [ 9 ]
; pozjdfxxw2 = bof3ifvdh3 . P_197 * ggyakluv1h ; ggyakluv1h = bof3ifvdh3 .
P_198 * lvuzhhuckmt . asd4csvbcs [ 13 ] ; ccxta0d4z5 = bof3ifvdh3 . P_199 *
ggyakluv1h ; ggyakluv1h = bof3ifvdh3 . P_200 * lvuzhhuckmt . asd4csvbcs [ 11
] ; ivji5cetyn = bof3ifvdh3 . P_201 * ggyakluv1h ; ggyakluv1h = bof3ifvdh3 .
P_202 * lvuzhhuckmt . asd4csvbcs [ 17 ] ; btk4cl4ktn = bof3ifvdh3 . P_203 *
ggyakluv1h ; if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { lvuzhhuckmt .
ewtdk1a3wj = bof3ifvdh3 . P_6 * pacxxwl3ko ; pacxxwl3ko = muDoubleScalarMax (
lvuzhhuckmt . ljdpmxc04v [ 0 ] , bof3ifvdh3 . P_76 ) ; lvuzhhuckmt .
czgs54xlrn = 1.0 / ( ( real_T ) ( pacxxwl3ko == 0.0 ) *
2.2204460492503131e-16 + pacxxwl3ko ) * ( lvuzhhuckmt . eap3iu1d2t -
ajkhqw3onn ) ; lvuzhhuckmt . ipcork0j5r = bof3ifvdh3 . P_7 * oukwyzj1ze_p ; }
{ if ( ( d1slopnfj2d . h30jmamuoh . AQHandles [ 0 ] || d1slopnfj2d .
h30jmamuoh . SlioLTF ) && ssGetLogOutput ( hfoeutytij -> _mdlRefSfcnS ) ) {
sdiSlioSdiWriteSignal ( d1slopnfj2d . h30jmamuoh . AQHandles [ 0 ] ,
d1slopnfj2d . h30jmamuoh . SlioLTF , 0 , rtmGetTaskTime ( hfoeutytij , 0 ) ,
( char * ) bwngodvth1 + 0 ) ; sdiSlioSdiWriteSignal ( d1slopnfj2d .
h30jmamuoh . AQHandles [ 1 ] , d1slopnfj2d . h30jmamuoh . SlioLTF , 1 ,
rtmGetTaskTime ( hfoeutytij , 0 ) , ( char * ) gbdmtjn4mq + 0 ) ;
sdiSlioSdiWriteSignal ( d1slopnfj2d . h30jmamuoh . AQHandles [ 2 ] ,
d1slopnfj2d . h30jmamuoh . SlioLTF , 2 , rtmGetTaskTime ( hfoeutytij , 0 ) ,
( char * ) g0sjdawhsf + 0 ) ; sdiSlioSdiWriteSignal ( d1slopnfj2d .
h30jmamuoh . AQHandles [ 3 ] , d1slopnfj2d . h30jmamuoh . SlioLTF , 3 ,
rtmGetTaskTime ( hfoeutytij , 0 ) , ( char * ) mx2sgp3e1r + 0 ) ;
sdiSlioSdiWriteSignal ( d1slopnfj2d . h30jmamuoh . AQHandles [ 4 ] ,
d1slopnfj2d . h30jmamuoh . SlioLTF , 4 , rtmGetTaskTime ( hfoeutytij , 0 ) ,
( char * ) c2lqxtprfq + 0 ) ; sdiSlioSdiWriteSignal ( d1slopnfj2d .
h30jmamuoh . AQHandles [ 5 ] , d1slopnfj2d . h30jmamuoh . SlioLTF , 5 ,
rtmGetTaskTime ( hfoeutytij , 0 ) , ( char * ) boerjqp35i + 0 ) ; } } if (
rtmIsMajorTimeStep ( hfoeutytij ) ) { oukwyzj1ze_p = muDoubleScalarMax (
lvuzhhuckmt . gra4msiia2 [ 0 ] , bof3ifvdh3 . P_77 ) ; lvuzhhuckmt .
g2kdahdcll = 1.0 / ( ( real_T ) ( oukwyzj1ze_p == 0.0 ) *
2.2204460492503131e-16 + oukwyzj1ze_p ) * ( lvuzhhuckmt . hr1vg5j2or -
erdf0qjfzm ) ; lvuzhhuckmt . mvhqmddcdi = bof3ifvdh3 . P_8 * ksg2lm4q2x ;
ksg2lm4q2x = muDoubleScalarMax ( lvuzhhuckmt . gh0ba0iypp [ 0 ] , bof3ifvdh3
. P_74 ) ; lvuzhhuckmt . cbxpo1dgoh = 1.0 / ( ( real_T ) ( ksg2lm4q2x == 0.0
) * 2.2204460492503131e-16 + ksg2lm4q2x ) * ( lvuzhhuckmt . kkjdrofzsj -
ikntplev3w ) ; lvuzhhuckmt . mugze5h0np = bof3ifvdh3 . P_9 * ekica1lnpt_p ;
ekica1lnpt_p = muDoubleScalarMax ( lvuzhhuckmt . it2ouoy2lw [ 0 ] ,
bof3ifvdh3 . P_75 ) ; lvuzhhuckmt . i5soltjzbg = 1.0 / ( ( real_T ) (
ekica1lnpt_p == 0.0 ) * 2.2204460492503131e-16 + ekica1lnpt_p ) * (
lvuzhhuckmt . mc5bjvku1h - baxqb1ibzr ) ; lvuzhhuckmt . oqif5mozdt =
bof3ifvdh3 . P_10 * g31qikai10 ; g31qikai10 = muDoubleScalarMax ( lvuzhhuckmt
. iamzy5525o [ 0 ] , bof3ifvdh3 . P_72 ) ; lvuzhhuckmt . a11ufkvxe2 = 1.0 / (
( real_T ) ( g31qikai10 == 0.0 ) * 2.2204460492503131e-16 + g31qikai10 ) * (
lvuzhhuckmt . inzhtyivhd - c1am01xkog ) ; lvuzhhuckmt . i5mqop40o4 =
bof3ifvdh3 . P_11 * keazeynoyg_p ; keazeynoyg_p = muDoubleScalarMax (
lvuzhhuckmt . gkdm5dhsql [ 0 ] , bof3ifvdh3 . P_73 ) ; lvuzhhuckmt .
dk3zxjazcl = 1.0 / ( ( real_T ) ( keazeynoyg_p == 0.0 ) *
2.2204460492503131e-16 + keazeynoyg_p ) * ( lvuzhhuckmt . e1nynqow2s -
ldk1rewpxt ) ; lvuzhhuckmt . e4gi0xz1up = bof3ifvdh3 . P_12 * nnrad0ft3n ;
nnrad0ft3n = muDoubleScalarMax ( lvuzhhuckmt . hpivumlrcc [ 0 ] , bof3ifvdh3
. P_70 ) ; lvuzhhuckmt . nxl5q24yqw = 1.0 / ( ( real_T ) ( nnrad0ft3n == 0.0
) * 2.2204460492503131e-16 + nnrad0ft3n ) * ( lvuzhhuckmt . piuo4l0c3f -
pgosqvvz3o ) ; lvuzhhuckmt . dytu4lqdaz = bof3ifvdh3 . P_13 * ctyfnsjs3t_p ;
ctyfnsjs3t_p = muDoubleScalarMax ( lvuzhhuckmt . ezyrayiasu [ 0 ] ,
bof3ifvdh3 . P_71 ) ; lvuzhhuckmt . i3lazf1uup = 1.0 / ( ( real_T ) (
ctyfnsjs3t_p == 0.0 ) * 2.2204460492503131e-16 + ctyfnsjs3t_p ) * (
lvuzhhuckmt . igs4te5eut - gjtzossbcx ) ; lvuzhhuckmt . oybzinbsjs =
bof3ifvdh3 . P_14 * ldhpz1tpdj ; ldhpz1tpdj = muDoubleScalarMax ( lvuzhhuckmt
. pf4arwrhyx [ 0 ] , bof3ifvdh3 . P_68 ) ; lvuzhhuckmt . lqu4qa401r = 1.0 / (
( real_T ) ( ldhpz1tpdj == 0.0 ) * 2.2204460492503131e-16 + ldhpz1tpdj ) * (
lvuzhhuckmt . iik1ydfzer - hsr0jzmjiq ) ; lvuzhhuckmt . iehotwguah =
bof3ifvdh3 . P_15 * odphm1jgsz_p ; odphm1jgsz_p = muDoubleScalarMax (
lvuzhhuckmt . gs5wyjrzvf [ 0 ] , bof3ifvdh3 . P_69 ) ; lvuzhhuckmt .
gdgkrl4bz4 = 1.0 / ( ( real_T ) ( odphm1jgsz_p == 0.0 ) *
2.2204460492503131e-16 + odphm1jgsz_p ) * ( lvuzhhuckmt . ab2humyxjs -
dfrjctleic ) ; lvuzhhuckmt . divng01nk2 = bof3ifvdh3 . P_16 * d0iyjnsu3c ;
d0iyjnsu3c = muDoubleScalarMax ( lvuzhhuckmt . kbgonrof1r [ 0 ] , bof3ifvdh3
. P_66 ) ; lvuzhhuckmt . onfvjve2wy = 1.0 / ( ( real_T ) ( d0iyjnsu3c == 0.0
) * 2.2204460492503131e-16 + d0iyjnsu3c ) * ( lvuzhhuckmt . n3ldelb453 -
f0vwa3gbu5 ) ; lvuzhhuckmt . g4baubdyll = bof3ifvdh3 . P_17 * bdblm00a4g_p ;
bdblm00a4g_p = muDoubleScalarMax ( lvuzhhuckmt . cpnsm5fki5 [ 0 ] ,
bof3ifvdh3 . P_67 ) ; lvuzhhuckmt . ds44fme4rr = 1.0 / ( ( real_T ) (
bdblm00a4g_p == 0.0 ) * 2.2204460492503131e-16 + bdblm00a4g_p ) * (
lvuzhhuckmt . a2ld4b11me - px1g5x0wqi ) ; } { if ( ( d1slopnfj2d . d1shbopr2m
. AQHandles [ 0 ] || d1slopnfj2d . d1shbopr2m . SlioLTF ) && ssGetLogOutput (
hfoeutytij -> _mdlRefSfcnS ) ) { sdiSlioSdiWriteSignal ( d1slopnfj2d .
d1shbopr2m . AQHandles [ 0 ] , d1slopnfj2d . d1shbopr2m . SlioLTF , 0 ,
rtmGetTaskTime ( hfoeutytij , 0 ) , ( char * ) eftkqi2uqx + 0 ) ;
sdiSlioSdiWriteSignal ( d1slopnfj2d . d1shbopr2m . AQHandles [ 1 ] ,
d1slopnfj2d . d1shbopr2m . SlioLTF , 1 , rtmGetTaskTime ( hfoeutytij , 0 ) ,
( char * ) chelevjaju + 0 ) ; sdiSlioSdiWriteSignal ( d1slopnfj2d .
d1shbopr2m . AQHandles [ 2 ] , d1slopnfj2d . d1shbopr2m . SlioLTF , 2 ,
rtmGetTaskTime ( hfoeutytij , 0 ) , ( char * ) ed1wyjpuuh + 0 ) ;
sdiSlioSdiWriteSignal ( d1slopnfj2d . d1shbopr2m . AQHandles [ 3 ] ,
d1slopnfj2d . d1shbopr2m . SlioLTF , 3 , rtmGetTaskTime ( hfoeutytij , 0 ) ,
( char * ) jrgsipw0bp + 0 ) ; sdiSlioSdiWriteSignal ( d1slopnfj2d .
d1shbopr2m . AQHandles [ 4 ] , d1slopnfj2d . d1shbopr2m . SlioLTF , 4 ,
rtmGetTaskTime ( hfoeutytij , 0 ) , ( char * ) m5vh3hyppt + 0 ) ;
sdiSlioSdiWriteSignal ( d1slopnfj2d . d1shbopr2m . AQHandles [ 5 ] ,
d1slopnfj2d . d1shbopr2m . SlioLTF , 5 , rtmGetTaskTime ( hfoeutytij , 0 ) ,
( char * ) kx0yhuedat + 0 ) ; } } } void fh5akag4fo ( real_T * localX_ ) {
nbzsdh3gog * const hfoeutytij = & ( elvjztouut . rtm ) ; pu40142whda * localX
= ( pu40142whda * ) localX_ ; NeslSimulationData * simulationData ; real_T
time ; boolean_T tmp ; boolean_T tmp_p ; real_T tmp_e [ 24 ] ; int_T tmp_i [
7 ] ; NeuDiagnosticManager * diagnosticManager ; NeuDiagnosticTree *
diagnosticTree ; int32_T tmp_m ; char * msg ; real_T time_p ; real_T tmp_g [
48 ] ; int_T tmp_j [ 13 ] ; real_T time_tmp ; int32_T tmp_f ; simulationData
= ( NeslSimulationData * ) d1slopnfj2d . fwekq1g4wz ; time_tmp =
rtmGetTaskTime ( hfoeutytij , 0 ) ; time = time_tmp ; simulationData -> mData
-> mTime . mN = 1 ; simulationData -> mData -> mTime . mX = & time ;
simulationData -> mData -> mContStates . mN = 24 ; simulationData -> mData ->
mContStates . mX = & localX -> lk3sdnwlk1 [ 0 ] ; simulationData -> mData ->
mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX = &
d1slopnfj2d . fu4515tfei ; simulationData -> mData -> mModeVector . mN = 0 ;
simulationData -> mData -> mModeVector . mX = & d1slopnfj2d . dlhbeuzmaz ;
tmp = false ; simulationData -> mData -> mFoundZcEvents = tmp ; tmp =
rtmIsMajorTimeStep ( hfoeutytij ) ; simulationData -> mData ->
mIsMajorTimeStep = tmp ; tmp_p = _ssGetSolverAssertCheck ( hfoeutytij ->
_mdlRefSfcnS ) ; simulationData -> mData -> mIsSolverAssertCheck = tmp_p ;
simulationData -> mData -> mIsSolverCheckingCIC = false ; tmp_p =
ssIsSolverComputingJacobian ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData
-> mData -> mIsComputingJacobian = tmp_p ; tmp_f =
ssGetEvaluatingF0ForJacobian ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData
-> mData -> mIsEvaluatingF0 = ( tmp_f != 0 ) ; simulationData -> mData ->
mIsSolverRequestingReset = false ; tmp_i [ 0 ] = 0 ; tmp_e [ 0 ] =
lvuzhhuckmt . bs1e5cpoll [ 0 ] ; tmp_e [ 1 ] = lvuzhhuckmt . bs1e5cpoll [ 1 ]
; tmp_e [ 2 ] = lvuzhhuckmt . bs1e5cpoll [ 2 ] ; tmp_e [ 3 ] = lvuzhhuckmt .
bs1e5cpoll [ 3 ] ; tmp_i [ 1 ] = 4 ; tmp_e [ 4 ] = lvuzhhuckmt . k30tufukck [
0 ] ; tmp_e [ 5 ] = lvuzhhuckmt . k30tufukck [ 1 ] ; tmp_e [ 6 ] =
lvuzhhuckmt . k30tufukck [ 2 ] ; tmp_e [ 7 ] = lvuzhhuckmt . k30tufukck [ 3 ]
; tmp_i [ 2 ] = 8 ; tmp_e [ 8 ] = lvuzhhuckmt . a0iis2ayez [ 0 ] ; tmp_e [ 9
] = lvuzhhuckmt . a0iis2ayez [ 1 ] ; tmp_e [ 10 ] = lvuzhhuckmt . a0iis2ayez
[ 2 ] ; tmp_e [ 11 ] = lvuzhhuckmt . a0iis2ayez [ 3 ] ; tmp_i [ 3 ] = 12 ;
tmp_e [ 12 ] = lvuzhhuckmt . kzrjgwxloa [ 0 ] ; tmp_e [ 13 ] = lvuzhhuckmt .
kzrjgwxloa [ 1 ] ; tmp_e [ 14 ] = lvuzhhuckmt . kzrjgwxloa [ 2 ] ; tmp_e [ 15
] = lvuzhhuckmt . kzrjgwxloa [ 3 ] ; tmp_i [ 4 ] = 16 ; tmp_e [ 16 ] =
lvuzhhuckmt . h1mwn5bwbv [ 0 ] ; tmp_e [ 17 ] = lvuzhhuckmt . h1mwn5bwbv [ 1
] ; tmp_e [ 18 ] = lvuzhhuckmt . h1mwn5bwbv [ 2 ] ; tmp_e [ 19 ] =
lvuzhhuckmt . h1mwn5bwbv [ 3 ] ; tmp_i [ 5 ] = 20 ; tmp_e [ 20 ] =
lvuzhhuckmt . dw2p0ylolg [ 0 ] ; tmp_e [ 21 ] = lvuzhhuckmt . dw2p0ylolg [ 1
] ; tmp_e [ 22 ] = lvuzhhuckmt . dw2p0ylolg [ 2 ] ; tmp_e [ 23 ] =
lvuzhhuckmt . dw2p0ylolg [ 3 ] ; tmp_i [ 6 ] = 24 ; simulationData -> mData
-> mInputValues . mN = 24 ; simulationData -> mData -> mInputValues . mX = &
tmp_e [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 7 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_i [ 0 ] ;
diagnosticManager = ( NeuDiagnosticManager * ) d1slopnfj2d . ntdusjysav ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; tmp_m = ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d .
bl4aw00lkd , NESL_SIM_UPDATE , simulationData , diagnosticManager ) ; if (
tmp_m != 0 ) { tmp_p = error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij
-> _mdlRefSfcnS ) ) ; if ( tmp_p ) { msg = rtw_diagnostics_msg (
diagnosticTree ) ; ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; }
} if ( rtmIsMajorTimeStep ( hfoeutytij ) ) { d1slopnfj2d . lbcqusxymb +=
bof3ifvdh3 . P_78 * lvuzhhuckmt . divng01nk2 ; d1slopnfj2d . martnwreej +=
bof3ifvdh3 . P_82 * lvuzhhuckmt . g4baubdyll ; d1slopnfj2d . lbikguphlp = 0U
; d1slopnfj2d . axiqwbld0q += bof3ifvdh3 . P_84 * lvuzhhuckmt . ds44fme4rr ;
if ( d1slopnfj2d . axiqwbld0q >= bof3ifvdh3 . P_85 ) { d1slopnfj2d .
axiqwbld0q = bof3ifvdh3 . P_85 ; } else { if ( d1slopnfj2d . axiqwbld0q <=
bof3ifvdh3 . P_86 ) { d1slopnfj2d . axiqwbld0q = bof3ifvdh3 . P_86 ; } }
d1slopnfj2d . hr3u05iedn = ( int8_T ) lvuzhhuckmt . argkaov1kz ; d1slopnfj2d
. dlusidt5mu += bof3ifvdh3 . P_90 * lvuzhhuckmt . ofsiaytreh ; d1slopnfj2d .
he40254wch = 0U ; d1slopnfj2d . ftka134rfi += bof3ifvdh3 . P_92 * lvuzhhuckmt
. onfvjve2wy ; if ( d1slopnfj2d . ftka134rfi >= bof3ifvdh3 . P_93 ) {
d1slopnfj2d . ftka134rfi = bof3ifvdh3 . P_93 ; } else { if ( d1slopnfj2d .
ftka134rfi <= bof3ifvdh3 . P_94 ) { d1slopnfj2d . ftka134rfi = bof3ifvdh3 .
P_94 ; } } d1slopnfj2d . fuwgakmpod = ( int8_T ) lvuzhhuckmt . jmr501ypmv ;
d1slopnfj2d . nx1wrktxq2 += bof3ifvdh3 . P_97 * lvuzhhuckmt . oybzinbsjs ;
d1slopnfj2d . lnboystaxq += bof3ifvdh3 . P_101 * lvuzhhuckmt . iehotwguah ;
d1slopnfj2d . f01rjososq = 0U ; d1slopnfj2d . kva2ijsjip += bof3ifvdh3 .
P_103 * lvuzhhuckmt . gdgkrl4bz4 ; if ( d1slopnfj2d . kva2ijsjip >=
bof3ifvdh3 . P_104 ) { d1slopnfj2d . kva2ijsjip = bof3ifvdh3 . P_104 ; } else
{ if ( d1slopnfj2d . kva2ijsjip <= bof3ifvdh3 . P_105 ) { d1slopnfj2d .
kva2ijsjip = bof3ifvdh3 . P_105 ; } } d1slopnfj2d . cpjueliazg = ( int8_T )
lvuzhhuckmt . mimrrzjvgj ; d1slopnfj2d . gohohcrj54 += bof3ifvdh3 . P_109 *
lvuzhhuckmt . fpdxc0m2q5 ; d1slopnfj2d . jshht1u2q5 = 0U ; d1slopnfj2d .
mibsc4a2kt += bof3ifvdh3 . P_111 * lvuzhhuckmt . lqu4qa401r ; if (
d1slopnfj2d . mibsc4a2kt >= bof3ifvdh3 . P_112 ) { d1slopnfj2d . mibsc4a2kt =
bof3ifvdh3 . P_112 ; } else { if ( d1slopnfj2d . mibsc4a2kt <= bof3ifvdh3 .
P_113 ) { d1slopnfj2d . mibsc4a2kt = bof3ifvdh3 . P_113 ; } } d1slopnfj2d .
j1flcekhiz = ( int8_T ) lvuzhhuckmt . ghui4bi0m1 ; d1slopnfj2d . hmmcsmj0xw
+= bof3ifvdh3 . P_116 * lvuzhhuckmt . e4gi0xz1up ; d1slopnfj2d . eat1taflmt
+= bof3ifvdh3 . P_120 * lvuzhhuckmt . dytu4lqdaz ; d1slopnfj2d . m3ypcbfysw =
0U ; d1slopnfj2d . akyzgxh1sj += bof3ifvdh3 . P_122 * lvuzhhuckmt .
i3lazf1uup ; if ( d1slopnfj2d . akyzgxh1sj >= bof3ifvdh3 . P_123 ) {
d1slopnfj2d . akyzgxh1sj = bof3ifvdh3 . P_123 ; } else { if ( d1slopnfj2d .
akyzgxh1sj <= bof3ifvdh3 . P_124 ) { d1slopnfj2d . akyzgxh1sj = bof3ifvdh3 .
P_124 ; } } d1slopnfj2d . gjsyon5lu1 = ( int8_T ) lvuzhhuckmt . l321nlx0ow ;
d1slopnfj2d . im3cksdclx += bof3ifvdh3 . P_128 * lvuzhhuckmt . kfhz4kh3k1 ;
d1slopnfj2d . iltjdvd4vg = 0U ; d1slopnfj2d . ap5cqbvm1g += bof3ifvdh3 .
P_130 * lvuzhhuckmt . nxl5q24yqw ; if ( d1slopnfj2d . ap5cqbvm1g >=
bof3ifvdh3 . P_131 ) { d1slopnfj2d . ap5cqbvm1g = bof3ifvdh3 . P_131 ; } else
{ if ( d1slopnfj2d . ap5cqbvm1g <= bof3ifvdh3 . P_132 ) { d1slopnfj2d .
ap5cqbvm1g = bof3ifvdh3 . P_132 ; } } d1slopnfj2d . gtdlxdr5hj = ( int8_T )
lvuzhhuckmt . ffbrr0m5qz ; d1slopnfj2d . a5avu4h2ix += bof3ifvdh3 . P_135 *
lvuzhhuckmt . oqif5mozdt ; d1slopnfj2d . mdyqmzjrn0 += bof3ifvdh3 . P_139 *
lvuzhhuckmt . i5mqop40o4 ; d1slopnfj2d . d3raebrh43 = 0U ; d1slopnfj2d .
eicckovdtk += bof3ifvdh3 . P_141 * lvuzhhuckmt . dk3zxjazcl ; if (
d1slopnfj2d . eicckovdtk >= bof3ifvdh3 . P_142 ) { d1slopnfj2d . eicckovdtk =
bof3ifvdh3 . P_142 ; } else { if ( d1slopnfj2d . eicckovdtk <= bof3ifvdh3 .
P_143 ) { d1slopnfj2d . eicckovdtk = bof3ifvdh3 . P_143 ; } } d1slopnfj2d .
ok503kfbwz = ( int8_T ) lvuzhhuckmt . bjgzy5rjw5 ; d1slopnfj2d . jlvuwqbqtq
+= bof3ifvdh3 . P_147 * lvuzhhuckmt . kqn2kxb5sa ; d1slopnfj2d . i43yu5fsyu =
0U ; d1slopnfj2d . lau0kxrr3b += bof3ifvdh3 . P_149 * lvuzhhuckmt .
a11ufkvxe2 ; if ( d1slopnfj2d . lau0kxrr3b >= bof3ifvdh3 . P_150 ) {
d1slopnfj2d . lau0kxrr3b = bof3ifvdh3 . P_150 ; } else { if ( d1slopnfj2d .
lau0kxrr3b <= bof3ifvdh3 . P_151 ) { d1slopnfj2d . lau0kxrr3b = bof3ifvdh3 .
P_151 ; } } d1slopnfj2d . nvuezdxtzi = ( int8_T ) lvuzhhuckmt . myyre2h0cb ;
d1slopnfj2d . lqn4y02ryj += bof3ifvdh3 . P_154 * lvuzhhuckmt . mvhqmddcdi ;
d1slopnfj2d . e1nkcmfeef += bof3ifvdh3 . P_158 * lvuzhhuckmt . mugze5h0np ;
d1slopnfj2d . phmwjirefk = 0U ; d1slopnfj2d . h2azwddpsi += bof3ifvdh3 .
P_160 * lvuzhhuckmt . i5soltjzbg ; if ( d1slopnfj2d . h2azwddpsi >=
bof3ifvdh3 . P_161 ) { d1slopnfj2d . h2azwddpsi = bof3ifvdh3 . P_161 ; } else
{ if ( d1slopnfj2d . h2azwddpsi <= bof3ifvdh3 . P_162 ) { d1slopnfj2d .
h2azwddpsi = bof3ifvdh3 . P_162 ; } } d1slopnfj2d . kpe2zccxxi = ( int8_T )
lvuzhhuckmt . niapjx0yaa ; d1slopnfj2d . itkowzvhmy += bof3ifvdh3 . P_166 *
lvuzhhuckmt . jgdhfclmal ; d1slopnfj2d . axj00twaij = 0U ; d1slopnfj2d .
aqhbkipuc1 += bof3ifvdh3 . P_168 * lvuzhhuckmt . cbxpo1dgoh ; if (
d1slopnfj2d . aqhbkipuc1 >= bof3ifvdh3 . P_169 ) { d1slopnfj2d . aqhbkipuc1 =
bof3ifvdh3 . P_169 ; } else { if ( d1slopnfj2d . aqhbkipuc1 <= bof3ifvdh3 .
P_170 ) { d1slopnfj2d . aqhbkipuc1 = bof3ifvdh3 . P_170 ; } } d1slopnfj2d .
imm0zy02qz = ( int8_T ) lvuzhhuckmt . f12elwi2je ; d1slopnfj2d . jhkfvfo11l
+= bof3ifvdh3 . P_173 * lvuzhhuckmt . ewtdk1a3wj ; d1slopnfj2d . ejngdjwvuh
+= bof3ifvdh3 . P_177 * lvuzhhuckmt . ipcork0j5r ; d1slopnfj2d . h4yyh4nnql =
0U ; d1slopnfj2d . dztpawf31l += bof3ifvdh3 . P_179 * lvuzhhuckmt .
g2kdahdcll ; if ( d1slopnfj2d . dztpawf31l >= bof3ifvdh3 . P_180 ) {
d1slopnfj2d . dztpawf31l = bof3ifvdh3 . P_180 ; } else { if ( d1slopnfj2d .
dztpawf31l <= bof3ifvdh3 . P_181 ) { d1slopnfj2d . dztpawf31l = bof3ifvdh3 .
P_181 ; } } d1slopnfj2d . ogphl1wuml = ( int8_T ) lvuzhhuckmt . lj554lxonv ;
d1slopnfj2d . msarqtw0ej += bof3ifvdh3 . P_185 * lvuzhhuckmt . k5ii4pjkz3 ;
d1slopnfj2d . jbclgbkabv = 0U ; d1slopnfj2d . kc4smoweoa += bof3ifvdh3 .
P_187 * lvuzhhuckmt . czgs54xlrn ; if ( d1slopnfj2d . kc4smoweoa >=
bof3ifvdh3 . P_188 ) { d1slopnfj2d . kc4smoweoa = bof3ifvdh3 . P_188 ; } else
{ if ( d1slopnfj2d . kc4smoweoa <= bof3ifvdh3 . P_189 ) { d1slopnfj2d .
kc4smoweoa = bof3ifvdh3 . P_189 ; } } d1slopnfj2d . mzswpaogfa = ( int8_T )
lvuzhhuckmt . fmhgxbzpod ; } simulationData = ( NeslSimulationData * )
d1slopnfj2d . dojae3fabx ; time_p = time_tmp ; simulationData -> mData ->
mTime . mN = 1 ; simulationData -> mData -> mTime . mX = & time_p ;
simulationData -> mData -> mContStates . mN = 30 ; simulationData -> mData ->
mContStates . mX = & localX -> kgvozz1pdk [ 0 ] ; simulationData -> mData ->
mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX = &
d1slopnfj2d . g5juej3g4q ; simulationData -> mData -> mModeVector . mN = 6 ;
simulationData -> mData -> mModeVector . mX = & d1slopnfj2d . beljpehthd [ 0
] ; tmp_p = false ; simulationData -> mData -> mFoundZcEvents = tmp_p ;
simulationData -> mData -> mIsMajorTimeStep = tmp ; tmp =
_ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; tmp = ssIsSolverComputingJacobian ( hfoeutytij
-> _mdlRefSfcnS ) ; simulationData -> mData -> mIsComputingJacobian = tmp ;
simulationData -> mData -> mIsEvaluatingF0 = ( tmp_f != 0 ) ; simulationData
-> mData -> mIsSolverRequestingReset = false ; tmp_j [ 0 ] = 0 ; tmp_g [ 0 ]
= lvuzhhuckmt . jv20suu5kg [ 0 ] ; tmp_g [ 1 ] = lvuzhhuckmt . jv20suu5kg [ 1
] ; tmp_g [ 2 ] = lvuzhhuckmt . jv20suu5kg [ 2 ] ; tmp_g [ 3 ] = lvuzhhuckmt
. jv20suu5kg [ 3 ] ; tmp_j [ 1 ] = 4 ; tmp_g [ 4 ] = lvuzhhuckmt . mj4gjt33f3
[ 0 ] ; tmp_g [ 5 ] = lvuzhhuckmt . mj4gjt33f3 [ 1 ] ; tmp_g [ 6 ] =
lvuzhhuckmt . mj4gjt33f3 [ 2 ] ; tmp_g [ 7 ] = lvuzhhuckmt . mj4gjt33f3 [ 3 ]
; tmp_j [ 2 ] = 8 ; tmp_g [ 8 ] = lvuzhhuckmt . hwk0u4eoqn [ 0 ] ; tmp_g [ 9
] = lvuzhhuckmt . hwk0u4eoqn [ 1 ] ; tmp_g [ 10 ] = lvuzhhuckmt . hwk0u4eoqn
[ 2 ] ; tmp_g [ 11 ] = lvuzhhuckmt . hwk0u4eoqn [ 3 ] ; tmp_j [ 3 ] = 12 ;
tmp_g [ 12 ] = lvuzhhuckmt . mrjmcb1eaq [ 0 ] ; tmp_g [ 13 ] = lvuzhhuckmt .
mrjmcb1eaq [ 1 ] ; tmp_g [ 14 ] = lvuzhhuckmt . mrjmcb1eaq [ 2 ] ; tmp_g [ 15
] = lvuzhhuckmt . mrjmcb1eaq [ 3 ] ; tmp_j [ 4 ] = 16 ; tmp_g [ 16 ] =
lvuzhhuckmt . lhbimp5kmr [ 0 ] ; tmp_g [ 17 ] = lvuzhhuckmt . lhbimp5kmr [ 1
] ; tmp_g [ 18 ] = lvuzhhuckmt . lhbimp5kmr [ 2 ] ; tmp_g [ 19 ] =
lvuzhhuckmt . lhbimp5kmr [ 3 ] ; tmp_j [ 5 ] = 20 ; tmp_g [ 20 ] =
lvuzhhuckmt . idnqelgv01 [ 0 ] ; tmp_g [ 21 ] = lvuzhhuckmt . idnqelgv01 [ 1
] ; tmp_g [ 22 ] = lvuzhhuckmt . idnqelgv01 [ 2 ] ; tmp_g [ 23 ] =
lvuzhhuckmt . idnqelgv01 [ 3 ] ; tmp_j [ 6 ] = 24 ; tmp_g [ 24 ] =
lvuzhhuckmt . okzuauvitn [ 0 ] ; tmp_g [ 25 ] = lvuzhhuckmt . okzuauvitn [ 1
] ; tmp_g [ 26 ] = lvuzhhuckmt . okzuauvitn [ 2 ] ; tmp_g [ 27 ] =
lvuzhhuckmt . okzuauvitn [ 3 ] ; tmp_j [ 7 ] = 28 ; tmp_g [ 28 ] =
lvuzhhuckmt . hd5f3jh03c [ 0 ] ; tmp_g [ 29 ] = lvuzhhuckmt . hd5f3jh03c [ 1
] ; tmp_g [ 30 ] = lvuzhhuckmt . hd5f3jh03c [ 2 ] ; tmp_g [ 31 ] =
lvuzhhuckmt . hd5f3jh03c [ 3 ] ; tmp_j [ 8 ] = 32 ; tmp_g [ 32 ] =
lvuzhhuckmt . eqathlbtwk [ 0 ] ; tmp_g [ 33 ] = lvuzhhuckmt . eqathlbtwk [ 1
] ; tmp_g [ 34 ] = lvuzhhuckmt . eqathlbtwk [ 2 ] ; tmp_g [ 35 ] =
lvuzhhuckmt . eqathlbtwk [ 3 ] ; tmp_j [ 9 ] = 36 ; tmp_g [ 36 ] =
lvuzhhuckmt . o2jluiwonh [ 0 ] ; tmp_g [ 37 ] = lvuzhhuckmt . o2jluiwonh [ 1
] ; tmp_g [ 38 ] = lvuzhhuckmt . o2jluiwonh [ 2 ] ; tmp_g [ 39 ] =
lvuzhhuckmt . o2jluiwonh [ 3 ] ; tmp_j [ 10 ] = 40 ; tmp_g [ 40 ] =
lvuzhhuckmt . e23ad5ihp4 [ 0 ] ; tmp_g [ 41 ] = lvuzhhuckmt . e23ad5ihp4 [ 1
] ; tmp_g [ 42 ] = lvuzhhuckmt . e23ad5ihp4 [ 2 ] ; tmp_g [ 43 ] =
lvuzhhuckmt . e23ad5ihp4 [ 3 ] ; tmp_j [ 11 ] = 44 ; tmp_g [ 44 ] =
lvuzhhuckmt . ppj0cxlxco [ 0 ] ; tmp_g [ 45 ] = lvuzhhuckmt . ppj0cxlxco [ 1
] ; tmp_g [ 46 ] = lvuzhhuckmt . ppj0cxlxco [ 2 ] ; tmp_g [ 47 ] =
lvuzhhuckmt . ppj0cxlxco [ 3 ] ; tmp_j [ 12 ] = 48 ; simulationData -> mData
-> mInputValues . mN = 48 ; simulationData -> mData -> mInputValues . mX = &
tmp_g [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 13 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_j [ 0 ] ;
diagnosticManager = ( NeuDiagnosticManager * ) d1slopnfj2d . eqhqru4bkb ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; tmp_f = ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d .
gqpntsbwxh , NESL_SIM_UPDATE , simulationData , diagnosticManager ) ; if (
tmp_f != 0 ) { tmp = error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij ->
_mdlRefSfcnS ) ) ; if ( tmp ) { msg = rtw_diagnostics_msg ( diagnosticTree )
; ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; } } } void
febppa0s54 ( real_T * localX_ , real_T * localXdot_ ) { nbzsdh3gog * const
hfoeutytij = & ( elvjztouut . rtm ) ; pu40142whda * localX = ( pu40142whda *
) localX_ ; id24jk0x2ms * localXdot = ( id24jk0x2ms * ) localXdot_ ;
NeslSimulationData * simulationData ; real_T time ; boolean_T tmp ; boolean_T
tmp_p ; real_T tmp_e [ 24 ] ; int_T tmp_i [ 7 ] ; NeuDiagnosticManager *
diagnosticManager ; NeuDiagnosticTree * diagnosticTree ; int32_T tmp_m ; char
* msg ; real_T time_p ; real_T tmp_g [ 48 ] ; int_T tmp_j [ 13 ] ; real_T
time_tmp ; int32_T tmp_f ; simulationData = ( NeslSimulationData * )
d1slopnfj2d . fwekq1g4wz ; time_tmp = rtmGetTaskTime ( hfoeutytij , 0 ) ;
time = time_tmp ; simulationData -> mData -> mTime . mN = 1 ; simulationData
-> mData -> mTime . mX = & time ; simulationData -> mData -> mContStates . mN
= 24 ; simulationData -> mData -> mContStates . mX = & localX -> lk3sdnwlk1 [
0 ] ; simulationData -> mData -> mDiscStates . mN = 0 ; simulationData ->
mData -> mDiscStates . mX = & d1slopnfj2d . fu4515tfei ; simulationData ->
mData -> mModeVector . mN = 0 ; simulationData -> mData -> mModeVector . mX =
& d1slopnfj2d . dlhbeuzmaz ; tmp = false ; simulationData -> mData ->
mFoundZcEvents = tmp ; tmp = rtmIsMajorTimeStep ( hfoeutytij ) ;
simulationData -> mData -> mIsMajorTimeStep = tmp ; tmp_p =
_ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp_p ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; tmp_p = ssIsSolverComputingJacobian (
hfoeutytij -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsComputingJacobian = tmp_p ; tmp_f = ssGetEvaluatingF0ForJacobian (
hfoeutytij -> _mdlRefSfcnS ) ; simulationData -> mData -> mIsEvaluatingF0 = (
tmp_f != 0 ) ; simulationData -> mData -> mIsSolverRequestingReset = false ;
tmp_i [ 0 ] = 0 ; tmp_e [ 0 ] = lvuzhhuckmt . bs1e5cpoll [ 0 ] ; tmp_e [ 1 ]
= lvuzhhuckmt . bs1e5cpoll [ 1 ] ; tmp_e [ 2 ] = lvuzhhuckmt . bs1e5cpoll [ 2
] ; tmp_e [ 3 ] = lvuzhhuckmt . bs1e5cpoll [ 3 ] ; tmp_i [ 1 ] = 4 ; tmp_e [
4 ] = lvuzhhuckmt . k30tufukck [ 0 ] ; tmp_e [ 5 ] = lvuzhhuckmt . k30tufukck
[ 1 ] ; tmp_e [ 6 ] = lvuzhhuckmt . k30tufukck [ 2 ] ; tmp_e [ 7 ] =
lvuzhhuckmt . k30tufukck [ 3 ] ; tmp_i [ 2 ] = 8 ; tmp_e [ 8 ] = lvuzhhuckmt
. a0iis2ayez [ 0 ] ; tmp_e [ 9 ] = lvuzhhuckmt . a0iis2ayez [ 1 ] ; tmp_e [
10 ] = lvuzhhuckmt . a0iis2ayez [ 2 ] ; tmp_e [ 11 ] = lvuzhhuckmt .
a0iis2ayez [ 3 ] ; tmp_i [ 3 ] = 12 ; tmp_e [ 12 ] = lvuzhhuckmt . kzrjgwxloa
[ 0 ] ; tmp_e [ 13 ] = lvuzhhuckmt . kzrjgwxloa [ 1 ] ; tmp_e [ 14 ] =
lvuzhhuckmt . kzrjgwxloa [ 2 ] ; tmp_e [ 15 ] = lvuzhhuckmt . kzrjgwxloa [ 3
] ; tmp_i [ 4 ] = 16 ; tmp_e [ 16 ] = lvuzhhuckmt . h1mwn5bwbv [ 0 ] ; tmp_e
[ 17 ] = lvuzhhuckmt . h1mwn5bwbv [ 1 ] ; tmp_e [ 18 ] = lvuzhhuckmt .
h1mwn5bwbv [ 2 ] ; tmp_e [ 19 ] = lvuzhhuckmt . h1mwn5bwbv [ 3 ] ; tmp_i [ 5
] = 20 ; tmp_e [ 20 ] = lvuzhhuckmt . dw2p0ylolg [ 0 ] ; tmp_e [ 21 ] =
lvuzhhuckmt . dw2p0ylolg [ 1 ] ; tmp_e [ 22 ] = lvuzhhuckmt . dw2p0ylolg [ 2
] ; tmp_e [ 23 ] = lvuzhhuckmt . dw2p0ylolg [ 3 ] ; tmp_i [ 6 ] = 24 ;
simulationData -> mData -> mInputValues . mN = 24 ; simulationData -> mData
-> mInputValues . mX = & tmp_e [ 0 ] ; simulationData -> mData ->
mInputOffsets . mN = 7 ; simulationData -> mData -> mInputOffsets . mX = &
tmp_i [ 0 ] ; simulationData -> mData -> mDx . mN = 24 ; simulationData ->
mData -> mDx . mX = & localXdot -> lk3sdnwlk1 [ 0 ] ; diagnosticManager = (
NeuDiagnosticManager * ) d1slopnfj2d . ntdusjysav ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_m =
ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d . bl4aw00lkd ,
NESL_SIM_DERIVATIVES , simulationData , diagnosticManager ) ; if ( tmp_m != 0
) { tmp_p = error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij ->
_mdlRefSfcnS ) ) ; if ( tmp_p ) { msg = rtw_diagnostics_msg ( diagnosticTree
) ; ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; } } localXdot ->
nanyzdwn3h = ( lvuzhhuckmt . k0xye32kow [ 1 ] - localX -> nanyzdwn3h ) *
1000.0 ; localXdot -> fvut32tit4 = ( lvuzhhuckmt . k0xye32kow [ 3 ] - localX
-> fvut32tit4 ) * 1000.0 ; localXdot -> nu35g5ezne = ( lvuzhhuckmt .
k0xye32kow [ 5 ] - localX -> nu35g5ezne ) * 1000.0 ; localXdot -> n3zqzpztbu
= ( lvuzhhuckmt . k0xye32kow [ 7 ] - localX -> n3zqzpztbu ) * 1000.0 ;
localXdot -> gm135svjp2 = ( lvuzhhuckmt . k0xye32kow [ 9 ] - localX ->
gm135svjp2 ) * 1000.0 ; localXdot -> nm2azj1trc = ( lvuzhhuckmt . k0xye32kow
[ 11 ] - localX -> nm2azj1trc ) * 1000.0 ; localXdot -> bpmqwncjfj [ 0 ] =
localX -> bpmqwncjfj [ 1 ] ; localXdot -> bpmqwncjfj [ 1 ] = ( ( d1slopnfj2d
. mfarqvu45m - localX -> bpmqwncjfj [ 0 ] ) * 1000.0 - 2.0 * localX ->
bpmqwncjfj [ 1 ] ) * 1000.0 ; localXdot -> nvdqtjs5r2 [ 0 ] = localX ->
nvdqtjs5r2 [ 1 ] ; localXdot -> nvdqtjs5r2 [ 1 ] = ( ( d1slopnfj2d .
jrb1kz3zlg - localX -> nvdqtjs5r2 [ 0 ] ) * 1000.0 - 2.0 * localX ->
nvdqtjs5r2 [ 1 ] ) * 1000.0 ; localXdot -> or3kmp553n [ 0 ] = localX ->
or3kmp553n [ 1 ] ; localXdot -> or3kmp553n [ 1 ] = ( ( d1slopnfj2d .
koqgz4rjix - localX -> or3kmp553n [ 0 ] ) * 1000.0 - 2.0 * localX ->
or3kmp553n [ 1 ] ) * 1000.0 ; localXdot -> aij4dkucqh [ 0 ] = localX ->
aij4dkucqh [ 1 ] ; localXdot -> aij4dkucqh [ 1 ] = ( ( d1slopnfj2d .
d00cvtrow5 - localX -> aij4dkucqh [ 0 ] ) * 1000.0 - 2.0 * localX ->
aij4dkucqh [ 1 ] ) * 1000.0 ; localXdot -> fpzb5mu1i2 [ 0 ] = localX ->
fpzb5mu1i2 [ 1 ] ; localXdot -> fpzb5mu1i2 [ 1 ] = ( ( d1slopnfj2d .
d2ihml4pca - localX -> fpzb5mu1i2 [ 0 ] ) * 1000.0 - 2.0 * localX ->
fpzb5mu1i2 [ 1 ] ) * 1000.0 ; localXdot -> mctmaipokl [ 0 ] = localX ->
mctmaipokl [ 1 ] ; localXdot -> mctmaipokl [ 1 ] = ( ( d1slopnfj2d .
psdk3h03r4 - localX -> mctmaipokl [ 0 ] ) * 1000.0 - 2.0 * localX ->
mctmaipokl [ 1 ] ) * 1000.0 ; simulationData = ( NeslSimulationData * )
d1slopnfj2d . dojae3fabx ; time_p = time_tmp ; simulationData -> mData ->
mTime . mN = 1 ; simulationData -> mData -> mTime . mX = & time_p ;
simulationData -> mData -> mContStates . mN = 30 ; simulationData -> mData ->
mContStates . mX = & localX -> kgvozz1pdk [ 0 ] ; simulationData -> mData ->
mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX = &
d1slopnfj2d . g5juej3g4q ; simulationData -> mData -> mModeVector . mN = 6 ;
simulationData -> mData -> mModeVector . mX = & d1slopnfj2d . beljpehthd [ 0
] ; tmp_p = false ; simulationData -> mData -> mFoundZcEvents = tmp_p ;
simulationData -> mData -> mIsMajorTimeStep = tmp ; tmp =
_ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; tmp = ssIsSolverComputingJacobian ( hfoeutytij
-> _mdlRefSfcnS ) ; simulationData -> mData -> mIsComputingJacobian = tmp ;
simulationData -> mData -> mIsEvaluatingF0 = ( tmp_f != 0 ) ; simulationData
-> mData -> mIsSolverRequestingReset = false ; tmp_j [ 0 ] = 0 ; tmp_g [ 0 ]
= lvuzhhuckmt . jv20suu5kg [ 0 ] ; tmp_g [ 1 ] = lvuzhhuckmt . jv20suu5kg [ 1
] ; tmp_g [ 2 ] = lvuzhhuckmt . jv20suu5kg [ 2 ] ; tmp_g [ 3 ] = lvuzhhuckmt
. jv20suu5kg [ 3 ] ; tmp_j [ 1 ] = 4 ; tmp_g [ 4 ] = lvuzhhuckmt . mj4gjt33f3
[ 0 ] ; tmp_g [ 5 ] = lvuzhhuckmt . mj4gjt33f3 [ 1 ] ; tmp_g [ 6 ] =
lvuzhhuckmt . mj4gjt33f3 [ 2 ] ; tmp_g [ 7 ] = lvuzhhuckmt . mj4gjt33f3 [ 3 ]
; tmp_j [ 2 ] = 8 ; tmp_g [ 8 ] = lvuzhhuckmt . hwk0u4eoqn [ 0 ] ; tmp_g [ 9
] = lvuzhhuckmt . hwk0u4eoqn [ 1 ] ; tmp_g [ 10 ] = lvuzhhuckmt . hwk0u4eoqn
[ 2 ] ; tmp_g [ 11 ] = lvuzhhuckmt . hwk0u4eoqn [ 3 ] ; tmp_j [ 3 ] = 12 ;
tmp_g [ 12 ] = lvuzhhuckmt . mrjmcb1eaq [ 0 ] ; tmp_g [ 13 ] = lvuzhhuckmt .
mrjmcb1eaq [ 1 ] ; tmp_g [ 14 ] = lvuzhhuckmt . mrjmcb1eaq [ 2 ] ; tmp_g [ 15
] = lvuzhhuckmt . mrjmcb1eaq [ 3 ] ; tmp_j [ 4 ] = 16 ; tmp_g [ 16 ] =
lvuzhhuckmt . lhbimp5kmr [ 0 ] ; tmp_g [ 17 ] = lvuzhhuckmt . lhbimp5kmr [ 1
] ; tmp_g [ 18 ] = lvuzhhuckmt . lhbimp5kmr [ 2 ] ; tmp_g [ 19 ] =
lvuzhhuckmt . lhbimp5kmr [ 3 ] ; tmp_j [ 5 ] = 20 ; tmp_g [ 20 ] =
lvuzhhuckmt . idnqelgv01 [ 0 ] ; tmp_g [ 21 ] = lvuzhhuckmt . idnqelgv01 [ 1
] ; tmp_g [ 22 ] = lvuzhhuckmt . idnqelgv01 [ 2 ] ; tmp_g [ 23 ] =
lvuzhhuckmt . idnqelgv01 [ 3 ] ; tmp_j [ 6 ] = 24 ; tmp_g [ 24 ] =
lvuzhhuckmt . okzuauvitn [ 0 ] ; tmp_g [ 25 ] = lvuzhhuckmt . okzuauvitn [ 1
] ; tmp_g [ 26 ] = lvuzhhuckmt . okzuauvitn [ 2 ] ; tmp_g [ 27 ] =
lvuzhhuckmt . okzuauvitn [ 3 ] ; tmp_j [ 7 ] = 28 ; tmp_g [ 28 ] =
lvuzhhuckmt . hd5f3jh03c [ 0 ] ; tmp_g [ 29 ] = lvuzhhuckmt . hd5f3jh03c [ 1
] ; tmp_g [ 30 ] = lvuzhhuckmt . hd5f3jh03c [ 2 ] ; tmp_g [ 31 ] =
lvuzhhuckmt . hd5f3jh03c [ 3 ] ; tmp_j [ 8 ] = 32 ; tmp_g [ 32 ] =
lvuzhhuckmt . eqathlbtwk [ 0 ] ; tmp_g [ 33 ] = lvuzhhuckmt . eqathlbtwk [ 1
] ; tmp_g [ 34 ] = lvuzhhuckmt . eqathlbtwk [ 2 ] ; tmp_g [ 35 ] =
lvuzhhuckmt . eqathlbtwk [ 3 ] ; tmp_j [ 9 ] = 36 ; tmp_g [ 36 ] =
lvuzhhuckmt . o2jluiwonh [ 0 ] ; tmp_g [ 37 ] = lvuzhhuckmt . o2jluiwonh [ 1
] ; tmp_g [ 38 ] = lvuzhhuckmt . o2jluiwonh [ 2 ] ; tmp_g [ 39 ] =
lvuzhhuckmt . o2jluiwonh [ 3 ] ; tmp_j [ 10 ] = 40 ; tmp_g [ 40 ] =
lvuzhhuckmt . e23ad5ihp4 [ 0 ] ; tmp_g [ 41 ] = lvuzhhuckmt . e23ad5ihp4 [ 1
] ; tmp_g [ 42 ] = lvuzhhuckmt . e23ad5ihp4 [ 2 ] ; tmp_g [ 43 ] =
lvuzhhuckmt . e23ad5ihp4 [ 3 ] ; tmp_j [ 11 ] = 44 ; tmp_g [ 44 ] =
lvuzhhuckmt . ppj0cxlxco [ 0 ] ; tmp_g [ 45 ] = lvuzhhuckmt . ppj0cxlxco [ 1
] ; tmp_g [ 46 ] = lvuzhhuckmt . ppj0cxlxco [ 2 ] ; tmp_g [ 47 ] =
lvuzhhuckmt . ppj0cxlxco [ 3 ] ; tmp_j [ 12 ] = 48 ; simulationData -> mData
-> mInputValues . mN = 48 ; simulationData -> mData -> mInputValues . mX = &
tmp_g [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 13 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_j [ 0 ] ;
simulationData -> mData -> mDx . mN = 30 ; simulationData -> mData -> mDx .
mX = & localXdot -> kgvozz1pdk [ 0 ] ; diagnosticManager = (
NeuDiagnosticManager * ) d1slopnfj2d . eqhqru4bkb ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_f =
ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d . gqpntsbwxh ,
NESL_SIM_DERIVATIVES , simulationData , diagnosticManager ) ; if ( tmp_f != 0
) { tmp = error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij ->
_mdlRefSfcnS ) ) ; if ( tmp ) { msg = rtw_diagnostics_msg ( diagnosticTree )
; ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; } } } void
gzlvoih4gg ( real_T * localX_ ) { nbzsdh3gog * const hfoeutytij = & (
elvjztouut . rtm ) ; pu40142whda * localX = ( pu40142whda * ) localX_ ;
NeslSimulationData * simulationData ; real_T time ; boolean_T tmp ; boolean_T
tmp_p ; real_T tmp_e [ 24 ] ; int_T tmp_i [ 7 ] ; NeuDiagnosticManager *
diagnosticManager ; NeuDiagnosticTree * diagnosticTree ; int32_T tmp_m ; char
* msg ; real_T time_p ; real_T tmp_g [ 48 ] ; int_T tmp_j [ 13 ] ; real_T
time_tmp ; int32_T tmp_f ; simulationData = ( NeslSimulationData * )
d1slopnfj2d . fwekq1g4wz ; time_tmp = rtmGetTaskTime ( hfoeutytij , 0 ) ;
time = time_tmp ; simulationData -> mData -> mTime . mN = 1 ; simulationData
-> mData -> mTime . mX = & time ; simulationData -> mData -> mContStates . mN
= 24 ; simulationData -> mData -> mContStates . mX = & localX -> lk3sdnwlk1 [
0 ] ; simulationData -> mData -> mDiscStates . mN = 0 ; simulationData ->
mData -> mDiscStates . mX = & d1slopnfj2d . fu4515tfei ; simulationData ->
mData -> mModeVector . mN = 0 ; simulationData -> mData -> mModeVector . mX =
& d1slopnfj2d . dlhbeuzmaz ; tmp = false ; simulationData -> mData ->
mFoundZcEvents = tmp ; tmp = rtmIsMajorTimeStep ( hfoeutytij ) ;
simulationData -> mData -> mIsMajorTimeStep = tmp ; tmp_p =
_ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp_p ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; tmp_p = ssIsSolverComputingJacobian (
hfoeutytij -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsComputingJacobian = tmp_p ; tmp_f = ssGetEvaluatingF0ForJacobian (
hfoeutytij -> _mdlRefSfcnS ) ; simulationData -> mData -> mIsEvaluatingF0 = (
tmp_f != 0 ) ; simulationData -> mData -> mIsSolverRequestingReset = false ;
tmp_i [ 0 ] = 0 ; tmp_e [ 0 ] = lvuzhhuckmt . bs1e5cpoll [ 0 ] ; tmp_e [ 1 ]
= lvuzhhuckmt . bs1e5cpoll [ 1 ] ; tmp_e [ 2 ] = lvuzhhuckmt . bs1e5cpoll [ 2
] ; tmp_e [ 3 ] = lvuzhhuckmt . bs1e5cpoll [ 3 ] ; tmp_i [ 1 ] = 4 ; tmp_e [
4 ] = lvuzhhuckmt . k30tufukck [ 0 ] ; tmp_e [ 5 ] = lvuzhhuckmt . k30tufukck
[ 1 ] ; tmp_e [ 6 ] = lvuzhhuckmt . k30tufukck [ 2 ] ; tmp_e [ 7 ] =
lvuzhhuckmt . k30tufukck [ 3 ] ; tmp_i [ 2 ] = 8 ; tmp_e [ 8 ] = lvuzhhuckmt
. a0iis2ayez [ 0 ] ; tmp_e [ 9 ] = lvuzhhuckmt . a0iis2ayez [ 1 ] ; tmp_e [
10 ] = lvuzhhuckmt . a0iis2ayez [ 2 ] ; tmp_e [ 11 ] = lvuzhhuckmt .
a0iis2ayez [ 3 ] ; tmp_i [ 3 ] = 12 ; tmp_e [ 12 ] = lvuzhhuckmt . kzrjgwxloa
[ 0 ] ; tmp_e [ 13 ] = lvuzhhuckmt . kzrjgwxloa [ 1 ] ; tmp_e [ 14 ] =
lvuzhhuckmt . kzrjgwxloa [ 2 ] ; tmp_e [ 15 ] = lvuzhhuckmt . kzrjgwxloa [ 3
] ; tmp_i [ 4 ] = 16 ; tmp_e [ 16 ] = lvuzhhuckmt . h1mwn5bwbv [ 0 ] ; tmp_e
[ 17 ] = lvuzhhuckmt . h1mwn5bwbv [ 1 ] ; tmp_e [ 18 ] = lvuzhhuckmt .
h1mwn5bwbv [ 2 ] ; tmp_e [ 19 ] = lvuzhhuckmt . h1mwn5bwbv [ 3 ] ; tmp_i [ 5
] = 20 ; tmp_e [ 20 ] = lvuzhhuckmt . dw2p0ylolg [ 0 ] ; tmp_e [ 21 ] =
lvuzhhuckmt . dw2p0ylolg [ 1 ] ; tmp_e [ 22 ] = lvuzhhuckmt . dw2p0ylolg [ 2
] ; tmp_e [ 23 ] = lvuzhhuckmt . dw2p0ylolg [ 3 ] ; tmp_i [ 6 ] = 24 ;
simulationData -> mData -> mInputValues . mN = 24 ; simulationData -> mData
-> mInputValues . mX = & tmp_e [ 0 ] ; simulationData -> mData ->
mInputOffsets . mN = 7 ; simulationData -> mData -> mInputOffsets . mX = &
tmp_i [ 0 ] ; diagnosticManager = ( NeuDiagnosticManager * ) d1slopnfj2d .
ntdusjysav ; diagnosticTree = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; tmp_m = ne_simulator_method ( ( NeslSimulator * )
d1slopnfj2d . bl4aw00lkd , NESL_SIM_PROJECTION , simulationData ,
diagnosticManager ) ; if ( tmp_m != 0 ) { tmp_p = error_buffer_is_empty (
ssGetErrorStatus ( hfoeutytij -> _mdlRefSfcnS ) ) ; if ( tmp_p ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( hfoeutytij ->
_mdlRefSfcnS , msg ) ; } } simulationData = ( NeslSimulationData * )
d1slopnfj2d . dojae3fabx ; time_p = time_tmp ; simulationData -> mData ->
mTime . mN = 1 ; simulationData -> mData -> mTime . mX = & time_p ;
simulationData -> mData -> mContStates . mN = 30 ; simulationData -> mData ->
mContStates . mX = & localX -> kgvozz1pdk [ 0 ] ; simulationData -> mData ->
mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX = &
d1slopnfj2d . g5juej3g4q ; simulationData -> mData -> mModeVector . mN = 6 ;
simulationData -> mData -> mModeVector . mX = & d1slopnfj2d . beljpehthd [ 0
] ; tmp_p = false ; simulationData -> mData -> mFoundZcEvents = tmp_p ;
simulationData -> mData -> mIsMajorTimeStep = tmp ; tmp =
_ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; tmp = ssIsSolverComputingJacobian ( hfoeutytij
-> _mdlRefSfcnS ) ; simulationData -> mData -> mIsComputingJacobian = tmp ;
simulationData -> mData -> mIsEvaluatingF0 = ( tmp_f != 0 ) ; simulationData
-> mData -> mIsSolverRequestingReset = false ; tmp_j [ 0 ] = 0 ; tmp_g [ 0 ]
= lvuzhhuckmt . jv20suu5kg [ 0 ] ; tmp_g [ 1 ] = lvuzhhuckmt . jv20suu5kg [ 1
] ; tmp_g [ 2 ] = lvuzhhuckmt . jv20suu5kg [ 2 ] ; tmp_g [ 3 ] = lvuzhhuckmt
. jv20suu5kg [ 3 ] ; tmp_j [ 1 ] = 4 ; tmp_g [ 4 ] = lvuzhhuckmt . mj4gjt33f3
[ 0 ] ; tmp_g [ 5 ] = lvuzhhuckmt . mj4gjt33f3 [ 1 ] ; tmp_g [ 6 ] =
lvuzhhuckmt . mj4gjt33f3 [ 2 ] ; tmp_g [ 7 ] = lvuzhhuckmt . mj4gjt33f3 [ 3 ]
; tmp_j [ 2 ] = 8 ; tmp_g [ 8 ] = lvuzhhuckmt . hwk0u4eoqn [ 0 ] ; tmp_g [ 9
] = lvuzhhuckmt . hwk0u4eoqn [ 1 ] ; tmp_g [ 10 ] = lvuzhhuckmt . hwk0u4eoqn
[ 2 ] ; tmp_g [ 11 ] = lvuzhhuckmt . hwk0u4eoqn [ 3 ] ; tmp_j [ 3 ] = 12 ;
tmp_g [ 12 ] = lvuzhhuckmt . mrjmcb1eaq [ 0 ] ; tmp_g [ 13 ] = lvuzhhuckmt .
mrjmcb1eaq [ 1 ] ; tmp_g [ 14 ] = lvuzhhuckmt . mrjmcb1eaq [ 2 ] ; tmp_g [ 15
] = lvuzhhuckmt . mrjmcb1eaq [ 3 ] ; tmp_j [ 4 ] = 16 ; tmp_g [ 16 ] =
lvuzhhuckmt . lhbimp5kmr [ 0 ] ; tmp_g [ 17 ] = lvuzhhuckmt . lhbimp5kmr [ 1
] ; tmp_g [ 18 ] = lvuzhhuckmt . lhbimp5kmr [ 2 ] ; tmp_g [ 19 ] =
lvuzhhuckmt . lhbimp5kmr [ 3 ] ; tmp_j [ 5 ] = 20 ; tmp_g [ 20 ] =
lvuzhhuckmt . idnqelgv01 [ 0 ] ; tmp_g [ 21 ] = lvuzhhuckmt . idnqelgv01 [ 1
] ; tmp_g [ 22 ] = lvuzhhuckmt . idnqelgv01 [ 2 ] ; tmp_g [ 23 ] =
lvuzhhuckmt . idnqelgv01 [ 3 ] ; tmp_j [ 6 ] = 24 ; tmp_g [ 24 ] =
lvuzhhuckmt . okzuauvitn [ 0 ] ; tmp_g [ 25 ] = lvuzhhuckmt . okzuauvitn [ 1
] ; tmp_g [ 26 ] = lvuzhhuckmt . okzuauvitn [ 2 ] ; tmp_g [ 27 ] =
lvuzhhuckmt . okzuauvitn [ 3 ] ; tmp_j [ 7 ] = 28 ; tmp_g [ 28 ] =
lvuzhhuckmt . hd5f3jh03c [ 0 ] ; tmp_g [ 29 ] = lvuzhhuckmt . hd5f3jh03c [ 1
] ; tmp_g [ 30 ] = lvuzhhuckmt . hd5f3jh03c [ 2 ] ; tmp_g [ 31 ] =
lvuzhhuckmt . hd5f3jh03c [ 3 ] ; tmp_j [ 8 ] = 32 ; tmp_g [ 32 ] =
lvuzhhuckmt . eqathlbtwk [ 0 ] ; tmp_g [ 33 ] = lvuzhhuckmt . eqathlbtwk [ 1
] ; tmp_g [ 34 ] = lvuzhhuckmt . eqathlbtwk [ 2 ] ; tmp_g [ 35 ] =
lvuzhhuckmt . eqathlbtwk [ 3 ] ; tmp_j [ 9 ] = 36 ; tmp_g [ 36 ] =
lvuzhhuckmt . o2jluiwonh [ 0 ] ; tmp_g [ 37 ] = lvuzhhuckmt . o2jluiwonh [ 1
] ; tmp_g [ 38 ] = lvuzhhuckmt . o2jluiwonh [ 2 ] ; tmp_g [ 39 ] =
lvuzhhuckmt . o2jluiwonh [ 3 ] ; tmp_j [ 10 ] = 40 ; tmp_g [ 40 ] =
lvuzhhuckmt . e23ad5ihp4 [ 0 ] ; tmp_g [ 41 ] = lvuzhhuckmt . e23ad5ihp4 [ 1
] ; tmp_g [ 42 ] = lvuzhhuckmt . e23ad5ihp4 [ 2 ] ; tmp_g [ 43 ] =
lvuzhhuckmt . e23ad5ihp4 [ 3 ] ; tmp_j [ 11 ] = 44 ; tmp_g [ 44 ] =
lvuzhhuckmt . ppj0cxlxco [ 0 ] ; tmp_g [ 45 ] = lvuzhhuckmt . ppj0cxlxco [ 1
] ; tmp_g [ 46 ] = lvuzhhuckmt . ppj0cxlxco [ 2 ] ; tmp_g [ 47 ] =
lvuzhhuckmt . ppj0cxlxco [ 3 ] ; tmp_j [ 12 ] = 48 ; simulationData -> mData
-> mInputValues . mN = 48 ; simulationData -> mData -> mInputValues . mX = &
tmp_g [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 13 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_j [ 0 ] ;
diagnosticManager = ( NeuDiagnosticManager * ) d1slopnfj2d . eqhqru4bkb ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; tmp_f = ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d .
gqpntsbwxh , NESL_SIM_PROJECTION , simulationData , diagnosticManager ) ; if
( tmp_f != 0 ) { tmp = error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij
-> _mdlRefSfcnS ) ) ; if ( tmp ) { msg = rtw_diagnostics_msg ( diagnosticTree
) ; ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; } } } void
g3gadye0b3 ( real_T * localX_ , real_T * localXdot_ ) { nbzsdh3gog * const
hfoeutytij = & ( elvjztouut . rtm ) ; pu40142whda * localX = ( pu40142whda *
) localX_ ; id24jk0x2ms * localXdot = ( id24jk0x2ms * ) localXdot_ ;
NeslSimulationData * simulationData ; real_T time ; boolean_T tmp ; boolean_T
tmp_p ; real_T tmp_e [ 24 ] ; int_T tmp_i [ 7 ] ; NeuDiagnosticManager *
diagnosticManager ; NeuDiagnosticTree * diagnosticTree ; int32_T tmp_m ; char
* msg ; real_T time_p ; real_T tmp_g [ 48 ] ; int_T tmp_j [ 13 ] ; real_T
time_tmp ; int32_T tmp_f ; simulationData = ( NeslSimulationData * )
d1slopnfj2d . fwekq1g4wz ; time_tmp = rtmGetTaskTime ( hfoeutytij , 0 ) ;
time = time_tmp ; simulationData -> mData -> mTime . mN = 1 ; simulationData
-> mData -> mTime . mX = & time ; simulationData -> mData -> mContStates . mN
= 24 ; simulationData -> mData -> mContStates . mX = & localX -> lk3sdnwlk1 [
0 ] ; simulationData -> mData -> mDiscStates . mN = 0 ; simulationData ->
mData -> mDiscStates . mX = & d1slopnfj2d . fu4515tfei ; simulationData ->
mData -> mModeVector . mN = 0 ; simulationData -> mData -> mModeVector . mX =
& d1slopnfj2d . dlhbeuzmaz ; tmp = false ; simulationData -> mData ->
mFoundZcEvents = tmp ; tmp = rtmIsMajorTimeStep ( hfoeutytij ) ;
simulationData -> mData -> mIsMajorTimeStep = tmp ; tmp_p =
_ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp_p ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; tmp_p = ssIsSolverComputingJacobian (
hfoeutytij -> _mdlRefSfcnS ) ; simulationData -> mData ->
mIsComputingJacobian = tmp_p ; tmp_f = ssGetEvaluatingF0ForJacobian (
hfoeutytij -> _mdlRefSfcnS ) ; simulationData -> mData -> mIsEvaluatingF0 = (
tmp_f != 0 ) ; simulationData -> mData -> mIsSolverRequestingReset = false ;
tmp_i [ 0 ] = 0 ; tmp_e [ 0 ] = lvuzhhuckmt . bs1e5cpoll [ 0 ] ; tmp_e [ 1 ]
= lvuzhhuckmt . bs1e5cpoll [ 1 ] ; tmp_e [ 2 ] = lvuzhhuckmt . bs1e5cpoll [ 2
] ; tmp_e [ 3 ] = lvuzhhuckmt . bs1e5cpoll [ 3 ] ; tmp_i [ 1 ] = 4 ; tmp_e [
4 ] = lvuzhhuckmt . k30tufukck [ 0 ] ; tmp_e [ 5 ] = lvuzhhuckmt . k30tufukck
[ 1 ] ; tmp_e [ 6 ] = lvuzhhuckmt . k30tufukck [ 2 ] ; tmp_e [ 7 ] =
lvuzhhuckmt . k30tufukck [ 3 ] ; tmp_i [ 2 ] = 8 ; tmp_e [ 8 ] = lvuzhhuckmt
. a0iis2ayez [ 0 ] ; tmp_e [ 9 ] = lvuzhhuckmt . a0iis2ayez [ 1 ] ; tmp_e [
10 ] = lvuzhhuckmt . a0iis2ayez [ 2 ] ; tmp_e [ 11 ] = lvuzhhuckmt .
a0iis2ayez [ 3 ] ; tmp_i [ 3 ] = 12 ; tmp_e [ 12 ] = lvuzhhuckmt . kzrjgwxloa
[ 0 ] ; tmp_e [ 13 ] = lvuzhhuckmt . kzrjgwxloa [ 1 ] ; tmp_e [ 14 ] =
lvuzhhuckmt . kzrjgwxloa [ 2 ] ; tmp_e [ 15 ] = lvuzhhuckmt . kzrjgwxloa [ 3
] ; tmp_i [ 4 ] = 16 ; tmp_e [ 16 ] = lvuzhhuckmt . h1mwn5bwbv [ 0 ] ; tmp_e
[ 17 ] = lvuzhhuckmt . h1mwn5bwbv [ 1 ] ; tmp_e [ 18 ] = lvuzhhuckmt .
h1mwn5bwbv [ 2 ] ; tmp_e [ 19 ] = lvuzhhuckmt . h1mwn5bwbv [ 3 ] ; tmp_i [ 5
] = 20 ; tmp_e [ 20 ] = lvuzhhuckmt . dw2p0ylolg [ 0 ] ; tmp_e [ 21 ] =
lvuzhhuckmt . dw2p0ylolg [ 1 ] ; tmp_e [ 22 ] = lvuzhhuckmt . dw2p0ylolg [ 2
] ; tmp_e [ 23 ] = lvuzhhuckmt . dw2p0ylolg [ 3 ] ; tmp_i [ 6 ] = 24 ;
simulationData -> mData -> mInputValues . mN = 24 ; simulationData -> mData
-> mInputValues . mX = & tmp_e [ 0 ] ; simulationData -> mData ->
mInputOffsets . mN = 7 ; simulationData -> mData -> mInputOffsets . mX = &
tmp_i [ 0 ] ; simulationData -> mData -> mDx . mN = 24 ; simulationData ->
mData -> mDx . mX = & localXdot -> lk3sdnwlk1 [ 0 ] ; diagnosticManager = (
NeuDiagnosticManager * ) d1slopnfj2d . ntdusjysav ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_m =
ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d . bl4aw00lkd ,
NESL_SIM_DERIVATIVES , simulationData , diagnosticManager ) ; if ( tmp_m != 0
) { tmp_p = error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij ->
_mdlRefSfcnS ) ) ; if ( tmp_p ) { msg = rtw_diagnostics_msg ( diagnosticTree
) ; ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; } } localXdot ->
nanyzdwn3h = ( lvuzhhuckmt . k0xye32kow [ 1 ] - localX -> nanyzdwn3h ) *
1000.0 ; localXdot -> fvut32tit4 = ( lvuzhhuckmt . k0xye32kow [ 3 ] - localX
-> fvut32tit4 ) * 1000.0 ; localXdot -> nu35g5ezne = ( lvuzhhuckmt .
k0xye32kow [ 5 ] - localX -> nu35g5ezne ) * 1000.0 ; localXdot -> n3zqzpztbu
= ( lvuzhhuckmt . k0xye32kow [ 7 ] - localX -> n3zqzpztbu ) * 1000.0 ;
localXdot -> gm135svjp2 = ( lvuzhhuckmt . k0xye32kow [ 9 ] - localX ->
gm135svjp2 ) * 1000.0 ; localXdot -> nm2azj1trc = ( lvuzhhuckmt . k0xye32kow
[ 11 ] - localX -> nm2azj1trc ) * 1000.0 ; localXdot -> bpmqwncjfj [ 0 ] =
localX -> bpmqwncjfj [ 1 ] ; localXdot -> bpmqwncjfj [ 1 ] = ( ( d1slopnfj2d
. mfarqvu45m - localX -> bpmqwncjfj [ 0 ] ) * 1000.0 - 2.0 * localX ->
bpmqwncjfj [ 1 ] ) * 1000.0 ; localXdot -> nvdqtjs5r2 [ 0 ] = localX ->
nvdqtjs5r2 [ 1 ] ; localXdot -> nvdqtjs5r2 [ 1 ] = ( ( d1slopnfj2d .
jrb1kz3zlg - localX -> nvdqtjs5r2 [ 0 ] ) * 1000.0 - 2.0 * localX ->
nvdqtjs5r2 [ 1 ] ) * 1000.0 ; localXdot -> or3kmp553n [ 0 ] = localX ->
or3kmp553n [ 1 ] ; localXdot -> or3kmp553n [ 1 ] = ( ( d1slopnfj2d .
koqgz4rjix - localX -> or3kmp553n [ 0 ] ) * 1000.0 - 2.0 * localX ->
or3kmp553n [ 1 ] ) * 1000.0 ; localXdot -> aij4dkucqh [ 0 ] = localX ->
aij4dkucqh [ 1 ] ; localXdot -> aij4dkucqh [ 1 ] = ( ( d1slopnfj2d .
d00cvtrow5 - localX -> aij4dkucqh [ 0 ] ) * 1000.0 - 2.0 * localX ->
aij4dkucqh [ 1 ] ) * 1000.0 ; localXdot -> fpzb5mu1i2 [ 0 ] = localX ->
fpzb5mu1i2 [ 1 ] ; localXdot -> fpzb5mu1i2 [ 1 ] = ( ( d1slopnfj2d .
d2ihml4pca - localX -> fpzb5mu1i2 [ 0 ] ) * 1000.0 - 2.0 * localX ->
fpzb5mu1i2 [ 1 ] ) * 1000.0 ; localXdot -> mctmaipokl [ 0 ] = localX ->
mctmaipokl [ 1 ] ; localXdot -> mctmaipokl [ 1 ] = ( ( d1slopnfj2d .
psdk3h03r4 - localX -> mctmaipokl [ 0 ] ) * 1000.0 - 2.0 * localX ->
mctmaipokl [ 1 ] ) * 1000.0 ; simulationData = ( NeslSimulationData * )
d1slopnfj2d . dojae3fabx ; time_p = time_tmp ; simulationData -> mData ->
mTime . mN = 1 ; simulationData -> mData -> mTime . mX = & time_p ;
simulationData -> mData -> mContStates . mN = 30 ; simulationData -> mData ->
mContStates . mX = & localX -> kgvozz1pdk [ 0 ] ; simulationData -> mData ->
mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX = &
d1slopnfj2d . g5juej3g4q ; simulationData -> mData -> mModeVector . mN = 6 ;
simulationData -> mData -> mModeVector . mX = & d1slopnfj2d . beljpehthd [ 0
] ; tmp_p = false ; simulationData -> mData -> mFoundZcEvents = tmp_p ;
simulationData -> mData -> mIsMajorTimeStep = tmp ; tmp =
_ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; tmp = ssIsSolverComputingJacobian ( hfoeutytij
-> _mdlRefSfcnS ) ; simulationData -> mData -> mIsComputingJacobian = tmp ;
simulationData -> mData -> mIsEvaluatingF0 = ( tmp_f != 0 ) ; simulationData
-> mData -> mIsSolverRequestingReset = false ; tmp_j [ 0 ] = 0 ; tmp_g [ 0 ]
= lvuzhhuckmt . jv20suu5kg [ 0 ] ; tmp_g [ 1 ] = lvuzhhuckmt . jv20suu5kg [ 1
] ; tmp_g [ 2 ] = lvuzhhuckmt . jv20suu5kg [ 2 ] ; tmp_g [ 3 ] = lvuzhhuckmt
. jv20suu5kg [ 3 ] ; tmp_j [ 1 ] = 4 ; tmp_g [ 4 ] = lvuzhhuckmt . mj4gjt33f3
[ 0 ] ; tmp_g [ 5 ] = lvuzhhuckmt . mj4gjt33f3 [ 1 ] ; tmp_g [ 6 ] =
lvuzhhuckmt . mj4gjt33f3 [ 2 ] ; tmp_g [ 7 ] = lvuzhhuckmt . mj4gjt33f3 [ 3 ]
; tmp_j [ 2 ] = 8 ; tmp_g [ 8 ] = lvuzhhuckmt . hwk0u4eoqn [ 0 ] ; tmp_g [ 9
] = lvuzhhuckmt . hwk0u4eoqn [ 1 ] ; tmp_g [ 10 ] = lvuzhhuckmt . hwk0u4eoqn
[ 2 ] ; tmp_g [ 11 ] = lvuzhhuckmt . hwk0u4eoqn [ 3 ] ; tmp_j [ 3 ] = 12 ;
tmp_g [ 12 ] = lvuzhhuckmt . mrjmcb1eaq [ 0 ] ; tmp_g [ 13 ] = lvuzhhuckmt .
mrjmcb1eaq [ 1 ] ; tmp_g [ 14 ] = lvuzhhuckmt . mrjmcb1eaq [ 2 ] ; tmp_g [ 15
] = lvuzhhuckmt . mrjmcb1eaq [ 3 ] ; tmp_j [ 4 ] = 16 ; tmp_g [ 16 ] =
lvuzhhuckmt . lhbimp5kmr [ 0 ] ; tmp_g [ 17 ] = lvuzhhuckmt . lhbimp5kmr [ 1
] ; tmp_g [ 18 ] = lvuzhhuckmt . lhbimp5kmr [ 2 ] ; tmp_g [ 19 ] =
lvuzhhuckmt . lhbimp5kmr [ 3 ] ; tmp_j [ 5 ] = 20 ; tmp_g [ 20 ] =
lvuzhhuckmt . idnqelgv01 [ 0 ] ; tmp_g [ 21 ] = lvuzhhuckmt . idnqelgv01 [ 1
] ; tmp_g [ 22 ] = lvuzhhuckmt . idnqelgv01 [ 2 ] ; tmp_g [ 23 ] =
lvuzhhuckmt . idnqelgv01 [ 3 ] ; tmp_j [ 6 ] = 24 ; tmp_g [ 24 ] =
lvuzhhuckmt . okzuauvitn [ 0 ] ; tmp_g [ 25 ] = lvuzhhuckmt . okzuauvitn [ 1
] ; tmp_g [ 26 ] = lvuzhhuckmt . okzuauvitn [ 2 ] ; tmp_g [ 27 ] =
lvuzhhuckmt . okzuauvitn [ 3 ] ; tmp_j [ 7 ] = 28 ; tmp_g [ 28 ] =
lvuzhhuckmt . hd5f3jh03c [ 0 ] ; tmp_g [ 29 ] = lvuzhhuckmt . hd5f3jh03c [ 1
] ; tmp_g [ 30 ] = lvuzhhuckmt . hd5f3jh03c [ 2 ] ; tmp_g [ 31 ] =
lvuzhhuckmt . hd5f3jh03c [ 3 ] ; tmp_j [ 8 ] = 32 ; tmp_g [ 32 ] =
lvuzhhuckmt . eqathlbtwk [ 0 ] ; tmp_g [ 33 ] = lvuzhhuckmt . eqathlbtwk [ 1
] ; tmp_g [ 34 ] = lvuzhhuckmt . eqathlbtwk [ 2 ] ; tmp_g [ 35 ] =
lvuzhhuckmt . eqathlbtwk [ 3 ] ; tmp_j [ 9 ] = 36 ; tmp_g [ 36 ] =
lvuzhhuckmt . o2jluiwonh [ 0 ] ; tmp_g [ 37 ] = lvuzhhuckmt . o2jluiwonh [ 1
] ; tmp_g [ 38 ] = lvuzhhuckmt . o2jluiwonh [ 2 ] ; tmp_g [ 39 ] =
lvuzhhuckmt . o2jluiwonh [ 3 ] ; tmp_j [ 10 ] = 40 ; tmp_g [ 40 ] =
lvuzhhuckmt . e23ad5ihp4 [ 0 ] ; tmp_g [ 41 ] = lvuzhhuckmt . e23ad5ihp4 [ 1
] ; tmp_g [ 42 ] = lvuzhhuckmt . e23ad5ihp4 [ 2 ] ; tmp_g [ 43 ] =
lvuzhhuckmt . e23ad5ihp4 [ 3 ] ; tmp_j [ 11 ] = 44 ; tmp_g [ 44 ] =
lvuzhhuckmt . ppj0cxlxco [ 0 ] ; tmp_g [ 45 ] = lvuzhhuckmt . ppj0cxlxco [ 1
] ; tmp_g [ 46 ] = lvuzhhuckmt . ppj0cxlxco [ 2 ] ; tmp_g [ 47 ] =
lvuzhhuckmt . ppj0cxlxco [ 3 ] ; tmp_j [ 12 ] = 48 ; simulationData -> mData
-> mInputValues . mN = 48 ; simulationData -> mData -> mInputValues . mX = &
tmp_g [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 13 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_j [ 0 ] ;
simulationData -> mData -> mDx . mN = 30 ; simulationData -> mData -> mDx .
mX = & localXdot -> kgvozz1pdk [ 0 ] ; diagnosticManager = (
NeuDiagnosticManager * ) d1slopnfj2d . eqhqru4bkb ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_f =
ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d . gqpntsbwxh ,
NESL_SIM_FORCINGFUNCTION , simulationData , diagnosticManager ) ; if ( tmp_f
!= 0 ) { tmp = error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij ->
_mdlRefSfcnS ) ) ; if ( tmp ) { msg = rtw_diagnostics_msg ( diagnosticTree )
; ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; } } } void
a1stgek52t ( real_T * localX_ ) { nbzsdh3gog * const hfoeutytij = & (
elvjztouut . rtm ) ; pu40142whda * localX = ( pu40142whda * ) localX_ ;
NeslSimulationData * simulationData ; real_T time ; boolean_T tmp ; real_T
tmp_p [ 48 ] ; int_T tmp_e [ 13 ] ; real_T * tmp_i ; NeuDiagnosticManager *
diagnosticManager ; NeuDiagnosticTree * diagnosticTree ; int32_T tmp_m ; char
* msg ; simulationData = ( NeslSimulationData * ) d1slopnfj2d . dojae3fabx ;
time = rtmGetTaskTime ( hfoeutytij , 0 ) ; simulationData -> mData -> mTime .
mN = 1 ; simulationData -> mData -> mTime . mX = & time ; simulationData ->
mData -> mContStates . mN = 30 ; simulationData -> mData -> mContStates . mX
= & localX -> kgvozz1pdk [ 0 ] ; simulationData -> mData -> mDiscStates . mN
= 0 ; simulationData -> mData -> mDiscStates . mX = & d1slopnfj2d .
g5juej3g4q ; simulationData -> mData -> mModeVector . mN = 6 ; simulationData
-> mData -> mModeVector . mX = & d1slopnfj2d . beljpehthd [ 0 ] ; tmp = false
; simulationData -> mData -> mFoundZcEvents = tmp ; simulationData -> mData
-> mIsMajorTimeStep = rtmIsMajorTimeStep ( hfoeutytij ) ; tmp =
_ssGetSolverAssertCheck ( hfoeutytij -> _mdlRefSfcnS ) ; simulationData ->
mData -> mIsSolverAssertCheck = tmp ; simulationData -> mData ->
mIsSolverCheckingCIC = false ; tmp = ssIsSolverComputingJacobian ( hfoeutytij
-> _mdlRefSfcnS ) ; simulationData -> mData -> mIsComputingJacobian = tmp ;
simulationData -> mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian (
hfoeutytij -> _mdlRefSfcnS ) != 0 ) ; simulationData -> mData ->
mIsSolverRequestingReset = false ; tmp_e [ 0 ] = 0 ; tmp_p [ 0 ] =
lvuzhhuckmt . jv20suu5kg [ 0 ] ; tmp_p [ 1 ] = lvuzhhuckmt . jv20suu5kg [ 1 ]
; tmp_p [ 2 ] = lvuzhhuckmt . jv20suu5kg [ 2 ] ; tmp_p [ 3 ] = lvuzhhuckmt .
jv20suu5kg [ 3 ] ; tmp_e [ 1 ] = 4 ; tmp_p [ 4 ] = lvuzhhuckmt . mj4gjt33f3 [
0 ] ; tmp_p [ 5 ] = lvuzhhuckmt . mj4gjt33f3 [ 1 ] ; tmp_p [ 6 ] =
lvuzhhuckmt . mj4gjt33f3 [ 2 ] ; tmp_p [ 7 ] = lvuzhhuckmt . mj4gjt33f3 [ 3 ]
; tmp_e [ 2 ] = 8 ; tmp_p [ 8 ] = lvuzhhuckmt . hwk0u4eoqn [ 0 ] ; tmp_p [ 9
] = lvuzhhuckmt . hwk0u4eoqn [ 1 ] ; tmp_p [ 10 ] = lvuzhhuckmt . hwk0u4eoqn
[ 2 ] ; tmp_p [ 11 ] = lvuzhhuckmt . hwk0u4eoqn [ 3 ] ; tmp_e [ 3 ] = 12 ;
tmp_p [ 12 ] = lvuzhhuckmt . mrjmcb1eaq [ 0 ] ; tmp_p [ 13 ] = lvuzhhuckmt .
mrjmcb1eaq [ 1 ] ; tmp_p [ 14 ] = lvuzhhuckmt . mrjmcb1eaq [ 2 ] ; tmp_p [ 15
] = lvuzhhuckmt . mrjmcb1eaq [ 3 ] ; tmp_e [ 4 ] = 16 ; tmp_p [ 16 ] =
lvuzhhuckmt . lhbimp5kmr [ 0 ] ; tmp_p [ 17 ] = lvuzhhuckmt . lhbimp5kmr [ 1
] ; tmp_p [ 18 ] = lvuzhhuckmt . lhbimp5kmr [ 2 ] ; tmp_p [ 19 ] =
lvuzhhuckmt . lhbimp5kmr [ 3 ] ; tmp_e [ 5 ] = 20 ; tmp_p [ 20 ] =
lvuzhhuckmt . idnqelgv01 [ 0 ] ; tmp_p [ 21 ] = lvuzhhuckmt . idnqelgv01 [ 1
] ; tmp_p [ 22 ] = lvuzhhuckmt . idnqelgv01 [ 2 ] ; tmp_p [ 23 ] =
lvuzhhuckmt . idnqelgv01 [ 3 ] ; tmp_e [ 6 ] = 24 ; tmp_p [ 24 ] =
lvuzhhuckmt . okzuauvitn [ 0 ] ; tmp_p [ 25 ] = lvuzhhuckmt . okzuauvitn [ 1
] ; tmp_p [ 26 ] = lvuzhhuckmt . okzuauvitn [ 2 ] ; tmp_p [ 27 ] =
lvuzhhuckmt . okzuauvitn [ 3 ] ; tmp_e [ 7 ] = 28 ; tmp_p [ 28 ] =
lvuzhhuckmt . hd5f3jh03c [ 0 ] ; tmp_p [ 29 ] = lvuzhhuckmt . hd5f3jh03c [ 1
] ; tmp_p [ 30 ] = lvuzhhuckmt . hd5f3jh03c [ 2 ] ; tmp_p [ 31 ] =
lvuzhhuckmt . hd5f3jh03c [ 3 ] ; tmp_e [ 8 ] = 32 ; tmp_p [ 32 ] =
lvuzhhuckmt . eqathlbtwk [ 0 ] ; tmp_p [ 33 ] = lvuzhhuckmt . eqathlbtwk [ 1
] ; tmp_p [ 34 ] = lvuzhhuckmt . eqathlbtwk [ 2 ] ; tmp_p [ 35 ] =
lvuzhhuckmt . eqathlbtwk [ 3 ] ; tmp_e [ 9 ] = 36 ; tmp_p [ 36 ] =
lvuzhhuckmt . o2jluiwonh [ 0 ] ; tmp_p [ 37 ] = lvuzhhuckmt . o2jluiwonh [ 1
] ; tmp_p [ 38 ] = lvuzhhuckmt . o2jluiwonh [ 2 ] ; tmp_p [ 39 ] =
lvuzhhuckmt . o2jluiwonh [ 3 ] ; tmp_e [ 10 ] = 40 ; tmp_p [ 40 ] =
lvuzhhuckmt . e23ad5ihp4 [ 0 ] ; tmp_p [ 41 ] = lvuzhhuckmt . e23ad5ihp4 [ 1
] ; tmp_p [ 42 ] = lvuzhhuckmt . e23ad5ihp4 [ 2 ] ; tmp_p [ 43 ] =
lvuzhhuckmt . e23ad5ihp4 [ 3 ] ; tmp_e [ 11 ] = 44 ; tmp_p [ 44 ] =
lvuzhhuckmt . ppj0cxlxco [ 0 ] ; tmp_p [ 45 ] = lvuzhhuckmt . ppj0cxlxco [ 1
] ; tmp_p [ 46 ] = lvuzhhuckmt . ppj0cxlxco [ 2 ] ; tmp_p [ 47 ] =
lvuzhhuckmt . ppj0cxlxco [ 3 ] ; tmp_e [ 12 ] = 48 ; simulationData -> mData
-> mInputValues . mN = 48 ; simulationData -> mData -> mInputValues . mX = &
tmp_p [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 13 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_e [ 0 ] ; tmp_i =
hfoeutytij -> massMatrixBasePr ; tmp_i = double_pointer_shift ( tmp_i ,
d1slopnfj2d . f3vldgt55s ) ; simulationData -> mData -> mMassMatrixPr . mN =
18 ; simulationData -> mData -> mMassMatrixPr . mX = tmp_i ;
diagnosticManager = ( NeuDiagnosticManager * ) d1slopnfj2d . eqhqru4bkb ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; tmp_m = ne_simulator_method ( ( NeslSimulator * ) d1slopnfj2d .
gqpntsbwxh , NESL_SIM_MASSMATRIX , simulationData , diagnosticManager ) ; if
( tmp_m != 0 ) { tmp = error_buffer_is_empty ( ssGetErrorStatus ( hfoeutytij
-> _mdlRefSfcnS ) ) ; if ( tmp ) { msg = rtw_diagnostics_msg ( diagnosticTree
) ; ssSetErrorStatus ( hfoeutytij -> _mdlRefSfcnS , msg ) ; } } } void
cpsgcdfxop ( void ) { nbzsdh3gog * const hfoeutytij = & ( elvjztouut . rtm )
; if ( ( ssGetSimMode ( hfoeutytij -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL )
&& ( ( hfoeutytij -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if ( d1slopnfj2d . ne4l15gebh .
AQHandles ) { sdiTerminateStreaming ( & d1slopnfj2d . ne4l15gebh . AQHandles
) ; } if ( d1slopnfj2d . ne4l15gebh . SlioLTF ) { rtwDestructAccessorPointer
( d1slopnfj2d . ne4l15gebh . SlioLTF ) ; } } if ( ( ssGetSimMode ( hfoeutytij
-> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && ( ( hfoeutytij -> _mdlRefSfcnS
) -> mdlInfo -> rtwgenMode != SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if (
d1slopnfj2d . h30jmamuoh . AQHandles [ 0 ] ) { sdiTerminateStreaming ( &
d1slopnfj2d . h30jmamuoh . AQHandles [ 0 ] ) ; } if ( d1slopnfj2d .
h30jmamuoh . AQHandles [ 1 ] ) { sdiTerminateStreaming ( & d1slopnfj2d .
h30jmamuoh . AQHandles [ 1 ] ) ; } if ( d1slopnfj2d . h30jmamuoh . AQHandles
[ 2 ] ) { sdiTerminateStreaming ( & d1slopnfj2d . h30jmamuoh . AQHandles [ 2
] ) ; } if ( d1slopnfj2d . h30jmamuoh . AQHandles [ 3 ] ) {
sdiTerminateStreaming ( & d1slopnfj2d . h30jmamuoh . AQHandles [ 3 ] ) ; } if
( d1slopnfj2d . h30jmamuoh . AQHandles [ 4 ] ) { sdiTerminateStreaming ( &
d1slopnfj2d . h30jmamuoh . AQHandles [ 4 ] ) ; } if ( d1slopnfj2d .
h30jmamuoh . AQHandles [ 5 ] ) { sdiTerminateStreaming ( & d1slopnfj2d .
h30jmamuoh . AQHandles [ 5 ] ) ; } if ( d1slopnfj2d . h30jmamuoh . SlioLTF )
{ rtwDestructAccessorPointer ( d1slopnfj2d . h30jmamuoh . SlioLTF ) ; } } if
( ( ssGetSimMode ( hfoeutytij -> _mdlRefSfcnS ) != SS_SIMMODE_EXTERNAL ) && (
( hfoeutytij -> _mdlRefSfcnS ) -> mdlInfo -> rtwgenMode !=
SS_RTWGEN_MODELREFERENCE_RTW_TARGET ) ) { if ( d1slopnfj2d . d1shbopr2m .
AQHandles [ 0 ] ) { sdiTerminateStreaming ( & d1slopnfj2d . d1shbopr2m .
AQHandles [ 0 ] ) ; } if ( d1slopnfj2d . d1shbopr2m . AQHandles [ 1 ] ) {
sdiTerminateStreaming ( & d1slopnfj2d . d1shbopr2m . AQHandles [ 1 ] ) ; } if
( d1slopnfj2d . d1shbopr2m . AQHandles [ 2 ] ) { sdiTerminateStreaming ( &
d1slopnfj2d . d1shbopr2m . AQHandles [ 2 ] ) ; } if ( d1slopnfj2d .
d1shbopr2m . AQHandles [ 3 ] ) { sdiTerminateStreaming ( & d1slopnfj2d .
d1shbopr2m . AQHandles [ 3 ] ) ; } if ( d1slopnfj2d . d1shbopr2m . AQHandles
[ 4 ] ) { sdiTerminateStreaming ( & d1slopnfj2d . d1shbopr2m . AQHandles [ 4
] ) ; } if ( d1slopnfj2d . d1shbopr2m . AQHandles [ 5 ] ) {
sdiTerminateStreaming ( & d1slopnfj2d . d1shbopr2m . AQHandles [ 5 ] ) ; } if
( d1slopnfj2d . d1shbopr2m . SlioLTF ) { rtwDestructAccessorPointer (
d1slopnfj2d . d1shbopr2m . SlioLTF ) ; } } } void bsskyrygm1 ( void ) {
nbzsdh3gog * const hfoeutytij = & ( elvjztouut . rtm ) ;
neu_destroy_diagnostic_manager ( ( NeuDiagnosticManager * ) d1slopnfj2d .
ntdusjysav ) ; nesl_destroy_simulation_data ( ( NeslSimulationData * )
d1slopnfj2d . fwekq1g4wz ) ; nesl_erase_simulator (
"closedLoop_tuned/Plant/Robot/Solver Configuration_1" ) ;
neu_destroy_diagnostic_manager ( ( NeuDiagnosticManager * ) d1slopnfj2d .
nbnbmwp5ah ) ; nesl_destroy_simulation_data ( ( NeslSimulationData * )
d1slopnfj2d . bxx3aunqbh ) ; nesl_erase_simulator (
"closedLoop_tuned/Plant/Robot/Solver Configuration_1" ) ;
neu_destroy_diagnostic_manager ( ( NeuDiagnosticManager * ) d1slopnfj2d .
eqhqru4bkb ) ; nesl_destroy_simulation_data ( ( NeslSimulationData * )
d1slopnfj2d . dojae3fabx ) ; nesl_erase_simulator (
"closedLoop_tuned/Plant/Robot/Solver Configuration_2" ) ;
neu_destroy_diagnostic_manager ( ( NeuDiagnosticManager * ) d1slopnfj2d .
jcs4deobwu ) ; nesl_destroy_simulation_data ( ( NeslSimulationData * )
d1slopnfj2d . iacissyba2 ) ; nesl_erase_simulator (
"closedLoop_tuned/Plant/Robot/Solver Configuration_2" ) ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( hfoeutytij ->
_mdlRefSfcnS , "closedLoop_tuned" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void mromvgiaby (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , real_T *
localX_ , real_T * localMM , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { nbzsdh3gog * const hfoeutytij = & (
elvjztouut . rtm ) ; pu40142whda * localX = ( pu40142whda * ) localX_ ;
rt_InitInfAndNaN ( sizeof ( real_T ) ) ; bof3ifvdh3 . P_85 = rtInf ;
bof3ifvdh3 . P_86 = rtMinusInf ; bof3ifvdh3 . P_87 = rtInf ; bof3ifvdh3 .
P_88 = rtMinusInf ; bof3ifvdh3 . P_93 = rtInf ; bof3ifvdh3 . P_94 =
rtMinusInf ; bof3ifvdh3 . P_95 = rtInf ; bof3ifvdh3 . P_96 = rtMinusInf ;
bof3ifvdh3 . P_104 = rtInf ; bof3ifvdh3 . P_105 = rtMinusInf ; bof3ifvdh3 .
P_106 = rtInf ; bof3ifvdh3 . P_107 = rtMinusInf ; bof3ifvdh3 . P_112 = rtInf
; bof3ifvdh3 . P_113 = rtMinusInf ; bof3ifvdh3 . P_114 = rtInf ; bof3ifvdh3 .
P_115 = rtMinusInf ; bof3ifvdh3 . P_123 = rtInf ; bof3ifvdh3 . P_124 =
rtMinusInf ; bof3ifvdh3 . P_125 = rtInf ; bof3ifvdh3 . P_126 = rtMinusInf ;
bof3ifvdh3 . P_131 = rtInf ; bof3ifvdh3 . P_132 = rtMinusInf ; bof3ifvdh3 .
P_133 = rtInf ; bof3ifvdh3 . P_134 = rtMinusInf ; bof3ifvdh3 . P_142 = rtInf
; bof3ifvdh3 . P_143 = rtMinusInf ; bof3ifvdh3 . P_144 = rtInf ; bof3ifvdh3 .
P_145 = rtMinusInf ; bof3ifvdh3 . P_150 = rtInf ; bof3ifvdh3 . P_151 =
rtMinusInf ; bof3ifvdh3 . P_152 = rtInf ; bof3ifvdh3 . P_153 = rtMinusInf ;
bof3ifvdh3 . P_161 = rtInf ; bof3ifvdh3 . P_162 = rtMinusInf ; bof3ifvdh3 .
P_163 = rtInf ; bof3ifvdh3 . P_164 = rtMinusInf ; bof3ifvdh3 . P_169 = rtInf
; bof3ifvdh3 . P_170 = rtMinusInf ; bof3ifvdh3 . P_171 = rtInf ; bof3ifvdh3 .
P_172 = rtMinusInf ; bof3ifvdh3 . P_180 = rtInf ; bof3ifvdh3 . P_181 =
rtMinusInf ; bof3ifvdh3 . P_182 = rtInf ; bof3ifvdh3 . P_183 = rtMinusInf ;
bof3ifvdh3 . P_188 = rtInf ; bof3ifvdh3 . P_189 = rtMinusInf ; bof3ifvdh3 .
P_190 = rtInf ; bof3ifvdh3 . P_191 = rtMinusInf ; ( void ) memset ( ( void *
) hfoeutytij , 0 , sizeof ( nbzsdh3gog ) ) ; lsbnhudl31 [ 0 ] = mdlref_TID0 ;
lsbnhudl31 [ 1 ] = mdlref_TID1 ; hfoeutytij -> _mdlRefSfcnS = ( _mdlRefSfcnS
) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent (
hfoeutytij -> _mdlRefSfcnS , "closedLoop_tuned" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } ( void ) memset ( ( ( void *
) & lvuzhhuckmt ) , 0 , sizeof ( n4awau1raf2 ) ) ; { int32_T i ; for ( i = 0
; i < 24 ; i ++ ) { lvuzhhuckmt . jxrjelubpn [ i ] = 0.0 ; } for ( i = 0 ; i
< 12 ; i ++ ) { lvuzhhuckmt . k0xye32kow [ i ] = 0.0 ; } for ( i = 0 ; i < 36
; i ++ ) { lvuzhhuckmt . acyhv10gdn [ i ] = 0.0 ; } for ( i = 0 ; i < 19 ; i
++ ) { lvuzhhuckmt . asd4csvbcs [ i ] = 0.0 ; } lvuzhhuckmt . jv20suu5kg [ 0
] = 0.0 ; lvuzhhuckmt . jv20suu5kg [ 1 ] = 0.0 ; lvuzhhuckmt . jv20suu5kg [ 2
] = 0.0 ; lvuzhhuckmt . jv20suu5kg [ 3 ] = 0.0 ; lvuzhhuckmt . mj4gjt33f3 [ 0
] = 0.0 ; lvuzhhuckmt . mj4gjt33f3 [ 1 ] = 0.0 ; lvuzhhuckmt . mj4gjt33f3 [ 2
] = 0.0 ; lvuzhhuckmt . mj4gjt33f3 [ 3 ] = 0.0 ; lvuzhhuckmt . hwk0u4eoqn [ 0
] = 0.0 ; lvuzhhuckmt . hwk0u4eoqn [ 1 ] = 0.0 ; lvuzhhuckmt . hwk0u4eoqn [ 2
] = 0.0 ; lvuzhhuckmt . hwk0u4eoqn [ 3 ] = 0.0 ; lvuzhhuckmt . mrjmcb1eaq [ 0
] = 0.0 ; lvuzhhuckmt . mrjmcb1eaq [ 1 ] = 0.0 ; lvuzhhuckmt . mrjmcb1eaq [ 2
] = 0.0 ; lvuzhhuckmt . mrjmcb1eaq [ 3 ] = 0.0 ; lvuzhhuckmt . lhbimp5kmr [ 0
] = 0.0 ; lvuzhhuckmt . lhbimp5kmr [ 1 ] = 0.0 ; lvuzhhuckmt . lhbimp5kmr [ 2
] = 0.0 ; lvuzhhuckmt . lhbimp5kmr [ 3 ] = 0.0 ; lvuzhhuckmt . idnqelgv01 [ 0
] = 0.0 ; lvuzhhuckmt . idnqelgv01 [ 1 ] = 0.0 ; lvuzhhuckmt . idnqelgv01 [ 2
] = 0.0 ; lvuzhhuckmt . idnqelgv01 [ 3 ] = 0.0 ; lvuzhhuckmt . kbgonrof1r [ 0
] = 0.0 ; lvuzhhuckmt . kbgonrof1r [ 1 ] = 0.0 ; lvuzhhuckmt . cpnsm5fki5 [ 0
] = 0.0 ; lvuzhhuckmt . cpnsm5fki5 [ 1 ] = 0.0 ; lvuzhhuckmt . il2zdrdpzs =
0.0 ; lvuzhhuckmt . a2ld4b11me = 0.0 ; lvuzhhuckmt . ofsiaytreh = 0.0 ;
lvuzhhuckmt . n3ldelb453 = 0.0 ; lvuzhhuckmt . ngr10hc5m3 = 0.0 ; lvuzhhuckmt
. okzuauvitn [ 0 ] = 0.0 ; lvuzhhuckmt . okzuauvitn [ 1 ] = 0.0 ; lvuzhhuckmt
. okzuauvitn [ 2 ] = 0.0 ; lvuzhhuckmt . okzuauvitn [ 3 ] = 0.0 ; lvuzhhuckmt
. pf4arwrhyx [ 0 ] = 0.0 ; lvuzhhuckmt . pf4arwrhyx [ 1 ] = 0.0 ; lvuzhhuckmt
. gs5wyjrzvf [ 0 ] = 0.0 ; lvuzhhuckmt . gs5wyjrzvf [ 1 ] = 0.0 ; lvuzhhuckmt
. d4klkeknc5 = 0.0 ; lvuzhhuckmt . ab2humyxjs = 0.0 ; lvuzhhuckmt .
fpdxc0m2q5 = 0.0 ; lvuzhhuckmt . iik1ydfzer = 0.0 ; lvuzhhuckmt . bpvkri3q0b
= 0.0 ; lvuzhhuckmt . hd5f3jh03c [ 0 ] = 0.0 ; lvuzhhuckmt . hd5f3jh03c [ 1 ]
= 0.0 ; lvuzhhuckmt . hd5f3jh03c [ 2 ] = 0.0 ; lvuzhhuckmt . hd5f3jh03c [ 3 ]
= 0.0 ; lvuzhhuckmt . hpivumlrcc [ 0 ] = 0.0 ; lvuzhhuckmt . hpivumlrcc [ 1 ]
= 0.0 ; lvuzhhuckmt . ezyrayiasu [ 0 ] = 0.0 ; lvuzhhuckmt . ezyrayiasu [ 1 ]
= 0.0 ; lvuzhhuckmt . hzrrdpmkic = 0.0 ; lvuzhhuckmt . igs4te5eut = 0.0 ;
lvuzhhuckmt . kfhz4kh3k1 = 0.0 ; lvuzhhuckmt . piuo4l0c3f = 0.0 ; lvuzhhuckmt
. pvbgkev205 = 0.0 ; lvuzhhuckmt . eqathlbtwk [ 0 ] = 0.0 ; lvuzhhuckmt .
eqathlbtwk [ 1 ] = 0.0 ; lvuzhhuckmt . eqathlbtwk [ 2 ] = 0.0 ; lvuzhhuckmt .
eqathlbtwk [ 3 ] = 0.0 ; lvuzhhuckmt . iamzy5525o [ 0 ] = 0.0 ; lvuzhhuckmt .
iamzy5525o [ 1 ] = 0.0 ; lvuzhhuckmt . gkdm5dhsql [ 0 ] = 0.0 ; lvuzhhuckmt .
gkdm5dhsql [ 1 ] = 0.0 ; lvuzhhuckmt . jkyw0vhmte = 0.0 ; lvuzhhuckmt .
e1nynqow2s = 0.0 ; lvuzhhuckmt . kqn2kxb5sa = 0.0 ; lvuzhhuckmt . inzhtyivhd
= 0.0 ; lvuzhhuckmt . ewb3tjnaav = 0.0 ; lvuzhhuckmt . o2jluiwonh [ 0 ] = 0.0
; lvuzhhuckmt . o2jluiwonh [ 1 ] = 0.0 ; lvuzhhuckmt . o2jluiwonh [ 2 ] = 0.0
; lvuzhhuckmt . o2jluiwonh [ 3 ] = 0.0 ; lvuzhhuckmt . gh0ba0iypp [ 0 ] = 0.0
; lvuzhhuckmt . gh0ba0iypp [ 1 ] = 0.0 ; lvuzhhuckmt . it2ouoy2lw [ 0 ] = 0.0
; lvuzhhuckmt . it2ouoy2lw [ 1 ] = 0.0 ; lvuzhhuckmt . c1cidqyaaz = 0.0 ;
lvuzhhuckmt . mc5bjvku1h = 0.0 ; lvuzhhuckmt . jgdhfclmal = 0.0 ; lvuzhhuckmt
. kkjdrofzsj = 0.0 ; lvuzhhuckmt . m0qfxlppqp = 0.0 ; lvuzhhuckmt .
e23ad5ihp4 [ 0 ] = 0.0 ; lvuzhhuckmt . e23ad5ihp4 [ 1 ] = 0.0 ; lvuzhhuckmt .
e23ad5ihp4 [ 2 ] = 0.0 ; lvuzhhuckmt . e23ad5ihp4 [ 3 ] = 0.0 ; lvuzhhuckmt .
ljdpmxc04v [ 0 ] = 0.0 ; lvuzhhuckmt . ljdpmxc04v [ 1 ] = 0.0 ; lvuzhhuckmt .
gra4msiia2 [ 0 ] = 0.0 ; lvuzhhuckmt . gra4msiia2 [ 1 ] = 0.0 ; lvuzhhuckmt .
knazmztaxp = 0.0 ; lvuzhhuckmt . hr1vg5j2or = 0.0 ; lvuzhhuckmt . k5ii4pjkz3
= 0.0 ; lvuzhhuckmt . eap3iu1d2t = 0.0 ; lvuzhhuckmt . dhka03xnzo = 0.0 ;
lvuzhhuckmt . ppj0cxlxco [ 0 ] = 0.0 ; lvuzhhuckmt . ppj0cxlxco [ 1 ] = 0.0 ;
lvuzhhuckmt . ppj0cxlxco [ 2 ] = 0.0 ; lvuzhhuckmt . ppj0cxlxco [ 3 ] = 0.0 ;
lvuzhhuckmt . bs1e5cpoll [ 0 ] = 0.0 ; lvuzhhuckmt . bs1e5cpoll [ 1 ] = 0.0 ;
lvuzhhuckmt . bs1e5cpoll [ 2 ] = 0.0 ; lvuzhhuckmt . bs1e5cpoll [ 3 ] = 0.0 ;
lvuzhhuckmt . k30tufukck [ 0 ] = 0.0 ; lvuzhhuckmt . k30tufukck [ 1 ] = 0.0 ;
lvuzhhuckmt . k30tufukck [ 2 ] = 0.0 ; lvuzhhuckmt . k30tufukck [ 3 ] = 0.0 ;
lvuzhhuckmt . a0iis2ayez [ 0 ] = 0.0 ; lvuzhhuckmt . a0iis2ayez [ 1 ] = 0.0 ;
lvuzhhuckmt . a0iis2ayez [ 2 ] = 0.0 ; lvuzhhuckmt . a0iis2ayez [ 3 ] = 0.0 ;
lvuzhhuckmt . kzrjgwxloa [ 0 ] = 0.0 ; lvuzhhuckmt . kzrjgwxloa [ 1 ] = 0.0 ;
lvuzhhuckmt . kzrjgwxloa [ 2 ] = 0.0 ; lvuzhhuckmt . kzrjgwxloa [ 3 ] = 0.0 ;
lvuzhhuckmt . h1mwn5bwbv [ 0 ] = 0.0 ; lvuzhhuckmt . h1mwn5bwbv [ 1 ] = 0.0 ;
lvuzhhuckmt . h1mwn5bwbv [ 2 ] = 0.0 ; lvuzhhuckmt . h1mwn5bwbv [ 3 ] = 0.0 ;
lvuzhhuckmt . dw2p0ylolg [ 0 ] = 0.0 ; lvuzhhuckmt . dw2p0ylolg [ 1 ] = 0.0 ;
lvuzhhuckmt . dw2p0ylolg [ 2 ] = 0.0 ; lvuzhhuckmt . dw2p0ylolg [ 3 ] = 0.0 ;
lvuzhhuckmt . ewtdk1a3wj = 0.0 ; lvuzhhuckmt . czgs54xlrn = 0.0 ; lvuzhhuckmt
. ipcork0j5r = 0.0 ; lvuzhhuckmt . g2kdahdcll = 0.0 ; lvuzhhuckmt .
mvhqmddcdi = 0.0 ; lvuzhhuckmt . cbxpo1dgoh = 0.0 ; lvuzhhuckmt . mugze5h0np
= 0.0 ; lvuzhhuckmt . i5soltjzbg = 0.0 ; lvuzhhuckmt . oqif5mozdt = 0.0 ;
lvuzhhuckmt . a11ufkvxe2 = 0.0 ; lvuzhhuckmt . i5mqop40o4 = 0.0 ; lvuzhhuckmt
. dk3zxjazcl = 0.0 ; lvuzhhuckmt . e4gi0xz1up = 0.0 ; lvuzhhuckmt .
nxl5q24yqw = 0.0 ; lvuzhhuckmt . dytu4lqdaz = 0.0 ; lvuzhhuckmt . i3lazf1uup
= 0.0 ; lvuzhhuckmt . oybzinbsjs = 0.0 ; lvuzhhuckmt . lqu4qa401r = 0.0 ;
lvuzhhuckmt . iehotwguah = 0.0 ; lvuzhhuckmt . gdgkrl4bz4 = 0.0 ; lvuzhhuckmt
. divng01nk2 = 0.0 ; lvuzhhuckmt . onfvjve2wy = 0.0 ; lvuzhhuckmt .
g4baubdyll = 0.0 ; lvuzhhuckmt . ds44fme4rr = 0.0 ; } ( void ) memset ( (
void * ) & d1slopnfj2d , 0 , sizeof ( eilavowrwl4 ) ) ; d1slopnfj2d .
owjdrnlrr5 = 0.0 ; d1slopnfj2d . kt4uicyvx0 = 0.0 ; d1slopnfj2d . lsxjomeomv
= 0.0 ; d1slopnfj2d . kyfvye0kyh = 0.0 ; d1slopnfj2d . k5tezogtje = 0.0 ;
d1slopnfj2d . mtrpzv3ygn = 0.0 ; d1slopnfj2d . c33z0kxz40 = 0.0 ; d1slopnfj2d
. czvkwuyek1 = 0.0 ; d1slopnfj2d . fljztst5wo = 0.0 ; d1slopnfj2d .
muit3a3q1x = 0.0 ; d1slopnfj2d . fyyyxyhfe2 = 0.0 ; d1slopnfj2d . luoxgto34c
= 0.0 ; d1slopnfj2d . lbcqusxymb = 0.0 ; d1slopnfj2d . martnwreej = 0.0 ;
d1slopnfj2d . axiqwbld0q = 0.0 ; d1slopnfj2d . dlusidt5mu = 0.0 ; d1slopnfj2d
. ftka134rfi = 0.0 ; d1slopnfj2d . mfarqvu45m = 0.0 ; d1slopnfj2d .
hylr2w3yna = 0.0 ; d1slopnfj2d . nx1wrktxq2 = 0.0 ; d1slopnfj2d . lnboystaxq
= 0.0 ; d1slopnfj2d . kva2ijsjip = 0.0 ; d1slopnfj2d . gohohcrj54 = 0.0 ;
d1slopnfj2d . mibsc4a2kt = 0.0 ; d1slopnfj2d . jrb1kz3zlg = 0.0 ; d1slopnfj2d
. fpo5oixhup = 0.0 ; d1slopnfj2d . hmmcsmj0xw = 0.0 ; d1slopnfj2d .
eat1taflmt = 0.0 ; d1slopnfj2d . akyzgxh1sj = 0.0 ; d1slopnfj2d . im3cksdclx
= 0.0 ; d1slopnfj2d . ap5cqbvm1g = 0.0 ; d1slopnfj2d . koqgz4rjix = 0.0 ;
d1slopnfj2d . mymypzqmu0 = 0.0 ; d1slopnfj2d . a5avu4h2ix = 0.0 ; d1slopnfj2d
. mdyqmzjrn0 = 0.0 ; d1slopnfj2d . eicckovdtk = 0.0 ; d1slopnfj2d .
jlvuwqbqtq = 0.0 ; d1slopnfj2d . lau0kxrr3b = 0.0 ; d1slopnfj2d . d00cvtrow5
= 0.0 ; d1slopnfj2d . iioyhpmu2z = 0.0 ; d1slopnfj2d . lqn4y02ryj = 0.0 ;
d1slopnfj2d . e1nkcmfeef = 0.0 ; d1slopnfj2d . h2azwddpsi = 0.0 ; d1slopnfj2d
. itkowzvhmy = 0.0 ; d1slopnfj2d . aqhbkipuc1 = 0.0 ; d1slopnfj2d .
d2ihml4pca = 0.0 ; d1slopnfj2d . ohubyvobgd = 0.0 ; d1slopnfj2d . jhkfvfo11l
= 0.0 ; d1slopnfj2d . ejngdjwvuh = 0.0 ; d1slopnfj2d . dztpawf31l = 0.0 ;
d1slopnfj2d . msarqtw0ej = 0.0 ; d1slopnfj2d . kc4smoweoa = 0.0 ; d1slopnfj2d
. psdk3h03r4 = 0.0 ; d1slopnfj2d . pojlpslfax = 0.0 ; d1slopnfj2d .
cmjntkjs5o [ 0 ] = 0.0 ; d1slopnfj2d . cmjntkjs5o [ 1 ] = 0.0 ; d1slopnfj2d .
dwblx5h40t [ 0 ] = 0.0 ; d1slopnfj2d . dwblx5h40t [ 1 ] = 0.0 ; d1slopnfj2d .
a4oaoqzmvb [ 0 ] = 0.0 ; d1slopnfj2d . a4oaoqzmvb [ 1 ] = 0.0 ; d1slopnfj2d .
f2edgntbzl [ 0 ] = 0.0 ; d1slopnfj2d . f2edgntbzl [ 1 ] = 0.0 ; d1slopnfj2d .
ml04raex0s [ 0 ] = 0.0 ; d1slopnfj2d . ml04raex0s [ 1 ] = 0.0 ; d1slopnfj2d .
d1gzuqoj4q [ 0 ] = 0.0 ; d1slopnfj2d . d1gzuqoj4q [ 1 ] = 0.0 ; d1slopnfj2d .
fu4515tfei = 0.0 ; d1slopnfj2d . mcnyytj12g = 0.0 ; d1slopnfj2d . g5juej3g4q
= 0.0 ; d1slopnfj2d . owpb4gqr4b = 0.0 ;
closedLoop_tuned_InitializeDataMapInfo ( hfoeutytij , localX , sysRanPtr ,
contextTid ) ; { hfoeutytij -> massMatrixBasePr = localMM ; d1slopnfj2d .
f3vldgt55s = 42 ; } if ( ( rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != (
NULL ) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & (
hfoeutytij -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( hfoeutytij ->
DataMapInfo . mmi , rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex (
hfoeutytij -> DataMapInfo . mmi , rt_CSTATEIdx ) ; } } void
mr_closedLoop_tuned_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T *
modelName , int_T * retVal ) { * retVal = 0 ; { boolean_T regSubmodelsMdlinfo
= false ; ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , & regSubmodelsMdlinfo ) ;
if ( regSubmodelsMdlinfo ) { } } * retVal = 0 ; ssRegModelRefMdlInfo (
mdlRefSfcnS , modelName , rtMdlInfo_closedLoop_tuned , 63 ) ; * retVal = 1 ;
} static void mr_closedLoop_tuned_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) ; static void
mr_closedLoop_tuned_cacheDataAsMxArray ( mxArray * destArray , mwIndex i ,
int j , const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_closedLoop_tuned_restoreDataFromMxArray ( void * destData
, const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_closedLoop_tuned_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( (
uint8_T * ) destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber (
srcArray , i , j ) ) , numBytes ) ; } static void
mr_closedLoop_tuned_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i
, int j , uint_T bitVal ) ; static void
mr_closedLoop_tuned_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i
, int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_closedLoop_tuned_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_closedLoop_tuned_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_closedLoop_tuned_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
; static void mr_closedLoop_tuned_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_closedLoop_tuned_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) ; static void mr_closedLoop_tuned_restoreDataFromMxArrayWithOffset
( void * destData , const mxArray * srcArray , mwIndex i , int j , mwIndex
offset , size_t numBytes ) { const uint8_T * varData = ( const uint8_T * )
mxGetData ( mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T *
) destData , ( const uint8_T * ) & varData [ offset * numBytes ] , numBytes )
; } static void mr_closedLoop_tuned_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
; static void mr_closedLoop_tuned_cacheBitFieldToCellArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal )
{ mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_closedLoop_tuned_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_closedLoop_tuned_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_closedLoop_tuned_GetDWork ( ) {
static const char * ssDWFieldNames [ 3 ] = { "lvuzhhuckmt" , "d1slopnfj2d" ,
"NULL_PrevZCX" , } ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 ,
ssDWFieldNames ) ; mr_closedLoop_tuned_cacheDataAsMxArray ( ssDW , 0 , 0 , &
( lvuzhhuckmt ) , sizeof ( lvuzhhuckmt ) ) ; { static const char *
rtdwDataFieldNames [ 97 ] = { "d1slopnfj2d.owjdrnlrr5" ,
"d1slopnfj2d.kt4uicyvx0" , "d1slopnfj2d.lsxjomeomv" ,
"d1slopnfj2d.kyfvye0kyh" , "d1slopnfj2d.k5tezogtje" ,
"d1slopnfj2d.mtrpzv3ygn" , "d1slopnfj2d.c33z0kxz40" ,
"d1slopnfj2d.czvkwuyek1" , "d1slopnfj2d.fljztst5wo" ,
"d1slopnfj2d.muit3a3q1x" , "d1slopnfj2d.fyyyxyhfe2" ,
"d1slopnfj2d.luoxgto34c" , "d1slopnfj2d.lbcqusxymb" ,
"d1slopnfj2d.martnwreej" , "d1slopnfj2d.axiqwbld0q" ,
"d1slopnfj2d.dlusidt5mu" , "d1slopnfj2d.ftka134rfi" ,
"d1slopnfj2d.mfarqvu45m" , "d1slopnfj2d.hylr2w3yna" ,
"d1slopnfj2d.nx1wrktxq2" , "d1slopnfj2d.lnboystaxq" ,
"d1slopnfj2d.kva2ijsjip" , "d1slopnfj2d.gohohcrj54" ,
"d1slopnfj2d.mibsc4a2kt" , "d1slopnfj2d.jrb1kz3zlg" ,
"d1slopnfj2d.fpo5oixhup" , "d1slopnfj2d.hmmcsmj0xw" ,
"d1slopnfj2d.eat1taflmt" , "d1slopnfj2d.akyzgxh1sj" ,
"d1slopnfj2d.im3cksdclx" , "d1slopnfj2d.ap5cqbvm1g" ,
"d1slopnfj2d.koqgz4rjix" , "d1slopnfj2d.mymypzqmu0" ,
"d1slopnfj2d.a5avu4h2ix" , "d1slopnfj2d.mdyqmzjrn0" ,
"d1slopnfj2d.eicckovdtk" , "d1slopnfj2d.jlvuwqbqtq" ,
"d1slopnfj2d.lau0kxrr3b" , "d1slopnfj2d.d00cvtrow5" ,
"d1slopnfj2d.iioyhpmu2z" , "d1slopnfj2d.lqn4y02ryj" ,
"d1slopnfj2d.e1nkcmfeef" , "d1slopnfj2d.h2azwddpsi" ,
"d1slopnfj2d.itkowzvhmy" , "d1slopnfj2d.aqhbkipuc1" ,
"d1slopnfj2d.d2ihml4pca" , "d1slopnfj2d.ohubyvobgd" ,
"d1slopnfj2d.jhkfvfo11l" , "d1slopnfj2d.ejngdjwvuh" ,
"d1slopnfj2d.dztpawf31l" , "d1slopnfj2d.msarqtw0ej" ,
"d1slopnfj2d.kc4smoweoa" , "d1slopnfj2d.psdk3h03r4" ,
"d1slopnfj2d.pojlpslfax" , "d1slopnfj2d.cmjntkjs5o" ,
"d1slopnfj2d.dwblx5h40t" , "d1slopnfj2d.a4oaoqzmvb" ,
"d1slopnfj2d.f2edgntbzl" , "d1slopnfj2d.ml04raex0s" ,
"d1slopnfj2d.d1gzuqoj4q" , "d1slopnfj2d.fu4515tfei" ,
"d1slopnfj2d.mcnyytj12g" , "d1slopnfj2d.g5juej3g4q" ,
"d1slopnfj2d.owpb4gqr4b" , "d1slopnfj2d.dlhbeuzmaz" ,
"d1slopnfj2d.emiegndpgn" , "d1slopnfj2d.beljpehthd" ,
"d1slopnfj2d.jyeac3e5ko" , "d1slopnfj2d.f3vldgt55s" ,
"d1slopnfj2d.hr3u05iedn" , "d1slopnfj2d.fuwgakmpod" ,
"d1slopnfj2d.cpjueliazg" , "d1slopnfj2d.j1flcekhiz" ,
"d1slopnfj2d.gjsyon5lu1" , "d1slopnfj2d.gtdlxdr5hj" ,
"d1slopnfj2d.ok503kfbwz" , "d1slopnfj2d.nvuezdxtzi" ,
"d1slopnfj2d.kpe2zccxxi" , "d1slopnfj2d.imm0zy02qz" ,
"d1slopnfj2d.ogphl1wuml" , "d1slopnfj2d.mzswpaogfa" ,
"d1slopnfj2d.lbikguphlp" , "d1slopnfj2d.he40254wch" ,
"d1slopnfj2d.f01rjososq" , "d1slopnfj2d.jshht1u2q5" ,
"d1slopnfj2d.m3ypcbfysw" , "d1slopnfj2d.iltjdvd4vg" ,
"d1slopnfj2d.d3raebrh43" , "d1slopnfj2d.i43yu5fsyu" ,
"d1slopnfj2d.phmwjirefk" , "d1slopnfj2d.axj00twaij" ,
"d1slopnfj2d.h4yyh4nnql" , "d1slopnfj2d.jbclgbkabv" ,
"d1slopnfj2d.baxue1nnnm" , "d1slopnfj2d.nwi1b1luuj" ,
"d1slopnfj2d.pojn0vmcuv" , "d1slopnfj2d.auux5mhg5v" , } ; mxArray * rtdwData
= mxCreateStructMatrix ( 1 , 1 , 97 , rtdwDataFieldNames ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 0 , & ( d1slopnfj2d .
owjdrnlrr5 ) , sizeof ( d1slopnfj2d . owjdrnlrr5 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 1 , & ( d1slopnfj2d .
kt4uicyvx0 ) , sizeof ( d1slopnfj2d . kt4uicyvx0 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 2 , & ( d1slopnfj2d .
lsxjomeomv ) , sizeof ( d1slopnfj2d . lsxjomeomv ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 3 , & ( d1slopnfj2d .
kyfvye0kyh ) , sizeof ( d1slopnfj2d . kyfvye0kyh ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 4 , & ( d1slopnfj2d .
k5tezogtje ) , sizeof ( d1slopnfj2d . k5tezogtje ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 5 , & ( d1slopnfj2d .
mtrpzv3ygn ) , sizeof ( d1slopnfj2d . mtrpzv3ygn ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 6 , & ( d1slopnfj2d .
c33z0kxz40 ) , sizeof ( d1slopnfj2d . c33z0kxz40 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 7 , & ( d1slopnfj2d .
czvkwuyek1 ) , sizeof ( d1slopnfj2d . czvkwuyek1 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 8 , & ( d1slopnfj2d .
fljztst5wo ) , sizeof ( d1slopnfj2d . fljztst5wo ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 9 , & ( d1slopnfj2d .
muit3a3q1x ) , sizeof ( d1slopnfj2d . muit3a3q1x ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 10 , & ( d1slopnfj2d
. fyyyxyhfe2 ) , sizeof ( d1slopnfj2d . fyyyxyhfe2 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 11 , & ( d1slopnfj2d
. luoxgto34c ) , sizeof ( d1slopnfj2d . luoxgto34c ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 12 , & ( d1slopnfj2d
. lbcqusxymb ) , sizeof ( d1slopnfj2d . lbcqusxymb ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 13 , & ( d1slopnfj2d
. martnwreej ) , sizeof ( d1slopnfj2d . martnwreej ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 14 , & ( d1slopnfj2d
. axiqwbld0q ) , sizeof ( d1slopnfj2d . axiqwbld0q ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 15 , & ( d1slopnfj2d
. dlusidt5mu ) , sizeof ( d1slopnfj2d . dlusidt5mu ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 16 , & ( d1slopnfj2d
. ftka134rfi ) , sizeof ( d1slopnfj2d . ftka134rfi ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 17 , & ( d1slopnfj2d
. mfarqvu45m ) , sizeof ( d1slopnfj2d . mfarqvu45m ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 18 , & ( d1slopnfj2d
. hylr2w3yna ) , sizeof ( d1slopnfj2d . hylr2w3yna ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 19 , & ( d1slopnfj2d
. nx1wrktxq2 ) , sizeof ( d1slopnfj2d . nx1wrktxq2 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 20 , & ( d1slopnfj2d
. lnboystaxq ) , sizeof ( d1slopnfj2d . lnboystaxq ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 21 , & ( d1slopnfj2d
. kva2ijsjip ) , sizeof ( d1slopnfj2d . kva2ijsjip ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 22 , & ( d1slopnfj2d
. gohohcrj54 ) , sizeof ( d1slopnfj2d . gohohcrj54 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 23 , & ( d1slopnfj2d
. mibsc4a2kt ) , sizeof ( d1slopnfj2d . mibsc4a2kt ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 24 , & ( d1slopnfj2d
. jrb1kz3zlg ) , sizeof ( d1slopnfj2d . jrb1kz3zlg ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 25 , & ( d1slopnfj2d
. fpo5oixhup ) , sizeof ( d1slopnfj2d . fpo5oixhup ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 26 , & ( d1slopnfj2d
. hmmcsmj0xw ) , sizeof ( d1slopnfj2d . hmmcsmj0xw ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 27 , & ( d1slopnfj2d
. eat1taflmt ) , sizeof ( d1slopnfj2d . eat1taflmt ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 28 , & ( d1slopnfj2d
. akyzgxh1sj ) , sizeof ( d1slopnfj2d . akyzgxh1sj ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 29 , & ( d1slopnfj2d
. im3cksdclx ) , sizeof ( d1slopnfj2d . im3cksdclx ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 30 , & ( d1slopnfj2d
. ap5cqbvm1g ) , sizeof ( d1slopnfj2d . ap5cqbvm1g ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 31 , & ( d1slopnfj2d
. koqgz4rjix ) , sizeof ( d1slopnfj2d . koqgz4rjix ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 32 , & ( d1slopnfj2d
. mymypzqmu0 ) , sizeof ( d1slopnfj2d . mymypzqmu0 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 33 , & ( d1slopnfj2d
. a5avu4h2ix ) , sizeof ( d1slopnfj2d . a5avu4h2ix ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 34 , & ( d1slopnfj2d
. mdyqmzjrn0 ) , sizeof ( d1slopnfj2d . mdyqmzjrn0 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 35 , & ( d1slopnfj2d
. eicckovdtk ) , sizeof ( d1slopnfj2d . eicckovdtk ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 36 , & ( d1slopnfj2d
. jlvuwqbqtq ) , sizeof ( d1slopnfj2d . jlvuwqbqtq ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 37 , & ( d1slopnfj2d
. lau0kxrr3b ) , sizeof ( d1slopnfj2d . lau0kxrr3b ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 38 , & ( d1slopnfj2d
. d00cvtrow5 ) , sizeof ( d1slopnfj2d . d00cvtrow5 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 39 , & ( d1slopnfj2d
. iioyhpmu2z ) , sizeof ( d1slopnfj2d . iioyhpmu2z ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 40 , & ( d1slopnfj2d
. lqn4y02ryj ) , sizeof ( d1slopnfj2d . lqn4y02ryj ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 41 , & ( d1slopnfj2d
. e1nkcmfeef ) , sizeof ( d1slopnfj2d . e1nkcmfeef ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 42 , & ( d1slopnfj2d
. h2azwddpsi ) , sizeof ( d1slopnfj2d . h2azwddpsi ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 43 , & ( d1slopnfj2d
. itkowzvhmy ) , sizeof ( d1slopnfj2d . itkowzvhmy ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 44 , & ( d1slopnfj2d
. aqhbkipuc1 ) , sizeof ( d1slopnfj2d . aqhbkipuc1 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 45 , & ( d1slopnfj2d
. d2ihml4pca ) , sizeof ( d1slopnfj2d . d2ihml4pca ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 46 , & ( d1slopnfj2d
. ohubyvobgd ) , sizeof ( d1slopnfj2d . ohubyvobgd ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 47 , & ( d1slopnfj2d
. jhkfvfo11l ) , sizeof ( d1slopnfj2d . jhkfvfo11l ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 48 , & ( d1slopnfj2d
. ejngdjwvuh ) , sizeof ( d1slopnfj2d . ejngdjwvuh ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 49 , & ( d1slopnfj2d
. dztpawf31l ) , sizeof ( d1slopnfj2d . dztpawf31l ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 50 , & ( d1slopnfj2d
. msarqtw0ej ) , sizeof ( d1slopnfj2d . msarqtw0ej ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 51 , & ( d1slopnfj2d
. kc4smoweoa ) , sizeof ( d1slopnfj2d . kc4smoweoa ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 52 , & ( d1slopnfj2d
. psdk3h03r4 ) , sizeof ( d1slopnfj2d . psdk3h03r4 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 53 , & ( d1slopnfj2d
. pojlpslfax ) , sizeof ( d1slopnfj2d . pojlpslfax ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 54 , & ( d1slopnfj2d
. cmjntkjs5o ) , sizeof ( d1slopnfj2d . cmjntkjs5o ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 55 , & ( d1slopnfj2d
. dwblx5h40t ) , sizeof ( d1slopnfj2d . dwblx5h40t ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 56 , & ( d1slopnfj2d
. a4oaoqzmvb ) , sizeof ( d1slopnfj2d . a4oaoqzmvb ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 57 , & ( d1slopnfj2d
. f2edgntbzl ) , sizeof ( d1slopnfj2d . f2edgntbzl ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 58 , & ( d1slopnfj2d
. ml04raex0s ) , sizeof ( d1slopnfj2d . ml04raex0s ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 59 , & ( d1slopnfj2d
. d1gzuqoj4q ) , sizeof ( d1slopnfj2d . d1gzuqoj4q ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 60 , & ( d1slopnfj2d
. fu4515tfei ) , sizeof ( d1slopnfj2d . fu4515tfei ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 61 , & ( d1slopnfj2d
. mcnyytj12g ) , sizeof ( d1slopnfj2d . mcnyytj12g ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 62 , & ( d1slopnfj2d
. g5juej3g4q ) , sizeof ( d1slopnfj2d . g5juej3g4q ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 63 , & ( d1slopnfj2d
. owpb4gqr4b ) , sizeof ( d1slopnfj2d . owpb4gqr4b ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 64 , & ( d1slopnfj2d
. dlhbeuzmaz ) , sizeof ( d1slopnfj2d . dlhbeuzmaz ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 65 , & ( d1slopnfj2d
. emiegndpgn ) , sizeof ( d1slopnfj2d . emiegndpgn ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 66 , & ( d1slopnfj2d
. beljpehthd ) , sizeof ( d1slopnfj2d . beljpehthd ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 67 , & ( d1slopnfj2d
. jyeac3e5ko ) , sizeof ( d1slopnfj2d . jyeac3e5ko ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 68 , & ( d1slopnfj2d
. f3vldgt55s ) , sizeof ( d1slopnfj2d . f3vldgt55s ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 69 , & ( d1slopnfj2d
. hr3u05iedn ) , sizeof ( d1slopnfj2d . hr3u05iedn ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 70 , & ( d1slopnfj2d
. fuwgakmpod ) , sizeof ( d1slopnfj2d . fuwgakmpod ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 71 , & ( d1slopnfj2d
. cpjueliazg ) , sizeof ( d1slopnfj2d . cpjueliazg ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 72 , & ( d1slopnfj2d
. j1flcekhiz ) , sizeof ( d1slopnfj2d . j1flcekhiz ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 73 , & ( d1slopnfj2d
. gjsyon5lu1 ) , sizeof ( d1slopnfj2d . gjsyon5lu1 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 74 , & ( d1slopnfj2d
. gtdlxdr5hj ) , sizeof ( d1slopnfj2d . gtdlxdr5hj ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 75 , & ( d1slopnfj2d
. ok503kfbwz ) , sizeof ( d1slopnfj2d . ok503kfbwz ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 76 , & ( d1slopnfj2d
. nvuezdxtzi ) , sizeof ( d1slopnfj2d . nvuezdxtzi ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 77 , & ( d1slopnfj2d
. kpe2zccxxi ) , sizeof ( d1slopnfj2d . kpe2zccxxi ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 78 , & ( d1slopnfj2d
. imm0zy02qz ) , sizeof ( d1slopnfj2d . imm0zy02qz ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 79 , & ( d1slopnfj2d
. ogphl1wuml ) , sizeof ( d1slopnfj2d . ogphl1wuml ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 80 , & ( d1slopnfj2d
. mzswpaogfa ) , sizeof ( d1slopnfj2d . mzswpaogfa ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 81 , & ( d1slopnfj2d
. lbikguphlp ) , sizeof ( d1slopnfj2d . lbikguphlp ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 82 , & ( d1slopnfj2d
. he40254wch ) , sizeof ( d1slopnfj2d . he40254wch ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 83 , & ( d1slopnfj2d
. f01rjososq ) , sizeof ( d1slopnfj2d . f01rjososq ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 84 , & ( d1slopnfj2d
. jshht1u2q5 ) , sizeof ( d1slopnfj2d . jshht1u2q5 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 85 , & ( d1slopnfj2d
. m3ypcbfysw ) , sizeof ( d1slopnfj2d . m3ypcbfysw ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 86 , & ( d1slopnfj2d
. iltjdvd4vg ) , sizeof ( d1slopnfj2d . iltjdvd4vg ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 87 , & ( d1slopnfj2d
. d3raebrh43 ) , sizeof ( d1slopnfj2d . d3raebrh43 ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 88 , & ( d1slopnfj2d
. i43yu5fsyu ) , sizeof ( d1slopnfj2d . i43yu5fsyu ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 89 , & ( d1slopnfj2d
. phmwjirefk ) , sizeof ( d1slopnfj2d . phmwjirefk ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 90 , & ( d1slopnfj2d
. axj00twaij ) , sizeof ( d1slopnfj2d . axj00twaij ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 91 , & ( d1slopnfj2d
. h4yyh4nnql ) , sizeof ( d1slopnfj2d . h4yyh4nnql ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 92 , & ( d1slopnfj2d
. jbclgbkabv ) , sizeof ( d1slopnfj2d . jbclgbkabv ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 93 , & ( d1slopnfj2d
. baxue1nnnm ) , sizeof ( d1slopnfj2d . baxue1nnnm ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 94 , & ( d1slopnfj2d
. nwi1b1luuj ) , sizeof ( d1slopnfj2d . nwi1b1luuj ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 95 , & ( d1slopnfj2d
. pojn0vmcuv ) , sizeof ( d1slopnfj2d . pojn0vmcuv ) ) ;
mr_closedLoop_tuned_cacheDataAsMxArray ( rtdwData , 0 , 96 , & ( d1slopnfj2d
. auux5mhg5v ) , sizeof ( d1slopnfj2d . auux5mhg5v ) ) ; mxSetFieldByNumber (
ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void
mr_closedLoop_tuned_SetDWork ( const mxArray * ssDW ) { ( void ) ssDW ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( lvuzhhuckmt ) , ssDW , 0 , 0
, sizeof ( lvuzhhuckmt ) ) ; { const mxArray * rtdwData = mxGetFieldByNumber
( ssDW , 0 , 1 ) ; mr_closedLoop_tuned_restoreDataFromMxArray ( & (
d1slopnfj2d . owjdrnlrr5 ) , rtdwData , 0 , 0 , sizeof ( d1slopnfj2d .
owjdrnlrr5 ) ) ; mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d
. kt4uicyvx0 ) , rtdwData , 0 , 1 , sizeof ( d1slopnfj2d . kt4uicyvx0 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . lsxjomeomv ) ,
rtdwData , 0 , 2 , sizeof ( d1slopnfj2d . lsxjomeomv ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . kyfvye0kyh ) ,
rtdwData , 0 , 3 , sizeof ( d1slopnfj2d . kyfvye0kyh ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . k5tezogtje ) ,
rtdwData , 0 , 4 , sizeof ( d1slopnfj2d . k5tezogtje ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . mtrpzv3ygn ) ,
rtdwData , 0 , 5 , sizeof ( d1slopnfj2d . mtrpzv3ygn ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . c33z0kxz40 ) ,
rtdwData , 0 , 6 , sizeof ( d1slopnfj2d . c33z0kxz40 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . czvkwuyek1 ) ,
rtdwData , 0 , 7 , sizeof ( d1slopnfj2d . czvkwuyek1 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . fljztst5wo ) ,
rtdwData , 0 , 8 , sizeof ( d1slopnfj2d . fljztst5wo ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . muit3a3q1x ) ,
rtdwData , 0 , 9 , sizeof ( d1slopnfj2d . muit3a3q1x ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . fyyyxyhfe2 ) ,
rtdwData , 0 , 10 , sizeof ( d1slopnfj2d . fyyyxyhfe2 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . luoxgto34c ) ,
rtdwData , 0 , 11 , sizeof ( d1slopnfj2d . luoxgto34c ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . lbcqusxymb ) ,
rtdwData , 0 , 12 , sizeof ( d1slopnfj2d . lbcqusxymb ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . martnwreej ) ,
rtdwData , 0 , 13 , sizeof ( d1slopnfj2d . martnwreej ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . axiqwbld0q ) ,
rtdwData , 0 , 14 , sizeof ( d1slopnfj2d . axiqwbld0q ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . dlusidt5mu ) ,
rtdwData , 0 , 15 , sizeof ( d1slopnfj2d . dlusidt5mu ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . ftka134rfi ) ,
rtdwData , 0 , 16 , sizeof ( d1slopnfj2d . ftka134rfi ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . mfarqvu45m ) ,
rtdwData , 0 , 17 , sizeof ( d1slopnfj2d . mfarqvu45m ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . hylr2w3yna ) ,
rtdwData , 0 , 18 , sizeof ( d1slopnfj2d . hylr2w3yna ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . nx1wrktxq2 ) ,
rtdwData , 0 , 19 , sizeof ( d1slopnfj2d . nx1wrktxq2 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . lnboystaxq ) ,
rtdwData , 0 , 20 , sizeof ( d1slopnfj2d . lnboystaxq ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . kva2ijsjip ) ,
rtdwData , 0 , 21 , sizeof ( d1slopnfj2d . kva2ijsjip ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . gohohcrj54 ) ,
rtdwData , 0 , 22 , sizeof ( d1slopnfj2d . gohohcrj54 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . mibsc4a2kt ) ,
rtdwData , 0 , 23 , sizeof ( d1slopnfj2d . mibsc4a2kt ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . jrb1kz3zlg ) ,
rtdwData , 0 , 24 , sizeof ( d1slopnfj2d . jrb1kz3zlg ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . fpo5oixhup ) ,
rtdwData , 0 , 25 , sizeof ( d1slopnfj2d . fpo5oixhup ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . hmmcsmj0xw ) ,
rtdwData , 0 , 26 , sizeof ( d1slopnfj2d . hmmcsmj0xw ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . eat1taflmt ) ,
rtdwData , 0 , 27 , sizeof ( d1slopnfj2d . eat1taflmt ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . akyzgxh1sj ) ,
rtdwData , 0 , 28 , sizeof ( d1slopnfj2d . akyzgxh1sj ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . im3cksdclx ) ,
rtdwData , 0 , 29 , sizeof ( d1slopnfj2d . im3cksdclx ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . ap5cqbvm1g ) ,
rtdwData , 0 , 30 , sizeof ( d1slopnfj2d . ap5cqbvm1g ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . koqgz4rjix ) ,
rtdwData , 0 , 31 , sizeof ( d1slopnfj2d . koqgz4rjix ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . mymypzqmu0 ) ,
rtdwData , 0 , 32 , sizeof ( d1slopnfj2d . mymypzqmu0 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . a5avu4h2ix ) ,
rtdwData , 0 , 33 , sizeof ( d1slopnfj2d . a5avu4h2ix ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . mdyqmzjrn0 ) ,
rtdwData , 0 , 34 , sizeof ( d1slopnfj2d . mdyqmzjrn0 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . eicckovdtk ) ,
rtdwData , 0 , 35 , sizeof ( d1slopnfj2d . eicckovdtk ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . jlvuwqbqtq ) ,
rtdwData , 0 , 36 , sizeof ( d1slopnfj2d . jlvuwqbqtq ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . lau0kxrr3b ) ,
rtdwData , 0 , 37 , sizeof ( d1slopnfj2d . lau0kxrr3b ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . d00cvtrow5 ) ,
rtdwData , 0 , 38 , sizeof ( d1slopnfj2d . d00cvtrow5 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . iioyhpmu2z ) ,
rtdwData , 0 , 39 , sizeof ( d1slopnfj2d . iioyhpmu2z ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . lqn4y02ryj ) ,
rtdwData , 0 , 40 , sizeof ( d1slopnfj2d . lqn4y02ryj ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . e1nkcmfeef ) ,
rtdwData , 0 , 41 , sizeof ( d1slopnfj2d . e1nkcmfeef ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . h2azwddpsi ) ,
rtdwData , 0 , 42 , sizeof ( d1slopnfj2d . h2azwddpsi ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . itkowzvhmy ) ,
rtdwData , 0 , 43 , sizeof ( d1slopnfj2d . itkowzvhmy ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . aqhbkipuc1 ) ,
rtdwData , 0 , 44 , sizeof ( d1slopnfj2d . aqhbkipuc1 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . d2ihml4pca ) ,
rtdwData , 0 , 45 , sizeof ( d1slopnfj2d . d2ihml4pca ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . ohubyvobgd ) ,
rtdwData , 0 , 46 , sizeof ( d1slopnfj2d . ohubyvobgd ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . jhkfvfo11l ) ,
rtdwData , 0 , 47 , sizeof ( d1slopnfj2d . jhkfvfo11l ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . ejngdjwvuh ) ,
rtdwData , 0 , 48 , sizeof ( d1slopnfj2d . ejngdjwvuh ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . dztpawf31l ) ,
rtdwData , 0 , 49 , sizeof ( d1slopnfj2d . dztpawf31l ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . msarqtw0ej ) ,
rtdwData , 0 , 50 , sizeof ( d1slopnfj2d . msarqtw0ej ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . kc4smoweoa ) ,
rtdwData , 0 , 51 , sizeof ( d1slopnfj2d . kc4smoweoa ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . psdk3h03r4 ) ,
rtdwData , 0 , 52 , sizeof ( d1slopnfj2d . psdk3h03r4 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . pojlpslfax ) ,
rtdwData , 0 , 53 , sizeof ( d1slopnfj2d . pojlpslfax ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . cmjntkjs5o ) ,
rtdwData , 0 , 54 , sizeof ( d1slopnfj2d . cmjntkjs5o ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . dwblx5h40t ) ,
rtdwData , 0 , 55 , sizeof ( d1slopnfj2d . dwblx5h40t ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . a4oaoqzmvb ) ,
rtdwData , 0 , 56 , sizeof ( d1slopnfj2d . a4oaoqzmvb ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . f2edgntbzl ) ,
rtdwData , 0 , 57 , sizeof ( d1slopnfj2d . f2edgntbzl ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . ml04raex0s ) ,
rtdwData , 0 , 58 , sizeof ( d1slopnfj2d . ml04raex0s ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . d1gzuqoj4q ) ,
rtdwData , 0 , 59 , sizeof ( d1slopnfj2d . d1gzuqoj4q ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . fu4515tfei ) ,
rtdwData , 0 , 60 , sizeof ( d1slopnfj2d . fu4515tfei ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . mcnyytj12g ) ,
rtdwData , 0 , 61 , sizeof ( d1slopnfj2d . mcnyytj12g ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . g5juej3g4q ) ,
rtdwData , 0 , 62 , sizeof ( d1slopnfj2d . g5juej3g4q ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . owpb4gqr4b ) ,
rtdwData , 0 , 63 , sizeof ( d1slopnfj2d . owpb4gqr4b ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . dlhbeuzmaz ) ,
rtdwData , 0 , 64 , sizeof ( d1slopnfj2d . dlhbeuzmaz ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . emiegndpgn ) ,
rtdwData , 0 , 65 , sizeof ( d1slopnfj2d . emiegndpgn ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . beljpehthd ) ,
rtdwData , 0 , 66 , sizeof ( d1slopnfj2d . beljpehthd ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . jyeac3e5ko ) ,
rtdwData , 0 , 67 , sizeof ( d1slopnfj2d . jyeac3e5ko ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . f3vldgt55s ) ,
rtdwData , 0 , 68 , sizeof ( d1slopnfj2d . f3vldgt55s ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . hr3u05iedn ) ,
rtdwData , 0 , 69 , sizeof ( d1slopnfj2d . hr3u05iedn ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . fuwgakmpod ) ,
rtdwData , 0 , 70 , sizeof ( d1slopnfj2d . fuwgakmpod ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . cpjueliazg ) ,
rtdwData , 0 , 71 , sizeof ( d1slopnfj2d . cpjueliazg ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . j1flcekhiz ) ,
rtdwData , 0 , 72 , sizeof ( d1slopnfj2d . j1flcekhiz ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . gjsyon5lu1 ) ,
rtdwData , 0 , 73 , sizeof ( d1slopnfj2d . gjsyon5lu1 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . gtdlxdr5hj ) ,
rtdwData , 0 , 74 , sizeof ( d1slopnfj2d . gtdlxdr5hj ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . ok503kfbwz ) ,
rtdwData , 0 , 75 , sizeof ( d1slopnfj2d . ok503kfbwz ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . nvuezdxtzi ) ,
rtdwData , 0 , 76 , sizeof ( d1slopnfj2d . nvuezdxtzi ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . kpe2zccxxi ) ,
rtdwData , 0 , 77 , sizeof ( d1slopnfj2d . kpe2zccxxi ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . imm0zy02qz ) ,
rtdwData , 0 , 78 , sizeof ( d1slopnfj2d . imm0zy02qz ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . ogphl1wuml ) ,
rtdwData , 0 , 79 , sizeof ( d1slopnfj2d . ogphl1wuml ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . mzswpaogfa ) ,
rtdwData , 0 , 80 , sizeof ( d1slopnfj2d . mzswpaogfa ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . lbikguphlp ) ,
rtdwData , 0 , 81 , sizeof ( d1slopnfj2d . lbikguphlp ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . he40254wch ) ,
rtdwData , 0 , 82 , sizeof ( d1slopnfj2d . he40254wch ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . f01rjososq ) ,
rtdwData , 0 , 83 , sizeof ( d1slopnfj2d . f01rjososq ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . jshht1u2q5 ) ,
rtdwData , 0 , 84 , sizeof ( d1slopnfj2d . jshht1u2q5 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . m3ypcbfysw ) ,
rtdwData , 0 , 85 , sizeof ( d1slopnfj2d . m3ypcbfysw ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . iltjdvd4vg ) ,
rtdwData , 0 , 86 , sizeof ( d1slopnfj2d . iltjdvd4vg ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . d3raebrh43 ) ,
rtdwData , 0 , 87 , sizeof ( d1slopnfj2d . d3raebrh43 ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . i43yu5fsyu ) ,
rtdwData , 0 , 88 , sizeof ( d1slopnfj2d . i43yu5fsyu ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . phmwjirefk ) ,
rtdwData , 0 , 89 , sizeof ( d1slopnfj2d . phmwjirefk ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . axj00twaij ) ,
rtdwData , 0 , 90 , sizeof ( d1slopnfj2d . axj00twaij ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . h4yyh4nnql ) ,
rtdwData , 0 , 91 , sizeof ( d1slopnfj2d . h4yyh4nnql ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . jbclgbkabv ) ,
rtdwData , 0 , 92 , sizeof ( d1slopnfj2d . jbclgbkabv ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . baxue1nnnm ) ,
rtdwData , 0 , 93 , sizeof ( d1slopnfj2d . baxue1nnnm ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . nwi1b1luuj ) ,
rtdwData , 0 , 94 , sizeof ( d1slopnfj2d . nwi1b1luuj ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . pojn0vmcuv ) ,
rtdwData , 0 , 95 , sizeof ( d1slopnfj2d . pojn0vmcuv ) ) ;
mr_closedLoop_tuned_restoreDataFromMxArray ( & ( d1slopnfj2d . auux5mhg5v ) ,
rtdwData , 0 , 96 , sizeof ( d1slopnfj2d . auux5mhg5v ) ) ; } } void
mr_closedLoop_tuned_RegisterSimStateChecksum ( SimStruct * S ) { const
uint32_T chksum [ 4 ] = { 2726610326U , 1649561126U , 2811560266U ,
3762188860U , } ; slmrModelRefRegisterSimStateChecksum ( S ,
"closedLoop_tuned" , & chksum [ 0 ] ) ; } mxArray *
mr_closedLoop_tuned_GetSimStateDisallowedBlocks ( ) { mxArray * data =
mxCreateCellMatrix ( 8 , 3 ) ; mwIndex subs [ 2 ] , offset ; { static const
char * blockType [ 8 ] = { "SimscapeExecutionBlock" ,
"SimscapeExecutionBlock" , "SimscapeExecutionBlock" ,
"SimscapeExecutionBlock" , "SimscapeExecutionBlock" ,
"SimscapeExecutionBlock" , "SimscapeExecutionBlock" ,
"SimscapeExecutionBlock" , } ; static const char * blockPath [ 8 ] = {
"closedLoop_tuned/Plant/Robot/Solver Configuration/EVAL_KEY/STATE_1" ,
"closedLoop_tuned/Plant/Robot/Solver Configuration/EVAL_KEY/OUTPUT_1_0" ,
"closedLoop_tuned/Plant/Robot/Solver Configuration/EVAL_KEY/STATE_2" ,
"closedLoop_tuned/Plant/Robot/Solver Configuration/EVAL_KEY/OUTPUT_2_0" ,
"closedLoop_tuned/Plant/Robot/Solver Configuration/EVAL_KEY/OUTPUT_1_0" ,
"closedLoop_tuned/Plant/Robot/Solver Configuration/EVAL_KEY/OUTPUT_2_0" ,
"closedLoop_tuned/Plant/Robot/Solver Configuration/EVAL_KEY/STATE_1" ,
"closedLoop_tuned/Plant/Robot/Solver Configuration/EVAL_KEY/STATE_2" , } ;
static const int reason [ 8 ] = { 0 , 0 , 0 , 0 , 2 , 2 , 2 , 2 , } ; for (
subs [ 0 ] = 0 ; subs [ 0 ] < 8 ; ++ ( subs [ 0 ] ) ) { subs [ 1 ] = 0 ;
offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data ,
offset , mxCreateString ( blockType [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 1 ;
offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data ,
offset , mxCreateString ( blockPath [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 2 ;
offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data ,
offset , mxCreateDoubleScalar ( ( double ) reason [ subs [ 0 ] ] ) ) ; } }
return data ; } static void * closedLoop_tuned_InitRestoreDataPtr = NULL ;
void mr_closedLoop_tuned_CreateInitRestoreData ( ) {
closedLoop_tuned_InitRestoreDataPtr = utMalloc ( sizeof ( d1slopnfj2d ) ) ;
memcpy ( closedLoop_tuned_InitRestoreDataPtr , ( void * ) & ( d1slopnfj2d ) ,
sizeof ( d1slopnfj2d ) ) ; } void mr_closedLoop_tuned_CopyFromInitRestoreData
( ) { memcpy ( ( void * ) & ( d1slopnfj2d ) ,
closedLoop_tuned_InitRestoreDataPtr , sizeof ( d1slopnfj2d ) ) ; } void
mr_closedLoop_tuned_DestroyInitRestoreData ( ) { utFree (
closedLoop_tuned_InitRestoreDataPtr ) ; }
