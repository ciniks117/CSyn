#include "__cf_closedLoop_tuned.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifndef CLOSEDLOOP_TUNED_57A28C5_2_DS_TDXF_P_H
#define CLOSEDLOOP_TUNED_57A28C5_2_DS_TDXF_P_H 1
extern int32_T closedLoop_tuned_57a28c5_2_ds_tdxf_p ( const NeDynamicSystem *
sys , const NeDynamicSystemInput * in , NeDsMethodOutput * ou ) ;
#endif
#ifdef __cplusplus
}
#endif
