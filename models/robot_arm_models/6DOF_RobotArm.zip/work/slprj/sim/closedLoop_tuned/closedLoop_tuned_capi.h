#include "__cf_closedLoop_tuned.h"
#ifndef RTW_HEADER_closedLoop_tuned_capi_h_
#define RTW_HEADER_closedLoop_tuned_capi_h_
#include "closedLoop_tuned.h"
extern void closedLoop_tuned_InitializeDataMapInfo ( nbzsdh3gog * const
hfoeutytij , pu40142whda * localX , void * sysRanPtr , int contextTid ) ;
#endif
