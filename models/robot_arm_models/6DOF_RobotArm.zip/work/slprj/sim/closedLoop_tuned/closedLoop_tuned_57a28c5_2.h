#include "__cf_closedLoop_tuned.h"
#ifndef __closedLoop_tuned_57a28c5_2_h__
#define __closedLoop_tuned_57a28c5_2_h__
#ifdef __cplusplus
extern "C" {
#endif
extern void closedLoop_tuned_57a28c5_2_dae ( NeDae * * dae , const
NeModelParameters * modelParams , const NeSolverParameters * solverParams ) ;
#ifdef __cplusplus
}
#endif
#endif
