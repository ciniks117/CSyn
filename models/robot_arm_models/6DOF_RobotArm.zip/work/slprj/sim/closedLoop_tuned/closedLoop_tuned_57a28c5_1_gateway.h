#include "__cf_closedLoop_tuned.h"
#ifndef __closedLoop_tuned_57a28c5_1_gateway_h__
#define __closedLoop_tuned_57a28c5_1_gateway_h__
#ifdef __cplusplus
extern "C" {
#endif
extern void closedLoop_tuned_57a28c5_1_gateway ( void ) ;
#ifdef __cplusplus
}
#endif
#endif
