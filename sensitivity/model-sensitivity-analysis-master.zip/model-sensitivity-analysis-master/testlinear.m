function y = testlinear(x,params,a)

m=params(1);
b=params(2);

y=m*x+b+a;

end            