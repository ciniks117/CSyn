# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 22:39:19 2019

@author: NickovicD
"""
from enum import Enum

class StlIOType(Enum):
    IN = 0
    OUT = 1
    UNDEFINED = 2