/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   stl_comp_op.h
 * Author: nickovic
 *
 * Created on July 8, 2019, 10:39 PM
 */

#ifndef STL_COMP_OP_H
#define STL_COMP_OP_H

enum StlComparisonOperator {
    LESS,
    LEQ,
    EQUAL,
    NEQ,
    GREATER,
    GEQ
};



#endif /* STL_COMP_OP_H */

