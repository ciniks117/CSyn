/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   stl_io_type.h
 * Author: nickovic
 *
 * Created on July 8, 2019, 11:23 PM
 */

#ifndef STL_IO_TYPE_H
#define STL_IO_TYPE_H


enum StlIOType {
    IN,
    OUT,
    UNKNOWN
};


#endif /* STL_IO_TYPE_H */

