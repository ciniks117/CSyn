from enum import Enum

class BooleanOperator(Enum):
    AND = 0
    OR = 1
    IMPLIES = 2
    IFF = 3
    XOR = 4